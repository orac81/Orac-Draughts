/* DYNAMO-DRAUGHTS - INTERNATIONAL 10x10 DRAUGHTS game
      Copyright A.Millett, 1990-2024.
      Released as Open Source Freeware under GPL-3 license.

 History:- Take BLITZ22 (23.3.92 (EXE=36774) On Coverdisk WhatPC magazine May 92))
 Imp experimental EURO flag, Change mvgenerators. -> BLITZ23, 28.3.92
 Imp REPLAY/SAVE/LOAD game -> BLITZ24, 29.3.92
 Split out separate EURO version. Imp KING-MOVE generators,
 conv DOAMOVE, Imp MVCAPT & assort.
-> EURO10, 29-30.3.92
 Imp RECURGEN and FILTERGEN - gen FULLY LEGAL jumps, ie. max jump.
 Debug above.  -> EURO11, 31.3-1.4.92
 Dont Crown till end-  change MULTIJUMP, DOAMOVE, Debug RECURGEN.
->dest EURO12, 2-3.4.92
 WHITE Moves FIRST! Imp proper BOOK. Write TITLE/HELPSCREENS
 Debug HUMANMOVE, imp HUMANSIDE. Test game v DGM-lost. -> EURO14, 3.4.92
 Optomise MVGEN, Improve weights & parameters. Wins game v DGM.
-> EURO15, 3-4.4.92
 More BOOKmvs, new adscreens for DYNAMO - new name! Imp BOARDFLIP.
-> DYNA16, 4.4.92
 Tidy Helpscreens. -> DYNA17, 4-5.4.92
 Reduce Shortblag, Imp MANLINKS, Imp Fastgen. -> DYNA18, 5.4.92
 Imp GENCOUNT. -> DYNA19, 5-6.4.92
 No OREO if boardy>9. More wts earlier. -> DYNA20, 6-7.4.92
 Tidy HELPSCREEN, Imp MUST-JUMP txt. -> DYNA21, 7.4.92
 BUG - Called GENERATEMOVES twice in compmove! -> DYNA22, 8.4.92
 Reduce IQ increment. Trim weights. -> DYNA23, 9-10.4.92
 Imp PROTECTON from SAGE/BLITZ.
-> DYNA24, 11.4.92 (& try install on GP1, but..)
 Imp 3-line manlinks. Reduce Bridgeval. Inc KINGVAL. (DVGM14.E)
-> DYNA25, 14.4.92
 BAD MOVE BUG!! imp LEAPSQ[] list, & MARK/UNMARK LEAPSQ (), NLEAP, etc.
 CHECKPROTECT bug - doesn't work!
-> DYNA26, 18.4.92
 Bug - Proper color in mid-Multijump when Undo.
 Move islegal,doamove,replay,openbook to DYMVxx.C.
 Imp Abort (y,n) query before abort.
 Lost DVGM15 badly - more conservative wgts.
 Played DVGM16 better.
-> DYNA27, 18-19.4.92
 Imp central Oreo, with a value. Bigger Dogval. Imp CLAMPS.
-> DYNA28, 19.4.92
 9th rank too high - can sacrafice a man!
 Only show think after 1 sec..
-> DYNA29,19-20.4.92
 Imp color ADSCREENS, SOUNDFLAG,TWOPLAYMODE, SMOUSE (0) & Mousemenus,
-> DYNA30, 16.6.92
 Imp JUMPTYPE flag - 0=jump most,1=Pool/Russian. Imp DIROF[],MAXDIR[]
 Imp FILTEROTHER for FILTERGEN.
-> DYNA31, 7.7.92
 Imp FLYINGKINGS flag. Debug FILTEROTHER.
-> DYNA32.C, 8.7.92
 Imp Spanish gam, BACKJUMPS flag. Save/Load GAMETYPE.
-> DYNA33.C, 9-10.7.92
 Imp BESTLINE, Smaller 10x10 vert sqr for xtra line 25.
-> DYNA34, 15-16.9.92
 Imp ZAPMOVE, CTRL-F/ESC instant abort. SPACE toggle BESTVIEW.
 Big BACK & Inv numbers for SPANISH.
-> DYNA35, 16.9.92
 BUG! Kings ALWAYS FLYING, even in 10x10! Adjust DOAMOVE & RECURGEN
-> DYNA36, 17.9.92-22.9.92
 POOL BUG! Sometimes disallows legal jumps. B:1,11,13,24.W:30,26,27,20,15.
 B.Move, 1118 disallowed.Put Blk10,not11, then OK! (Letter.R.Price.)
 MAXDIR[] inadequate! Extend to MAXDIR[Mbrd] whole brd, for each sqr.
 Adjust HUMANMOVE-dont DOAMOVE twice.
-> DYNA37, 3-4.11.92
 Imp Portgame flag for PORTUGESE (JUANA) game, as gametype 5.
-> DYNA38, 21.11.92
 Imp SPOOLGAME, +/-/HOME/END in REPLAYGAME. Imp TPRINTFLAG/Out to Prn.
 Imp DGENxx.C, move Gen I/O to this.
-> DYNA39, 22.11.92
 Experiment with palette for wht/blk. Imp Portugese language text.
-> DYNA40, 18.12.92
 Imp JUAN.EGA/CGA/SPR,JUANDAT.C (mod SAF20 overlays).
-> DYNA41, 30.12.92
 Imp Pieces on Wht sqrs, with border (JUAN.EGA & CGA).
 Imp Output game to File. Imp Move-Numbering.
-> DYNA42, 1-2.1.93
 Bug in replay CCOLOR val - correctit.
-> DYNA43, 3.1.93 (Beta release to Govert Westerveld - JUAN43,SH)
 Fewer adscreens, TC frontscr. Tidy grafx, Imp BOX.CGA.
-> DYNA44, 28-29.1.93
 Imp DELUXE flag. Imp cmdline auto-replay func. Imp loadable DYNABOOK.TXT.
-> DYNA45, 30-31.1.93
 Debug LOADBOOK - imp Book-Comments.
-> DYNA46, 2.2.93
 Imp new portugesee txt from Govert.Inc Bridgeval.
 Imp portflag & long diag bonus.
-> DYNA47, 3.2.93
 Imp Serial Number (-PARS.DAT)
-> DYNA48, 4-5.2.93
 Imp better JUAN.EGA graphics. Imp SOFIA flag & new text.
-> DYNA49, 27.2.93
 Imp new gametypes 6,7 for Minidama/Brazilian.
-> DYNA50, 28.2-1.3.93
 Imp Pseudo Dbase. Move NMOVES==0 test. Imp PVFLAG - deep prime/var.
-> DYNA51, 2-3.3.93
 Imp Pseudo 2k v 1k Dbase. Adjust val kings and INITWEIGHTS.
-> DYNA52, 4.3.93 (out to G.Westerveld - 10xJUANA, 1xSOFIA)
 Re-spell SOPHIA as SOFIA. Add some text provided by Govert.
-> DYNA53, 12.4.93
 Imp HARDSCROLL. Imp SPACE for VGA. Imp new CHECKPROTECT.
-> DYNA54, 1.5.93
 BUG:Bad COMP MOVE in multijump when ZAPMOVE used in 1st (CTRL-F/Timeout)
 put ZAPMOVE=0 within Multijump loop.
 Adj initweights. Adj kweights+=50, compensate kvals -= 50.
 Imp CROWNMOVES/KINGMOVES, extend search if any CROWNMOVES.
-> DYNA55, 2.5.93
 Move ADSCR,FRONTSCR,INITSPR to DGENxx.C. Adj initwgts - more cent bias.
 Imp Centmask- only use MANLINKS in board center. Less Edge bias.
 Play game v Dam - still loses - uneven defence line.
-> DYNA56, 3.5.93
 Imp VGAPAL - fine tune 18bit palette. Imp NULLMOVE search near krank mv.
 Imp WTARG/BTARG for even defence.
-> DYNA57, 5-6.5.93
 Adj MANLINKS, INITWEIGHTS. Reduce XEVAL if W&B have K. Imp LASTBEST
 Futher param tune-up. Kill BRIDGE/OREO?DOGHOLE vals.
-> DYNA58, 7-8.5.93
 Imp bigger clamp vals, reduce side penalty. Reduce early timepermove.
 Replace msg in REPLAYG.
-> DYNA59, 9-13.5.93
 Bug in ESC/OUTPUTGAME. Imp OUTPUTPOS. Imp POOLBOOK.
-> DYNA60, 9.9.93
 Imp new graphics, CHBIG01.SAF.
-> DYNA61, 13.10.93
 Imp PRINTAFLAG, better PRINTBOARD graphics for printer.
 Allow {COMMENT on start book-line. Enhance book.
 CTRL-K - Invert notation bot/top.
-> DYNA62, 02.12.93
 Enhance book. Imp CTRL-O. Decrease Dogvals. Imp ENPRISEFLAG deepscan.
 Adjust IQADD vals. Increase ZAPTICKS margin. Debug OUTPUTGAME/BETWEENFLAG.
-> DYNA63, 26.12.93-7.1.94
 Imp sep DYBK64.C - book module.
 Imp CTRL-X - don't scan jumps deep (Gil.D)
 Imp Piece-list functions from SAGE.
-> DYNA64, 26.1.94..25.2.94
 Imp new HASHTAB. Imp AUTOGAMES statistical analyser.
-> DYNA65, 26.2.94..2.2.94
 Imp WINDOWSIZE of 45.
 Imp 12x12 Canadian draughts.
-> DYNA67, 3.2.94..
 Convert to Microsoft-VC..
 VC cannot take str >2K, so redo graphics.. imp seperate .SPR files
-> DYNA70A, 11.4.95..
 Imp MYSEG for more data storage,,,
 Imp showanal - display analysis as line at bottom..
 Imp ToolButtons - general ProcessToolKey () sub..
 Imp TGA03 to translate TGA files to 4-plane SPR files for dynamo
 Design new BMPs for prog - Tape ctls, Disk icons, etc.
 Imp button-movements
 Imp stepmove - to step thro game
 Speed up prn board - remove slow PALON from brd routine.
 Make buttons active..
-> DYNA70B, 15.4.95
 Imp PRINTFAT - fast printf-at substitute. Can handle inv-video
 Imp Text-buttons in Tool-routine - like real win buttons!
 Imp MSGPRINTF - pop-up dialog..
-> DYNA70C, 17.4.95
 Imp EDIT field in Toolbox routine.
 Imp pop-up edit boxes for load/save..
-> DYNA70D, 18.4.95
 Del replaygame.
 Re-write statline, repos all output.
 Imp GameTypeStr function.
 Redo SHOWANAL - use printfat in grey box.
 Start on spins.
-> DYNA70E, 19.4.94
 Finish spins, make them work in new SET PARAMS box.
 Imp WINBAR - windows-style title bar, with header text.
-> DYNA70F, 19.4.94
 Imp new TITLESCREEN with spins, buttons, etc..
 Imp MoveBox - display last few moves..
-> DYNA70G, 20.4.94
-> DYNA80A, 22.4.95
 Bug in spin-buttons on palette control
 Imp ActionHit - delay before first repeat.
-> DYNA80B, 22.4.95
 Quick tidyup for release..
 Imp Multi-language support..
 Imp HelpScreen viewer
 Debug mem alloc
-> DYNA80C, 7.10.95
 Write new manual/help text.
-> DYNA80D, 10.10.95
 Final touches - Imp PDN VIEW/LOAD option.
 Imp all 8 game types in 1 program.
 Imp better protection, writes back -PARAM file.
-> DYNA80E, 12.10.95..
 Bug in protect - imp separate file -PARAD.DAT
 Bug in move-box- shows move#*2 - correct it..
 Bug in 'Z' command - corrct it.
-> DYNA80E, 13.10.95, release final EXE..

 Quick hack to make a DYNAMO ENGINE console app running under win32/MSVC.. 
 (Stripping all DOS graphics and i/o code out)
-> DYNA910, 27.12.2006
 Pick through code again, tidy up a bit more.. 
 Fix hash table to work. Imp simple txt-in for moves. Imp autoplay. Imp set time-per-mv. Imp better txt brd.
-> DYNA911, 30.1.2008
 Imp bestline/analy output fn..
 Small mods & improvements
-> DYNA912, 31.1.2008
  Bkup once more..
-> DYNA914, 31.1.2008 
  Test compile using CLMAK, partly working, but needs more work, Tidy up misc files.
  Tweak board display, imp n# cmd to select (gametype) var.
  Build crude ver dynamo.elf (cc: linux) & dynamo.exe (clmak: win32)
-> DYNA915, 2.7.2024
  Imp USE_HASH, set to select (old) hash table code.
  Imp USE_RAND, to allow no randomisation (for testing etc)
  Imp i# command, set level with IQ if timepermove=0..
-> DYNA916, 6.7.2024
  Imp drawboard_big () draw larger board. Experiment with ascii piece sets.
  Try various things to compile with cc65 but its too big.
-> DYNA917, 7.7.2024
  Imp R cmd to change varyflag.
-> DYNA918, 11.7.2024
  More tidying. Imp clearer var names MAX_PLY etc.
  Imp SMALL_CODE to help (try) make 6502 version. Set smaller sizes for MAX_PLY when SMALL_CODE set.
  Remove some dead code.
  Fix move entry by number.
  Imp twoplaymode.
-> DYNA920, 23.7.2024
 
======================================================================================================
COMPILING WIN32: From Wine console, type:  PATH %PATH%;D:\M\DOS\;    then to compile a program:    clmak /Os program.c

rem --------------------------------------------------------------------------
rem CLMAK.BAT (From wine run: PATH %PATH%;D:\M\DOS\; )
echo off
echo Running Visual C.. (in D:\MSDEV)
rem cl /Id:\msdev\include /link d:\msdev\lib\libc.lib /MD /O2 %1 %2 %3 %4 %5 %6 %7 %8 %9 
d:\msdev\bin\cl %1 %2 %3 %4 %5 %6 %7 %8 %9 /MD /O2 /Id:\msdev\include /link d:\msdev\lib\msvcrt.lib d:\msdev\lib\oldnames.lib d:\msdev\lib\kernel32.lib d:\msdev\lib\user32.lib d:\msdev\lib\gdi32.lib d:\msdev\lib\comdlg32.lib 
======================================================================================================
*/

#include <stdio.h>
#include <stdlib.h>	/* RAND,MIN,MAX */
#include <ctype.h>	/* ISDIGIT */
//#include <malloc.h>	/* _fmalloc.. */
#include <string.h>
#include <stdarg.h>	// va_list..
#include <time.h>

#include "dynamo.h"	// Forward declarations,,

#define PROG_VER "9.20"
#define SMALL_CODE  0		/* Try to use smaller code options where possible */
#define Debug       0
#define Othergames  1
#define PROG_TYPE 0		// 0=TTY, 1=Win/console, 2=ANSI
#define USE_HASH  0		/* Use (old) hash table code (Needs 400K) */
#define USE_RAND  1     	/* Enable/disable randomisation code (see varyflag) */

char szProgName [] = "\n  DYNAMO DRAUGHTS " PROG_VER ", (C) A.MILLETT 1990-2024, FREEWARE/GPL3.\n\n";

int xprintf (const char *,...);
void cons_cls ();

//#define regv _DX	/* Fast INT register var (REGISTER INT) */
unsigned int regv;	/* Above don't work with all C's so use this. */

#define TRUE 1
#define FALSE 0

#ifndef max
 #define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif  /* max */

#ifndef min
 #define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif  /* min */

#ifndef BYTE
 typedef unsigned char BYTE;     /* A convenient new data type */
#endif

int boardx = 10;		/* Board size */
int boardy = 10;
int maxboard = 143;		// Maximum board pos
int menperside = 20;
int curx,cury;		// Current cursor pos
int bmult = 21;		/* Multiplier */

int kcmd;		/* Command key hit */
int inkey,cmdkey;
int pxpos,pypos; 	/* Player posn */
int cxpos,cypos;	/* Computer posn */
int cpos;
int xpos,ypos;		/* General pos */
int xdir,ydir;
int yoff;
int ccolor;		/* White = 4, Black = 2 */
int cpiece;
int temp,temp2;

int bxpos,bypos;	/* Best xy pos */
int beval;		/* Best score */
int xeval;		/* Comp term eval score */

int twoplaymode = 0;
int cornmode = 0;	/* Grid of unused squares */
long tloc;		/* Temp used in time access */
long xtime;

int cdir;
			/* Search-vars */
int cply;
int xbrd;
int gamestage;		/* % board filled */

int xweight;
int cmove,zmove;
int multijump;
int ccut;
int knockdown;
int aborted;
int qcrowned;
int xpiece;
int knockflag = 1;
int xtaken;
int xcapt;			/* Capture sq*/
int xdest;
int killermove,killerdir;

int iqcutoff = 20;		/* Search depth control */

#if SMALL_CODE
 #define MAX_PLY 30		/* Absolute max ply depth */
 #define MAX_BOARD 300		/* Biggest board size */
 #define MAX_LIST 200		/* Size of move lists */
 typedef unsigned char DINT;	/* Save mem by using BYTE for some arrays */
#else
 #define MAX_PLY 60		/* Absolute max ply depth */
 #define MAX_BOARD 300		/* Biggest board size */
 #define MAX_LIST 700		/* Size of move lists */
 typedef int DINT;
#endif

int jumpflag,oppjumpflag;
unsigned int nmoves;
int kingmoves,crownmoves,oppcrownmoves;
int dirul,dirur,dirdl,dirdr;		/* Dirs Up-left.. */
int dir2ul,dir2ur,dir2dl,dir2dr;
int gencount;

int alphaflag = 2;	/* Indicates alpha-beta pruning on/off */
int killerflag = 2;	/* Indicates killer mode */
int prefflag = 1;	/* Deep scan prefered moves on 1st ply */
int windowlo,windowhi;  /* Norm limits to alpha-beta window */
int windowsize = 55;
int awindlo,awindhi;
int retry;
int shortflag = 30;	/* Flag sets short look ahead and sort depth */
int halfshort;
int doingshort = 0;	/* Global flag tells deeper plys short in process */
int materialdif;	/* Difference in material + for wh */
int nowhite,noblack;
int tempiq;		/* Store for iq when doing short look */
int shortply;		/* No cuts on this ply */
int lowshortply;
int templo,temphi;	/* Temp window store */

int thinkflag = 1;	/* Indicates computer display of thinking */
int varyflag = 3;	/* Randomise opening play (0=off, 1-99) */
int resignflag = 0;	/* Set when computer resigns */
int loseflag = 0;	/* Play to lose option! */
int trimflag = 1;	/* Trim window bounds as we look */
int drawflag = 1;
int iterate = 1;	/* Iterative deepening flag */
int itereval;
int xflag = 0;		/* Double mvgen */
int maxiq = 0;
int docrown = 1;	/* Crown kings */
int diskerror = 0;
int usedb = 1;		/* Use Pseudo Databases */
int blkpos,whtpos;
int whtx,whty,blkx,blky;
int manlink = 1;	/* Man-bond strength */
int euroflag = 1;	/* Indicates international 10x10 game */
int portflag = 0;	/* Spainish/Port game ? */
int poolflag = 0;	/* Pool 8x8 type board ? */
int jumptype = 0;	/* 0=Jump most, 1=POOL/Russian.. */
int flyingkings = 0;	/* for RUSSIAN game.. */
int backjumps = 1;	/* Allow backward-jumps (non in spanish) */
int gametype = 0;	/* 0 =International 10x10,1=Spain,2=Pool,3=Russian */

const int maxGameType = 8;

int bestflag = 15;	/* Disp Best-line flag/depth */
int lastbest;
int numflag = 0;	/* Invert numbering */
int wtarg,btarg;	/* Target back-defence */
int enpriseflag = 0;		/* Entend forced move sequences */

int zapiq;
int zapmove;
long zapticks;		/* Kill off search after this time */
int zapcount;
int bmove,bdir;

int movefrom,moveto,movedir;	/* Curr mv */

unsigned long termnodes = 0;	/* Count of terminal nodes */
unsigned long avnodes = 0;	/* Alt time control */
unsigned int  nkillers = 0;	/* Count of killer moves */
unsigned int  nalphas = 0;	/* Count of alpha cuts */
int deepest;			/* Deepest ply hit */
int manvalue = 120;		/* Valuation for a man */
int kingvalue = 320;		/* Val for 1st king */
/* int bookrand = 50; */
int fwdflag = 1;		/* std/prob mode */
int inflag = 0;			/* Infinite mode */
int *hashtab;		/* Hash table address */
int *hashptr;
long hashsize = 65700;
long lhash;
unsigned int hashval;
int hashflag = 5;		/* Depth to stop hash table usage */

#if USE_HASH
  unsigned int hashboard [MAX_BOARD];	/* Random vals for hashing */
#endif

#define RNDOFF_MASK 63
int rndoffset [RNDOFF_MASK+4];		/* Table random values to randomise eval a little (varyflag enables) */
char *charptr = NULL;

int doneeval;		/* Struct eval vars.. */
int zoneboard [MAX_BOARD];
int zonetotal [4], zonepercent [4], zonesqrs [4];
int div3,zmin,zmax;

int percent;
long extime;		/* Timer for complete move (All multijumps) */
long fulltime;		/* Time with fractions for part-move */
long timepermove = 2;
long targetticks = 0;	/* Target for current move (1/18 sec) */
long targettime = 10;

int tnomoves  [MAX_PLY];	/* No of moves at given ply */
int tcmove    [MAX_PLY];	/* Move under examination at g. ply */
int tccut     [MAX_PLY];	/* Accumulated cut off val at g. ply */
int tcolor    [MAX_PLY];	/* Color who moves at g. ply */
int toldpiece [MAX_PLY];   /* Value of moved piece at g. ply */
int ttaken    [MAX_PLY];	/* Value of taken piece at g. ply */
int tjumpflag [MAX_PLY];	/* Stash for jump flag */
int tweight   [MAX_PLY];	/* Storage for running weight val at g. ply */
int tbestmove [MAX_PLY];	/* Best move so far at g. ply */
int tbestdir  [MAX_PLY];	/* Best dir so far at g. ply */
int tbesteval [MAX_PLY];	/* Best eval so far at g. ply */
int twindlo   [MAX_PLY];	/* Window low value */
int twindhi   [MAX_PLY];	/* Window high value */
int tmbrd     [MAX_PLY];	/* Actual piece moved on board at g.ply */
int tmdir     [MAX_PLY];	/* Actual dir moved on board at g.ply */
int tmostjumps [MAX_PLY];	/* Score for most-jump search */
int tcurjumps [MAX_PLY];
unsigned int thashval [MAX_PLY];	/* Hash code for posn */
int curjumps;

int tnblkmen  [MAX_PLY];	/* No of Black men on board at g. ply. */
int tnwhtmen  [MAX_PLY];	/* No of White men on board at g. ply. */
int tnblkking [MAX_PLY];   /* No of Black kings on board at g. ply. */
int tnwhtking [MAX_PLY];   /* No of White kings on board at g. ply. */

int piececount [10] ; 	/* Running count for pieces - [2] for Bman, etc */
int kingvals [50] ;	/* Value of 1 king, 2 kings, etc.. */
int manvals [50] ;	/* Value of 1 man, 2 men, etc.. */
int blmanweights [MAX_BOARD];	/* Weight squares for Black MAN moves */
int whmanweights [MAX_BOARD];
int kingweights [MAX_BOARD];		/* Weight of each square for KING moves (same both sides) */

int *mvbrd, *mvdir, *mveval, *mvcapt, *mvtot, *mvindex;

int xmvbrd [MAX_LIST] ;	/* Move list - co-ord of each movable piece */
int xmvdir [MAX_LIST] ;	/* Move list - dir for each move */
int xmveval [MAX_LIST] ;	/* Spot eval for each move, for short look */
int xmvcapt [MAX_LIST] ;	/* Capt location for K's */
int xmvtot [MAX_LIST] ;	/* Maximum jump-count for mv */
int xmvindex [MAX_LIST] ;	/* Pointer to WH/BL pos.. */
			/* int xmvlink [MAX_LIST] ; */

#if SMALL_CODE
 #define Mgame 400
#else
 #define Mgame 1000
#endif

int mgame [Mgame + 4] = {0,0};	/* Game move */
int vgame [Mgame + 4] = {0,0};
int ngame;
int fullgame,tfull;	/* Assort Replay vars.. */
int tgame,xgame;
int endbrd;
int leapsq [Mgame];	/* Used to mark out used sqrs in mv generation */
int nleap,cleap,xleap;

int board [MAX_BOARD];	/* Playing area */
//int qckbrd [MAX_BOARD];	// Fast-loading new-board 
//int qckcol;		// Init-new board color..
//int initbrd [MAX_BOARD];
DINT crownsqrs [MAX_BOARD];	/* Flag any crowning sqrs */
DINT sqnums [MAX_BOARD];	/* Square numbers */
DINT sqpos  [MAX_BOARD];	/* Xref list of SQNUMS */
int nsqrs,csqr,cnum;
int dirof [512];	/* Direction 1,2,3,4 for any brd dir */
int maxdir [MAX_BOARD];	/* XREF array used in FILTEROTHER */
int pow2 [] = {1,2,4,8,16,32,64,128,256};
int bestline [257] = {0,0,0,0};	// Best-line storage.. 

long freeram;

int botline;
int notateflag = 0;	/* Use chess notation ? */
int drawsize = 3;
char szWork [256];	/* Work area, PV etc*/

#define Bestline(Ply,Deep) bestline [((Ply) << 4) + Deep]


int Oreoval = 6;	/* Oreo triangle 2,3,7 */
int Backval = 6;	/* Triangle 1,2,6 */
int Bridgeval = 6;	/* Bridge 1,3 */
int Dogval1 = 30;	/* Dog-Hole cramps (1,5) */
int Dogval2 = 18;	/* 2nd Dog-Hole cramps (3,12) */

#define Greysq -8
#define Edge -8

#define Bman 2		/* Val of black man  on board */
#define Bking 3		/* Val of black king on board */
#define Wman 4		/* Val of white man  on board */
#define Wking 5		/* Val of white king on board */

#define White 4		/* Board vals */
#define Black 2
#define Whtorblk 6
#define ToggleWB 6

#define C1black 8	/* 1 away from crown */
#define C1white 16
#define C2black 32
#define C2white 64
#define Centmask 128

#define Nblkmen piececount[2]	/* Alt for No of black men. */
#define Nblkking piececount[3]	/* Alt for No of black kings. */
#define Nwhtmen piececount[4]   /* Alt for No of white men. */
#define Nwhtking piececount[5]  /* Alt for No of white kings. */
#define Nmen piececount[2]+piececount[4]
#define Nkings piececount[3]+piececount[5]
#define Nblack piececount[2]+piececount[3]
#define Nwhite piececount[4]+piececount[5]

#define Setboard(Xpos,Ypos,Cpiece) \
	board [(Xpos) + (Ypos) * bmult] = Cpiece;

#define Getboard(Xpos,Ypos) \
	board [(Xpos) + (Ypos) * bmult]

#define Posof(Xpos,Ypos) ((Xpos) + (Ypos) * bmult)

#define InvertPos(Cpos) (maxboard - (Cpos))

			/* Macro to Swap 2 moves in move table */
#define Swapmoves(Move1,Move2) \
	regv = mvbrd [Move1];\
	mvbrd [Move1] = mvbrd [Move2];\
	mvbrd [Move2] = regv;\
	regv = mveval [Move1];\
	mveval [Move1] = mveval [Move2];\
	mveval [Move2] = regv;\
	regv = mvcapt [Move1];\
	mvcapt [Move1] = mvcapt [Move2];\
	mvcapt [Move2] = regv;\
	regv = mvindex [Move1];\
	mvindex [Move1] = mvindex [Move2];\
	mvindex [Move2] = regv;\
	regv = mvdir [Move1];\
	mvdir [Move1] = mvdir [Move2];\
	mvdir [Move2] = regv;

void initptrs ()		/* Initialise movelist pointers */
{
	mvbrd = xmvbrd;
	mvdir = xmvdir;
	mvcapt = xmvcapt;
	mveval = xmveval;
	mvtot = xmvtot;
	mvindex = xmvindex;
	cply = 1;
}

void listpos ()
{
    xprintf ("Listpos!");
}

void addleap (int jumpsq)	/* Stash capt sq, for correct mv gen */
{
	nleap ++;
	if (ccolor == Black) {
	  leapsq [nleap] = -jumpsq;
	} else {
	  leapsq [nleap] = jumpsq;
	}
}

void markleapsq (int sqfill)	/* MARK any prev multi-jump capt with FILL */
{
	int cleap = nleap;
	if (ccolor == Black) {
	  while (cleap > 0) {
	    if ((xleap = leapsq [cleap]) >= 0) return;
	    board [-xleap] = sqfill;
	    cleap --;
	  }
	} else {
	  while (cleap > 0) {
	    if ((xleap = leapsq [cleap]) <= 0) return;
	    board [xleap] = sqfill;
	    cleap --;
	  }
	}
}

//------------------------------------------------------------------------------
//  General i/o functions..   (DGENxx.C)
//------------------------------------------------------------------------------

  /* DGENxx.C  General I/O functions for DYNAMO, (C) A.Millett 1990-93 */


  // return time in 1/10 sec..
int readtime ()
{
    return time (NULL) * 10;
}

int bpos (int xpos, int ypos)
{
	return (xpos + ypos * bmult);
}
//

	// Calc move# from start for pos (npos) 0=1st,2=2nd..
int CalcMoveNum (int npos)
{
	int cpos;
	UINT last = 0;
	UINT cur;
	int mno = 0;
	for (cpos = 1; cpos <= npos; cpos ++) {
	  cur = (UINT) mgame [cpos]; 		// hibyte=from, lobyte=dest.
	  if ((last ^ cur) & 0xff00) mno ++;  	// Not djump, increment
	  last = cur << 8;
	}
	return (mno);
}

	// Get from (mgame), cutting out-jump sqrs..
int GetMove (int *cpos)
{
	int msrc,mdest;
	int cur;
	mdest = msrc = mgame [*cpos];
	if (msrc == 0) return 0;
	do {
	  (*cpos) ++;
	  cur = mgame [*cpos];
	  if ((cur ^ (msrc << 8)) & 0xff00) break;
	  mdest = cur;		// Save last destination
	} while (1);
	return ((msrc & 0xff00) | (mdest & 0x00ff));
}

	// Find (cgame) rec # for given move number..
int FindMove (int nmov)
{
	UINT last = 0;
	UINT cur;
	int cpos = 1;
	int mno = 0; 
	while (mno < nmov) {
	  cur = (UINT) mgame [cpos]; 	// hibyte=from, lobyte=dest.
	  if ((last ^ cur) & 0xff) mno ++;  // Not djump, increment
	  last = cur << 8;
	  cpos ++;
	}
	return (cpos);
}


// End of file..

//------------------------------------------------------------------------------
//  Search related functions..  (DYMVxx.c)
//------------------------------------------------------------------------------

  /* DYNAMO-DRAUGHTS, Copyrights A.Millett 1992 */
  /*  DYMVxx.C - Include file with SEARCH and assort */

#define Whtorblk 6
#define ToggleWB 6

int temp99;
int *keyrb,*keylb;	/* Key left/right bridge sqrs */
int *orr1b,*orr2b,*orr3b,*orl2b,*orl3b;	/* 2nd/3rd OREO sqrs */
int *dogrb,*doglb;
int *keyrw,*keylw;
int *orr2w,*orr3w,*orl1w,*orl2w,*orl3w;
int *dogrw,*doglw;
int *corn1w,*corn2w;
int *corn1b,*corn2b;

		/* Piece list code */
int blpos  [32];	/* Pos of each piece, in order 0=King..15=Man */
int whpos  [32];
int bltype [32];	/* Type of each piece */
int whtype [32];
int tcapindex [MAX_PLY];	/* Index of Capt.piece */
int nblack;
int nwhite;
int nwhpos;		/* # entries in xxPOS tables */
int nblpos;
int piecepos [8];	/* Start pos for given piece */

int xindex;		/* Current indexed piece */
int capindex;		/* Index Captured piece */
int xtakeloc;
unsigned tindex;

#define Updateblpos(Cbrd,Cpiece,Cval) \
	temp = findblindex (Cbrd,Cpiece);\
	blpos [temp] = Cval;

#define Updatewhpos(Cbrd,Cpiece,Cval) \
	temp99 = 0; temp = findwhindex (Cbrd,Cpiece);\
	whpos [temp] = Cval;

void buildpos ()	/* Build wh/blpos [] tables */
{
	int cbrd,xpiece;
	int csqr;
	nblack = 0;
	nwhite = 0;
	for (xpiece = Wking; xpiece >= Bman; xpiece --) {	/* Kings..Pawns */
	  if (xpiece & Black) {
	    piecepos [xpiece] = nblack;	/* Save start for piece */
	  } else {
	    piecepos [xpiece] = nwhite;
	  }
	  for (csqr = 1; csqr <= nsqrs; csqr ++) {
	    cbrd = sqpos [csqr];
	    if ( board [cbrd] == xpiece) {
	      if (xpiece & Black) {
		blpos [nblack] = cbrd;
		bltype [nblack] = xpiece;
		nblack ++;
	      } else {
		whpos [nwhite] = cbrd;
		whtype [nwhite] = xpiece;
		nwhite ++;
	      }
	    }
	  }
	}
	whpos [nwhite] = blpos [nblack] = 0;
	nblpos = nblack;
	nwhpos = nwhite;
}

int findwhindex (int cbrd, int cpiece)	/* Find index of white piece */
{
	register int cpos;
	if (whpos [(cpos = piecepos [cpiece])] == cbrd) {
	  return (cpos);
	}
	cpos ++;
	while (cpos < nwhpos) {
	  if (whpos [cpos] == cbrd) {
	    return (cpos);
	  }
	  cpos ++;
	}
	exit (0);
}

int findblindex (int cbrd, int cpiece)	/* Find index of black piece */
{
	register int cpos;
	if (blpos [(cpos = piecepos [cpiece])] == cbrd) {
	  return (cpos);
	}
	cpos ++;
	while (cpos < nblpos) {
	  if (blpos [cpos] == cbrd) {
	    return (cpos);
	  }
	  cpos ++;
	}
	exit (0);
}

		/* GAME-SEARCH FUNCTIONS */

void  countpieces()		/* Count no of pieces - b/w/men/kings */
{
	int xpos,ypos;
	Nblkmen = Nwhtmen = Nblkking = Nwhtking = 0;	/* Clr counts */
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    temp = Getboard (xpos, ypos);
	    if (temp > 0) piececount [temp] ++;
	  }
	}
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
}

void  setvalpieces ()		/* Init piece-vals */
{
	int ccount;
	kingvals [0] = -10; manvals [0] = -1000;
	kingvals [1] = kingvalue - manvalue;	/* Advantage for 1st king */
	manvals [1] = manvalue;
	for ( ccount = 2; ccount < 40; ccount++) {
	  manvals  [ccount] = ccount * manvalue;
	  kingvals [ccount] = ccount * (kingvalue - manvalue - 60) + 60;
	}
	if (nowhite > noblack) {  /* Depress last man val, encourage xch..*/
	  manvals [nowhite] -= 7;
	}
	if (noblack > nowhite) {
	  manvals [noblack] -= 7;
	}
}

int centx,centy,iswclr,isbclr,clrtemp;

int  isclear (int cpos, int dir1, int dir2, int opcolor)	  /* 3 sqrs ahead? */
{
	clrtemp = 2;
	if (board [cpos] == Greysq) return (0);
	if (board [cpos + dir1] & opcolor) return (0);
	if (board [cpos + dir2] & opcolor) return (0);
	opcolor = opcolor | Greysq;
	if (board [cpos + dir1 + dir2] & opcolor) return (0);
	if (board [cpos + dir2 + dir2] & opcolor) clrtemp --;
	if (board [cpos + dir1 + dir1] & opcolor) clrtemp --;
	return (clrtemp);
}

int  is2clear (int cpos, int dir1, int dir2, int opcolor)
{
	if (board [cpos] == Greysq) return (0);
	if (board [cpos + dir1] & opcolor) return (0);
	if (board [cpos + dir2] & opcolor) return (0);
	return (1);
}



void  initweights ()	/* Pre-select weight tables for men and kings. */
{
	int wmwt,bmwt,kwt;
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	materialdif = nowhite - noblack + ((Nwhtking - Nblkking) << 1);
	gamestage = (50 * (nowhite + noblack)) / menperside;
	btarg = (noblack - 4) / 3;
	wtarg = (nowhite - 4) / 3;
	for (ypos = 1; ypos <= boardy; ypos ++) {
	  centy = (ypos + ypos - boardy - 1) >> 1;
	  if (centy < 0) centy =- centy;
	  for (xpos = 1; xpos <= boardx; xpos ++) {
	    centx = (xpos + xpos - boardx - 1) >> 1;
	    if (centx < 0) centx =- centx;
	    cpos = xpos + ypos * bmult;
	    if (board [cpos] == Greysq) {
	      wmwt = bmwt = kwt = 0;
	      goto wt1;
	    }
	    wmwt = (1 + boardy - ypos) ;
	    bmwt = ypos ;
	    temp = centx;
	    if (centy > centx) temp = centy;
	    kwt = 30 - temp * 3;
	    if (temp == 0) kwt -= 4;
	    if (gamestage < 70) {		/* Flip Time */
	      temp = wmwt; wmwt = bmwt; bmwt = temp;
	    } else if (gamestage < 82) {	/* Evens */
	      wmwt = bmwt = 5;
	    } else {		/* >80, hold back.. */
	    }
	    if (gamestage > 70) {
	      temp = 2; if (gamestage > 80) temp = 3;
	      if (ypos + ypos > boardy) {
		wmwt -= temp;
	      } else {
		bmwt -= temp;
	      }
	    }
	    if (gamestage < 45) {		/* 3x Time */
	      wmwt = 3 * wmwt; bmwt = 3 * bmwt;
	    } else if (gamestage < 65) {	/* Double Time */
	      wmwt += wmwt; bmwt += bmwt;
	    }
	    iswclr = isclear (cpos, dirdl, dirdr,Black);
	    isbclr = isclear (cpos, dirul, dirur,White);
	    if (ypos == 1) {		/* Back hold */
	      isbclr = 0;
	      wmwt += 3;
	      bmwt += 75;
	    }
	    if (ypos == boardy) {
	      iswclr = 0;
	      bmwt += 3;
	      wmwt += 75;
	    }
	    if (xpos == 1 || xpos == boardx) {	/* Edge */
	      temp = 1; if (gamestage < 70) temp = 0;
	      wmwt += temp; bmwt += temp;
	    }
	    if (xpos == 2 || xpos == boardx - 1) {	/* 1-off Edge */
	      wmwt -= 2; bmwt -= 2;
	    }
	    if (centx + centy == 0) {
	      wmwt ++; bmwt ++;
	    }
	    if (ypos == 2) {	/* Clr run ? */
	      bmwt += 55;
	      if (is2clear (cpos, dirul, dirur,White) ) bmwt += 22;
	    }
	    if (ypos == boardy - 1) {
	      wmwt += 55;
	      if (is2clear (cpos, dirdl, dirdr,Black) ) wmwt += 22;
	    }
	    if (iswclr) wmwt += iswclr + iswclr;
	    if (isbclr) bmwt += isbclr + isbclr;
	    if (ypos == 3) {
	      if (gamestage < 70) bmwt += 7;
	      if (gamestage < 60) bmwt += 7;
	      if (gamestage < 45) bmwt += 5;
	      if (isbclr) {
		bmwt += 15;
		if (isbclr == 2) bmwt += 7;
	      }
	    }
	    if (ypos == 4) {
	      if (gamestage < 55) bmwt += 4;
	      temp = isclear (cpos + dirul, dirul, dirur,White)
		   + isclear (cpos + dirur, dirul, dirur,White);
	      if (cpos == 94) bmwt += 3;
	      if (temp) {
		bmwt += 3 + temp * 4;
	      }
	    }
	    if (ypos == boardy - 2) {
	      if (gamestage < 70) wmwt += 7;
	      if (gamestage < 60) wmwt += 7;
	      if (gamestage < 45) wmwt += 5;
	      if (iswclr) {
		wmwt += 15;
		if (iswclr == 2) wmwt += 7;
	      }
	    }
	    if (ypos == boardy - 3) {
	      if (gamestage < 55) wmwt += 4;
	      temp = isclear (cpos + dirdl, dirdl, dirdr,Black)
		   + isclear (cpos + dirdr, dirdl, dirdr,Black);
	      if (cpos == 49) wmwt += 3;
	      if (temp) {
		wmwt += 3 + temp * 4;
	      }
	    }
	    if (xpos + ypos == boardx + 1) kwt += 2;
	    if (crownsqrs [cpos] & Centmask) {
	      wmwt += 2; bmwt += 2;
	    }
	    if (gamestage < 70) {
	      wmwt -= 10; bmwt -= 10;
	    }
	    wmwt -= 10; bmwt -= 10;
wt1:
	    whmanweights [cpos] = wmwt;
	    blmanweights [cpos] = bmwt;
	    kingweights [cpos] = kwt;
	  }
	}
	temp = bpos (boardx,1); temp2 = bpos (boardx - 1, 2);
	if (board [temp] != Edge) {
	  whmanweights [temp] -= 4; whmanweights [temp2] -= 1;
	  blmanweights [temp] -= 4; blmanweights [temp2] -= 1;
	}
	temp = bpos (1,boardy); temp2 = bpos (2,boardy - 1);
	if (board [temp] != Edge) {
	  whmanweights [temp] -= 4; whmanweights [temp2] -= 2;
	  blmanweights [temp] -= 4; blmanweights [temp2] -= 2;
	}
	if (euroflag) {
	  whmanweights [14] += 4; whmanweights [25] += 3;whmanweights [49] += 2;
	}
	if (Nkings > 4 && Nmen == 0) {
	  if (euroflag) {
	    kingweights [14] += 14; kingweights [25] += 14;
	  }
	  if (portflag) {
	    kingweights [17] += 14; kingweights [28] += 14;
	  }
	  if (poolflag) {
	    kingweights [12] += 14; kingweights [21] += 14;
	  }
	}
	for (cpos = 0; cpos < MAX_BOARD - 2; cpos ++) {	/* History weights */
	  if (board [cpos] != Greysq) {
	    kingweights [cpos + 1] = kingweights [cpos];
	    whmanweights [cpos + 1] = whmanweights [cpos];
	    blmanweights [cpos + 1] = blmanweights [cpos];
	  }
	}
}

/* ====================================================================================================== */

		/* MOVE GENERATORS */

#define GenerateMoves \
	jumpflag = 0;\
	markleapsq (Greysq);\
	if (ccolor == Black) {		/* Whose go is it? */\
	  genblackmoves ();		/* Gen all legal black moves */\
	} else {\
	  genwhitemoves ();		/* Gen all legal white moves */\
	}\
	markleapsq (0);

#define Whteval (whmanweights [1 + regv] - whmanweights [1 + cbrd])
#define Blkeval (blmanweights [1 + cbrd] - blmanweights [1 + regv])

#define Gen1dir(Cdir,C2dir,Opcolor,Eval) \
	if ( (cdest = board [cbrd + Cdir]) == 0 && jumpflag == 0) { \
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = Cdir;\
	  regv = cbrd + Cdir;\
	  mveval [nmoves] = Eval;\
	  mvindex [nmoves] = tindex;\
	} else if ( (cdest & Opcolor) && (board [cbrd + C2dir] == 0)) {\
	  if (jumpflag == 0) {\
	    jumpflag = 1;\
	    nmoves = 0;\
	  }\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	} \
	if ( (board [cbrd - Cdir] & Opcolor) && (board [cbrd - C2dir] == 0) && backjumps) {\
	  if (jumpflag == 0) {\
	    jumpflag = 1;\
	    nmoves = 0;\
	  }\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = - C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	}

		/* Fast jump generators.. */
#define Gen1jmp(Cdir,C2dir,Opcolor) \
	if ( (board [cbrd +Cdir] & Opcolor) && (board [cbrd +C2dir] == 0)) {\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	} \
	if ( (board [cbrd -Cdir] & Opcolor) && (board [cbrd -C2dir] == 0) && backjumps) {\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = - C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	}

int qdest,qcapt,qbrd;

void  whtscanadir (int qdest,int cdir)	/* Gen KING moves */
{
	qbrd = qdest;
	if (jumpflag == 0) {
	  while ( (regv = board [(qdest += cdir)]) == 0) {
	    kingmoves ++;
	    nmoves ++;
	    mvbrd [nmoves] = qbrd;
	    mvdir [nmoves] = qdest - qbrd;
	    mveval [nmoves] = kingweights [1 + qdest] - kingweights [1 + qbrd];
	    mvindex [nmoves] = tindex;
	  }
	  if ((regv & Black) == 0) {		/* Jump? */
	    return;
	  }
	  qcapt = qdest;
	  if (board [qdest += cdir]) return;	/* Gap beyond ? */
	  jumpflag = 1;				/* Restart for JUMPS */
	  nmoves = 0;
	  goto skipblk;
	}
	while ( (regv = board [(qdest += cdir)]) == 0) ;
	if ((regv & Black) == 0) return;	/* Jump? */
	qcapt = qdest;
	if (board [qdest += cdir]) return;	/* Gap beyond ? */
skipblk:
	do {
	  kingmoves ++;
	  nmoves ++;
	  mvbrd [nmoves] = qbrd;
	  mvdir [nmoves] = qdest - qbrd;
	  mvcapt [nmoves] = qcapt;
	  mveval [nmoves] = 0;
	  mvindex [nmoves] = tindex;
	} while (board [qdest += cdir] == 0);
}

void  blkscanadir (int qdest,int cdir)	/* Gen KING moves */
{
	qbrd = qdest;
	if (jumpflag == 0) {
	  while ( (regv = board [(qdest += cdir)]) == 0) {
	    kingmoves ++;
	    nmoves ++;
	    mvbrd [nmoves] = qbrd;
	    mvdir [nmoves] = qdest - qbrd;
	    mveval [nmoves] = kingweights [1 + qbrd] - kingweights [1 + qdest];
	    mvindex [nmoves] = tindex;
	  }
	  if ((regv & White) == 0) {		/* Jump? */
	    return;
	  }
	  qcapt = qdest;
	  if (board [qdest += cdir]) return;	/* Gap beyond ? */
	  jumpflag = 1;				/* Restart for JUMPS */
	  nmoves = 0;
	  goto skipblk;
	}
	while ( (regv = board [(qdest += cdir)]) == 0) ;
	if ((regv & White) == 0) return;	/* Jump? */
	qcapt = qdest;
	if (board [qdest += cdir]) return;	/* Gap beyond ? */
skipblk:
	do {
	  kingmoves ++;
	  nmoves ++;
	  mvbrd [nmoves] = qbrd;
	  mvdir [nmoves] = qdest - qbrd;
	  mvcapt [nmoves] = qcapt;
	  mveval [nmoves] = 0;
	  mvindex [nmoves] = tindex;
	} while (board [qdest += cdir] == 0);
}

int oppcolor;

void  scanajmp (int qdest,int cdir)	/* Gen KING jumps only */
{
	qbrd = qdest;
	while ( (regv = board [(qdest += cdir)]) == 0) ;
	if ((regv & oppcolor) == 0) return;	/* Jump? */
	qcapt = qdest;
	if (board [qdest += cdir]) return;	/* Gap beyond ? */
	do {
	  kingmoves ++;
	  nmoves ++;
	  mvbrd [nmoves] = qbrd;
	  mvdir [nmoves] = qdest - qbrd;
	  mvcapt [nmoves] = qcapt;
	  mveval [nmoves] = 0;
	  mvindex [nmoves] = tindex;
	} while (board [qdest += cdir] == 0);
}

void  gen1blkmov (int cbrd)
{
	int cdest;
	if (board [cbrd] != Bking) {
	  Gen1dir (dirul, dir2ul, White, Blkeval)
	  Gen1dir (dirur, dir2ur, White, Blkeval)
	  return;
	}
	oppcolor = White;
	blkscanadir (cbrd,dirdl);
	blkscanadir (cbrd,dirdr);
	blkscanadir (cbrd,dirul);
	blkscanadir (cbrd,dirur);
}

#define Gen1b(Cpos) \
	if (board [Cpos] & Black) {gen1blkmov (Cpos);}


int cbrd,pcount;

void  genblackmoves ()
{
	register unsigned cbrd,cdest;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;		/* Also set JUMPFLAG before use */
	for (tindex = 0; tindex < (UINT) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (board [cbrd] != Bking) {
	      Gen1dir (dirul, dir2ul, White, Blkeval)
	      Gen1dir (dirur, dir2ur, White, Blkeval)
	    } else {
	      oppcolor = White;
	      blkscanadir (cbrd,dirdl);
	      blkscanadir (cbrd,dirdr);
	      blkscanadir (cbrd,dirul);
	      blkscanadir (cbrd,dirur);
	    }
	  }
	}
}

void  genblackjumps ()	/* Fast mvgen - jumps only */
{
	register int cbrd;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;		/* Also set JUMPFLAG before use */
	jumpflag = 1;
	for (tindex = 0; tindex < (UINT) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (board [cbrd] != Bking) {
	      Gen1jmp (dirul, dir2ul, White)
	      Gen1jmp (dirur, dir2ur, White)
	    } else {
	      oppcolor = White;
	      scanajmp (cbrd,dirdl);
	      scanajmp (cbrd,dirdr);
	      scanajmp (cbrd,dirul);
	      scanajmp (cbrd,dirur);
	    }
	  }
	  tindex ++;
	  if (tindex >= (UINT) nblpos) goto blexit;
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (board [cbrd] != Bking) {
	      Gen1jmp (dirul, dir2ul, White)
	      Gen1jmp (dirur, dir2ur, White)
	    } else {
	      oppcolor = White;
	      scanajmp (cbrd,dirdl);
	      scanajmp (cbrd,dirdr);
	      scanajmp (cbrd,dirul);
	      scanajmp (cbrd,dirur);
	    }
	  }
	}
blexit:
	if (nmoves == 0) jumpflag = 0;
}

void  gen1whtmov (int cbrd)
{
	int cdest;
	if (board [cbrd] != Wking) {
	  Gen1dir (dirdl, dir2dl, Black, Whteval)
	  Gen1dir (dirdr, dir2dr, Black, Whteval)
	  return;
	}
	oppcolor = Black;
	whtscanadir (cbrd,dirul);
	whtscanadir (cbrd,dirur);
	whtscanadir (cbrd,dirdl);
	whtscanadir (cbrd,dirdr);
}

#define Gen1w(Cpos) \
	if (board [Cpos] & White) gen1whtmov (Cpos);

void  genwhitemoves ()
{
	register unsigned cbrd,cdest;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;		/* Also set JUMPFLAG before use */
	for (tindex = 0; tindex < (UINT) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    if (board [cbrd] != Wking) {
	      Gen1dir (dirdl, dir2dl, Black, Whteval)
	      Gen1dir (dirdr, dir2dr, Black, Whteval)
	    } else {
	      oppcolor = Black;
	      whtscanadir (cbrd,dirul);
	      whtscanadir (cbrd,dirur);
	      whtscanadir (cbrd,dirdl);
	      whtscanadir (cbrd,dirdr);
	    }
	  }
	}
}

void genwhitejumps ()		/* Fast gen jumps only */
{
	register int cbrd;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;
	jumpflag = 1;
	for (tindex = 0; tindex < (UINT) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    if (board [cbrd] != Wking) {
	      Gen1jmp (dirdl, dir2dl, Black)
	      Gen1jmp (dirdr, dir2dr, Black)
	    } else {
	      oppcolor = Black;
	      scanajmp (cbrd,dirul);
	      scanajmp (cbrd,dirur);
	      scanajmp (cbrd,dirdl);
	      scanajmp (cbrd,dirdr);
	    }
	  }
	}
	if (nmoves == 0) jumpflag = 0;
}

void genforsq (int csqr)	/* Gen mvs for 1 sqr */
{
	jumpflag = 0;
	nmoves = 0;
	temp99 = 1;
	markleapsq (Greysq);
	if (ccolor == Black) {
	  tindex = findblindex (csqr, board [csqr]);
	  if (board [csqr] & Black) gen1blkmov (csqr);
	} else {
	  tindex = findwhindex (csqr, board [csqr]);
	  if (board [csqr] & White) gen1whtmov (csqr);
	}
	markleapsq (0);
}

int jumpcount = 0;

   /* Recursive move generator, gen tree with all possiblilities then make list according to rules. */

void recurgen ()
{
	tnomoves  [cply] = nmoves;	/* Save move table size */
	tmostjumps [cply] = 0;
	/* tcurjumps [cply] = curjumps; */
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  xbrd = mvbrd [cmove];
	  xdir = mvdir [cmove];
	  xdest = xbrd + xdir;
	  xpiece = board [xbrd];	/* Piece to be moved */
	  toldpiece [cply] = xpiece;	/* Stash its val on stack */
	  if (xpiece & 1) {
	    xcapt = mvcapt [cmove];
	  } else {
	    xcapt = xbrd + (xdir >> 1);
	  }
	  xtaken = board [xcapt];
	  if (gametype == 5) {		// Portgame.. portugese..
	    if (xtaken & 1) {
	      curjumps += 21;
	    } else {
	      curjumps += 20;
	    }
	  }
	  board [xbrd] = 0;
	  board [xcapt] = Greysq;
	  board [xdest] = xpiece;
	  ttaken [cply] = xtaken;		/* Save vars on stack */
	  tcmove [cply] = cmove;

	  mvbrd += nmoves;	/* Inc move list ptrs */
	  mvdir += nmoves;
	  mvcapt += nmoves;
	  mveval += nmoves;
	  mvtot += nmoves;
	  mvindex += nmoves;

	  jumpflag = 1;		/* Flag indicates that gen moves are jumps */
	  nmoves = 0;
	  if (ccolor == Black) {		/* Whose go is it? */
	    gen1blkmov (xdest);	/* Gen legal black moves for XDEST*/
	  } else {
	    gen1whtmov (xdest);	/* Gen legal white moves for XDEST */
	  }
	  if (nmoves) {		/* More Jumps? */
	    if (flyingkings && (crownsqrs [xdest] & ccolor)) {	/* CROWN.. */
	      xpiece = xpiece | 1;
	      board [xdest] = xpiece;
	    }
	    cply ++;
	    if (cply > MAX_PLY - 2) {
	      xprintf ("RECUR Ply overflow! Hit SPACE!");
	      for (temp = 1; temp < MAX_PLY; temp++) {
		xprintf ("%d,",tmbrd [temp]);
	      }
	      exit (0);
	    }
	    recurgen ();
	    cply --;
	  } else {		/* No more jumps, ret jump-score */
	    if (gametype == 5) {	// Portgame - portugese
	      jumpcount = curjumps;
	    } else {
	      jumpcount = cply;
	    }
	  }
	  xpiece = toldpiece [cply] ;
	  xtaken = ttaken [cply] ;
	  cmove  = tcmove [cply] ;
	  nmoves = tnomoves [cply] ;

	  mvbrd -= nmoves;	/* Dec move list ptrs */
	  mvdir -= nmoves;
	  mvcapt -= nmoves;
	  mveval -= nmoves;
	  mvtot -= nmoves;
	  mvindex -= nmoves;
					/* UNDO move */
	  xbrd = mvbrd [cmove];
	  xdir = mvdir [cmove];
	  board [xbrd + xdir] = 0;	/* Wipe moved piece */
	  board [xbrd] = xpiece;	/* Restore old piece */
	  if (xpiece & 1) {
	    xcapt = mvcapt [cmove];
	  } else {
	    xcapt = xbrd + (xdir >> 1) ;
	  }
	  board [xcapt] = xtaken;
	  if (gametype == 5) {	// Portgame - portugese
	    if (xtaken & 1) {
	      curjumps -= 21;
	    } else {
	      curjumps -= 20;
	    }
	  }
					/* Save score */
	  mvtot [cmove] = jumpcount;
	  if (jumpcount > tmostjumps [cply]) {
	    tmostjumps [cply] = jumpcount;
	  }
	}
	jumpcount = tmostjumps [cply];		/* Return best score */
}

void filterother ()
{
	int tmove,cmove;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  maxdir [mvbrd [cmove]] = 0;
	}
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  temp = dirof [mvdir [cmove] & 511];
	  if (mvtot [cmove] > cply) maxdir [mvbrd [cmove]] |= pow2 [temp];
	}
	tmove = 0;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvtot [cmove] > cply
		|| (maxdir [mvbrd [cmove]] & pow2 [dirof [mvdir [cmove] & 511]]) == 0) {
	    tmove ++;
	    mvbrd [tmove] = mvbrd [cmove];
	    mvdir [tmove] = mvdir [cmove];
	    mveval [tmove] = mveval [cmove];
	    mvcapt [tmove] = mvcapt [cmove];
	    mvindex [tmove] = mvindex [cmove];
	  }
	}
	nmoves = tmove;
}

void filtergen ()		/* Scan jumps, del illegal */
{
	int tmove;
	if (nmoves < 2) return;
	markleapsq (Greysq);
	curjumps = cply;
 	recurgen ();
	markleapsq (0);
	jumpflag = 1;
	#if Othergames		/* Russian/Pool checkers? */
	  if (jumptype) {
	    filterother ();
	    return;
	  }
	#endif
	tmove = 0;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvtot [cmove] == jumpcount) {	/* Only the max jumps */
	    tmove ++;
	    mvbrd [tmove] = mvbrd [cmove];
	    mvdir [tmove] = mvdir [cmove];
	    mveval [tmove] = mveval [cmove];
	    mvcapt [tmove] = mvcapt [cmove];
	    mvindex [tmove] = mvindex [cmove];
	  }
	}
	nmoves = tmove;
}

void filtergensq (int csqr)		/* Filter-Moves for 1 sqr */
{
	int tmove;
	markleapsq (Greysq);
	curjumps = cply;
 	recurgen ();
	markleapsq (0);
	jumpflag = 1;
	#if Othergames		/* Russian/Pool checkers? */
	  if (jumptype) {
	    filterother ();
	    return;
	  }
	#endif
	tmove = 0;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvtot [cmove] == jumpcount || jumptype) {
	    if (mvbrd [cmove] == csqr) {
	      tmove ++;
	      mvbrd [tmove] = mvbrd [cmove];
	      mvdir [tmove] = mvdir [cmove];
	      mveval [tmove] = mveval [cmove];
	      mvcapt [tmove] = mvcapt [cmove];
	      mvindex [tmove] = mvindex [cmove];
	    }
	  }
	}
	nmoves = tmove;
}

/* ====================================================================================================== */

#if USE_HASH

void gethashval ()	/* Get HASHVAL for pos */
{
	register unsigned int cindex,xhash;
	xhash = 0;
	  for (cindex = 0; cindex < (UINT) nwhpos; cindex ++ ) {
	    xhash += hashboard [whpos [cindex]];
	  }
	  for (cindex = 0; cindex < (UINT) nblpos; cindex ++ ) {
	    xhash += hashboard [blpos [cindex]];
	  }
	if (ccolor == Black) xhash ++;
	hashval = xhash;
	hashval = hashval % (hashsize - 10);	// Old version relied on 16 bit ints...
}

#endif 		// USE_HASH

void hilitemoves ()
{
	static int tbest;
	register int cmove;
	register int ceval;
	if (nmoves < 3) return;
	if (ccolor == White) {
	  tbest = -32767;
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	    ceval = mveval [cmove];
	    if (ceval > tbest) {
	      tbest = ceval;
	    } else if (ceval > -30000) {
              mveval [cmove] = ceval - 1000;
	    }
	  }
	} else {
	  tbest = 32767;
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	    ceval = mveval [cmove];
	    if (ceval < tbest) {
	      tbest = ceval;
	    } else if (ceval < 30000) {
              mveval [cmove] = ceval + 1000;
	    }
	  }
	}
}

void dowlink (int cbrd,int cval)	/* Check white man-links */
{
	if (manlink == 0) return;
	if (board [cbrd + dirul] == Wman) xweight += cval;
	if (board [cbrd + dirdr] == Wman) xweight += cval;
	if (board [cbrd + dirur] == Wman) xweight += cval;
	if (board [cbrd + dirdl] == Wman) xweight += cval;
}

void doblink (int cbrd,int cval)	/* Check black man-links */
{
	if (manlink == 0) return;
	if (board [cbrd + dirul] == Bman) xweight += cval;
	if (board [cbrd + dirdr] == Bman) xweight += cval;
	if (board [cbrd + dirur] == Bman) xweight += cval;
	if (board [cbrd + dirdl] == Bman) xweight += cval;
}

//------------------------------------------------------------------------------
//  Bestline/move output routines..
//------------------------------------------------------------------------------


	// Build an ASC int 000 format 
	// FORM - # digits, (bit 4 set = no leading zeros)
	// bit 5=left justify, bit 6=null-terminate
void int2asc (char *cptr, int cval, int form)
{
	int leadflag = form;
	int termchr = 32;
	if (leadflag & 64) termchr = 0;
	form &= 15;
	cptr [form] = termchr;	// Put terminator on end
	if (leadflag & 32) {	// Left justify
	  int cv = cval;
	  while (form) {
	    form --;
	    cptr [form] = termchr;
	  }
	  form = 0;
	  while (cv) {
	    cv = cv / 10; form ++;
	  } 
	}
	while (form) {
	  form --;
	  if ((leadflag & 16) && cval == 0) {	// no leading zeros
	    cptr [form] = 32;
	  } else {
	    cptr [form] = (cval % 10) + 48;
	  }
	  cval = cval / 10;
	}
}

  // Covnvert board-pos to null term string (numeric or chess not)
void Pos2Str (char *ostr, int cpos)
{
	if (notateflag) {	// Use chess notation?
	  cpos = sqpos [cpos];
	  if (numflag) cpos = InvertPos (cpos);
	  ostr[0] = 96 + (cpos % bmult);
	  int2asc (ostr + 1, bmult - 1 - cpos / bmult, 2 | 32 | 64);
	} else {
	  int2asc (ostr, cpos, 2 | 32 | 64);
	}
}

	// Ret null-term string with move..
	// (shift str-ptr on for multi-calls..)
char * Move2Str (int mfrom, int mdir)
{
	static char oostr [40];
	static int spos;
	char *ostr = oostr + ((spos & 3) << 3);
	char *cstr = ostr;
	if (mfrom == 0) return ("     ");
	spos ++;
	Pos2Str (ostr, sqnums [mfrom]);
	while (*cstr) cstr ++;
	*cstr = '-'; cstr ++;
	Pos2Str (cstr, sqnums [mfrom + mdir]);
	return (ostr);
}

void listbest (char *szBest, int maxline)	// Build string (BESTSTR) with best line
{
	int cline;
	char *pStr = szBest;
	char *tstr;
	cline = 1;
	maxline = min (maxline, bestflag);
	lastbest = Bestline (1,1);
	while ( cline < maxline && (temp = Bestline (1,cline)) != 0) {
	  tstr = pStr + 5;
	  Pos2Str (pStr, sqnums [temp & 255]);
	  while (*pStr) pStr ++;
	  Pos2Str (pStr,sqnums [((UINT) temp) >> 8]);
	  while (*pStr) pStr ++;
	  while (pStr < tstr) {
	    *pStr = 32; pStr ++; 
	  }
	  cline ++; 
	}
	*pStr = 0;

}

  // Show best-line anal..  NULL for header

void showanal (char *pPV)
{
    if (pPV == NULL) {
      xprintf (" IQ  Cur  Eval Time KNode PV\n");
      return;
    }
    xprintf ("%3d:%5s=%4d %3lu %5lu ",
	    iqcutoff,Move2Str (xbrd,xdir),tbesteval [1],
	    (xtime * 10) / 182,termnodes/1000);
    listbest (pPV, 11);
    xprintf (" %s\n",pPV);
}

int seval,halfway,headman;
	// Analyse board, split in 3 zones, for 'gaps' to break through.
void  structeval ()	/* Slower structual eval */
{
	int cindex,cbrd;
	seval = 0;
	halfway = (boardy >> 1) * bmult;
	zonetotal [1] = zonetotal [2] = zonetotal [3] =0;
	headman = 0;
	for (cindex = 0; cindex < nwhpos; cindex ++ ) {
	  cbrd = whpos [cindex];
	  if (cbrd > headman) headman = cbrd;
	  if (cbrd < halfway) zonetotal [ zoneboard [cbrd]] ++;
	}
	if (Nwhtking == 0) {
	  if (Nblkking && headman < halfway + bmult) seval -= 15;
	  if (euroflag) {
	    if (headman == 86 && board [97] == 0) seval += 5;
	  }
	}
	zonetotal [1] *= zonepercent [2];
	zonetotal [2] *= zonepercent [1];
	zonetotal [3] *= zonepercent [2];
	zonetotal [2] -= 10;	/* Center zone bias */
	zmin = min (zonetotal [1], zonetotal [2]);
	zmin = min (zmin, zonetotal [3]);
	zmax = max (zonetotal [1], zonetotal [2]);
	zmax = max (zmax, zonetotal [3]);
        temp = zmax - zmin - 35;  /* about 30..40 pts per man dif.. */
	if (temp > 10) {
	  seval = seval - temp / 8 + 1;	/* Punish White imbalance */
	}
	halfway += bmult + bmult;
	zonetotal [1] = zonetotal [2] = zonetotal [3] =0;
	headman = 9999;
	for (cindex = 0; cindex < nblpos; cindex ++ ) {
	  cbrd = blpos [cindex];
	  if (cbrd < headman) headman = cbrd;
	  if (cbrd > halfway) zonetotal [ zoneboard [cbrd]] ++;
	}
	if (Nblkking == 0) {
	  if (Nwhtking && headman > halfway - bmult) seval += 15;
	  if (euroflag) {
	    if (headman == 57 && board [46] == 0) seval -= 5;
	  }
	}
	zonetotal [1] *= zonepercent [2];
	zonetotal [2] *= zonepercent [1];
	zonetotal [3] *= zonepercent [2];
	zonetotal [2] -= 10;
	zmin = min (zonetotal [1], zonetotal [2]);
	zmin = min (zmin, zonetotal [3]);
	zmax = max (zonetotal [1], zonetotal [2]);
	zmax = max (zmax, zonetotal [3]);
        temp = zmax - zmin - 35;  /* about 30..40 pts per man dif.. */
	if (temp > 10) {
	  seval = seval + temp / 8 - 1;	/* Punish Black imbalance */
	}
}

struct {			/* Temp piece-count */
	int c_bot [20];
	int c_top [20];
} pc;

#define zcount pc.c_top
#define Tadd(Cpos) zcount[ board[Cpos]]++;

#define WDadd(Cpos) if(board[cpos]==Wman)ceval++;
#define BDadd(Cpos) if(board[cpos]==Bman)ceval++;

int *brdptr;		/* Temp board pointer */
void terminalnode ()		/* Return XEVAL for curr pos. */
{
	termnodes ++;		/* Increment terminal node count */

	xeval = manvals [Nwhtmen + Nwhtking]
		- manvals [Nblkmen + Nblkking]
		+ kingvals [Nwhtking] - kingvals [Nblkking]
		+ xweight ;

      if (euroflag) {
	if (gamestage > 50) {
	  if ((regv = board [14]) == Wman && board [25] == Bman) xeval += 15;
	  if ((regv || board [25]) & White) xeval += 3;
	  if ((board [20] || board [46]) & White) xeval += 3;
	  if ((regv = board [129]) == Bman && board [118] == Wman) xeval -= 15;
	  if ((regv || board [118]) & Black) xeval -= 3;
	  if ((board [123] || board [97]) & Black) xeval -= 3;
	}
      } else {
	if (*keyrb == Bman) {		/* BLACK back defence */
	  if (*dogrb == Wman)      	/* Dog hole ? */
	    xeval -= Dogval1;
	  if (*keylb == Bman)		/* Bridge factor */
	    xeval -= Bridgeval;
	}
	if (*orr1b == Bman && *orr2b == Bman && *orr3b == Bman)	/* Dcorn tri ? */
	  xeval -= Backval;

	if (*keylb == Bman) {
	  if (*doglb == Wman)		/* 2nd dog hole ? */
	    xeval -= Dogval2;
	  if (*orl2b == Bman && *orl3b == Bman)	/* Oreo ? */
	    xeval -= Oreoval;
	}

	if (*keylw == Wman) {		/* WHITE defence */
	  if (*doglw == Bman)		/* Dog hole ? */
	    xeval += Dogval1;
	  if (*keyrw == Wman)		/* Bridge factor */
	    xeval += Bridgeval;
	}
	if (*orl1w == Wman && *orl2w == Wman && *orl3w == Wman)
	  xeval += Backval;

	if (*keyrw == Wman) {
	  if (*dogrw == Bman)		/* 2nd dog hole ? */
	    xeval += Dogval2;
	  if (*orr2w == Wman && *orr3w == Wman)	/* Oreo ? */
	    xeval += Oreoval;
	}
      }

	if (euroflag) {		/* Clamps.. */
	  if (board [97] == Bman && board [86] == Wman)
	    xeval -= 11;
	  if (board [94] == Bman && board [81] == Wman)
	    xeval -= 10;
	  if (board [73] == Bman && board [62] == Wman)
	    xeval -= 10;
	  if (board [70] == Bman && board [57] == Wman)
	    xeval -= 10;
				/* White clamps.. */
	  if (board [46] == Wman && board [57] == Bman)
	    xeval += 11;
	  if (board [49] == Wman && board [62] == Bman)
	    xeval += 10;
	  if (board [70] == Wman && board [81] == Bman)
	    xeval += 10;
	  if (board [73] == Wman && board [86] == Bman)
	    xeval += 10;

	  if (Nkings) {		/* Long diag K bonus */
	    zcount [2] = zcount [3] = zcount [4] = zcount [5] = 0;
	    Tadd (22); Tadd (33); Tadd (44);
	    Tadd (55); Tadd (66); Tadd (77); Tadd (88);
	    Tadd (99); Tadd (110); Tadd (121);
	    if (zcount [Wking] && zcount [Bking] == 0) {
	      xeval += 10;
	      if (zcount [Bman] == 0) {
		xeval += 10;
	      }
	    }
	    if (zcount [Bking] && zcount [Wking] == 0) {
	      xeval -= 10;
	      if (zcount [Wman] == 0) {
		xeval -= 10;
	      }
	    }
	  }
	} else if (portflag) {		/* Long Diag */
	  zcount [2] = zcount [3] = zcount [4] = zcount [5] = 0;
	  Tadd (11); Tadd (22); Tadd (33); Tadd (44);
	  Tadd (55); Tadd (66); Tadd (77); Tadd (88);
	  if (zcount [5] && zcount [3] == 0) {
	    xeval += 10;
	    if (zcount [2] == 0) {
	      xeval += 15;
	      if (Nwhtking == 1 && Nwhtmen == 0 && Nblkking > 1) {
		xeval += 25;
	      }
	    }
	  }
	  if (zcount [3] && zcount [5] == 0) {
	    xeval -= 10;
	    if (zcount [4] == 0) {
	      xeval -= 15;
	      if (Nblkking == 1 && Nblkmen == 0 && Nwhtking > 1) {
		xeval -= 25;
	      }
	    }
	  }
	}
	if (Nwhtking && Nblkking) {	/* Reduce eval=drawish */
	  xeval = xeval >> 1;
	}
	if (loseflag) xeval = - xeval;
	if (cply > deepest)		/* Stash deepest term node */
	  deepest = cply;
}


#define Rstat 20
#define Riq 23
#define Rmsg 24

void compmove ()	/* Recursive call for building move tables */
{
	if (cply <= bestflag) {
	  Bestline (cply,cply) = 0;
	}

	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	materialdif = nowhite - noblack + ((Nwhtking - Nblkking) << 1);

        #if SMALL_CODE
	  if (cply > MAX_PLY - 10) {
	    terminalnode ();		/* MAX_PLY near, Abort search early */
	    return;
	  }
        #endif
	if (multijump == 0) {	/* Has prev. ply gen MULTI-JUMP moves ? */
	  if (ccut > iqcutoff && cply > 1) {	/* Gen jumps only.. */
	    jumpflag = 0;
	      if (ccolor == Black) {
		if (leapsq [nleap] < 0) markleapsq (Greysq);
		genblackjumps ();		/* Fast gen jumps.. */
		if (leapsq [nleap] < 0) markleapsq (0);
	      } else {
		if (leapsq [nleap] > 0) markleapsq (Greysq);
		genwhitejumps ();
		if (leapsq [nleap] > 0) markleapsq (0);
	      }
	    if (jumpflag == 0) {
	      terminalnode ();		/* IQ cutoff point reached */
	      return;
	    }
	  } else {		/* Norm move gen */

	    if (zapticks) {				/* Zap search ? */
	      xtime = readtime () - fulltime;
	      if (xtime > zapticks) {	/* Time up! */
		iqcutoff = zapiq;
		zapmove = 1;
	      }
	      zapcount ++;
	      if (zapcount > 100) {
		zapcount = 0;
	      }
	    }	/* End ZAPTIME */

	    oppcrownmoves = oppjumpflag = 0;
	    if (enpriseflag && ccut + shortflag < iqcutoff) {	/* Does opp have me en-prise? */
	      ccolor = ToggleWB - ccolor;
	      jumpflag = 0;
	      if (ccolor == Black) {		/* Whose go is it? */
		genblackmoves ();		/* Gen all legal black moves */
	      } else {
		genwhitemoves ();		/* Gen all legal white moves */
	      }
	      ccolor = ToggleWB - ccolor;
	      oppjumpflag = jumpflag;
	      oppcrownmoves = crownmoves;
	    }
	    jumpflag = 0;
	    if (ccolor == Black) {		/* Whose go is it? */
	      if (leapsq [nleap] < 0) markleapsq (Greysq);
	      genblackmoves ();		/* Gen all legal black moves */
	      if (leapsq [nleap] < 0) markleapsq (0);
	    } else {
	      if (leapsq [nleap] > 0) markleapsq (Greysq);
	      genwhitemoves ();		/* Gen all legal white moves */
	      if (leapsq [nleap] > 0) markleapsq (0);
	    }
	    #if Debug
	      if (gen2flag & 1) {		/* Dbl gen test */
	        GenerateMoves
	      }
	    #endif
	  }
	} else {	/* Multijump sequence.. */
	  jumpflag = 1;
	}			/* END MVGEN & TERMNODE.. */

	if (jumpflag ) {
	  filtergen ();		/* Scan jumps, del illegal */
	}

	if (nmoves == 0) {      /* No moves, so side is lost */
	  termnodes ++;
	  if (ccolor == Black)
	    xeval = 32000 - cply;	/* +ve bad for black */
	  else
	    xeval = -32000 + cply;	/* -ve bad for white */
	  if (loseflag) xeval = - xeval;	/* Play to lose ! */
	  return;
	}

	if (usedb && jumpflag == 0 && ccut + ccut > iqcutoff) {  /* Pseudo Dbase ? */
	  if (nowhite == 1 && noblack == 1) {
	    if (ccolor == White) {
	      whtpos = mvbrd [1];
	      blkpos = tmbrd [cply - 1] + tmdir [cply - 1];
	    } else {
	      blkpos = mvbrd [1];
	      whtpos = tmbrd [cply - 1] + tmdir [cply - 1];
	    }
	    if (Nwhtking == 1) {
	      if (Nblkking == 1) {	/* Wk v Bk */
		if (portflag && board [11] + board [88] == 0) {
		  xeval = 0; return;
		}
		if (euroflag && board [22] + board [121] == 0) {
		  xeval = 0; return;
		}
	      } else {			/* Wk v Bm */
		blkx = blkpos % bmult; blky = blkpos / bmult;
		whtx = whtpos % bmult; whty = whtpos / bmult;
		if (euroflag && whtx + whty == 11 && blkx + blky > 11) {
		  xeval = 10000; return;
		}
		if (portflag && whtx == whty && blkx < blky) {
		  xeval = 10000; return;
		}
	      }
	    } else if (Nblkking == 1) {	/* Bk v Wm */
		blkx = blkpos % bmult; blky = blkpos / bmult;
		whtx = whtpos % bmult; whty = whtpos / bmult;
		if (euroflag && blkx + blky == 11 && whtx + whty < 11) {
		  xeval = -10000; return;
		}
		if (portflag && blkx == blky && whtx < whty) {
		  xeval = -10000; return;
		}
	    }
	  }
	  if (nowhite == 1 && noblack == 2 && ccolor == Black	/* 2Bk v Wk*/
		&& Nblkking + Nwhtking == 3 && tnwhtking [cply - 1]
		+ tnblkking [cply - 1] == 3 && tjumpflag [cply - 1] == 0) {
	    if (portflag && ((board [17] | board [28] | board [71] | board [82])
		& White) == 0) {
	      xeval = -1; return;
	    }
	    if (euroflag && ((board [14] | board [25] | board [118] | board [129])
		& White) == 0) {
	      xeval = -1; return;
	    }
	  }
	  if (nowhite == 2 && noblack == 1 && ccolor == White	/* 2Wk v Bk*/
		&& Nblkking + Nwhtking == 3 && tnwhtking [cply - 1]
		+ tnblkking [cply - 1] == 3 && tjumpflag [cply - 1] == 0) {
	    if (portflag && ((board [17] | board [28] | board [71] | board [82])
		& Black) == 0) {
	      xeval = 1; return;
	    }
	    if (euroflag && ((board [14] | board [25] | board [118] | board [129])
		& Black) == 0) {
	      xeval = 1; return;
	    }
	  }
	}		/* DB end */
				/* Calc new cutoff val */
	if (fwdflag) {
	  ccut += (nmoves >> 2) + 10;
	  if (jumpflag) {
	    temp = materialdif + 1;
	    if (ccolor == Black) temp -= 2;
	    if (temp < 0) temp = -temp;		/* ABS */
	    if (nmoves == 1) ccut -= 3;
	    if (tcolor [cply - 1] == ccolor) {	/* Multijump? */
	      ccut -= 5;
	      if (temp < 2) ccut --;
	    } else {
	      if (temp == 0 || materialdif == 0) {
		ccut -= 5;
	      } else {
		if (temp == 1) ccut -= 2;
		if (temp == 2) ccut --;
	      }
	    }
	  }
	} else {	/* Original - deep scan */
	 if (nmoves > 1) {
	    ccut += ((nmoves > 8) ? 14 : nmoves + 6);
	    if (enpriseflag > 1) {
	      if (oppjumpflag) {
		ccut -= enpriseflag;
	      } else if (oppcrownmoves) {
		ccut -= (enpriseflag >> 1);
	      }
	    }
	 } else {
	  if (cply > 2 && tnomoves [cply - 2] < 2) {
	    ccut -= 2;
	  }
	 }
	}

	hashval = 0;
        #if USE_HASH
	  if (ccut + hashflag < iqcutoff && hashflag) {
	    gethashval ();
	    thashval [cply] = hashval;
	  }
        #endif

	if (killerflag && nmoves > 2 && tbestmove [cply]) { /* Killer move ? */
	  register int movbrd,killermove2;
	  static int killerdir2;
	  killermove = tbestmove [cply]; killerdir = tbestdir [cply];
	  if (killerflag == 2 && cply > 2 && hashval) {
	  /* killermove2 = tbestmove [cply-2];killerdir2 = tbestdir [cply-2];*/
	    temp = hashtab [hashval];
	    killermove2 = (temp & 255);
	    killerdir2 = (temp >> 8) - killermove2;
	  } else {
	    killermove2 = -1;
	  }
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {	/* Find Killer */
	    movbrd = mvbrd [cmove];
	    if (killermove == movbrd && killerdir == mvdir [cmove]) {
	      nkillers ++;
	      if (ccolor == White) {		/* Force to top */
		mveval [cmove] = 10000;
	      } else {
		mveval [cmove] = -10000;
	      }
	      break;
	    }
	    if (killermove2 == movbrd && killerdir2 == mvdir [cmove]) {
	      nkillers ++;
	      if (ccolor == White) {		/* Force to top */
		mveval [cmove] = 11000;
	      } else {
		mveval [cmove] = -11000;
	      }
	      break;
	    }
	  }
	}		/* End of killer move */

	tcolor    [cply] = ccolor;	/* Save color */
	tnomoves  [cply] = nmoves;	/* Save move table size */
	tccut     [cply] = ccut;	/* Save running cutoff total */
	tweight   [cply] = xweight;	/* Save running weight/time value */
	tjumpflag [cply] = jumpflag ;	/* Save jump status */

	tnblkmen  [cply] = Nblkmen ;	/* Stash piece counts */
	tnblkking [cply] = Nblkking ;
	tnwhtmen  [cply] = Nwhtmen ;
	tnwhtking [cply] = Nwhtking ;

	if (cply == 1) {
	  shortply = 1;		/* No cuts at or below this phy */
	}

	if (cply == 1 && iterate && targetticks && nmoves > 1) {

	  iqcutoff = 20;
	  xtime = readtime () - fulltime;
	  do {
	    // showanal (1);	// Just IQ..
	    windowlo = -32767; windowhi = 32767;
	    if (iqcutoff > 50 && windowsize) {
	      windowlo = itereval - windowsize;
	      windowhi = itereval + windowsize;
	    }
iterloop:
	    awindlo = windowlo; awindhi = windowhi;
	    retry = 0;
	    knockdown = 0;
	    doingshort = 1;
	    if (iqcutoff > 35) {
	      doingshort = 0;
	      knockdown = 1;
	    }
	    lastbest = 0;
	    shortply = 1;
	    scanmoves ();		/* Search each move, return best */
	    if (aborted == 1) return;	/* Human abort */
	    if (zapmove) {		/* Move was zapped */
	      if (tbestmove [1] < 1) {  /* No new move found.. use old */
		tbesteval [1] = itereval;
		tbestmove [1] = bmove;
		tbestdir [1] = bdir;
	      }
	      return;
	    }
	    if (windowsize && retry) {		/* Window overflow */
	      if (tbesteval [1] <= awindlo) {
		windowhi = awindlo + 10; windowlo = -32767;
		goto iterloop;
	      }
	      if (tbesteval [1] >= awindhi) {
		windowlo = awindhi - 10; windowhi = 32767;
		goto iterloop;
	      }
	    }
	    itereval = tbesteval [1];	/* Save Best eval */
	    bmove = tbestmove [1];
	    bdir = tbestdir [1];

	    xtime = readtime () - fulltime;
	    percent = (int) ((long) (xtime * 100) / targetticks) ;
	    if (percent > 70 || aborted == 2) { /* Time up! */
	      return;	/* Found move */
	    }
	    if (maxiq && iqcutoff > maxiq) return;
	    if ( itereval > 30000 || itereval < -30000) return;	/* Win/lose.. */
	    hilitemoves ();
	    if (inflag) {	/* Infinite search */
	      iqcutoff += 20;
	      continue;
	    }
	    if (percent < 50) iqcutoff += 1;
	    if (percent < 40) iqcutoff += 1;
	    if (percent < 30) iqcutoff += 2;
	    if (percent < 25) iqcutoff += 2;
	    if (percent < 20) iqcutoff += 2;
	    if (percent < 15) iqcutoff += 2;
	    if (percent < 10) iqcutoff += 2;
	    if (percent < 5) iqcutoff += 2;
	    if (xtime < 0) return;
	    // if (tempdoing == 0 && alphaflag < 2) filtermoves ();	/* Hi-lite critical moves */
	    // sortmovesbyeval ();		/* Sort move table */
	    iqcutoff += 8;
	    if (nmoves > 10) iqcutoff ++;
	    if (nmoves > 20) iqcutoff ++;
	  } while (1);
	} else if (shortflag && shortflag + ccut < iqcutoff
		      && doingshort == 0 && nmoves > 1) {
	  templo = windowlo; temphi = windowhi;
	  windowlo = -32767; windowhi = 32767;	/* Full width short */
	  tempiq = iqcutoff;

	  doingshort = 1;
	  iqcutoff = (iqcutoff >> 1) - 12;
	  /*if (cply > 2) iqcutoff = ccut;*/
	  shortply = cply;	/* No cuts at this ply */
	  if (ccut + shortflag + 10 < tempiq) shortply ++;
	  knockdown = 0;
	  scanmoves ();		/* Search each move, return best */
	  iqcutoff = tempiq;
	  if (aborted ) return;
	  windowlo = templo; windowhi = temphi;
	  doingshort = 0;	/* Enable deeper looks */
	  shortply = 1;
	  if (fwdflag) {
	    if (cply == 3) xweight += (tbesteval [cply] / 10);
	  }
	  hilitemoves ();
	  //* sortmovesbyeval ();	/* Sort move table */
	  knockdown = 1;	/* Deeper on 1st move.. */
	  scanmoves ();		/* Search each move, return best */
	  if (aborted) return;
	} else {
	  knockdown = 0;
	  if (doneeval == 0 && ccut + ccut > iqcutoff) {
	    doneeval = 1;
	    structeval (); /* Slow eval done early, added to XWEIGHT */
	    xweight += seval;
	    scanmoves ();
	    doneeval = 0;
	  } else {
	    scanmoves ();
	  }
	  if (aborted) return;
	}
}

void picknextmove ()		/* Scan for next best EVAL.. */
{
	static int bmove;
	int beval;	/* Best mv/eval */
	int tmove;
	if ((UINT) cmove >= nmoves ) return;
	if (ccolor == Black) {
	  bmove = cmove;
	  beval = mveval [bmove];
	  for (tmove = cmove; (UINT) tmove <= nmoves; tmove ++) {
	    if (mveval [tmove] < beval) {
	      beval = mveval [tmove];
	      bmove = tmove;
	    }
	  }
	} else {			/* White move .. */
	  bmove = cmove;
	  beval = mveval [bmove];
	  for (tmove = cmove; (UINT) tmove <= nmoves; tmove ++) {
	    if (mveval [tmove] > beval) {
	      beval = mveval [tmove];
	      bmove = tmove;
	    }
	  }
	}
	Swapmoves (cmove,bmove);	/* Put best at top.. */
}

void scanmoves ()		/* Evaluate move list, ret best */
{
	tbestmove [cply] = 0;   	/* Init best move */
	tbestdir  [cply] = 0;
	if (ccolor == Black) {		/* Init best eval counter to lowest */
	  tbesteval [cply] = 32767;
	} else {
	  // tbesteval [cply] = windowlo;	/* -ve bad for white */
	  tbesteval [cply] = -32767;
	}

	for ( cmove = 1; (UINT) cmove <= nmoves; cmove++) {

	  picknextmove ();		/* PICK NEXT BEST EVAL */

	  qcrowned = 0;			/* Flag indicates crowning */
	  xbrd = mvbrd [cmove];		/* Get coord of piece, & dir */
	  xdir = mvdir [cmove];
	  xpiece = board [xbrd];	/* Piece to be moved */

	  toldpiece [cply] = xpiece;	/* Stash its val on stack */
	  tmbrd [cply] = xbrd;		/* Save moved loc/dir.. */
	  tmdir [cply] = xdir;
	  xdest = xbrd + xdir;
	  xindex = mvindex [cmove];

	  if (xbrd == 0) {	/* Null move, just eval board as is */
	    terminalnode ();
	    goto nullmove;
	  }

	  if (ccolor == Black) {
	    if (xbrd != blpos [xindex]) {xprintf ("Scan:"); listpos (); exit (0);}
	  } else {
	    if (xbrd != whpos [xindex]) {xprintf ("Scan:"); listpos (); exit (0);}
	  }
	  board [xbrd] = 0;
	  board [xdest] = xpiece;	  /* And place piece at new pos */

	  if (jumpflag == 0) {		/* En-prise ? */
	    if (xpiece == Bman && (board [xdest + xdir] & White) == 0) {
	      register int altdir;
	      altdir = 16 - xdir;
	      if (board [xdest + altdir] == Wman && board [xdest + altdir + altdir] == 0 && board [xdest - altdir]) {
		xweight -= 3;
		ccut -= 2;
	      }
	    }
	    if (xpiece == Wman && (board [xdest + xdir] & Black) == 0) {
	      register int altdir;
	      altdir = -16 - xdir;
	      if (board [xdest + altdir] == Bman && board [xdest + altdir + altdir] == 0
			&& board [xdest - altdir]) {
		xweight += 3;
		ccut -= 2;
	      }
	    }
	  }

	  if (knockflag && knockdown) {
	    ccut --;
	  }
	  knockdown = 0;
	  if (cply == 1) {		/* 1st ply factors.. */
	    #if USE_RAND
	    if (varyflag) {	/* Randomise weight slightly (table of 64 rand vals) */
	      xweight += rndoffset [(xbrd + xbrd + xdest) & RNDOFF_MASK];
	    }
	    #endif 		/* USE_RAND */
	    
	    if (prefflag && shortflag && shortflag < iqcutoff && doingshort == 0) {
	      temp = cmove;
	      if (temp > 5) temp = 5;
	      ccut += (temp >> 1);
	    }
	  }

	  if (xpiece & Black) {		/* Update weight for black ? */
	    blpos [xindex] = xdest;
	    if (xpiece == Bman) {
	      xweight += blmanweights [xbrd] - blmanweights [xdest] ;
	      /* if (crownsqrs [xdest] & Centmask) { */
		doblink (xbrd,manlink);		/* Break old links */
		doblink (xdest,-manlink);	/* Eval new links */
	    } else {
	      xweight += kingweights [xbrd] - kingweights [xdest] ;
	    }
	  } else {			/* Update weight for white ? */
	    whpos [xindex] = xdest;
	    if (xpiece == Wman) {
	      xweight += whmanweights [xdest] - whmanweights [xbrd];
	      /* if (crownsqrs [xdest] & Centmask) { */
		dowlink (xbrd,-manlink);
		dowlink (xdest,manlink);
	    } else {
	      xweight += kingweights [xdest] - kingweights [xbrd];
	    }
	  }

	  xcapt = xtaken = 0;
	  if (jumpflag) {		  /* Jump, so also take.. */
	    if (toldpiece [cply] & 1) {
	      xcapt = mvcapt [cmove];
	    } else {
	      xcapt = xbrd + (xdir >> 1);  /* Calc pos taken piece */
	    }
	    xtaken = board [xcapt];
	    #if _DEBUG
	      if ((xtaken & ToggleWB) == 0) {
	        xprintf ("Error!!!"); exit (0);
	       }
            #endif
	    piececount [xtaken] --;	  /* Decrease count for taken piece */
	    board [xcapt] = 0;

				/* Wipe weight val for taken piece */
	    if (xtaken & Black) {	/* Update weight for black ? */
	      Updateblpos (xcapt,xtaken,0)
	      capindex = temp;
	      if (xtaken == Bman) {
		xweight += blmanweights [xcapt] ;
		/* if (crownsqrs [xcapt] & Centmask) { */
		doblink (xcapt,manlink);		/* Break old links */
	      } else {
		xweight += kingweights [xcapt] ;
	      }

	    } else {			/* Update weight for white ? */
	      Updatewhpos (xcapt,xtaken,0)
	      capindex = temp;
	      if (xtaken == Wman) {
		xweight -= whmanweights [xcapt] ;
		/* if (crownsqrs [xcapt] & Centmask) { */
		dowlink (xcapt,-manlink);	/* Break old links */
	      } else {
		xweight -= kingweights [xcapt] ;
	      }
	    }
	  }
	  addleap (xcapt);	/* Save CAPT sqr.. */

			/* Ok, move done on board, save rest of bumph */

	  ttaken    [cply] = xtaken;
	  tcmove    [cply] = cmove;
	  twindlo [cply] = windowlo;
	  twindhi [cply] = windowhi;
	  tcapindex [cply] = capindex;

	  mvbrd += nmoves;	/* Inc move list ptrs */
	  mvdir += nmoves;
	  mvcapt += nmoves;
	  mveval += nmoves;
	  mvtot += nmoves;
	  mvindex += nmoves;

	  if (flyingkings) {
	    if (crownsqrs [xdest] & ccolor) {	/* CROWN.. */
	      if (xpiece == Bman ) {
		Nblkmen --;
		xpiece = Bking;
		Nblkking ++;
		qcrowned ++;
		ccut --;
	      }
	      if (xpiece == Wman ) {
		Nwhtmen --;
		xpiece = Wking;
		Nwhtking ++;
		qcrowned ++;
		ccut --;
	      }
	      board [xdest] = xpiece;	  /* And place piece at new pos */
	    }
	  }

 	  multijump = 0;
	  if (jumpflag) {    	/* See if multi-jump. EURO(&& qcrowned==0) */
	    jumpflag = 0;		/* Flag indicates that gen moves are jumps */
	    nmoves = 0;
	    tindex = xindex;
	    markleapsq (Greysq);
	    if (ccolor == Black) {		/* Whose go is it? */
	      gen1blkmov (xdest);	/* Gen legal black moves for QDEST*/
	    } else {
	      gen1whtmov (xdest);	/* Gen legal white moves for QDEST */
	    }
	    markleapsq (0);
	    if (jumpflag) {		/* Must be jumps to cont.. */
	      multijump = 1;
	    }
	  }

	  if (multijump == 0) {		/* End of Jump-Sequence? */
	   if (flyingkings == 0) {
	    if (crownsqrs [xdest] & ccolor) {	/* CROWN.. */
	      if (xpiece == Bman ) {
		Nblkmen --;
		xpiece = Bking;
		Nblkking ++;
		qcrowned ++;
	      }
	      if (xpiece == Wman ) {
		Nwhtmen --;
		xpiece = Wking;
		Nwhtking ++;
		qcrowned ++;
	      }
	      board [xdest] = xpiece;	  /* And place piece at new pos */
	    }
	   }
	   ccolor = ToggleWB - ccolor;
	  }

	  cply ++;
	  if (cply > MAX_PLY - 3) {
	    xprintf ("SEARCH Ply overflow! Hit SPACE!");
	    for (temp = 1; temp < MAX_PLY; temp++) {
	      xprintf ("%d,",tmbrd [temp]);
	    }
	    exit (0);
	  }
	  compmove();		/* Recursively call next ply, return xeval. */
	  cply --;
	  nleap --;
	  ccut   = tccut  [cply] ;
	  ccolor = ToggleWB - tcolor [cply] ;

		/* Recall vars off stack */

	  xpiece = toldpiece [cply] ;
	  xtaken = ttaken [cply] ;
	  cmove  = tcmove [cply] ;

	  ccolor = tcolor [cply] ;
	  nmoves = tnomoves [cply] ;
	  ccut   = tccut    [cply] ;
	  xweight= tweight  [cply] ;	/* Reget running weight/time value */


	  mvbrd -= nmoves;	/* Dec move list ptrs */
	  mvdir -= nmoves;
	  mvcapt -= nmoves;
	  mveval -= nmoves;
	  mvtot -= nmoves;
	  mvindex -= nmoves;

	  jumpflag = tjumpflag [cply] ;

	  Nblkmen = tnblkmen   [cply] ;		/* Reget piece counts */
	  Nblkking = tnblkking [cply] ;
	  Nwhtmen = tnwhtmen   [cply] ;
	  Nwhtking = tnwhtking [cply] ;
	  windowlo = twindlo [cply] ;
	  windowhi = twindhi [cply] ;
	  capindex = tcapindex [cply];

					/* UNDO move */
	  xindex = mvindex [cmove];
	  xbrd = mvbrd [cmove];
	  xdir = mvdir [cmove];
	  xdest = xbrd + xdir;
	  board [xdest] = 0;	/* Wipe moved piece */
	  board [xbrd] = xpiece;	/* Restore old piece */
	  if (xtaken) {			/* Restore piece if taken */
	    if (xpiece & 1) {
	      xcapt = mvcapt [cmove];
	    } else {
	      xcapt = xbrd + (xdir >> 1) ;
	    }
	    board [xcapt] = xtaken;
	  }

	  if (ccolor == White) {	/* Restore piece-list */
	    whpos [xindex] = xbrd;
	    whtype [xindex] = xpiece;
	    if (xtaken) blpos [capindex] = xcapt;
	  } else {
	    blpos [xindex] = xbrd;
	    bltype [xindex] = xpiece;
	    if (xtaken) whpos [capindex] = xcapt;
	  }

	  if (aborted) return;		/* Was move aborted ? */

nullmove:
	  mveval [cmove] = xeval;	/* Save spot eval for short/sort */

	  if (trimflag) {   /* Trim window? */
	    if (ccolor == Black) {		/* Black.. */
	      if (xeval < windowhi)
		windowhi = xeval ;
	    } else {
	      if (xeval > windowlo)
		windowlo = xeval ;
	    }
	  }

	  if (ccolor == Black) {		/* See if better Black move found */
	    if (xeval < tbesteval [cply]) {
	      if (zapmove == 0) {
		tbesteval [cply] = xeval;
		tbestmove [cply] = xbrd;
		tbestdir  [cply] = xdir;
		if (cply < bestflag) {		/* Bestline ? */
		  int cline;
		  Bestline (cply,cply) = xbrd + ((xbrd + xdir) << 8);
		  cline = cply + 1;
		  while (cline < bestflag && (temp = Bestline (cply + 1,cline)) != 0) {
		    Bestline (cply,cline) = temp;
		    cline ++;
		  }
		  Bestline (cply,cline) = 0;
		}
	      }

	      #if USE_HASH
				/* Save hash move & history stat ? */
	      if (ccut + hashflag < iqcutoff && hashflag && cmove > 1 && jumpflag == 0) {
	        hashtab [thashval [cply]] = xbrd + (xdest << 8);
		if (ccut + 20 < iqcutoff) {
		  if (xpiece == Bman) {
		    blmanweights [1 + xdest] ++;
		  } else {
		    kingweights [1 + xdest] ++;
		  }
		}
	      }
	      #endif	 	/* USE_HASH */

	      if (alphaflag && cply > shortply) {  	/* Alpha-beta cut? */
		if (xeval <= windowlo) {
		  nalphas ++; return;
		}
	      }
	    }
	  } else {			/* See if better White move found */
	    if (xeval > tbesteval [cply]) {
	      if (zapmove == 0) {
		tbesteval [cply] = xeval;
		tbestmove [cply] = xbrd;
		tbestdir  [cply] = xdir;
		if (cply < bestflag) {		/* Bestline ? */
		  int cline;
		  Bestline (cply,cply) = xbrd + ((xbrd + xdir) << 8);
		  cline = cply + 1;
		  while (cline < bestflag && (temp = Bestline (cply + 1,cline)) != 0) {
		    Bestline (cply,cline) = temp;
		    cline ++;
		  }
		  Bestline (cply,cline) = 0;
		}
	      }

	      #if USE_HASH
				/* Save hash move & history stat ? */
	      if (ccut + hashflag < iqcutoff && hashflag && cmove > 1 && jumpflag == 0) {
	        hashtab [thashval [cply]] = xbrd + (xdest << 8);
		if (ccut + 20 < iqcutoff) {
		  if (xpiece == Wman) {
		    whmanweights [1 + xdest] ++;
		  } else {
		    kingweights [1 + xdest] ++;
		  }
		}
	      }
	      #endif 		/* USE_HASH */

	      if (alphaflag && cply > shortply) {  	/* Alpha-beta cut? */
		if (xeval >= windowhi) {
		  nalphas ++; return;
		}
	      }
	    }
	  }

	 if (cply == 1) {			/* Iterate/think ? */
	  xtime = readtime () - fulltime;	/* Time so far */
	  inkey = 0;
	  if (thinkflag) {			/* Print stats */
	    if ( xtime > 20 || cmove == 1 || ((UINT) cmove == nmoves && xtime > 8)) {
	       showanal (szWork);
	    }
	  }

	  if (iterate && targetticks && xtime > targetticks) { /* Time up! */
	    temp = (itereval - tbesteval [1]) >> 1;	/* Dif in scores */
	    if (ccolor == Black) temp = -temp;
	    if (temp < 0) temp = 0;
	    if (temp > 2) temp ++;
	    if (temp > 29) temp = 29;
	    if (xtime > targettime * (10 + temp ) ) {
	      aborted = 2;
	      return;	/* Found move */
	    }
	  }
	  if (windowsize && iterate && timepermove) {	/* Window overflow */
	    if (tbesteval [1] <= awindlo || tbesteval [1] >= awindhi) {
	      retry = 1;
	      return;
	    }
	  }
	 }		/* End of PLY-1 jobs */

	}	/* End of Move-scan loop */

	xeval = tbesteval [cply];		/* Pass best eval back to prev ply */
}		/* All done, return to prev ply */


void findcompmove()	/* Initialise stacks and call compmove */
			/* Multijump flag must be set up before call. */
			/* If set, no initial move table generated */
{
	halfshort = shortflag >> 1;
	doneeval = 0;
	lastbest = 0;
	aborted = 0;
	doingshort = 0;
	termnodes = 0;		/* Clear term node count */
	nkillers = 0;		/* Clear killer count */
	nalphas  = 0;		/* Clear alpha cut count */
	deepest = 0;		/* Deepest ply */
	initptrs ();		/* Init movelist pointers */
	cply = 1;
	ccut = 0;		/* Initialise running cutoff value */
	countpieces ();		/* Initialise piece-count vars */
	setvalpieces ();	/* Set value of piece combinations */
	initweights ();		/* Select king/man weight tables */

	#if USE_RAND
	 for (temp = 0; temp <= RNDOFF_MASK; temp++) {
	   rndoffset [temp] = 0;
           if (varyflag) rndoffset [temp] = rand () % varyflag;
	 }
	#endif 		/* USE_RAND */

	xweight = 0;		/* Initialise running weight value */
	if (multijump == 0) {	/* Has prev MOVE gen MULTI-JUMP moves ? */
	  GenerateMoves		/* Gen mv list */
	} else {
	  jumpflag = 1;
	}
	if (jumpflag ) {
	  filtergen ();		/* Scan jumps, del illegal */
	}
	if (nmoves == 0) return;
	if (nmoves == 1) {		/* Only one possible move */
	  tbestmove [1] = mvbrd [1];
	  tbestdir [1] = mvdir [1];
	  tbesteval [1] = 0;
	  tjumpflag [1] = jumpflag;
	} else {
	  showanal (NULL);		// Header
	  compmove ();		/* Recursivly analyse tree till cutoff */
	}
}

	/* DYBKxx.C  DYNAMO inc file: sundry functions, book, etc */


void newboard (int clrp)	/* Setup board & eval.. (1=Setup pieces) */
{
	bmult = boardx + 2; 
	srand (0);
	maxboard = bmult * (boardy + 2) - 1;	/* Flip Board */
	dirul = - bmult - 1; dirur = - bmult + 1;
	dirdl = bmult - 1; dirdr = bmult + 1;
	dir2ul = dirul + dirul; dir2ur = dirur + dirur;
	dir2dl = dirdl + dirdl; dir2dr = dirdr + dirdr;
	for (xpos = 1; xpos <= 12; xpos ++) {
	  dirof [xpos * dirul & 511] = 1;
	  dirof [xpos * dirur & 511] = 2;
	  dirof [xpos * dirdl & 511] = 3;
	  dirof [xpos * dirdr & 511] = 4;
	}
	euroflag = 0;
	if (boardx == 10 && boardy == 10 && cornmode == 0) euroflag = 1;
	portflag = 0;
	if (boardx == 8 && boardy == 8 && cornmode == 1) portflag = 1;
	poolflag = 0;
	if (boardx == 8 && boardy == 8 && cornmode == 0) poolflag = 1;
	fullgame = nleap = ngame = 0;
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  Setboard ( xpos, 0, Edge)
	  Setboard ( xpos, boardy + 1, Edge)
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    cpos = xpos + ypos * bmult;
	    sqnums [cpos] = crownsqrs [cpos] = 0;
	    temp = 0;
	    if (((ypos + xpos) & 1) == cornmode) temp = Edge;
	    Setboard ( xpos, ypos, temp)
	    if (ypos == 1) {
	      crownsqrs [cpos] = Black;
	    }
	    if (ypos == boardy) {
	      crownsqrs [cpos] = White;
	    }
	    if (ypos == 2 || ypos == 3) {
	      crownsqrs [cpos] |= C1black;
	    }
	    if (ypos == boardy - 1 || ypos == boardy - 2) {
	      crownsqrs [cpos] |= C1white;
	    }
	    if (ypos > 2 && xpos > 2 && ypos < boardy - 1 && xpos < boardx - 1) {
	      crownsqrs [cpos] |= Centmask;
	    }
	  }
	}
	for (ypos = 0; ypos <= boardy + 1; ypos ++) {
	  Setboard ( 0, ypos, Edge)
	  Setboard ( boardx + 1, ypos, Edge)
	}

	nsqrs = 0; cnum = 0;	/* Sqr numbering.. */
	if (numflag) {
	  for (xpos = 1; xpos <= maxboard; xpos ++) {
	    if (board [xpos] == 0) {
	      nsqrs ++;
	      cnum ++;
	      sqnums [xpos] = cnum;
	      sqpos [cnum] = xpos;
	    }
	  }
	} else {
	  for (xpos = maxboard; xpos; xpos --) {
	    if (board [xpos] == 0) {
	      nsqrs ++;
	      cnum ++;
	      sqnums [xpos] = cnum;
	      sqpos [cnum] = xpos;
	    }
	  }
	}
		// Calc 3 zones for weight analysis.. (also fill hashbrd)
	div3 = boardx / 3;
	zonesqrs [1] = zonesqrs [2] = zonesqrs [3] =0;
	for (xpos = 1; xpos < maxboard; xpos ++) {
	  #if USE_HASH
	    hashboard [xpos] = ((rand () & 0x7fff) << 1);
	  #endif 
	  if (board [xpos] != Greysq) {
	    temp = xpos % bmult;		/* Column 1..boardx */
	    if (temp <= div3) {
	      temp = 1;
	    } else if (temp <= boardx - div3) {
	      temp = 2;
	    } else {
	      temp = 3;
	    }
	    zonesqrs [temp] ++;
	    zoneboard [xpos] = temp;	/* Divide into 3 vert zones */
	  }
	}
	zoneboard [0] = 0;
	for (xpos = 1; xpos <= 3; xpos ++) {
	  zonepercent [xpos] = (zonesqrs [xpos] * 100) / nsqrs;
	}
	#if USE_HASH
	  hashboard [0] = 0;
        #endif
	srand (time (NULL));

	if (clrp) {	/* NEWBRD */
	  ccolor = White;
	  flyingkings = jumptype = 0;
	  backjumps = 1;
	  if (gametype == 2 || gametype == 3) jumptype = 1;
	  if (gametype == 1 || gametype == 5) backjumps = 0;
	  if (gametype == 3) flyingkings = 1;
	  if (gametype == 2 || gametype == 3)  {
	    ccolor = Black;
	  }
	  fullgame = 1;
	  temp = menperside;
	  xpos = 1;
	  while (xpos < maxboard / 2 && temp) {
	    if (board [xpos] == 0) {
	      board [xpos] = Wman;
	      temp --;
	    }
	    xpos ++;
	  }
	  temp = menperside;
	  xpos = bmult * boardy + boardx;
	  while (xpos > maxboard / 2 && temp) {
	    if (board [xpos] == 0) {
	      board [xpos] = Bman;
	      temp --;
	    }
	    xpos --;
	  }
	  #if 0
	  	// Save init pos in quick-board array
	  for (xpos = 0; xpos < MAX_BOARD - 5; xpos ++) {
	    qckbrd [xpos] = board [xpos];
	  }
	  qckcol = ccolor;
	  #endif
	}

		/* FIND Bridges/Oreo/Dogholes */

	corn1w = corn2w = corn1b = corn2b = board;
	temp = 2 + bmult;
	if (board [temp] == Greysq) {
	  temp ++;
	  doglw = board + temp - 2 + bmult + bmult;
	} else {
	  corn1w = board + temp;
	  corn2w = doglw = board + temp - 1 + bmult;
	}
	orl1w = keylw = board + temp;
	if (euroflag) orl1w += 2;
	orl2w = orl1w + 2; orl3w = orl1w + 1 + bmult;
	temp = boardx - 1 + bmult;
	if (board [temp] == Greysq) {
	  temp --;
	  dogrw = board + temp + 2 + bmult + bmult;
	} else {
	  corn1w = board + temp;
	  corn2w = dogrw = board + temp + 1 + bmult;
	}
	keyrw = board + temp;
	orr2w = keyrw - 2; orr3w = keyrw - 1 + bmult;

	temp = 2 + (bmult * boardy);
	if (board [temp] == Greysq) {
	  temp ++;
	  doglb = board + temp - 2 - bmult - bmult;
	} else {
	  corn1b = board + temp;
	  corn2b = doglb = board + temp - 1 - bmult;
	}
	keylb = board + temp;
	orl2b = keylb + 2; orl3b = keylb + 1 - bmult;
	temp = boardx - 1 + (bmult * boardy);
	if (board [temp] == Greysq) {
	  temp --;
	  dogrb = board + temp + 2 - bmult - bmult;
	} else {
	  corn1b = board + temp;
	  corn2b = dogrb = board + temp + 1 - bmult;
	}
	orr1b = keyrb = board + temp;
	if (euroflag) orr1b -= 2;
	orr2b = orr1b - 2; orr3b = orr1b - 1 - bmult;
	if (boardy > 8) {
	  Oreoval = Backval = Bridgeval = 5;
	} else {
	  Oreoval = Backval = 12;
	  Bridgeval = 18;
	}
	Dogval1 = Dogval2 = 10;
	if (boardx == boardy && (boardx & 1) == 0) {
	  if (cornmode) {	/* Hi val for 7th rank only */
	    Dogval2 = 32;
	  } else {
	    Dogval1 = 32;
	  }
	}
	if (boardy == 10) {
	  Dogval1 = Dogval2 = 12;
	}
}

#if 0
void FastNewBoard ()	// Faster new-board..
{
	int xpos;
	for (xpos = 0; xpos < MAX_BOARD - 5; xpos ++) {
	  board [xpos] = qckbrd [xpos];
	}
	ccolor = qckcol;
	nleap = 0; ngame = 0;
}
#endif

				/* MOVE LEGALITY & EXEC subs */
  // Full move legality check
  // (mfrom,mto) are abs board[] position locs.
  // ret 0 if illegal, move#in mvgen if ok.
int islegal (int mfrom, int mto)
{
	int cmove,tmove,tdir;
	initptrs ();		/* Init movelist pointers */
	buildpos ();		/* Build piece-lists */
	if ((board [mfrom] & ccolor) == 0) return (0);
	if (ngame > 0 && (mgame [ngame] & 255) == mfrom) {  /* MultiJump */
	  genforsq (mfrom);
	} else {
	  GenerateMoves		/* Gen move list */
	}
	if (jumpflag) {
	  filtergensq (mfrom);
	} else {
	  genforsq (mfrom);
	}
	if (nmoves == 0) return (0);	/* No moves, illegal.. */
	tmove = mfrom;
	tdir = mto - tmove;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvbrd [cmove] == tmove) {
	    if (mto < 0 || mvdir [cmove] == tdir) {
	      xcapt = mvcapt [cmove];
	      return (cmove);		/* Found it! */
	    }
	  }
	}
	return (0);	/* Not in list, illegal.. */
}

int lastjumpflag;

  // Execute move
  // (mfrom,mto) are abs board[] position locs.
  // dmode bit 0 for slow display, bit 1 enable display, bit 3=keep old moves
  // ret 1 if illegal, 0 if ok..
int doamove (int frombrd,int tobrd,int dmode)
{
	int cdir,tpiece;
	int jumpbrd = 0;
	if (islegal (frombrd, tobrd) == 0) return (1);
				/* XCAPT also set.. */
	qcrowned = 0;		/* Crowning flag */
	cdir = tobrd - frombrd;
	tpiece = board [tobrd] = board [frombrd];
	board [frombrd] = 0;
	lastjumpflag = jumpflag;
	if (jumpflag) {
	  if (tpiece & 1) {
	    jumpbrd = xcapt;	/* From ISLEGAL.. */
	  } else {
	    jumpbrd = frombrd + (cdir >> 1);
	  }
	  /* gotoxy (1,25);printi (jumpbrd); */
	  board [jumpbrd] = 0;
	}
	addleap (jumpbrd);
	if (flyingkings) {
	  if ( (crownsqrs [tobrd] & ccolor) && (tpiece & 1) == 0) {
	    board [tobrd] = board [tobrd] | 1;	/* Crown it */
	    qcrowned ++;
	  }
	}
	multijump = 0;
	if (jumpflag) {			/* Multijump? */
	  multijump = 0;
	  buildpos ();		/* Build piece-lists */
	  genforsq (tobrd);		/* Gen moves for 1 sqr */
	  if (jumpflag)	{		/* Must be jumps to cont.. */
	    filtergen ();
	    multijump = 1;
	  }
	}
	if ( (crownsqrs [tobrd] & ccolor) && (tpiece & 1) == 0) {
	  if (multijump == 0 && flyingkings == 0) {
	    board [tobrd] = board [tobrd] | 1;	/* Crown it */
	    qcrowned ++;
	  }
	}
	if (ngame < Mgame-3) {		/* Save move in GAME[] */
	  ngame ++ ;
	  mgame [ngame] = (frombrd << 8) + tobrd;
	  if (!(dmode & 8)) {		// Wipe any old game stub..
	    mgame [ngame + 1] = 0;
	    mgame [ngame + 2] = 0;
	  }
	}
	return (0);
}

void execcompmove ()		/* Find and execute comp move */
{
      targettime = timepermove;
      targetticks = targettime * 10;

      zapticks = (targetticks * 5) / 2;	/* Kill off search time */
      if (inflag) {	/* Infinite search */
	targetticks = zapticks = 999999999; targettime = zapticks / 10;
      }
      resignflag = 0;		/* This is set if computer resigns */
      multijump = 0;		/* Initialise jump status for 1st ply */

      extime = readtime ();	/* Overall move exec time */

      #if USE_HASH
      if (hashflag) {		/* Clr table */
	hashptr = hashtab;
	for (lhash = 0; lhash < hashsize; lhash ++) {
	  hashptr [0] = 0;
	  hashptr ++;
	}
      }
      #endif			/* USE_HASH */

      initptrs ();		/* Init movelist pointers */
      buildpos ();		/* Build piece-lists */
      GenerateMoves
      countpieces ();		/* Initialise piece-count vars */

      do {				/* Loop for Multi-jump */
	buildpos ();		/* Build piece-lists */
	zapcount = zapmove = zapiq = 0;
	fulltime = readtime ();
	windowlo = -32767; windowhi = 32767;
	for (cmove = 1; cmove < MAX_PLY - 4; cmove ++)	/* Clr killers */
	  tbestmove [cmove] = 0;

	aborted = 0;
	findcompmove ();		/* Find sage move for pos */
	if (nmoves == 0) {
	  resignflag = 1;
	  return;
	}

	if (aborted == 1) {	/* Abort key hit ? */
	  ccolor = ToggleWB - ccolor;
	  return;
	}
	fulltime = readtime () - fulltime;	/* Calc sage move time */
						/* Time regulation on? */

	movefrom = tbestmove [1];
	moveto = movefrom + tbestdir [1];

	if ( doamove (movefrom,moveto,1) ) {	  /* Do move on board */
	  xprintf ("BUG! HIT SPC! BAD comp move :%d",movefrom);
	  return ;
	}
	/* xprintf ("Move: %02d-%02d\n",movefrom,moveto); */ 
        { 
	  xprintf ("\n");
          if (drawsize & 2) cons_cls ();
	  listbest (szWork, 11);
	  xprintf ( "I Move: %s  (Eval:%d Time:%d Node:%lu) \n", 
		Move2Str(movefrom,moveto-movefrom), tbesteval [1], (xtime * 10) / 182, termnodes);
	  xprintf ( "    PV:%s\n\n", szWork);
        }


	if (multijump) {
	  continue;		/* OK, Do next multijump */
	}
	break;			/* Otherwise not multijump */
      } while (1);		/* End of multijump loop */
      extime = readtime () - extime;
}


long lasttime = 0;

void calcmen ()
{
	menperside = (((boardy - 2) / 2) * boardx) / 2;
}

  // Set up vars for given game type..
void AssertGameType ()
{
		// Scan to get legal game type
	gametype = gametype % maxGameType;
	// 0..7 "International\0Spanish\0Pool\0Russian\0Canadian\0Portugese\0Mini-damas\0Brazilian\0\0\0\0"

	boardx = boardy = 8;
	if (gametype == 5) {	// Portgame - Portugese..
	  gametype = 5;
	  cornmode = 1;
	  numflag = 1;
	  menperside = 12;
	  return;
	}
	if (gametype >= 6) {	// Sofia - others..
	  cornmode = 0; numflag = 0; 
	  numflag = 1;	/* Inv num */
	  calcmen ();
	  if (gametype == 6) {	/* Minidama */
	    menperside = 8; cornmode = 1;
	  }
	  return;
	}
	cornmode = 0;
	numflag = 0;
	if (gametype == 0) {
	  boardx = boardy = 10;
	}
	if (gametype == 4) {
	  boardx = boardy = 12;
	}
	if (gametype == 1) {
	  cornmode = 1; numflag = 1;
	}
	calcmen ();
}

void initprog ()
{
        #if USE_HASH
	  freeram = 0x70000L;		// Fixed 448K.. (old DOS hugemem limit)
	  charptr = (char *) malloc (freeram - 4096);
	  if (hashflag && freeram > hashsize + hashsize + 100) {
	    hashtab = (int *) charptr;
	    hashptr = (int *) hashtab;
	    freeram = freeram - (hashsize << 1) - 50;
	    charptr += (hashsize << 1) + 100;
	    xprintf ("\nHash table allocated..\n");
	  } else {
	    hashflag = 0;
	    hashtab = NULL;
	    xprintf ("\nNot enough memory for hash-table.. \n");
	  }
        #endif 			/* USE_HASH */

	AssertGameType ();	// Init vars for given game type..
}

// End of orginial DYNA80F code

//-----------------------------------------------------------------------------------------
//  Misc library functions..
//-----------------------------------------------------------------------------------------

#define CONS_TXT_BLUE      0x0001 // text color contains blue.
#define CONS_TXT_GREEN     0x0002 // text color contains green.
#define CONS_TXT_RED       0x0004 // text color contains red.
#define CONS_TXT_INTENSITY 0x0008 // text color is intensified.
#define CONS_BK_BLUE       0x0010 // background color contains blue.
#define CONS_BK_GREEN      0x0020 // background color contains green.
#define CONS_BK_RED        0x0040 // background color contains red.
#define CONS_BK_INTENSITY  0x0080 // background color is intensified.

#define CONS_TXT_WHITE     0x000f
#define CONS_TXT_GREY      0x0007
#define CONS_BK_WHITE      0x00f0
#define CONS_BK_GREY       0x0070

#if (CONS_TYPE == 1)		// WINDOWS Console commands..

#include <windows.h>
#include <wincon.h>

HANDLE cons_hOut = NULL;
HANDLE cons_hIn = NULL;

void cons_init ()
{
    cons_hOut = GetStdHandle (STD_OUTPUT_HANDLE);
    cons_hIn = GetStdHandle (STD_INPUT_HANDLE);
}

void cons_goto (int x, int y)
{
    COORD coord;
    coord.X = (short) x;
    coord.Y = (short) y;
    SetConsoleCursorPosition (cons_hOut, coord);
}

void cons_setAttrib (int x)
{
    SetConsoleTextAttribute (cons_hOut, (WORD) x);
}


void cons_cls ()
{
    COORD coord = {0,0};
    DWORD unused;
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    GetConsoleScreenBufferInfo (cons_hOut, &csbi);
    FillConsoleOutputCharacter (cons_hOut, (TCHAR) ' ', csbi.dwSize.X * csbi.dwSize.Y, coord, &unused);
    FillConsoleOutputAttribute (cons_hOut, 0, csbi.dwSize.X * csbi.dwSize.Y, coord, &unused);
    cons_goto (0,0);
    cons_setAttrib (CONS_TXT_WHITE);
}

#else		// CONS_TYPE - none, just printf/scanf..

void cons_init () {};
void cons_cls () 
{
		// xprintf ("\x1b[2J\x1b[1;1H");  // Cls for ANSI terminals (linux)
}

void cons_goto (int x, int y) {};
void cons_setAttrib (int x) {};

#endif

//------------------------------------------------------------------------------------
//  Simple Console i/o routines..
//------------------------------------------------------------------------------------

static int draw_goffset[] = {0,1,2,3,4,5,1,1,1,1,1,1,1,1,1,1,1};
static char draw_gfx[] = "      ::::::/^\\\\_//B\\\\K//#\\\\#//W\\\\K/";  /* 3x2 ascii piece set (note \\ = 1 backslash) */
//static char gfx[] = "      ::::::/^\\\\_/<K>\\_//#\\\\#/<K>\\#/";  /* 3x2 ascii piece set (note \\ = 1 backslash) */

void drawboard_big ()
{
    int xpos,ypos,cloc,cx,cy,cgfx;
    int sqrx = 3, sqry = 2;
    for (ypos = 1; ypos <= boardy; ypos ++) {
      for (cy = 0; cy < sqry; cy++) {
        for (xpos = 1; xpos <= boardx; xpos ++) {
          cloc = Posof(xpos,ypos);
          cgfx = draw_goffset [board [cloc] & 15] * sqrx * sqry + cy * sqrx;		/* start Offset into gfx[] ascii set */
          for (cx = 0; cx < sqrx; cx++) {
            xprintf ("%c", draw_gfx[cgfx + cx]);
          }
        }
        xprintf ("\n");
      }
    }
    xprintf ("\n");
}

void drawboard ()
{
    int xpos,ypos,cloc;
    /*           "0123456789abcdef";  */
    char pc [] = "  bBwW  .       ";
    char x;
    if (drawsize & 1) {
      drawboard_big (); return;
    }
    for (ypos = 1; ypos <= boardy; ypos ++) {
      for (xpos = 1; xpos <= boardx; xpos ++) {
        cloc = Posof(xpos,ypos);
	x = pc [board [cloc] & 15];
        xprintf ("%c",x);
      }
      xprintf ("\n");
    }
    xprintf ("\n");
}


/*   Some Test graphics for big ASC board..
  __ :::: __ ::::    ::::    ::::
 /B \::::/W \::::    ::::    ::::
 \__/::::\__/::::    ::::    ::::
 ::::    ::::/BK\::::    ::::
 ::::    ::::\__/::::    ::::
 ::::    ::::\__/::::    ::::
     ::::    ::::/WK\::::    ::::
     ::::    ::::\__/::::    ::::
     ::::    ::::\__/::::    ::::

 :::/B\:::   :::   :::
 :::\_/:::   :::   :::
    :::/W\:::/W\:::   :::
    :::\_/:::\K/:::   :::
 :::   :::   :::   :::
 :::   :::   :::   :::
    :::   :::   :::   :::
    :::   :::   :::   :::
 :::   :::   :::   :::
 :::   :::   :::   :::
*/

int do_human_move (char *szIn)
{
    char *pStr = szIn;
    int src,dest;
    if (isdigit(*pStr) == FALSE) return FALSE;
    src = atoi (pStr);
    while (isdigit (*pStr)) {
      pStr ++;
    }
    if (*pStr != '-') return FALSE;
    pStr ++;
    if (isdigit(*pStr) == FALSE) return FALSE;
    dest = atoi (pStr);
    // xprintf ("..Mv:%d,%d\n",src,dest);
    if (doamove (sqpos[src], sqpos[dest], 1)) {
      return FALSE;
    }
    if (multijump == 0) return TRUE;
    return 2;	// Indicate more jumps..
}

void help_screen ()
{
	xprintf (szProgName);
	xprintf (
	 "nn-nn  -  Make a move (ie: 33-28 <ENTER>) \n"
	 "q      -  Quit\n"
 	 "g      -  Go - make computer take a move.\n"
 	 "a      -  Computer auto-play 10 moves.\n"
	 "d      -  Draw board. (d0=small,d1=big)\n"
	 "n      -  New game\n"
	 "n#     -  Set game type : 0=International, 1=Spanish, 2=Pool, 3=Russian, 4=Canadian, 5=Portugese..\n"
	 "t#     -  Set time per move in seconds. If zero, set IQ level.\n"
	 "i#     -  Set IQ search level. (i1-i999)\n"
         "w      -  Toggle two player mode (computer does not reply)\n"
	 "r#     -  Set random factor. (r0-99, r0=off)\n"
       );
        
        #if USE_RAND
	   xprintf ("Random Factor:%d \n",varyflag);
        #endif
        if (timepermove == 0) {
	   xprintf ("IQ level:%d \n",iqcutoff);
	} else {
	   xprintf ("Time per move:%d \n", timepermove);
        }
        if (twoplaymode) xprintf ("Two player mode on.\n");
	xprintf ("\n");
}

char szIn [256];

void main ()
{
    int cret = FALSE;
    int autoplay = FALSE;
    xprintf (szProgName);
    initprog ();
    newboard (1);
    drawboard ();
    while (1) {
      if (autoplay) {
        xprintf ("Autoplay...\n");
        // szIn [0] = 'g';
      } else {
        xprintf ("Enter Command (h=help):");
        gets (szIn);			/* OMG! */
      }
      if (isdigit (szIn[0])) {   // Execute move 
        cret = do_human_move (szIn);
	if (cret == FALSE) {
	  xprintf ("Bad move!\n");
	  continue;
	}
        drawboard ();
	if (cret == 2) {	// multijump..
	  xprintf ("Multijump! Enter next part of jump..\n");
	} else {		// Not multijump, exec comp reply..
	  ccolor = ToggleWB - ccolor;
          if (twoplaymode == 0) {	/* Not in 2 player mode */
	    execcompmove ();
	    ccolor = ToggleWB - ccolor;
            drawboard ();
          }
	}
	continue;
      }
      switch (szIn [0]) {
        case 'h':
          help_screen ();
          break;
        case 'q':
	  return ;
	case 'a':
	  if (autoplay == 0) autoplay = 21;
          autoplay --;
	case 'g':	// Computer go ..
	  execcompmove ();
	  ccolor = ToggleWB - ccolor;
          drawboard ();
	  if (resignflag) autoplay = FALSE;
          break;
        case 'd':		/* d# : d0 small, d1 drawboard_big() */
          if (isdigit (szIn[1])) {	// d# - set draw mode: bit 0 set for big board, bit 1 for cls..
            drawsize = szIn[1] & 7;
          }
          drawboard ();
          break;
        case 'n':
          if (isdigit (szIn[1])) {	// n# - set a game type 0..7 "International\0Spanish\0Pool\0Russian\0Canadian\0Portugese\0Mini-damas\0Brazilian\0\0"
            gametype = szIn[1] & 15;
            AssertGameType ();
          }
          newboard (1);
          drawboard ();
          break;
	case 't':
	  timepermove = atoi (szIn + 1);
	  break;
	case 'i':
	  iqcutoff = atoi (szIn + 1);
	  break;
	case 'w':
	  twoplaymode = !twoplaymode;
	  break;
	#if USE_RAND
	case 'r':
	  varyflag = atoi (szIn + 1);
	  break;
        #endif
      }
    }  // While loop..
}

  // redirectable console printf replacement..
int xprintf (const char *format,...)
{
    int vlen;
    va_list argptr;
	// Turn variable len format into a szString..
    va_start (argptr,format);
    vlen = vprintf (format, argptr);
    va_end (argptr);
    return vlen;
}
