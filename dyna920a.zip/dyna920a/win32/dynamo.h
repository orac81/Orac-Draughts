// DYNAMO.H - global declarations

typedef unsigned char BYTE;
typedef unsigned long ULONG;
typedef unsigned int UINT;
	// Size of an array in elements, not bytes..
#define aSizeOf(Array) (sizeof (Array) / sizeof (Array [0]))


#define LOWORD(X) ((UINT)(long)(X))
#define HIWORD(l)  ((UINT)((((long)(l)) >> 16) & 0xFFFF))
#define LOBYTE(w)  ((BYTE)(w))
#define HIBYTE(w)  ((BYTE)(((UINT)(w) >> 8) & 0xFF))



#define NO_FILE -1

//-------------------------------------------------------------------
// Language declare..

#define SIZEStrSpace 2000
extern char StrSpace [SIZEStrSpace + 100];	// Alloc some local space for them..
extern char *Strings[50];	// Array of pointers to multi-language strings..

#define STlanguages          Strings[0]
#define STmenutext           Strings[1]
#define STtitlebuttons       Strings[2]
#define STtoolboxtext        Strings[3]
#define STtoolboxkeys        Strings[4]
#define STalterengineparameters Strings[5]
#define STloadfile           Strings[6]
#define STsavefile           Strings[7]
#define STentercomment       Strings[8]
#define STabortgame          Strings[9]
#define STbestline           Strings[10]
#define ST2player            Strings[11]
#define STsound              Strings[12]
#define STloadopeningbook    Strings[13]
#define STbook               Strings[14]
#define STchessnot           Strings[15]
#define STinfinite           Strings[16]
#define SThitspacemouse      Strings[17]
#define STspacetocont        Strings[18]
#define STyouwin             Strings[19]
#define STscreenprinter      Strings[20]
#define STokcancel           Strings[21]
#define STplaylevel          Strings[22]
#define STdlgpalette         Strings[23]
#define STpdnheader          Strings[24]
#define STpdnload            Strings[25]
#define STpdnsave            Strings[26]
#define STpdnselect          Strings[27]
#define STfileaccesserror    Strings[28]
#define STtimeshow           Strings[29]
#define STwhitemove          Strings[30]
#define STblackmove          Strings[31]
#define STgametypestr        Strings[32]
#define STextratitle         Strings[33]
#define STextrafront         Strings[34]

//-------------------------------------------------------------------
// Dialog declare..

#define DISABLE 0x8000
#define DLGSPIN 2
#define DLGTXTBUT 1
	// Tool-button info structure (for each button)
typedef struct {
  UINT x,y;		// x/y pos of button in bmp (rel to topleft)
  UINT lx,ly;		// size (SPIN=pos of txt field)
  int lkey,rkey;	// asc codes ret for l/r mouse button (SPIN=range)
  void *var;		// Ptr to associated variable..(spin/tickbox)
  int type;		// Set for text-field button..==2 for spin,
} TBUTTONINFO;

	// Tool-button header structure
typedef struct {
  TBUTTONINFO *bi;	// Ptr to struct with info on each button pos/size/chr
  UINT x,y;		// top left x/y pos on scr (all fields offset by this)
  UINT lx,ly;		// x/y size bmp
  UINT ax,ay;		// x/y area for quick hit-test..
  BYTE *bmp;	// ptr to bmp info (NULL for none)
  int infox,infoy;	// x/y area for info-display..
  int infolx;		// size..(0 for no help-info)
  char *edit;		// ptr to EDIT field
  UINT edx,edy;		// x/y pos of edit field
  UINT edmax;		// max chrs edit field (==0 for no edit, -ve for numeric)
  UINT edlx;		// edlx = width of box in chars, if edmax>edlx,multiline..
  char *txt;		// txt descriptor.
} TBUTTONHEADER;

#define KEY_RET  13
#define KEY_HOME 71
#define KEY_UP   72
#define KEY_PGUP 73
#define KEY_LEFT 75
#define KEY_RIGHT 77
#define KEY_END  79
#define KEY_DOWN 80
#define KEY_PGDN 81
#define KEY_F1   59
#define KEY_F2   60
#define KEY_F3   61

//-------------------------------------------------------------------
// FUNCTION DECLARATIONS..

void uptree ();
void hitspace ();
void helpscreen ();
void scanmoves ();
void initsprites ();
void statline ();
int doamove (int ,int ,int );
void newboard (int);
void viewlist (int,int,char *);
void listpos ();
void setparameters (int, int);
void showborder ();
void FastNewBoard ();
void stepmove (int);
int xprintf (const char *format, ...);
