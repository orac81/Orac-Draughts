  /* DYNAMO-DRAUGHTS, Copyrights A.Millett 1992-2024 */
  /*  DYMVxx.C - Include file with SEARCH and assort */

#define Whtorblk 6
#define ToggleWB 6

int temp99;
int *keyrb,*keylb;	/* Key left/right bridge sqrs */
int *orr1b,*orr2b,*orr3b,*orl2b,*orl3b;	/* 2nd/3rd OREO sqrs */
int *dogrb,*doglb;
int *keyrw,*keylw;
int *orr2w,*orr3w,*orl1w,*orl2w,*orl3w;
int *dogrw,*doglw;
int *corn1w,*corn2w;
int *corn1b,*corn2b;

		/* Piece list code */
int blpos  [32];	/* Pos of each piece, in order 0=King..15=Man */
int whpos  [32];
int bltype [32];	/* Type of each piece */
int whtype [32];
int tcapindex [Mply];	/* Index of Capt.piece */
int nblack;
int nwhite;
int nwhpos;		/* # entries in xxPOS tables */
int nblpos;
int piecepos [8];	/* Start pos for given piece */

int xindex;		/* Current indexed piece */
int capindex;		/* Index Captured piece */
int xtakeloc;
unsigned tindex;

#define Updateblpos(Cbrd,Cpiece,Cval) \
	temp = findblindex (Cbrd,Cpiece);\
	blpos [temp] = Cval;

#define Updatewhpos(Cbrd,Cpiece,Cval) \
	temp99 = 0; temp = findwhindex (Cbrd,Cpiece);\
	whpos [temp] = Cval;

void buildpos ()	/* Build wh/blpos [] tables */
{
	int cbrd,xpiece;
	int csqr;
	nblack = 0;
	nwhite = 0;
	for (xpiece = Wking; xpiece >= Bman; xpiece --) {	/* Kings..Pawns */
	  if (xpiece & Black) {
	    piecepos [xpiece] = nblack;	/* Save start for piece */
	  } else {
	    piecepos [xpiece] = nwhite;
	  }
	  for (csqr = 1; csqr <= nsqrs; csqr ++) {
	    cbrd = sqpos [csqr];
	    if ( board [cbrd] == xpiece) {
	      if (xpiece & Black) {
		blpos [nblack] = cbrd;
		bltype [nblack] = xpiece;
		nblack ++;
	      } else {
		whpos [nwhite] = cbrd;
		whtype [nwhite] = xpiece;
		nwhite ++;
	      }
	    }
	  }
	}
	whpos [nwhite] = blpos [nblack] = 0;
	nblpos = nblack;
	nwhpos = nwhite;
}

int findwhindex (int cbrd, int cpiece)	/* Find index of white piece */
{
	register int cpos;
	if (whpos [(cpos = piecepos [cpiece])] == cbrd) {
	  return (cpos);
	}
	cpos ++;
	while (cpos < nwhpos) {
	  if (whpos [cpos] == cbrd) {
	    return (cpos);
	  }
	  cpos ++;
	}
	printsi ("W!",cbrd); printsi (",",cpiece); printsi (",",temp99); listpos ();
	exit (0);
}

int findblindex (int cbrd, int cpiece)	/* Find index of black piece */
{
	register int cpos;
	if (blpos [(cpos = piecepos [cpiece])] == cbrd) {
	  return (cpos);
	}
	cpos ++;
	while (cpos < nblpos) {
	  if (blpos [cpos] == cbrd) {
	    return (cpos);
	  }
	  cpos ++;
	}
	printsi ("B!",cbrd); printsi (",",cpiece); printsi (",",temp99); listpos ();
	exit (0);
}

void listpos ()
{
	int zindex;
	prints ("LISTPOS!");
	drawboard ();
	while (getkey () != ' ');
	gotoxy (1,17);
	for (zindex = 0; zindex < nwhite; zindex ++) {
	  printsi ("  W:",zindex); printsi (",",whpos [zindex]);
	  printsi (",",whtype [zindex]);
	  printsi (",",findwhindex (whpos [zindex],whtype [zindex]) );
	}
	prints ("     \n");
	for (zindex = 0; zindex < nblack; zindex ++) {
	  printsi ("  B:",zindex); printsi (",",blpos [zindex]);
	  printsi (",",bltype [zindex]);
	  printsi (",",findblindex (blpos [zindex],bltype [zindex]) );
	}
	printsi ("     \nCmove ",cmove); printsi (",color ",ccolor);
	printsi (", Ply ",cply); printsi (", Xindex ",xindex);
	printsi (", Xbrd ",xbrd); prints ("   \n");
	#if Debug
	  viewlist (1,1,"NMOVES=");
	#endif
	while (getkey () != ' ');
}

		/* GAME-SEARCH FUNCTIONS */

void CODESEG countpieces()		/* Count no of pieces - b/w/men/kings */
{
	int xpos,ypos;
	Nblkmen = Nwhtmen = Nblkking = Nwhtking = 0;	/* Clr counts */
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    temp = Getboard (xpos, ypos);
	    if (temp > 0) piececount [temp] ++;
	  }
	}
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
}

void CODESEG setvalpieces ()		/* Init piece-vals */
{
	int ccount;
	kingvals [0] = -10; manvals [0] = -1000;
	kingvals [1] = kingvalue - manvalue;	/* Advantage for 1st king */
	manvals [1] = manvalue;
	for ( ccount = 2; ccount < 40; ccount++) {
	  manvals  [ccount] = ccount * manvalue;
	  kingvals [ccount] = ccount * (kingvalue - manvalue - 60) + 60;
	}
	if (nowhite > noblack) {  /* Depress last man val, encourage xch..*/
	  manvals [nowhite] -= 7;
	}
	if (noblack > nowhite) {
	  manvals [noblack] -= 7;
	}
}

int centx,centy,iswclr,isbclr,clrtemp;

int CODESEG isclear (int cpos, int dir1, int dir2, int opcolor)	  /* 3 sqrs ahead? */
{
	clrtemp = 2;
	if (board [cpos] == Greysq) return (0);
	if (board [cpos + dir1] & opcolor) return (0);
	if (board [cpos + dir2] & opcolor) return (0);
	opcolor = opcolor | Greysq;
	if (board [cpos + dir1 + dir2] & opcolor) return (0);
	if (board [cpos + dir2 + dir2] & opcolor) clrtemp --;
	if (board [cpos + dir1 + dir1] & opcolor) clrtemp --;
	return (clrtemp);
}

int CODESEG is2clear (int cpos, int dir1, int dir2, int opcolor)
{
	if (board [cpos] == Greysq) return (0);
	if (board [cpos + dir1] & opcolor) return (0);
	if (board [cpos + dir2] & opcolor) return (0);
	return (1);
}



void CODESEG initweights ()	/* Pre-select weight tables for men and kings. */
{
	int wmwt,bmwt,kwt;
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	materialdif = nowhite - noblack + ((Nwhtking - Nblkking) << 1);
	gamestage = (50 * (nowhite + noblack)) / menperside;
	btarg = (noblack - 4) / 3;
	wtarg = (nowhite - 4) / 3;
	for (ypos = 1; ypos <= boardy; ypos ++) {
	  centy = (ypos + ypos - boardy - 1) >> 1;
	  if (centy < 0) centy =- centy;
	  for (xpos = 1; xpos <= boardx; xpos ++) {
	    centx = (xpos + xpos - boardx - 1) >> 1;
	    if (centx < 0) centx =- centx;
	    cpos = xpos + ypos * bmult;
	    if (board [cpos] == Greysq) {
	      wmwt = bmwt = kwt = 0;
	      goto wt1;
	    }
	    wmwt = (1 + boardy - ypos) ;
	    bmwt = ypos ;
	    temp = centx;
	    if (centy > centx) temp = centy;
	    kwt = 30 - temp * 3;
	    if (temp == 0) kwt -= 4;
	    if (gamestage < 70) {		/* Flip Time */
	      temp = wmwt; wmwt = bmwt; bmwt = temp;
	    } else if (gamestage < 82) {	/* Evens */
	      wmwt = bmwt = 5;
	    } else {		/* >80, hold back.. */
	    }
	    if (gamestage > 70) {
	      temp = 2; if (gamestage > 80) temp = 3;
	      if (ypos + ypos > boardy) {
		wmwt -= temp;
	      } else {
		bmwt -= temp;
	      }
	    }
	    if (gamestage < 45) {		/* 3x Time */
	      wmwt = 3 * wmwt; bmwt = 3 * bmwt;
	    } else if (gamestage < 65) {	/* Double Time */
	      wmwt += wmwt; bmwt += bmwt;
	    }
	    iswclr = isclear (cpos, dirdl, dirdr,Black);
	    isbclr = isclear (cpos, dirul, dirur,White);
	    if (ypos == 1) {		/* Back hold */
	      isbclr = 0;
	      wmwt += 3;
	      bmwt += 75;
	    }
	    if (ypos == boardy) {
	      iswclr = 0;
	      bmwt += 3;
	      wmwt += 75;
	    }
	    if (xpos == 1 || xpos == boardx) {	/* Edge */
	      temp = 1; if (gamestage < 70) temp = 0;
	      wmwt += temp; bmwt += temp;
	    }
	    if (xpos == 2 || xpos == boardx - 1) {	/* 1-off Edge */
	      wmwt -= 2; bmwt -= 2;
	    }
	    if (centx + centy == 0) {
	      wmwt ++; bmwt ++;
	    }
	    if (ypos == 2) {	/* Clr run ? */
	      bmwt += 55;
	      if (is2clear (cpos, dirul, dirur,White) ) bmwt += 22;
	    }
	    if (ypos == boardy - 1) {
	      wmwt += 55;
	      if (is2clear (cpos, dirdl, dirdr,Black) ) wmwt += 22;
	    }
	    if (iswclr) wmwt += iswclr + iswclr;
	    if (isbclr) bmwt += isbclr + isbclr;
	    if (ypos == 3) {
	      if (gamestage < 70) bmwt += 7;
	      if (gamestage < 60) bmwt += 7;
	      if (gamestage < 45) bmwt += 5;
	      if (isbclr) {
		bmwt += 15;
		if (isbclr == 2) bmwt += 7;
	      }
	    }
	    if (ypos == 4) {
	      if (gamestage < 55) bmwt += 4;
	      temp = isclear (cpos + dirul, dirul, dirur,White)
		   + isclear (cpos + dirur, dirul, dirur,White);
	      if (cpos == 94) bmwt += 3;
	      if (temp) {
		bmwt += 3 + temp * 4;
	      }
	    }
	    if (ypos == boardy - 2) {
	      if (gamestage < 70) wmwt += 7;
	      if (gamestage < 60) wmwt += 7;
	      if (gamestage < 45) wmwt += 5;
	      if (iswclr) {
		wmwt += 15;
		if (iswclr == 2) wmwt += 7;
	      }
	    }
	    if (ypos == boardy - 3) {
	      if (gamestage < 55) wmwt += 4;
	      temp = isclear (cpos + dirdl, dirdl, dirdr,Black)
		   + isclear (cpos + dirdr, dirdl, dirdr,Black);
	      if (cpos == 49) wmwt += 3;
	      if (temp) {
		wmwt += 3 + temp * 4;
	      }
	    }
	    if (xpos + ypos == boardx + 1) kwt += 2;
	    if (crownsqrs [cpos] & Centmask) {
	      wmwt += 2; bmwt += 2;
	    }
	    if (gamestage < 70) {
	      wmwt -= 10; bmwt -= 10;
	    }
	    wmwt -= 10; bmwt -= 10;
wt1:
	    whmanweights [cpos] = wmwt;
	    blmanweights [cpos] = bmwt;
	    kingweights [cpos] = kwt;
	  }
	}
	temp = bpos (boardx,1); temp2 = bpos (boardx - 1, 2);
	if (board [temp] != Edge) {
	  whmanweights [temp] -= 4; whmanweights [temp2] -= 1;
	  blmanweights [temp] -= 4; blmanweights [temp2] -= 1;
	}
	temp = bpos (1,boardy); temp2 = bpos (2,boardy - 1);
	if (board [temp] != Edge) {
	  whmanweights [temp] -= 4; whmanweights [temp2] -= 2;
	  blmanweights [temp] -= 4; blmanweights [temp2] -= 2;
	}
	if (euroflag) {
	  whmanweights [14] += 4; whmanweights [25] += 3;whmanweights [49] += 2;
	}
	if (Nkings > 4 && Nmen == 0) {
	  if (euroflag) {
	    kingweights [14] += 14; kingweights [25] += 14;
	  }
	  if (portflag) {
	    kingweights [17] += 14; kingweights [28] += 14;
	  }
	  if (poolflag) {
	    kingweights [12] += 14; kingweights [21] += 14;
	  }
	}
	for (cpos = 0; cpos < Mbrd - 2; cpos ++) {	/* History weights */
	  if (board [cpos] != Greysq) {
	    kingweights [cpos + 1] = kingweights [cpos];
	    whmanweights [cpos + 1] = whmanweights [cpos];
	    blmanweights [cpos + 1] = blmanweights [cpos];
	  }
	}
}


		/* MOVE GENERATORS */

#define GenerateMoves \
	jumpflag = 0;\
	markleapsq (Greysq);\
	if (ccolor == Black) {		/* Whose go is it? */\
	  genblackmoves ();		/* Gen all legal black moves */\
	} else {\
	  genwhitemoves ();		/* Gen all legal white moves */\
	}\
	markleapsq (0);

#define Whteval (whmanweights [1 + regv] - whmanweights [1 + cbrd])
#define Blkeval (blmanweights [1 + cbrd] - blmanweights [1 + regv])

#define Gen1dir(Cdir,C2dir,Opcolor,Eval) \
	if ( (cdest = board [cbrd + Cdir]) == 0 && jumpflag == 0) { \
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = Cdir;\
	  regv = cbrd + Cdir;\
	  mveval [nmoves] = Eval;\
	  mvindex [nmoves] = tindex;\
	} else if ( (cdest & Opcolor) && (board [cbrd + C2dir] == 0)) {\
	  if (jumpflag == 0) {\
	    jumpflag = 1;\
	    nmoves = 0;\
	  }\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	} \
	if ( (board [cbrd - Cdir] & Opcolor) && (board [cbrd - C2dir] == 0) && backjumps) {\
	  if (jumpflag == 0) {\
	    jumpflag = 1;\
	    nmoves = 0;\
	  }\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = - C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	}

		/* Fast jump generators.. */
#define Gen1jmp(Cdir,C2dir,Opcolor) \
	if ( (board [cbrd +Cdir] & Opcolor) && (board [cbrd +C2dir] == 0)) {\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	} \
	if ( (board [cbrd -Cdir] & Opcolor) && (board [cbrd -C2dir] == 0) && backjumps) {\
	  nmoves ++; \
	  mvbrd [nmoves] = cbrd;\
	  mvdir [nmoves] = - C2dir;\
	  mveval [nmoves] = 0;\
	  mvindex [nmoves] = tindex;\
	}

int qdest,qcapt,qbrd;

void FASTCALL whtscanadir (int qdest,int cdir)	/* Gen KING moves */
{
	qbrd = qdest;
	if (jumpflag == 0) {
	  while ( (regv = board [(qdest += cdir)]) == 0) {
	    kingmoves ++;
	    nmoves ++;
	    mvbrd [nmoves] = qbrd;
	    mvdir [nmoves] = qdest - qbrd;
	    mveval [nmoves] = kingweights [1 + qdest] - kingweights [1 + qbrd];
	    mvindex [nmoves] = tindex;
	  }
	  if ((regv & Black) == 0) {		/* Jump? */
	    return;
	  }
	  qcapt = qdest;
	  if (board [qdest += cdir]) return;	/* Gap beyond ? */
	  jumpflag = 1;				/* Restart for JUMPS */
	  nmoves = 0;
	  goto skipblk;
	}
	while ( (regv = board [(qdest += cdir)]) == 0) ;
	if ((regv & Black) == 0) return;	/* Jump? */
	qcapt = qdest;
	if (board [qdest += cdir]) return;	/* Gap beyond ? */
skipblk:
	do {
	  kingmoves ++;
	  nmoves ++;
	  mvbrd [nmoves] = qbrd;
	  mvdir [nmoves] = qdest - qbrd;
	  mvcapt [nmoves] = qcapt;
	  mveval [nmoves] = 0;
	  mvindex [nmoves] = tindex;
	} while (board [qdest += cdir] == 0);
}

void FASTCALL blkscanadir (int qdest,int cdir)	/* Gen KING moves */
{
	qbrd = qdest;
	if (jumpflag == 0) {
	  while ( (regv = board [(qdest += cdir)]) == 0) {
	    kingmoves ++;
	    nmoves ++;
	    mvbrd [nmoves] = qbrd;
	    mvdir [nmoves] = qdest - qbrd;
	    mveval [nmoves] = kingweights [1 + qbrd] - kingweights [1 + qdest];
	    mvindex [nmoves] = tindex;
	  }
	  if ((regv & White) == 0) {		/* Jump? */
	    return;
	  }
	  qcapt = qdest;
	  if (board [qdest += cdir]) return;	/* Gap beyond ? */
	  jumpflag = 1;				/* Restart for JUMPS */
	  nmoves = 0;
	  goto skipblk;
	}
	while ( (regv = board [(qdest += cdir)]) == 0) ;
	if ((regv & White) == 0) return;	/* Jump? */
	qcapt = qdest;
	if (board [qdest += cdir]) return;	/* Gap beyond ? */
skipblk:
	do {
	  kingmoves ++;
	  nmoves ++;
	  mvbrd [nmoves] = qbrd;
	  mvdir [nmoves] = qdest - qbrd;
	  mvcapt [nmoves] = qcapt;
	  mveval [nmoves] = 0;
	  mvindex [nmoves] = tindex;
	} while (board [qdest += cdir] == 0);
}

int oppcolor;

void FASTCALL scanajmp (int qdest,int cdir)	/* Gen KING jumps only */
{
	qbrd = qdest;
	while ( (regv = board [(qdest += cdir)]) == 0) ;
	if ((regv & oppcolor) == 0) return;	/* Jump? */
	qcapt = qdest;
	if (board [qdest += cdir]) return;	/* Gap beyond ? */
	do {
	  kingmoves ++;
	  nmoves ++;
	  mvbrd [nmoves] = qbrd;
	  mvdir [nmoves] = qdest - qbrd;
	  mvcapt [nmoves] = qcapt;
	  mveval [nmoves] = 0;
	  mvindex [nmoves] = tindex;
	} while (board [qdest += cdir] == 0);
}

void FASTCALL gen1blkmov (int cbrd)
{
	int cdest;
	if (board [cbrd] != Bking) {
	  Gen1dir (dirul, dir2ul, White, Blkeval)
	  Gen1dir (dirur, dir2ur, White, Blkeval)
	  return;
	}
	oppcolor = White;
	blkscanadir (cbrd,dirdl);
	blkscanadir (cbrd,dirdr);
	blkscanadir (cbrd,dirul);
	blkscanadir (cbrd,dirur);
}

#define Gen1b(Cpos) \
	if (board [Cpos] & Black) {gen1blkmov (Cpos);}


int cbrd,pcount;

void FASTCALL genblackmoves ()
{
	register unsigned cbrd,cdest;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;		/* Also set JUMPFLAG before use */
	for (tindex = 0; tindex < (UINT) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (board [cbrd] != Bking) {
	      Gen1dir (dirul, dir2ul, White, Blkeval)
	      Gen1dir (dirur, dir2ur, White, Blkeval)
	    } else {
	      oppcolor = White;
	      blkscanadir (cbrd,dirdl);
	      blkscanadir (cbrd,dirdr);
	      blkscanadir (cbrd,dirul);
	      blkscanadir (cbrd,dirur);
	    }
	  }
	}
}

void FASTCALL genblackjumps ()	/* Fast mvgen - jumps only */
{
	register int cbrd;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;		/* Also set JUMPFLAG before use */
	jumpflag = 1;
	for (tindex = 0; tindex < (UINT) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (board [cbrd] != Bking) {
	      Gen1jmp (dirul, dir2ul, White)
	      Gen1jmp (dirur, dir2ur, White)
	    } else {
	      oppcolor = White;
	      scanajmp (cbrd,dirdl);
	      scanajmp (cbrd,dirdr);
	      scanajmp (cbrd,dirul);
	      scanajmp (cbrd,dirur);
	    }
	  }
	  tindex ++;
	  if (tindex >= (UINT) nblpos) goto blexit;
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (board [cbrd] != Bking) {
	      Gen1jmp (dirul, dir2ul, White)
	      Gen1jmp (dirur, dir2ur, White)
	    } else {
	      oppcolor = White;
	      scanajmp (cbrd,dirdl);
	      scanajmp (cbrd,dirdr);
	      scanajmp (cbrd,dirul);
	      scanajmp (cbrd,dirur);
	    }
	  }
	}
blexit:
	if (nmoves == 0) jumpflag = 0;
}

void FASTCALL gen1whtmov (int cbrd)
{
	int cdest;
	if (board [cbrd] != Wking) {
	  Gen1dir (dirdl, dir2dl, Black, Whteval)
	  Gen1dir (dirdr, dir2dr, Black, Whteval)
	  return;
	}
	oppcolor = Black;
	whtscanadir (cbrd,dirul);
	whtscanadir (cbrd,dirur);
	whtscanadir (cbrd,dirdl);
	whtscanadir (cbrd,dirdr);
}

#define Gen1w(Cpos) \
	if (board [Cpos] & White) gen1whtmov (Cpos);

void FASTCALL genwhitemoves ()
{
	register unsigned cbrd,cdest;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;		/* Also set JUMPFLAG before use */
	for (tindex = 0; tindex < (UINT) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    if (board [cbrd] != Wking) {
	      Gen1dir (dirdl, dir2dl, Black, Whteval)
	      Gen1dir (dirdr, dir2dr, Black, Whteval)
	    } else {
	      oppcolor = Black;
	      whtscanadir (cbrd,dirul);
	      whtscanadir (cbrd,dirur);
	      whtscanadir (cbrd,dirdl);
	      whtscanadir (cbrd,dirdr);
	    }
	  }
	}
}

void genwhitejumps ()		/* Fast gen jumps only */
{
	register int cbrd;
	/*register int *brdptr;*/
	crownmoves = kingmoves = nmoves = 0;
	jumpflag = 1;
	for (tindex = 0; tindex < (UINT) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    if (board [cbrd] != Wking) {
	      Gen1jmp (dirdl, dir2dl, Black)
	      Gen1jmp (dirdr, dir2dr, Black)
	    } else {
	      oppcolor = Black;
	      scanajmp (cbrd,dirul);
	      scanajmp (cbrd,dirur);
	      scanajmp (cbrd,dirdl);
	      scanajmp (cbrd,dirdr);
	    }
	  }
	}
	if (nmoves == 0) jumpflag = 0;
}

void genforsq (int csqr)	/* Gen mvs for 1 sqr */
{
	jumpflag = 0;
	nmoves = 0;
	temp99 = 1;
	markleapsq (Greysq);
	if (ccolor == Black) {
	  tindex = findblindex (csqr, board [csqr]);
	  if (board [csqr] & Black) gen1blkmov (csqr);
	} else {
	  tindex = findwhindex (csqr, board [csqr]);
	  if (board [csqr] & White) gen1whtmov (csqr);
	}
	markleapsq (0);
}

int jumpcount;

void recurgen ()		/* Recursively gen moves, do JUMPCOUNT */
{
	tnomoves  [cply] = nmoves;	/* Save move table size */
	tmostjumps [cply] = 0;
	/* tcurjumps [cply] = curjumps; */
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  xbrd = mvbrd [cmove];
	  xdir = mvdir [cmove];
	  xdest = xbrd + xdir;
	  xpiece = board [xbrd];	/* Piece to be moved */
	  toldpiece [cply] = xpiece;	/* Stash its val on stack */
	  if (xpiece & 1) {
	    xcapt = mvcapt [cmove];
	  } else {
	    xcapt = xbrd + (xdir >> 1);
	  }
	  xtaken = board [xcapt];
	  if (gametype == 5) {		// Portgame.. portugese..
	    if (xtaken & 1) {
	      curjumps += 21;
	    } else {
	      curjumps += 20;
	    }
	  }
	  board [xbrd] = 0;
	  board [xcapt] = Greysq;
	  board [xdest] = xpiece;
	  ttaken [cply] = xtaken;		/* Save vars on stack */
	  tcmove [cply] = cmove;

	  mvbrd += nmoves;	/* Inc move list ptrs */
	  mvdir += nmoves;
	  mvcapt += nmoves;
	  mveval += nmoves;
	  mvtot += nmoves;
	  mvindex += nmoves;

	  jumpflag = 1;		/* Flag indicates that gen moves are jumps */
	  nmoves = 0;
	  if (ccolor == Black) {		/* Whose go is it? */
	    gen1blkmov (xdest);	/* Gen legal black moves for XDEST*/
	  } else {
	    gen1whtmov (xdest);	/* Gen legal white moves for XDEST */
	  }
	  if (nmoves) {		/* More Jumps? */
	    if (flyingkings && (crownsqrs [xdest] & ccolor)) {	/* CROWN.. */
	      xpiece = xpiece | 1;
	      board [xdest] = xpiece;
	    }
	    cply ++;
	    if (cply > Mply - 3) {
	      drawboard ();
	      prints ("RECUR Ply overflow! Hit SPACE!");
	      while (getkey () != ' ');
	      for (temp = 1; temp < Mply; temp++) {
		printsi (",",tmbrd [temp]);
	      }
	      exit (0);
	    }
	    recurgen ();
	    cply --;
	  } else {		/* No more jumps, ret jump-score */
	    if (gametype == 5) {	// Portgame - portugese
	      jumpcount = curjumps;
	    } else {
	      jumpcount = cply;
	    }
	  }
	  xpiece = toldpiece [cply] ;
	  xtaken = ttaken [cply] ;
	  cmove  = tcmove [cply] ;
	  nmoves = tnomoves [cply] ;

	  mvbrd -= nmoves;	/* Dec move list ptrs */
	  mvdir -= nmoves;
	  mvcapt -= nmoves;
	  mveval -= nmoves;
	  mvtot -= nmoves;
	  mvindex -= nmoves;
					/* UNDO move */
	  xbrd = mvbrd [cmove];
	  xdir = mvdir [cmove];
	  board [xbrd + xdir] = 0;	/* Wipe moved piece */
	  board [xbrd] = xpiece;	/* Restore old piece */
	  if (xpiece & 1) {
	    xcapt = mvcapt [cmove];
	  } else {
	    xcapt = xbrd + (xdir >> 1) ;
	  }
	  board [xcapt] = xtaken;
	  if (gametype == 5) {	// Portgame - portugese
	    if (xtaken & 1) {
	      curjumps -= 21;
	    } else {
	      curjumps -= 20;
	    }
	  }
					/* Save score */
	  mvtot [cmove] = jumpcount;
	  if (jumpcount > tmostjumps [cply]) {
	    tmostjumps [cply] = jumpcount;
	  }
	}
	jumpcount = tmostjumps [cply];		/* Return best score */
}

void filterother ()
{
	int tmove,cmove;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  maxdir [mvbrd [cmove]] = 0;
	}
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  temp = dirof [mvdir [cmove] & 511];
	  if (mvtot [cmove] > cply) maxdir [mvbrd [cmove]] |= pow2 [temp];
	}
	tmove = 0;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvtot [cmove] > cply
		|| (maxdir [mvbrd [cmove]] & pow2 [dirof [mvdir [cmove] & 511]]) == 0) {
	    tmove ++;
	    mvbrd [tmove] = mvbrd [cmove];
	    mvdir [tmove] = mvdir [cmove];
	    mveval [tmove] = mveval [cmove];
	    mvcapt [tmove] = mvcapt [cmove];
	    mvindex [tmove] = mvindex [cmove];
	  }
	}
	nmoves = tmove;
}

void filtergen ()		/* Scan jumps, del illegal */
{
	int tmove;
	if (nmoves < 2) return;
	markleapsq (Greysq);
	curjumps = cply;
 	recurgen ();
	markleapsq (0);
	jumpflag = 1;
	#if Othergames		/* Russian/Pool checkers? */
	  if (jumptype) {
	    filterother ();
	    return;
	  }
	#endif
	tmove = 0;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvtot [cmove] == jumpcount) {	/* Only the max jumps */
	    tmove ++;
	    mvbrd [tmove] = mvbrd [cmove];
	    mvdir [tmove] = mvdir [cmove];
	    mveval [tmove] = mveval [cmove];
	    mvcapt [tmove] = mvcapt [cmove];
	    mvindex [tmove] = mvindex [cmove];
	  }
	}
	nmoves = tmove;
}

void filtergensq (int csqr)		/* Filter-Moves for 1 sqr */
{
	int tmove;
	markleapsq (Greysq);
	curjumps = cply;
 	recurgen ();
	markleapsq (0);
	jumpflag = 1;
	#if Othergames		/* Russian/Pool checkers? */
	  if (jumptype) {
	    filterother ();
	    return;
	  }
	#endif
	tmove = 0;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvtot [cmove] == jumpcount || jumptype) {
	    if (mvbrd [cmove] == csqr) {
	      tmove ++;
	      mvbrd [tmove] = mvbrd [cmove];
	      mvdir [tmove] = mvdir [cmove];
	      mveval [tmove] = mveval [cmove];
	      mvcapt [tmove] = mvcapt [cmove];
	      mvindex [tmove] = mvindex [cmove];
	    }
	  }
	}
	nmoves = tmove;
}

void gethashval ()	/* Get HASHVAL for pos */
{
	register unsigned cindex,xhash;
	xhash = 0;
	  for (cindex = 0; cindex < (UINT) nwhpos; cindex ++ ) {
	    xhash += hashboard [whpos [cindex]];
	  }
	  for (cindex = 0; cindex < (UINT) nblpos; cindex ++ ) {
	    xhash += hashboard [blpos [cindex]];
	  }
	if (ccolor == Black) xhash ++;
	hashval = xhash;
	/*hashval = hashval % (hashsize - 10); */
}

void hilitemoves ()
{
	static int tbest;
	register int cmove;
	register int ceval;
	if (nmoves < 3) return;
	if (ccolor == White) {
	  tbest = -32767;
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	    ceval = mveval [cmove];
	    if (ceval > tbest) {
	      tbest = ceval;
	    } else if (ceval > -30000) {
              mveval [cmove] = ceval - 1000;
	    }
	  }
	} else {
	  tbest = 32767;
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	    ceval = mveval [cmove];
	    if (ceval < tbest) {
	      tbest = ceval;
	    } else if (ceval < 30000) {
              mveval [cmove] = ceval + 1000;
	    }
	  }
	}
}

void dowlink (int cbrd,int cval)	/* Check white man-links */
{
	if (manlink == 0) return;
	if (board [cbrd + dirul] == Wman) xweight += cval;
	if (board [cbrd + dirdr] == Wman) xweight += cval;
	if (board [cbrd + dirur] == Wman) xweight += cval;
	if (board [cbrd + dirdl] == Wman) xweight += cval;
}

void doblink (int cbrd,int cval)	/* Check black man-links */
{
	if (manlink == 0) return;
	if (board [cbrd + dirul] == Bman) xweight += cval;
	if (board [cbrd + dirdr] == Bman) xweight += cval;
	if (board [cbrd + dirur] == Bman) xweight += cval;
	if (board [cbrd + dirdl] == Bman) xweight += cval;
}

char beststr [100];

void CODESEG listbest ()	// Build string (BESTSTR) with best line
{
	int cline;
	char *cstr = beststr;
	char *tstr;
	for (cline = 0; cline < 77; cline ++) {	// Wipe old str
	  beststr [cline] = 32;
	}
	beststr [77] = 0; beststr [90] = 0;
	cline = 1;
	lastbest = Bestline (1,1);
	while ( cline < bestflag && (temp = Bestline (1,cline)) != 0) {
	  tstr = cstr + 5;
	  Pos2Str (cstr, sqnums [temp & 255]);
	  while (*cstr) cstr ++;
	  Pos2Str (cstr,sqnums [((UINT) temp) >> 8]);
	  while (*cstr) cstr ++;
	  *cstr = 32; cstr ++; *cstr = 32; 
	  cstr = max (cstr,tstr);
	  cline ++; 
	}
}


  // Show best-line anal..
  // set bit 0 mode IQ update only
  // set bit 1 mode full repaint
void showanal (int mode)
{
	if (bestview == 0) {
	  if ((mode & 2) && gamenote [0]) {	// Show comment?
	    char cchr;
	    SelectSet (1);		// 8x8 set..
	    fillobject (0,469,79,1,0xff,PRNWHT);
	    fillobject (0,470,79,10,0xff,PRNANAL);
	    cchr = gamenote [78];	// Temp terminate..
	    gamenote [78] = 0;
	    prnat (1 | PRNINV | PRNPIX,471,-1,PRNANAL,gamenote);
	    gamenote [78] = cchr;
	    goto endanal;
	  }
	  return;
	}
	SelectSet (1);		// 8x8 set..
	if (mode & 1) {
	  printfat (4 | PRNINV | PRNPIX,463,-1,PRNANAL,"IQ:%3d",iqcutoff);
	  goto endanal;
	}
	if (mode & 2) {		// Final print..
	  fillobject (0,461,79,1,0xff,PRNWHT);
	  fillobject (0,462,79,18,0xff,PRNANAL);
	  printfat (4 | PRNINV | PRNPIX,463,-1,PRNANAL,
	    "IQ:%3d                 Eval:%4d  Sec:%3lu  Node:%lu",
	    iqcutoff,tbesteval [1],(xtime * 10) / 182,termnodes);
	} else {	// Print during search
	  printfat (4 | PRNINV | PRNPIX,463,-1,PRNANAL,
	    "IQ:%3d (%5s, %2d/%2d)  Eval:%4d  Sec:%3lu  Node:%lu    ",
	    iqcutoff,Move2Str (xbrd,xdir),cmove,nmoves,tbesteval [1],
	    (xtime * 10) / 182,termnodes);
	  if (lastbest == Bestline (1,1)) {  // No line update..
	    goto endanal;
	  }
	}
	listbest ();
	//temp = strlen(beststr); beststr[temp]='.';beststr[temp+1] = 0;
	prnat (1 | PRNINV | PRNPIX,471,-1,PRNANAL,beststr);
endanal:
	SelectSet (0);
}

int seval,halfway,headman;
	// Analyse board, split in 3 zones, for 'gaps' to break through.
void CODESEG structeval ()	/* Slower structual eval */
{
	int cindex,cbrd;
	seval = 0;
	halfway = (boardy >> 1) * bmult;
	zonetotal [1] = zonetotal [2] = zonetotal [3] =0;
	headman = 0;
	for (cindex = 0; cindex < nwhpos; cindex ++ ) {
	  cbrd = whpos [cindex];
	  if (cbrd > headman) headman = cbrd;
	  if (cbrd < halfway) zonetotal [ zoneboard [cbrd]] ++;
	}
	if (Nwhtking == 0) {
	  if (Nblkking && headman < halfway + bmult) seval -= 15;
	  if (euroflag) {
	    if (headman == 86 && board [97] == 0) seval += 5;
	  }
	}
	//#if Debug
	//  if (cply == 0) {
	//    prints ("\n");
	//    for (cindex = 1; cindex <= 3; cindex ++) {
	//      printsi ("!",zonetotal [cindex]);
	//    }
	//  }
	//#endif
	zonetotal [1] *= zonepercent [2];
	zonetotal [2] *= zonepercent [1];
	zonetotal [3] *= zonepercent [2];
	zonetotal [2] -= 10;	/* Center zone bias */
	zmin = min (zonetotal [1], zonetotal [2]);
	zmin = min (zmin, zonetotal [3]);
	zmax = max (zonetotal [1], zonetotal [2]);
	zmax = max (zmax, zonetotal [3]);
        temp = zmax - zmin - 35;  /* about 30..40 pts per man dif.. */
	if (temp > 10) {
	  seval = seval - temp / 8 + 1;	/* Punish White imbalance */
	}
	/*#if Debug
	  if (cply == 0) {
	    for (cindex = 1; cindex <= 3; cindex ++) {
	      printsi ("#",zonetotal [cindex]);
	      printsi ("%",zonepercent [cindex]);
	      printsi ("Sq",zonesqrs [cindex]);
	    }
	    printsi (" max",zmax); printsi (" min",zmin);
	    printsi ("  \n==",seval);
	  }
	#endif */
	halfway += bmult + bmult;
	zonetotal [1] = zonetotal [2] = zonetotal [3] =0;
	headman = 9999;
	for (cindex = 0; cindex < nblpos; cindex ++ ) {
	  cbrd = blpos [cindex];
	  if (cbrd < headman) headman = cbrd;
	  if (cbrd > halfway) zonetotal [ zoneboard [cbrd]] ++;
	}
	if (Nblkking == 0) {
	  if (Nwhtking && headman > halfway - bmult) seval += 15;
	  if (euroflag) {
	    if (headman == 57 && board [46] == 0) seval -= 5;
	  }
	}
	zonetotal [1] *= zonepercent [2];
	zonetotal [2] *= zonepercent [1];
	zonetotal [3] *= zonepercent [2];
	zonetotal [2] -= 10;
	zmin = min (zonetotal [1], zonetotal [2]);
	zmin = min (zmin, zonetotal [3]);
	zmax = max (zonetotal [1], zonetotal [2]);
	zmax = max (zmax, zonetotal [3]);
        temp = zmax - zmin - 35;  /* about 30..40 pts per man dif.. */
	if (temp > 10) {
	  seval = seval + temp / 8 - 1;	/* Punish Black imbalance */
	}
}

struct {			/* Temp piece-count */
	int c_bot [20];
	int c_top [20];
} pc;

#define zcount pc.c_top
#define Tadd(Cpos) zcount[ board[Cpos]]++;

#define WDadd(Cpos) if(board[cpos]==Wman)ceval++;
#define BDadd(Cpos) if(board[cpos]==Bman)ceval++;

int *brdptr;		/* Temp board pointer */
void terminalnode ()		/* Return XEVAL for curr pos. */
{
	termnodes ++;		/* Increment terminal node count */

	xeval = manvals [Nwhtmen + Nwhtking]
		- manvals [Nblkmen + Nblkking]
		+ kingvals [Nwhtking] - kingvals [Nblkking]
		+ xweight ;

      if (euroflag) {
	if (gamestage > 50) {
	  if ((regv = board [14]) == Wman && board [25] == Bman) xeval += 15;
	  if ((regv || board [25]) & White) xeval += 3;
	  if ((board [20] || board [46]) & White) xeval += 3;
	  if ((regv = board [129]) == Bman && board [118] == Wman) xeval -= 15;
	  if ((regv || board [118]) & Black) xeval -= 3;
	  if ((board [123] || board [97]) & Black) xeval -= 3;
	}
      } else {
	if (*keyrb == Bman) {		/* BLACK back defence */
	  if (*dogrb == Wman)      	/* Dog hole ? */
	    xeval -= Dogval1;
	  if (*keylb == Bman)		/* Bridge factor */
	    xeval -= Bridgeval;
	}
	if (*orr1b == Bman && *orr2b == Bman && *orr3b == Bman)	/* Dcorn tri ? */
	  xeval -= Backval;

	if (*keylb == Bman) {
	  if (*doglb == Wman)		/* 2nd dog hole ? */
	    xeval -= Dogval2;
	  if (*orl2b == Bman && *orl3b == Bman)	/* Oreo ? */
	    xeval -= Oreoval;
	}

	if (*keylw == Wman) {		/* WHITE defence */
	  if (*doglw == Bman)		/* Dog hole ? */
	    xeval += Dogval1;
	  if (*keyrw == Wman)		/* Bridge factor */
	    xeval += Bridgeval;
	}
	if (*orl1w == Wman && *orl2w == Wman && *orl3w == Wman)
	  xeval += Backval;

	if (*keyrw == Wman) {
	  if (*dogrw == Bman)		/* 2nd dog hole ? */
	    xeval += Dogval2;
	  if (*orr2w == Wman && *orr3w == Wman)	/* Oreo ? */
	    xeval += Oreoval;
	}
      }

	if (euroflag) {		/* Clamps.. */
	  if (board [97] == Bman && board [86] == Wman)
	    xeval -= 11;
	  if (board [94] == Bman && board [81] == Wman)
	    xeval -= 10;
	  if (board [73] == Bman && board [62] == Wman)
	    xeval -= 10;
	  if (board [70] == Bman && board [57] == Wman)
	    xeval -= 10;
				/* White clamps.. */
	  if (board [46] == Wman && board [57] == Bman)
	    xeval += 11;
	  if (board [49] == Wman && board [62] == Bman)
	    xeval += 10;
	  if (board [70] == Wman && board [81] == Bman)
	    xeval += 10;
	  if (board [73] == Wman && board [86] == Bman)
	    xeval += 10;

	  if (Nkings) {		/* Long diag K bonus */
	    zcount [2] = zcount [3] = zcount [4] = zcount [5] = 0;
	    Tadd (22); Tadd (33); Tadd (44);
	    Tadd (55); Tadd (66); Tadd (77); Tadd (88);
	    Tadd (99); Tadd (110); Tadd (121);
	    if (zcount [Wking] && zcount [Bking] == 0) {
	      xeval += 10;
	      if (zcount [Bman] == 0) {
		xeval += 10;
	      }
	    }
	    if (zcount [Bking] && zcount [Wking] == 0) {
	      xeval -= 10;
	      if (zcount [Wman] == 0) {
		xeval -= 10;
	      }
	    }
	  }
	} else if (portflag) {		/* Long Diag */
	  zcount [2] = zcount [3] = zcount [4] = zcount [5] = 0;
	  Tadd (11); Tadd (22); Tadd (33); Tadd (44);
	  Tadd (55); Tadd (66); Tadd (77); Tadd (88);
	  if (zcount [5] && zcount [3] == 0) {
	    xeval += 10;
	    if (zcount [2] == 0) {
	      xeval += 15;
	      if (Nwhtking == 1 && Nwhtmen == 0 && Nblkking > 1) {
		xeval += 25;
	      }
	    }
	  }
	  if (zcount [3] && zcount [5] == 0) {
	    xeval -= 10;
	    if (zcount [4] == 0) {
	      xeval -= 15;
	      if (Nblkking == 1 && Nblkmen == 0 && Nwhtking > 1) {
		xeval -= 25;
	      }
	    }
	  }
	}
	if (Nwhtking && Nblkking) {	/* Reduce eval=drawish */
	  xeval = xeval >> 1;
	}
	if (loseflag) xeval = - xeval;
	if (cply > deepest)		/* Stash deepest term node */
	  deepest = cply;
}


#define Rstat 20
#define Riq 23
#define Rmsg 24

void compmove ()	/* Recursive call for building move tables */
{
	if (cply <= bestflag) {
	  Bestline (cply,cply) = 0;
	}

	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	materialdif = nowhite - noblack + ((Nwhtking - Nblkking) << 1);

	if (multijump == 0) {	/* Has prev. ply gen MULTI-JUMP moves ? */
	  if (ccut > iqcutoff && cply > 1) {	/* Gen jumps only.. */
	    jumpflag = 0;
	   #if Debug
	    if ((gen2flag & 2) == 0) {
	   #endif
	      if (ccolor == Black) {
		if (leapsq [nleap] < 0) markleapsq (Greysq);
		genblackjumps ();		/* Fast gen jumps.. */
		if (leapsq [nleap] < 0) markleapsq (0);
	      } else {
		if (leapsq [nleap] > 0) markleapsq (Greysq);
		genwhitejumps ();
		if (leapsq [nleap] > 0) markleapsq (0);
	      }
	   #if Debug
	    } else {
	      if (ccolor == Black) {
		if (leapsq [nleap] < 0) markleapsq (Greysq);
		genblackmoves ();		/* Gen all legal black moves */
		if (leapsq [nleap] < 0) markleapsq (0);
	      } else {
		if (leapsq [nleap] > 0) markleapsq (Greysq);
		genwhitemoves ();
		if (leapsq [nleap] > 0) markleapsq (0);
	      }
	    }
	   #endif
	    if (jumpflag == 0) {
	      terminalnode ();		/* IQ cutoff point reached */
	      return;
	    }
	  } else {		/* Norm move gen */

	    if (zapticks) {				/* Zap search ? */
	      xtime = readtime () - fulltime;
	      if (xtime > zapticks) {	/* Time up! */
		iqcutoff = zapiq;
		zapmove = 1;
	      }
	      zapcount ++;
	      if (zapcount > 100) {
		zapcount = 0;
		inkey = getkey ();
		if (inkey == 2) {
		  Togglebestline;
		}
		if (inkey == 27 || inkey == 6) {
		  iqcutoff = zapiq;
		  zapmove = 1;
		  aborted = 2;
		  if (inkey == 27) {
	    	    tbestmove [1] = -1;
	    	    aborted = 1;
		  }
		}
	      }
	    }	/* End ZAPTIME */

	    oppcrownmoves = oppjumpflag = 0;
	    if (enpriseflag && ccut + shortflag < iqcutoff) {	/* Does opp have me en-prise? */
	      ccolor = ToggleWB - ccolor;
	      jumpflag = 0;
	      if (ccolor == Black) {		/* Whose go is it? */
		genblackmoves ();		/* Gen all legal black moves */
	      } else {
		genwhitemoves ();		/* Gen all legal white moves */
	      }
	      ccolor = ToggleWB - ccolor;
	      oppjumpflag = jumpflag;
	      oppcrownmoves = crownmoves;
	    }
	    jumpflag = 0;
	    if (ccolor == Black) {		/* Whose go is it? */
	      if (leapsq [nleap] < 0) markleapsq (Greysq);
	      genblackmoves ();		/* Gen all legal black moves */
	      if (leapsq [nleap] < 0) markleapsq (0);
	    } else {
	      if (leapsq [nleap] > 0) markleapsq (Greysq);
	      genwhitemoves ();		/* Gen all legal white moves */
	      if (leapsq [nleap] > 0) markleapsq (0);
	    }
	    #if Debug
	      if (gen2flag & 1) {		/* Dbl gen test */
	        GenerateMoves
	      }
	    #endif
	  }
	} else {	/* Multijump sequence.. */
	  jumpflag = 1;
	}			/* END MVGEN & TERMNODE.. */

	if (jumpflag && testflag == 0) {
	  filtergen ();		/* Scan jumps, del illegal */
	}

	if (nmoves == 0) {      /* No moves, so side is lost */
	  termnodes ++;
	  if (ccolor == Black)
	    xeval = 32000 - cply;	/* +ve bad for black */
	  else
	    xeval = -32000 + cply;	/* -ve bad for white */
	  if (loseflag) xeval = - xeval;	/* Play to lose ! */
	  return;
	}

	if (usedb && jumpflag == 0 && ccut + ccut > iqcutoff) {  /* Pseudo Dbase ? */
	  if (nowhite == 1 && noblack == 1) {
	    if (ccolor == White) {
	      whtpos = mvbrd [1];
	      blkpos = tmbrd [cply - 1] + tmdir [cply - 1];
	    } else {
	      blkpos = mvbrd [1];
	      whtpos = tmbrd [cply - 1] + tmdir [cply - 1];
	    }
	    if (Nwhtking == 1) {
	      if (Nblkking == 1) {	/* Wk v Bk */
		if (portflag && board [11] + board [88] == 0) {
		  xeval = 0; return;
		}
		if (euroflag && board [22] + board [121] == 0) {
		  xeval = 0; return;
		}
	      } else {			/* Wk v Bm */
		blkx = blkpos % bmult; blky = blkpos / bmult;
		whtx = whtpos % bmult; whty = whtpos / bmult;
		if (euroflag && whtx + whty == 11 && blkx + blky > 11) {
		  xeval = 10000; return;
		}
		if (portflag && whtx == whty && blkx < blky) {
		  xeval = 10000; return;
		}
	      }
	    } else if (Nblkking == 1) {	/* Bk v Wm */
		blkx = blkpos % bmult; blky = blkpos / bmult;
		whtx = whtpos % bmult; whty = whtpos / bmult;
		if (euroflag && blkx + blky == 11 && whtx + whty < 11) {
		  xeval = -10000; return;
		}
		if (portflag && blkx == blky && whtx < whty) {
		  xeval = -10000; return;
		}
	    }
	  }
	  if (nowhite == 1 && noblack == 2 && ccolor == Black	/* 2Bk v Wk*/
		&& Nblkking + Nwhtking == 3 && tnwhtking [cply - 1]
		+ tnblkking [cply - 1] == 3 && tjumpflag [cply - 1] == 0) {
	    if (portflag && ((board [17] | board [28] | board [71] | board [82])
		& White) == 0) {
	      xeval = -1; return;
	    }
	    if (euroflag && ((board [14] | board [25] | board [118] | board [129])
		& White) == 0) {
	      xeval = -1; return;
	    }
	  }
	  if (nowhite == 2 && noblack == 1 && ccolor == White	/* 2Wk v Bk*/
		&& Nblkking + Nwhtking == 3 && tnwhtking [cply - 1]
		+ tnblkking [cply - 1] == 3 && tjumpflag [cply - 1] == 0) {
	    if (portflag && ((board [17] | board [28] | board [71] | board [82])
		& Black) == 0) {
	      xeval = 1; return;
	    }
	    if (euroflag && ((board [14] | board [25] | board [118] | board [129])
		& Black) == 0) {
	      xeval = 1; return;
	    }
	  }
	}		/* DB end */
				/* Calc new cutoff val */
	if (fwdflag) {
	  ccut += (nmoves >> 2) + 10;
	  if (jumpflag) {
	    temp = materialdif + 1;
	    if (ccolor == Black) temp -= 2;
	    if (temp < 0) temp = -temp;		/* ABS */
	    if (nmoves == 1) ccut -= 3;
	    if (tcolor [cply - 1] == ccolor) {	/* Multijump? */
	      ccut -= 5;
	      if (temp < 2) ccut --;
	    } else {
	      if (temp == 0 || materialdif == 0) {
		ccut -= 5;
	      } else {
		if (temp == 1) ccut -= 2;
		if (temp == 2) ccut --;
	      }
	    }
	  }
	} else {	/* Original - deep scan */
	 if (nmoves > 1) {
	    ccut += ((nmoves > 8) ? 14 : nmoves + 6);
	    if (enpriseflag > 1) {
	      if (oppjumpflag) {
		ccut -= enpriseflag;
	      } else if (oppcrownmoves) {
		ccut -= (enpriseflag >> 1);
	      }
	    }
	 } else {
	  if (cply > 2 && tnomoves [cply - 2] < 2) {
	    ccut -= 2;
	  }
	 }
	}

	hashval = 0;
	if (ccut + hashflag < iqcutoff && hashflag) {
	  gethashval ();
	  thashval [cply] = hashval;
	}

	if (killerflag && nmoves > 2 && tbestmove [cply]) { /* Killer move ? */
	  register int movbrd,killermove2;
	  static int killerdir2;
	  killermove = tbestmove [cply]; killerdir = tbestdir [cply];
	  if (killerflag == 2 && cply > 2 && hashval) {
	  /* killermove2 = tbestmove [cply-2];killerdir2 = tbestdir [cply-2];*/
	    temp = hashtab [hashval];
	    killermove2 = (temp & 255);
	    killerdir2 = (temp >> 8) - killermove2;
	  } else {
	    killermove2 = -1;
	  }
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {	/* Find Killer */
	    movbrd = mvbrd [cmove];
	    if (killermove == movbrd && killerdir == mvdir [cmove]) {
	      nkillers ++;
	      if (ccolor == White) {		/* Force to top */
		mveval [cmove] = 10000;
	      } else {
		mveval [cmove] = -10000;
	      }
	      break;
	    }
	    if (killermove2 == movbrd && killerdir2 == mvdir [cmove]) {
	      nkillers ++;
	      if (ccolor == White) {		/* Force to top */
		mveval [cmove] = 11000;
	      } else {
		mveval [cmove] = -11000;
	      }
	      break;
	    }
	  }
	}		/* End of killer move */

	tcolor    [cply] = ccolor;	/* Save color */
	tnomoves  [cply] = nmoves;	/* Save move table size */
	tccut     [cply] = ccut;	/* Save running cutoff total */
	tweight   [cply] = xweight;	/* Save running weight/time value */
	tjumpflag [cply] = jumpflag ;	/* Save jump status */

	tnblkmen  [cply] = Nblkmen ;	/* Stash piece counts */
	tnblkking [cply] = Nblkking ;
	tnwhtmen  [cply] = Nwhtmen ;
	tnwhtking [cply] = Nwhtking ;

	if (cply == 1) {
	  shortply = 1;		/* No cuts at or below this phy */
	}

	if (cply == 1 && iterate && targetticks && nmoves > 1) {
	  iqcutoff = 20;
	  xtime = readtime () - fulltime;
	  do {
	    showanal (1);	// Just IQ..
	    windowlo = -32767; windowhi = 32767;
	    if (iqcutoff > 50 && windowsize) {
	      windowlo = itereval - windowsize;
	      windowhi = itereval + windowsize;
	    }
iterloop:
	    awindlo = windowlo; awindhi = windowhi;
	    retry = 0;
	    knockdown = 0;
	    doingshort = 1;
	    if (iqcutoff > 35) {
	      doingshort = 0;
	      knockdown = 1;
	    }
	    lastbest = 0;
	    shortply = 1;
	    scanmoves ();		/* Search each move, return best */
	    if (aborted == 1) return;	/* Human abort */
	    if (zapmove) {		/* Move was zapped */
	      if (tbestmove [1] < 1) {  /* No new move found.. use old */
		tbesteval [1] = itereval;
		tbestmove [1] = bmove;
		tbestdir [1] = bdir;
	      }
	      return;
	    }
	    if (windowsize && retry) {		/* Window overflow */
	      if (tbesteval [1] <= awindlo) {
		windowhi = awindlo + 10; windowlo = -32767;
		goto iterloop;
	      }
	      if (tbesteval [1] >= awindhi) {
		windowlo = awindhi - 10; windowhi = 32767;
		goto iterloop;
	      }
	    }
	    itereval = tbesteval [1];	/* Save Best eval */
	    bmove = tbestmove [1];
	    bdir = tbestdir [1];

	    xtime = readtime () - fulltime;
	    percent = (int) ((long) (xtime * 100) / targetticks) ;
	    if (percent > 70 || aborted == 2) { /* Time up! */
	      return;	/* Found move */
	    }
	    if (maxiq && iqcutoff > maxiq) return;
	    if ( itereval > 30000 || itereval < -30000) return;	/* Win/lose.. */
	    hilitemoves ();
	    if (inflag) {	/* Infinite search */
	      iqcutoff += 20;
	      continue;
	    }
	    if (percent < 50) iqcutoff += 1;
	    if (percent < 40) iqcutoff += 1;
	    if (percent < 30) iqcutoff += 2;
	    if (percent < 25) iqcutoff += 2;
	    if (percent < 20) iqcutoff += 2;
	    if (percent < 15) iqcutoff += 2;
	    if (percent < 10) iqcutoff += 2;
	    if (percent < 5) iqcutoff += 2;
	    if (xtime < 0) return;
	    // if (tempdoing == 0 && alphaflag < 2) filtermoves ();	/* Hi-lite critical moves */
	    // sortmovesbyeval ();		/* Sort move table */
	    iqcutoff += 8;
	    if (nmoves > 10) iqcutoff ++;
	    if (nmoves > 20) iqcutoff ++;
	  } while (1);
	} else if (shortflag && shortflag + ccut < iqcutoff
		      && doingshort == 0 && nmoves > 1) {
	  templo = windowlo; temphi = windowhi;
	  windowlo = -32767; windowhi = 32767;	/* Full width short */
	  tempiq = iqcutoff;

	  doingshort = 1;
	  iqcutoff = (iqcutoff >> 1) - 12;
	  /*if (cply > 2) iqcutoff = ccut;*/
	  shortply = cply;	/* No cuts at this ply */
	  if (ccut + shortflag + 10 < tempiq) shortply ++;
	  knockdown = 0;
	  scanmoves ();		/* Search each move, return best */
	  iqcutoff = tempiq;
	  if (aborted ) return;
	  windowlo = templo; windowhi = temphi;
	  doingshort = 0;	/* Enable deeper looks */
	  shortply = 1;
	  if (fwdflag) {
	    if (cply == 3) xweight += (tbesteval [cply] / 10);
	  }
	  hilitemoves ();
	  //* sortmovesbyeval ();	/* Sort move table */
	  knockdown = 1;	/* Deeper on 1st move.. */
	  scanmoves ();		/* Search each move, return best */
	  if (aborted) return;
	} else {
	  knockdown = 0;
	  if (doneeval == 0 && ccut + ccut > iqcutoff) {
	    doneeval = 1;
	    structeval (); /* Slow eval done early, added to XWEIGHT */
	    xweight += seval;
	    scanmoves ();
	    doneeval = 0;
	  } else {
	    scanmoves ();
	  }
	  if (aborted) return;
	}
}

MYINLINE void picknextmove ()		/* Scan for next best EVAL.. */
{
	static int bmove;
	int beval;	/* Best mv/eval */
	int tmove;
	if ((UINT) cmove >= nmoves ) return;
	if (ccolor == Black) {
	  bmove = cmove;
	  beval = mveval [bmove];
	  for (tmove = cmove; (UINT) tmove <= nmoves; tmove ++) {
	    if (mveval [tmove] < beval) {
	      beval = mveval [tmove];
	      bmove = tmove;
	    }
	  }
	} else {			/* White move .. */
	  bmove = cmove;
	  beval = mveval [bmove];
	  for (tmove = cmove; (UINT) tmove <= nmoves; tmove ++) {
	    if (mveval [tmove] > beval) {
	      beval = mveval [tmove];
	      bmove = tmove;
	    }
	  }
	}
	Swapmoves (cmove,bmove);	/* Put best at top.. */
}

void scanmoves ()		/* Evaluate move list, ret best */
{
	tbestmove [cply] = 0;   	/* Init best move */
	tbestdir  [cply] = 0;
	if (ccolor == Black) {		/* Init best eval counter to lowest */
	  tbesteval [cply] = 32767;
	} else {
	  // tbesteval [cply] = windowlo;	/* -ve bad for white */
	  tbesteval [cply] = -32767;
	}

	for ( cmove = 1; (UINT) cmove <= nmoves; cmove++) {

	  picknextmove ();		/* PICK NEXT BEST EVAL */

	  qcrowned = 0;			/* Flag indicates crowning */
	  xbrd = mvbrd [cmove];		/* Get coord of piece, & dir */
	  xdir = mvdir [cmove];
	  xpiece = board [xbrd];	/* Piece to be moved */

	  toldpiece [cply] = xpiece;	/* Stash its val on stack */
	  tmbrd [cply] = xbrd;		/* Save moved loc/dir.. */
	  tmdir [cply] = xdir;
	  xdest = xbrd + xdir;
	  xindex = mvindex [cmove];

	  if (xbrd == 0) {	/* Null move, just eval board as is */
	    terminalnode ();
	    goto nullmove;
	  }

	  if (ccolor == Black) {
	    if (xbrd != blpos [xindex]) {prints ("Scan:"); listpos (); exit (0);}
	  } else {
	    if (xbrd != whpos [xindex]) {prints ("Scan:"); listpos (); exit (0);}
	  }
	  board [xbrd] = 0;
	  board [xdest] = xpiece;	  /* And place piece at new pos */

	  if (jumpflag == 0) {		/* En-prise ? */
	    if (xpiece == Bman && (board [xdest + xdir] & White) == 0) {
	      register int altdir;
	      altdir = 16 - xdir;
	      if (board [xdest + altdir] == Wman && board [xdest + altdir + altdir] == 0 && board [xdest - altdir]) {
		xweight -= 3;
		ccut -= 2;
	      }
	    }
	    if (xpiece == Wman && (board [xdest + xdir] & Black) == 0) {
	      register int altdir;
	      altdir = -16 - xdir;
	      if (board [xdest + altdir] == Bman && board [xdest + altdir + altdir] == 0
			&& board [xdest - altdir]) {
		xweight += 3;
		ccut -= 2;
	      }
	    }
	  }

	  if (knockflag && knockdown) {
	    ccut --;
	  }
	  knockdown = 0;
	  if (cply == 1) {		/* 1st ply factors.. */
	    if (varyflag == 1) {	/* Rand weight slightly */
	      xweight += rndoffset [(xbrd + xbrd + xdest) & 63];
	    }
	    if (prefflag && shortflag && shortflag < iqcutoff && doingshort == 0) {
	      temp = cmove;
	      if (temp > 5) temp = 5;
	      ccut += (temp >> 1);
	    }
	  }

	  if (xpiece & Black) {		/* Update weight for black ? */
	    blpos [xindex] = xdest;
	    if (xpiece == Bman) {
	      xweight += blmanweights [xbrd] - blmanweights [xdest] ;
	      /* if (crownsqrs [xdest] & Centmask) { */
		doblink (xbrd,manlink);		/* Break old links */
		doblink (xdest,-manlink);	/* Eval new links */
	    } else {
	      xweight += kingweights [xbrd] - kingweights [xdest] ;
	    }
	  } else {			/* Update weight for white ? */
	    whpos [xindex] = xdest;
	    if (xpiece == Wman) {
	      xweight += whmanweights [xdest] - whmanweights [xbrd];
	      /* if (crownsqrs [xdest] & Centmask) { */
		dowlink (xbrd,-manlink);
		dowlink (xdest,manlink);
	    } else {
	      xweight += kingweights [xdest] - kingweights [xbrd];
	    }
	  }

	  xcapt = xtaken = 0;
	  if (jumpflag) {		  /* Jump, so also take.. */
	    if (toldpiece [cply] & 1) {
	      xcapt = mvcapt [cmove];
	    } else {
	      xcapt = xbrd + (xdir >> 1);  /* Calc pos taken piece */
	    }
	    xtaken = board [xcapt];
	    #if Debug
	     if ((xtaken & ToggleWB) == 0) {
	      drawboard ();
	      pause (10);
	      gotoxy (1,1);
	      printsi ("XCAPT=",xcapt);
	      printsi (" Col=",ccolor);
	      viewlist (1,2,"NMOVES:");
	      exit (0);
	     }
	    #endif
	    piececount [xtaken] --;	  /* Decrease count for taken piece */
	    board [xcapt] = 0;

				/* Wipe weight val for taken piece */
	    if (xtaken & Black) {	/* Update weight for black ? */
	      Updateblpos (xcapt,xtaken,0)
	      capindex = temp;
	      if (xtaken == Bman) {
		xweight += blmanweights [xcapt] ;
		/* if (crownsqrs [xcapt] & Centmask) { */
		doblink (xcapt,manlink);		/* Break old links */
	      } else {
		xweight += kingweights [xcapt] ;
	      }

	    } else {			/* Update weight for white ? */
	      Updatewhpos (xcapt,xtaken,0)
	      capindex = temp;
	      if (xtaken == Wman) {
		xweight -= whmanweights [xcapt] ;
		/* if (crownsqrs [xcapt] & Centmask) { */
		dowlink (xcapt,-manlink);	/* Break old links */
	      } else {
		xweight -= kingweights [xcapt] ;
	      }
	    }
	  }
	  addleap (xcapt);	/* Save CAPT sqr.. */

			/* Ok, move done on board, save rest of bumph */

	  ttaken    [cply] = xtaken;
	  tcmove    [cply] = cmove;
	  twindlo [cply] = windowlo;
	  twindhi [cply] = windowhi;
	  tcapindex [cply] = capindex;

	  mvbrd += nmoves;	/* Inc move list ptrs */
	  mvdir += nmoves;
	  mvcapt += nmoves;
	  mveval += nmoves;
	  mvtot += nmoves;
	  mvindex += nmoves;

	  if (flyingkings) {
	    if (crownsqrs [xdest] & ccolor) {	/* CROWN.. */
	      if (xpiece == Bman ) {
		Nblkmen --;
		xpiece = Bking;
		Nblkking ++;
		qcrowned ++;
		ccut --;
	      }
	      if (xpiece == Wman ) {
		Nwhtmen --;
		xpiece = Wking;
		Nwhtking ++;
		qcrowned ++;
		ccut --;
	      }
	      board [xdest] = xpiece;	  /* And place piece at new pos */
	    }
	  }

 	  multijump = 0;
	  if (jumpflag) {    	/* See if multi-jump. EURO(&& qcrowned==0) */
	    jumpflag = 0;		/* Flag indicates that gen moves are jumps */
	    nmoves = 0;
	    tindex = xindex;
	    markleapsq (Greysq);
	    if (ccolor == Black) {		/* Whose go is it? */
	      gen1blkmov (xdest);	/* Gen legal black moves for QDEST*/
	    } else {
	      gen1whtmov (xdest);	/* Gen legal white moves for QDEST */
	    }
	    markleapsq (0);
	    if (jumpflag) {		/* Must be jumps to cont.. */
	      multijump = 1;
	    }
	  }

	  if (multijump == 0) {		/* End of Jump-Sequence? */
	   if (flyingkings == 0) {
	    if (crownsqrs [xdest] & ccolor) {	/* CROWN.. */
	      if (xpiece == Bman ) {
		Nblkmen --;
		xpiece = Bking;
		Nblkking ++;
		qcrowned ++;
	      }
	      if (xpiece == Wman ) {
		Nwhtmen --;
		xpiece = Wking;
		Nwhtking ++;
		qcrowned ++;
	      }
	      board [xdest] = xpiece;	  /* And place piece at new pos */
	    }
	   }
	   ccolor = ToggleWB - ccolor;
	  }

	  cply ++;
	  if (cply > Mply - 3) {
	    drawboard ();
	    prints ("SEARCH Ply overflow! Hit SPACE!");
	    while (getkey () != ' ');
	    for (temp = 1; temp < Mply; temp++) {
	      printsi (",",tmbrd [temp]);
	    }
	    exit (0);
	  }
	  compmove();		/* Recursively call next ply, return xeval. */
	  cply --;
	  nleap --;
	  ccut   = tccut  [cply] ;
	  ccolor = ToggleWB - tcolor [cply] ;

		/* Recall vars off stack */

	  xpiece = toldpiece [cply] ;
	  xtaken = ttaken [cply] ;
	  cmove  = tcmove [cply] ;

	  ccolor = tcolor [cply] ;
	  nmoves = tnomoves [cply] ;
	  ccut   = tccut    [cply] ;
	  xweight= tweight  [cply] ;	/* Reget running weight/time value */


	  mvbrd -= nmoves;	/* Dec move list ptrs */
	  mvdir -= nmoves;
	  mvcapt -= nmoves;
	  mveval -= nmoves;
	  mvtot -= nmoves;
	  mvindex -= nmoves;

	  jumpflag = tjumpflag [cply] ;

	  Nblkmen = tnblkmen   [cply] ;		/* Reget piece counts */
	  Nblkking = tnblkking [cply] ;
	  Nwhtmen = tnwhtmen   [cply] ;
	  Nwhtking = tnwhtking [cply] ;
	  windowlo = twindlo [cply] ;
	  windowhi = twindhi [cply] ;
	  capindex = tcapindex [cply];

					/* UNDO move */
	  xindex = mvindex [cmove];
	  xbrd = mvbrd [cmove];
	  xdir = mvdir [cmove];
	  xdest = xbrd + xdir;
	  board [xdest] = 0;	/* Wipe moved piece */
	  board [xbrd] = xpiece;	/* Restore old piece */
	  if (xtaken) {			/* Restore piece if taken */
	    if (xpiece & 1) {
	      xcapt = mvcapt [cmove];
	    } else {
	      xcapt = xbrd + (xdir >> 1) ;
	    }
	    board [xcapt] = xtaken;
	  }

	  if (ccolor == White) {	/* Restore piece-list */
	    whpos [xindex] = xbrd;
	    whtype [xindex] = xpiece;
	    if (xtaken) blpos [capindex] = xcapt;
	  } else {
	    blpos [xindex] = xbrd;
	    bltype [xindex] = xpiece;
	    if (xtaken) whpos [capindex] = xcapt;
	  }

	  if (aborted) return;		/* Was move aborted ? */

nullmove:
	  mveval [cmove] = xeval;	/* Save spot eval for short/sort */

	  if (trimflag) {   /* Trim window? */
	    if (ccolor == Black) {		/* Black.. */
	      if (xeval < windowhi)
		windowhi = xeval ;
	    } else {
	      if (xeval > windowlo)
		windowlo = xeval ;
	    }
	  }

	  if (ccolor == Black) {		/* See if better Black move found */
	    if (xeval < tbesteval [cply]) {
	      if (zapmove == 0) {
		tbesteval [cply] = xeval;
		tbestmove [cply] = xbrd;
		tbestdir  [cply] = xdir;
		if (cply < bestflag) {		/* Bestline ? */
		  int cline;
		  Bestline (cply,cply) = xbrd + ((xbrd + xdir) << 8);
		  cline = cply + 1;
		  while (cline < bestflag && (temp = Bestline (cply + 1,cline)) != 0) {
		    Bestline (cply,cline) = temp;
		    cline ++;
		  }
		  Bestline (cply,cline) = 0;
		}
	      }
		/* Save hash move & history stat ? */
	      if (ccut + hashflag < iqcutoff && hashflag && cmove > 1 && jumpflag == 0) {
	        hashtab [thashval [cply]] = xbrd + (xdest << 8);
		if (ccut + 20 < iqcutoff) {
		  if (xpiece == Bman) {
		    blmanweights [1 + xdest] ++;
		  } else {
		    kingweights [1 + xdest] ++;
		  }
		}
	      }
	      if (alphaflag && cply > shortply) {  	/* Alpha-beta cut? */
		if (xeval <= windowlo) {
		  nalphas ++; return;
		}
	      }
	    }
	  } else {			/* See if better White move found */
	    if (xeval > tbesteval [cply]) {
	      if (zapmove == 0) {
		tbesteval [cply] = xeval;
		tbestmove [cply] = xbrd;
		tbestdir  [cply] = xdir;
		if (cply < bestflag) {		/* Bestline ? */
		  int cline;
		  Bestline (cply,cply) = xbrd + ((xbrd + xdir) << 8);
		  cline = cply + 1;
		  while (cline < bestflag && (temp = Bestline (cply + 1,cline)) != 0) {
		    Bestline (cply,cline) = temp;
		    cline ++;
		  }
		  Bestline (cply,cline) = 0;
		}
	      }
		/* Save hash move & history stat ? */
	      if (ccut + hashflag < iqcutoff && hashflag && cmove > 1 && jumpflag == 0) {
	        hashtab [thashval [cply]] = xbrd + (xdest << 8);
		if (ccut + 20 < iqcutoff) {
		  if (xpiece == Wman) {
		    whmanweights [1 + xdest] ++;
		  } else {
		    kingweights [1 + xdest] ++;
		  }
		}
	      }
	      if (alphaflag && cply > shortply) {  	/* Alpha-beta cut? */
		if (xeval >= windowhi) {
		  nalphas ++; return;
		}
	      }
	    }
	  }

	 if (cply == 1) {			/* Iterate/think ? */
	  xtime = readtime () - fulltime;	/* Time so far */
	  inkey = 0;
	  if (thinkflag) {			/* Print stats */
	    if (debugflag || xtime > 20 || cmove == 1 || ((UINT) cmove == nmoves && xtime > 8)) {
	      showanal (0);
	    }
	  }

	  if (iterate && targetticks && xtime > targetticks) { /* Time up! */
	    temp = (itereval - tbesteval [1]) >> 1;	/* Dif in scores */
	    if (ccolor == Black) temp = -temp;
	    if (temp < 0) temp = 0;
	    if (temp > 2) temp ++;
	    if (temp > 29) temp = 29;
	    if (xtime > targettime * (18 + temp ) ) {
	      aborted = 2;
	      return;	/* Found move */
	    }
	  }
	  if (windowsize && iterate && timepermove) {	/* Window overflow */
	    if (tbesteval [1] <= awindlo || tbesteval [1] >= awindhi) {
	      retry = 1;
	      return;
	    }
	  }
	 }		/* End of PLY-1 jobs */

	}	/* End of Move-scan loop */

	xeval = tbesteval [cply];		/* Pass best eval back to prev ply */
}		/* All done, return to prev ply */

/* ------------------------------------------------------------------------------------------ */

void findcompmove()	/* Initialise stacks and call compmove */
			/* Multijump flag must be set up before call. */
			/* If set, no initial move table generated */
{
	Setink (2);
	halfshort = shortflag >> 1;
	doneeval = 0;
	lastbest = 0;
	aborted = 0;
	doingshort = 0;
	termnodes = 0;		/* Clear term node count */
	nkillers = 0;		/* Clear killer count */
	nalphas  = 0;		/* Clear alpha cut count */
	deepest = 0;		/* Deepest ply */
	initptrs ();		/* Init movelist pointers */
	cply = 1;
	ccut = 0;		/* Initialise running cutoff value */
	countpieces ();		/* Initialise piece-count vars */
	setvalpieces ();	/* Set value of piece combinations */
	initweights ();		/* Select king/man weight tables */
	debugline = 1;
	for (temp = 0; temp < 64; temp++) {
	  rndoffset [temp] = rand () % 3;
	}
	xweight = 0;		/* Initialise running weight value */
	if (multijump == 0) {	/* Has prev MOVE gen MULTI-JUMP moves ? */
	  GenerateMoves		/* Gen mv list */
	} else {
	  jumpflag = 1;
	}
	if (jumpflag && testflag == 0) {
	  filtergen ();		/* Scan jumps, del illegal */
	}
	if (nmoves == 0) return;
	if (nmoves == 1) {		/* Only one possible move */
	  tbestmove [1] = mvbrd [1];
	  tbestdir [1] = mvdir [1];
	  tbesteval [1] = 0;
	  tjumpflag [1] = jumpflag;
	} else {
	  compmove ();		/* Recursivly analyse tree till cutoff */
	}
	if (debugflag) {
	  getpal (15); gotoxy (1,25);
	  hitspace ();
	}
}

