	/* DYBKxx.C  DYNAMO inc file: sundry functions, book, etc */
	/* (C) A.Millett 1994-2024. */


void CODESEG newboard (int clrp)	/* Setup board & eval.. (1=Setup pieces) */
{
	bmult = boardx + 2; fsrand (0);
	maxboard = bmult * (boardy + 2) - 1;	/* Flip Board */
	dirul = - bmult - 1; dirur = - bmult + 1;
	dirdl = bmult - 1; dirdr = bmult + 1;
	dir2ul = dirul + dirul; dir2ur = dirur + dirur;
	dir2dl = dirdl + dirdl; dir2dr = dirdr + dirdr;
	for (xpos = 1; xpos <= 12; xpos ++) {
	  dirof [xpos * dirul & 511] = 1;
	  dirof [xpos * dirur & 511] = 2;
	  dirof [xpos * dirdl & 511] = 3;
	  dirof [xpos * dirdr & 511] = 4;
	}
	euroflag = 0;
	if (euron && boardx == 10 && boardy == 10 && cornmode == 0) euroflag = 1;
	portflag = 0;
	if (boardx == 8 && boardy == 8 && cornmode == 1) portflag = 1;
	poolflag = 0;
	if (boardx == 8 && boardy == 8 && cornmode == 0) poolflag = 1;
	automode = 0;
	alttotaltime = totaltime = 0;
	alttimermoves = timermoves = 0;
	fullgame = nleap = ngame = 0;
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  Setboard ( xpos, 0, Edge)
	  Setboard ( xpos, boardy + 1, Edge)
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    cpos = xpos + ypos * bmult;
	    sqnums [cpos] = crownsqrs [cpos] = 0;
	    temp = 0;
	    if (((ypos + xpos) & 1) == cornmode) temp = Edge;
	    Setboard ( xpos, ypos, temp)
	    if (ypos == 1) {
	      crownsqrs [cpos] = Black;
	    }
	    if (ypos == boardy) {
	      crownsqrs [cpos] = White;
	    }
	    if (ypos == 2 || ypos == 3) {
	      crownsqrs [cpos] |= C1black;
	    }
	    if (ypos == boardy - 1 || ypos == boardy - 2) {
	      crownsqrs [cpos] |= C1white;
	    }
	    if (ypos > 2 && xpos > 2 && ypos < boardy - 1 && xpos < boardx - 1) {
	      crownsqrs [cpos] |= Centmask;
	    }
	  }
	}
	for (ypos = 0; ypos <= boardy + 1; ypos ++) {
	  Setboard ( 0, ypos, Edge)
	  Setboard ( boardx + 1, ypos, Edge)
	}

	nsqrs = 0; cnum = 0;	/* Sqr numbering.. */
	if (numflag) {
	  for (xpos = 1; xpos <= maxboard; xpos ++) {
	    if (board [xpos] == 0) {
	      nsqrs ++;
	      cnum ++;
	      sqnums [xpos] = cnum;
	      sqpos [cnum] = xpos;
	    }
	  }
	} else {
	  for (xpos = maxboard; xpos; xpos --) {
	    if (board [xpos] == 0) {
	      nsqrs ++;
	      cnum ++;
	      sqnums [xpos] = cnum;
	      sqpos [cnum] = xpos;
	    }
	  }
	}
		// Calc 3 zones for weight analysis.. (also fill hashbrd)
	div3 = boardx / 3;
	zonesqrs [1] = zonesqrs [2] = zonesqrs [3] =0;
	for (xpos = 1; xpos < maxboard; xpos ++) {
	  hashboard [xpos] = (frand () << 1);
	  if (board [xpos] != Greysq) {
	    temp = xpos % bmult;		/* Column 1..boardx */
	    if (temp <= div3) {
	      temp = 1;
	    } else if (temp <= boardx - div3) {
	      temp = 2;
	    } else {
	      temp = 3;
	    }
	    zonesqrs [temp] ++;
	    zoneboard [xpos] = temp;	/* Divide into 3 vert zones */
	  }
	}
	zoneboard [0] = 0;
	for (xpos = 1; xpos <= 3; xpos ++) {
	  zonepercent [xpos] = (zonesqrs [xpos] * 100) / nsqrs;
	}
	hashboard [0] = 0;
	fsrand ((int) freadtime ());

	if (clrp) {	/* NEWBRD */
	  ccolor = White;
	  flyingkings = jumptype = 0;
	  backjumps = 1;
	  if (gametype == 2 || gametype == 3) jumptype = 1;
	  if (gametype == 1 || gametype == 5) backjumps = 0;
	  if (gametype == 3) flyingkings = 1;
	  if (gametype == 2 || gametype == 3)  {
	    ccolor = Black;
	  }
	  StartCol = ccolor;		// Start colour for game-type..
	  fullgame = 1;
	  temp = menperside;
	  xpos = 1;
	  while (xpos < maxboard / 2 && temp) {
	    if (board [xpos] == 0) {
	      board [xpos] = Wman;
	      temp --;
	    }
	    xpos ++;
	  }
	  temp = menperside;
	  xpos = bmult * boardy + boardx;
	  while (xpos > maxboard / 2 && temp) {
	    if (board [xpos] == 0) {
	      board [xpos] = Bman;
	      temp --;
	    }
	    xpos --;
	  }
	  	// Save init pos in quick-board array
	  for (xpos = 0; xpos < Mbrd - 5; xpos ++) {
	    qckbrd [xpos] = board [xpos];
	  }
	  qckcol = ccolor;
	}

		/* FIND Bridges/Oreo/Dogholes */

	corn1w = corn2w = corn1b = corn2b = board;
	temp = 2 + bmult;
	if (board [temp] == Greysq) {
	  temp ++;
	  doglw = board + temp - 2 + bmult + bmult;
	} else {
	  corn1w = board + temp;
	  corn2w = doglw = board + temp - 1 + bmult;
	}
	orl1w = keylw = board + temp;
	if (euroflag) orl1w += 2;
	orl2w = orl1w + 2; orl3w = orl1w + 1 + bmult;
	temp = boardx - 1 + bmult;
	if (board [temp] == Greysq) {
	  temp --;
	  dogrw = board + temp + 2 + bmult + bmult;
	} else {
	  corn1w = board + temp;
	  corn2w = dogrw = board + temp + 1 + bmult;
	}
	keyrw = board + temp;
	orr2w = keyrw - 2; orr3w = keyrw - 1 + bmult;

	temp = 2 + (bmult * boardy);
	if (board [temp] == Greysq) {
	  temp ++;
	  doglb = board + temp - 2 - bmult - bmult;
	} else {
	  corn1b = board + temp;
	  corn2b = doglb = board + temp - 1 - bmult;
	}
	keylb = board + temp;
	orl2b = keylb + 2; orl3b = keylb + 1 - bmult;
	temp = boardx - 1 + (bmult * boardy);
	if (board [temp] == Greysq) {
	  temp --;
	  dogrb = board + temp + 2 - bmult - bmult;
	} else {
	  corn1b = board + temp;
	  corn2b = dogrb = board + temp + 1 - bmult;
	}
	orr1b = keyrb = board + temp;
	if (euroflag) orr1b -= 2;
	orr2b = orr1b - 2; orr3b = orr1b - 1 - bmult;
	if (boardy > 8) {
	  Oreoval = Backval = Bridgeval = 5;
	} else {
	  Oreoval = Backval = 12;
	  Bridgeval = 18;
	}
	Dogval1 = Dogval2 = 10;
	if (boardx == boardy && (boardx & 1) == 0) {
	  if (cornmode) {	/* Hi val for 7th rank only */
	    Dogval2 = 32;
	  } else {
	    Dogval1 = 32;
	  }
	}
	if (boardy == 10) {
	  Dogval1 = Dogval2 = 12;
	}
}


void FastNewBoard ()	// Faster new-board..
{
	int xpos;
	for (xpos = 0; xpos < Mbrd - 5; xpos ++) {
	  board [xpos] = qckbrd [xpos];
	}
	ccolor = qckcol;
	nleap = 0; ngame = 0;
}

				/* MOVE LEGALITY & EXEC subs */
  // Full move legality check
  // (mfrom,mto) are abs board[] position locs.
  // ret 0 if illegal, move#in mvgen if ok.
int FASTCALL islegal (int mfrom, int mto)
{
	int cmove,tmove,tdir;
	initptrs ();		/* Init movelist pointers */
	buildpos ();		/* Build piece-lists */
	if ((board [mfrom] & ccolor) == 0) return (0);
	if (ngame > 0 && (mgame [ngame] & 255) == mfrom) {  /* MultiJump */
	  genforsq (mfrom);
	} else {
	  GenerateMoves		/* Gen move list */
	}
	if (jumpflag) {
	  if (testflag == 0) {   /* Scan jumps, del illegal */
	    filtergensq (mfrom);
	  }
	} else {
	  genforsq (mfrom);
	}
	if (nmoves == 0) return (0);	/* No moves, illegal.. */
	tmove = mfrom;
	tdir = mto - tmove;
	for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	  if (mvbrd [cmove] == tmove) {
	    if (mto < 0 || mvdir [cmove] == tdir) {
	      xcapt = mvcapt [cmove];
	      return (cmove);		/* Found it! */
	    }
	  }
	}
	return (0);	/* Not in list, illegal.. */
}

int lastjumpflag;

  // Execute move
  // (mfrom,mto) are abs board[] position locs.
  // dmode bit 0 for slow display, bit 1 enable display, bit 3=keep old moves
  // ret 1 if illegal, 0 if ok..
int FASTCALL doamove (int frombrd,int tobrd,int dmode)
{
	int cdir,ctemp,tpiece;
	int jumpbrd = 0;
	if (islegal (frombrd, tobrd) == 0) return (1);
				/* XCAPT also set.. */
	qcrowned = 0;		/* Crowning flag */
	cdir = tobrd - frombrd;
	tpiece = board [tobrd] = board [frombrd];
	board [frombrd] = 0;
	lastjumpflag = jumpflag;
	if (jumpflag) {
	  if (tpiece & 1) {
	    jumpbrd = xcapt;	/* From ISLEGAL.. */
	  } else {
	    jumpbrd = frombrd + (cdir >> 1);
	  }
	  /* gotoxy (1,25);printi (jumpbrd); */
	  board [jumpbrd] = 0;
	}
	addleap (jumpbrd);
	if (flyingkings) {
	  if ( (crownsqrs [tobrd] & ccolor) && (tpiece & 1) == 0) {
	    board [tobrd] = board [tobrd] | 1;	/* Crown it */
	    qcrowned ++;
	  }
	}
	multijump = 0;
	if (jumpflag) {			/* Multijump? */
	  multijump = 0;
	  buildpos ();		/* Build piece-lists */
	  genforsq (tobrd);		/* Gen moves for 1 sqr */
	  if (jumpflag)	{		/* Must be jumps to cont.. */
	    if (testflag == 0) {	/* Scan jumps, del illegal */
	      filtergen ();
	    }
	    multijump = 1;
	  }
	}
	if ( (crownsqrs [tobrd] & ccolor) && (tpiece & 1) == 0) {
	  if (multijump == 0 && flyingkings == 0) {
	    board [tobrd] = board [tobrd] | 1;	/* Crown it */
	    qcrowned ++;
	  }
	}
	if (dmode & 7) {
	  for (ctemp = 1; ctemp < 4; ctemp ++) {
	    gputat (frombrd, tpiece);
	    gputat (tobrd, 0);
	    if (soundflag) {
	      if ((dmode & 7) == 1) {
		soundit (100 + frombrd * 10, 1);
		spause (1);
	      } else {
		spause (1);
	      }
	    }
	    gputat (frombrd, 0);
	    gputat (tobrd, board [tobrd]);
	    if (soundflag) {
	      if ((dmode & 7) == 1) {
		spause (2);
	      } else {
		spause (1);
	      }
	    }
	  }
	  if (lastjumpflag) {
	    gputat (jumpbrd, 0);
	  }
	  if ((dmode & 7) > 1) ctemp ++;
	}
	if (ngame < Mgame-3) {		/* Save move in GAME[] */
	  ngame ++ ;
	  mgame [ngame] = (frombrd << 8) + tobrd;
	  if (!(dmode & 8)) {		// Wipe any old game stub..
	    mgame [ngame + 1] = 0;
	    mgame [ngame + 2] = 0;
	  }
	}
	#if Shareware
	  if (timepermove > 10 && ngame > 20) timepermove = 1;
	#endif
	return (0);
}

int rcchar,rchandle;
int rcptr;	/* Next char in buf */
int rcnum;	/* Num left in buffer.. */
#define Rcbuf 500
char rcbuf [Rcbuf + 5];

int FASTCALL fileopen (char *filename, int mode)
{						/* Load data from disk */
	rcnum = rcptr = 0;
	diskerror = 0;
	inr.x.dx = (unsigned int) filename;
	inr.h.ah = 0x3d;
	inr.h.al = mode;		/* 0=read,1=write,2=rnd */
	int86 (0x21,&inr,&outr);	/* INT 21, 3d OPEN */
	if (outr.x.cflag & 1) { 	/* Carry set ? */
	  diskerror ++;
	  return (0);
	}
	rchandle = outr.x.ax;
	return (rchandle);
}

int FASTCALL farread (void far *brddata,int datasize)    /* Ret # read */
{						/* Load data from disk */
	inr.x.bx = rchandle;
	inr.x.cx = datasize;
	inr.h.ah = 0x3f;
	inr.x.dx = FP_OFF (brddata);	/* Disk buffer */
	sregs.ds = FP_SEG (brddata);
	int86x (0x21,&inr,&outr,&sregs);	/* INT 21, 40 Write */
	return (outr.x.ax);		/* # read,0 if past end */
}

void fileclose ()
{
	inr.x.bx = rchandle;
	inr.h.ah = 0x3e;
	int86 (0x21,&inr,&outr);	/* INT 21, 3e CLOSE */
}

int readchar ()
{
	if (rcptr >= rcnum) {
	  rcnum = farread ((void far *) rcbuf,Rcbuf);
	  rcptr = 0;
	  if (rcnum == 0) return (-1);
	}
	temp = rcbuf [rcptr]; rcptr ++;
	return (temp);
}

		/* Opening Book routines */

int bookflag = 1;	/* Opening book flag */
int bookmove,bookdir;
int cbook;
long lbook;
char bookname [40] = "DBOOK.TXT";
#define EQ 1

int intbook [] = {0,
3228,0,
3328,0,
3329,0,
3429,0,
3228,1721,0,
3228,1923,0,
3228,2024,0,
3228,1823,0,
3228,2025,0,
3228,2024,3732,1823,4137,1318,3127,813,3731,1420,4641,208,4137,1014,0, /*Valneris2/92*/
3228,2024,3430,1420,3025,1014,3732,1823,4137,1721,3127,0, /* D0493/1.Ghestem*/
3228,2024,3430,1420,3732,1823,4137,1721,3127,1014,3025,2126,4034,2429,3324,2029,2940,0, /* D0493/2.Ghestem*/
3228,1923,2819,1423,3732,1014,4137,510,0,
3228,1923,2819,1423,3127,1014,3631,510,3732,1721,4136,2126,3328,2637,4231,1117,2819,1423,3933,711,4641,1014,4137,0, /* D0293/1.Weirsma*/
3228,1923,2819,1423,3732,1014,4137,1621,3530,2025,4741,2126,3228,2332,3728,2637,4132,1721,3024,1117,4641,611,4137,1116,0, /* D0293/9*/
3228,1923,2819,1423,3732,1014,3430,1721,3025,1117,3126,611,3530,2127,3221,1627,4137,1419,2514,920,3025,409,0, /* D1292/6.Katz*/
3228,1923,2819,1423,3127,1014,3631,510,3732,1419,3328,1014,3933,1722,2817,1122,3126,2231,2637,611,4439,1117,0, /* D1093/2b.*/
3228,1823,3832,1218,4338,712,4943,0,
3228,1823,3329,2332,3728,1924,3933,1419,4439,2025,2920,2514,4137,1218,3732,1923,2819,1423,3530,712,5044,1014,3025,1419,4641,1520,2514,0, /* D1093/4*/
3228,1823,3329,2332,3728,1318,3832,1923,2819,1423,4137,1722,4641,1117,3127,2231,3627,1014,3530,2025,3933,510,4035,611,4439,106,0, /* D0293/3*/
3228,1823,3832,1721,3127,1117,4338,2126,4943,611,3731,2637,4231,2329,3423,1722,0, /*Dam*/
3228,2025,3732,1823,0,
3228,2025,3320,1621,3126,1822,3933,1116,4439,1318,5044,913,0, /*Val2/92*/
3228,1721,3329,1923,2819,1324,2433,3928,913,4439,1117,5044,711,3933,0, /*Valneris2/92*/
3228,1721,3832,2126,4338,1117,4943,1721,3429,1823,2918,1223,3127,2024,4034,1420,4440,0, /* D0493/4.*/
3228,1721,3429,1923,2819,1423,2334,3930,1117,3126,711,4439,107,5044,0, /* D0493/5.Wiersma*/
3228,1721,3732,2126,4137,1923,2819,1423,4741,1117,3430,1014,4034,2025,3228,2332,3728,2637,0, /* D0293/6.Thoen*/
3228,1721,3329,2126,3933,1117,4439,611,5044,2025,3732,2637,4231,1923,2819,1423,4137,1014,4641,0, /* D0293/10.Vatoetin*/
3228,1721,3329,1923,2819,1324,2433,3928,913,3732,1419,4439,1014,5044,1117,3833,611,3530,2025,0, /* D1093/6.Delmotte*/
3228,1722,2817,1221,3126,712,2617,1221,3631,107,3126,712,2617,1221,3732,1117,4137,2126,0, /* D0293/4*/
3228,1722,2817,1221,3732,1923,4137,712,3530,2025,3329,1420,4035,1014,4440,107,5044,510,3126,0, /* D0293/7.Gantwerg*/
3228,1722,2817,1221,3430,712,4034,107,4540,2126,3025,1117,3127,711,3832,1923,4338,1419,2514,0, /* D1292/5.Der*/
3228,1621,3126,1116,3732,1822,4137,1318,3530,913,3025,711,3731,107,3127,2231,3627,409,4641,0, /* D1292/4.Dusseldorp*/
3329,1722,0,
3329,1923,0,
3329,1822,0,
3329,1722,3933,1117,4439,611,5044,106,3228,1923,0, /*Dam*/
3329,1722,3933,1117,4439,711,5044,107,3126,1621,3228,1923,2819,1423,3530,1014,3024,2328,3731,0, /* D1093/5.Keller*/
3329,1722,3933,1117,4439,611,5044,106,3228,1621,3126,3126,1923,2819,1423,3530,1014,3024,510,0, /* D0293/2.Moengue*/
3329,1722,3933,1117,4439,611,5044,106,3126,1621,3228,1923,2819,1423,3530,1014,0, /* D1292/2.Dolfing*/
3329,1722,3430,2025,3024,1930,3524,1117,3227,611,3732,106,4137,0,
3329,1923,3530,2025,4035,1419,3024,1930,3524,1722,3127,2231,3627,1117,3833,611,4540,1520,2415,2530,0, /* D1093/1.Clerc*/
3329,1923,3530,2025,3024,1722,3833,2228,3322,1827,2738,2918,1223,4233,1420,3328,2332,3728,2029,3423,0, /* D1292/1.Beljakin/TRUUS*/
3329,1822,3126,2025,2923,1928,3223,1419,2314,1019,0,
3328,0,
3328,1721,3933,2126,3127,1117,4439,1722,2817,1221,3328,712,3833,0, /*Valneris2/92*/
3328,1822,3833,1218,3429,712,4034,107,4540,1923,2819,0, /*Dam*/
3328,1822,3833,1218,3126,712,3731,1923,2819,1423,3227,2328,3429,107,3530,2025,2924,2534,4029,1014,0, /* D1093/2.Sijbrands*/
3328,1721,3933,2126,4439,1117,5044,611,3127,1823,3731,2637,0, /*Dam*/
3127,1923,3328,1721,0,
3126,1923,3631,1419,4136,1014,4641,510,3127,2024,3430,1420,0, /*Dam*/
3126,1823,3631,1218,4136,712,4641,207,3127,0, /*Dam*/
3227,1823,0,
3429,1923,3328,2334,4029,1721,4540,1419,0, /*Dam*/
3429,1923,4034,1419,3328,1722,2817,1122,3933,1014,4339,510,4843,711,4540,107,3126,2227,3221,1627,0, /*D1093/3*/
3429,1923,4034,1419,4540,1014,5045,510,3126,1722,3731,1117,4137,711,4641,107,3228,2332,3728,1823,0, /* D0293/5.*/
3429,1721,3126,2127,3221,1627,4034,1117,4540,1923,2924,2029,3324,611,3430,1419,3025,1930,2534,1116,0, /* D0293/8.Drente*/
3430,2025,3024,1930,3524,1822,3329,1420,0,
3530,2025,3329,1923,4035,1419,3024,1930,3524,914,4540,1520,2415,2530,3425,2334,3445,3228,1721,3732,0, /* D1293/3.Draat*/
 /* D=Damspel. Dam=Damocles */
0,0,0,0,0,0};

int spainbook [] = {0,
1014,0,
1013,2118,0,
1215,0,
1014,2218,1215,2320,510,2722,105,2016,0,
1014,2319,1423,2819,913,3228,1317,2823,0,
1014,2118,1421,2518,510,2319,1013,0,
1014,2320,1216,2015,1120,2415,0,
 0,0,0,0,0,0};

int poolbook [] = {0,
 1115,0,
 1116,0,
 914,2218,509,1815,1118,2117,1421,2314,1405,1216,2723,1620,2318,2027,3223,811,1814,1017,2522,0, /*Kap*/
 1115,2217,811,2522,1116,2419,1524,2819,711,1713,914,2217,1115,2925,1524,2720,2011,308,0, /*Kap37*/
 1115,2319,811,2723,1116,2420,1524,2027,408,2117,914,1713,1619,2316,1219,2521,811,2217,1015,0, /*Kap01 */
 1115,2319,711,2217,1116,1713,1623,2718,1811,815,2420,408,2522,811,2824,914,2217,307,3127,1418,0, /*Kap05*/
 1115,2217,1519,2415,1019,2316,1219,1714,918,2724,1923,2619,509,2420,914,2824,609,0, /*Kap36*/
 /*1115,2218,1522,2518,811,2925,408,2522,0,*/
 1115,2319,811,2217,1116,1713,1623,2619,914,3126,408,2522,1418,2623,0, /*{ KapPCWp110v2*/
 1116,2218,1014,2420,610,2011,815,1522,2617,408,2824,811,1713,106,3026,1115,2420,711,0, /*Kap10*/
 1116,2420,0,
 1116,2419,0,
 1116,2218,0,
 1014,2318,0,
 1015,2318,0,
 913,2218,0,
0,0,0,0,0,0};

#define Mbook 30000L
int far *book;
int far *bigbook;
int huge *headbigbook;
int bigtype = -1;	/* Type of play big book is for.. */
int nbook;
int bookpass;

int CODESEG convbook (int xbook)
{
	if (xbook < 0) xbook = -xbook;
	return ( (sqpos [xbook / 100] << 8) + sqpos [xbook % 100]);
}

void CODESEG findbookmove ()	/* Search for matching book-move */
{
	int cbook,cgame;
	bookmove = 0;
	book = (int far *) intbook;
	if ( ngame < 0 || fullgame == 0 || losemode || boardx != boardy) return;
	if (gametype && gametype < 6) {
	  if (boardx != 8 || menperside != 12) return;
	} else if (gametype == 6) {
	  if (boardx != 10 || menperside != 10) return;
	} else if (gametype == 7) {
	  if (boardx != 8 || menperside != 12) return;
	} else {
	  if (boardx != 10 || menperside != 20) return;
	}
	if (gametype == 1 || gametype == 5) {	/* Spain/Port games */
	  book = (int far *) spainbook;
	  if (cornmode == 0) return;
	} else {
	  if (cornmode) return;
	}
	if (gametype == 2 || gametype == 3 || gametype == 7) {
	  book = (int far *) poolbook;
	}
	if (bigtype >= 0 && gametype == bigtype) book = bigbook;

	bookpass = 0;
	for (cgame = 0; cgame <= ngame + 2; cgame ++) {
	  vgame [cgame] = mgame [cgame];
	}
	cbook = 1;
	while (book [cbook]) {
findloop:
	  cgame = 1;
	  while (cgame <= ngame && vgame [cgame] == convbook (book [cbook]) ) {
	    cgame ++;
	    cbook ++;
	  }
	  temp2 = book [cbook];
	  if (cgame > ngame && temp2 > 100) {	/* Matches book, move found.. */
	    bookmove = temp2;
	    if (frand () & 1) return;	/* 50% chance try another.. */
	  }
	  if (temp2 == EQ) {	/* Transposition.. */
	    for (temp2 = 1; temp2 < cgame; temp2 ++) {	/* Change GAME */
	      vgame [temp2] = convbook (book [cbook + temp2]);
	    }
	    bookpass ++;
	    if (bookpass > 30) return;	/* Closed loop.. */
	    cbook = 1; goto findloop;
	  }
	  while ( book [cbook]) {   /* Spool to next line */
	    cbook ++;
	  }
	  cbook ++;
	}
}


int bookch,bookch2;

void skipcomm ()
{
	while (bookch == '{') {	/* Skip further comment lines..*/
	  do {
	    bookch = readchar ();
	  } while (bookch != 13 && bookch > 0);
	  bookch = readchar ();
	  bookch = readchar ();
	}
}

void loadbook (char *filename)
{
	int temp;
	/*headbigbook = (int far *) ttbook;*/
	/*bigbook = headbigbook + 10;*/
	book = bigbook;
	bigbook [0] = 0;
	temp = 0;
	fileopen (filename,0);
	nbook = 0;
	if (diskerror) {
	  prints ("\nCannot open book!\n");
	  return;
	}

	bookch = readchar ();
	bookch2 = readchar ();
	if (bookch == 55 && bookch2 == 55) {	/* Binary book */
	  fileclose ();
	  farloaddata (filename,headbigbook, (UINT) (Mbook + Mbook));
	  if (diskerror) return;
	  nbook = headbigbook [1];
	  printsi ("\nBook size = ",nbook);
	  return;
	}
	if (bookch != '=' || isdigit (bookch2) == 0) {
	  prints ("\nBook format error!\n");
	  return;
	}
	bigtype = bookch2 - 48;
	readchar (); readchar ();
	bookch = readchar ();
	while (isdigit (bookch )) {
	  temp = 0;
	  while (isdigit (bookch)) {
	    temp = temp * 10 + bookch - 48;
	    bookch = readchar ();
	  }
	  if (bookch == '?') {
	    temp = -temp;
	    bookch = readchar ();
	  }
	  nbook ++;
	  bigbook [nbook] = temp;
	  if (bookch == ',') {
	    bookch = readchar ();
	  } else if (bookch == '=') {	/* Transpose */
	    bookch = readchar ();
	    nbook ++;
	    bigbook [nbook] = 1;
	  } else if (bookch == 13 && readchar () == 10) {
	    nbook ++;
	    bigbook [nbook] = 0;
	    bookch = readchar ();
	    skipcomm ();
	  }
	  if (bookch == '{') {	/* Comment.. */
	    do {
	      bookch = readchar ();
	    } while (bookch != '}' && bookch != 13 && bookch > 0);
	    bookch = readchar ();
	    if (bookch == 10) {
	      nbook ++;
	      bigbook [nbook] = 0;
	      bookch = readchar ();
	      if (bookch == '*') {	/* Continuation */
		nbook --; bookch = readchar ();
	      }
	      skipcomm ();	/* Skip further comment lines..*/
	    }
	  }
	  if (bookch == ',') bookch = readchar ();
	}
	if (bookch != '.' && readchar () != 'e') {
	  prints ("\nError in "); prints (filename);
	  printsi (" at ",nbook); prints ("  (..");
	  for (cbook = nbook - 6; cbook <= nbook; cbook ++) {
	    printsi (",",book [cbook]);
	  }
	  prints (")\n");
	  hitspace ();
	  nbook = 0; bigtype = -1;
	  fileclose ();
	  return;
	}
	fileclose ();
	bigbook [nbook + 1] = 0;
	headbigbook [0] = 14135;
	headbigbook [1] = nbook;
	headbigbook [2] = bigtype;
	prints ("\nLoaded "); prints (filename);
	printsi (", size=",nbook);
	prints ("\n");
}

#if Deluxe
void searchbook (int validate)
{
	static int oldngame,oldfullgame,linecount,lastfound;
	unsigned cbook,tbook;
	static unsigned linestart;
	static int xbook,cgame;
	clrvdu (); getpal (10);
	prints (
  "WARNING - This function may lose game-moves played - Hit ESC and save\n"
  "game before using this function.\n\n");
	if (validate) {
	  prints ("Ready to VALIDATE book moves, and display any errors - Hit SPACE..\n\n");
	  ptemp = 0;
	  do {
	    inkey = getkey (); if (inkey == 27) return;
	  } while (inkey != ' ');
	} else {
	  prints ("Ready to search book for current board position..\n\n"
	  "Output to Screen or Printer (s,p, ESC) ?\n\n");
	  printboard (0);
	}
	if (inkey == 27) return;
	getpal (7);
	prints ("\n\nSearching..\n");
	for (cgame = 0; cgame <= ngame + 2; cgame ++) {
	  vgame [cgame] = mgame [cgame];
	}
	oldngame = ngame; oldfullgame = fullgame; cbook = 1;
	saveinitbrd ();
	initcolor = ccolor;
	linecount = 0; lastfound = 0;
	while (book [cbook]) {
	  linestart = cbook;
	  linecount ++;
	  if (getkey () == 27) break;
	  FastNewBoard ();
	  fullgame = 1;
	  do {
	    xbook = book [cbook];
	    if (xbook < 0) xbook = - xbook;
	    movefrom = sqpos [xbook /100];
	    moveto = sqpos [xbook % 100];
	    ccolor = ToggleWB & board [movefrom];
	    if (doamove (movefrom, moveto, 8) == 1) { /* Bad book move */
	      if (validate) {
		printsi ("Line=",linecount); printc (':');
		for (tbook = linestart; tbook < cbook; tbook ++) {
		 printi (book [tbook]); printc (',');
		}
		prints (" ERROR=> ");
		while (book [tbook] && tbook < cbook + 10) {
		  if (book [tbook] == EQ) {
		    prints (" = ");
		  } else {
		    printsi (",",book [tbook]);
		  }
		  tbook ++;
		}
		prints ("\n");
	      }
	      break ;
	    }
	    cbook ++;
	    if (validate == 0) {
	      csqr = 0;
	      do {	/* Position match ? */
		csqr ++;
		temp = sqpos [csqr];
	      } while (csqr <= nsqrs && board [temp] == initbrd [temp]);
	      if (csqr > nsqrs) {	/* Match found ! */
		for (tbook = linestart; tbook < cbook; tbook ++) {
		  if (book [tbook] != book [tbook - linestart + lastfound]) break;
		}
		if (tbook < cbook) {	/* Not same as last, print.. */
		  tprintflag = ptemp;
		  printsi ("Line=",linecount); printc (':');
		  for (tbook = linestart; tbook < cbook; tbook ++) {
		   printi (book [tbook]); printc (',');
		  }
		  prints (" *HERE* ");
		  while (book [tbook] && tbook < cbook + 7) {
		    if (book [tbook] == EQ) {
		      prints (" = ");
		    } else {
		      printsi (",",book [tbook]);
		    }
		    tbook ++;
		  }
		  prints ("\n");
		  tprintflag = 0;
		  lastfound = linestart;
		}
	      }
	    }
	  } while (book [cbook] > 100);
	  while (book [cbook]) cbook ++;
	  cbook ++;
	}
	totaltime = 0; timermoves = 0;
	if (oldfullgame) {	/* Reget game moves */
	  fullgame = 1; ngame = oldngame;
	  for (cgame = 0; cgame <= ngame + 2; cgame ++) {
	    mgame [cgame] = vgame [cgame];
	  }
	  spoolgame (ngame);	/* Reget board pos */
	} else {
	  fullgame = 0; ngame = 0; spoolgame (0);
	}
	nleap = 0;
	hitspace ();
}
#endif

#if Debug
void printtab (int *ctab)
{
	int xpos,ypos;
	for (ypos = 1; ypos <= boardy; ypos ++) {
	  for (xpos = 1; xpos <= boardx; xpos ++) {
	    nprint = 0;
	    printi (ctab [xpos + ypos * bmult]);
	    rjust (5);
	  }
	  prints ("\n");
	}
}

void viewlist (int xp, int yp, char *istr)
{
	UINT temp;
	gotoxy (xp,yp); prints (istr); printi (nmoves);
	for (temp = 1; temp <= nmoves; temp ++) {
	  gotoxy (xp,yp + temp);
	  printsi ("Mv:",temp);
	  printsi (", Brd:",mvbrd [temp]);
	  printsi (", Dir:",mvdir [temp]);
	  printsi ("/",dirof [mvdir [temp] & 511]);
	  printsi (", Cap:",mvcapt [temp]);
	  printsi (", Tot:",mvtot [temp]);
	}
	gotoxy (xp,yp + temp);
	prints ("----------------");
}

long tcount;

void tester ()		/* Do some tests.. */
{
	initptrs ();
	countpieces ();
	jumpflag = 0;
	buildpos ();		/* Build piece-lists */
	genblackmoves ();
	curjumps = cply;
	if (jumpflag && testflag == 0) recurgen ();
	viewlist (1,1,"Blk. NMOVES=");
	jumpflag = 0;
	genwhitemoves ();
	if (jumpflag && testflag == 0) recurgen ();
	viewlist (40,1,"Wht. NMOVES=");
	do {
	  inkey = getkey ();
	  if (inkey == 27) return;
	} while (inkey != ' ');
	prints ("\nWman weights (1,1..max)\n");
	printtab (whmanweights);
	prints ("Bman weights\n");
	printtab (blmanweights);
	while (getkey () != ' ');
	prints ("K weights\n");
	printtab (kingweights);
	xweight = 0; terminalnode ();
	printsi ("\n(RET=IQ,C=Crown,H=History) XEVAL=",xeval);
	do {
	  inkey = getkey ();
	  if (inkey == 27) return;
	  if (inkey == 'c') {
	    printtab (crownsqrs);
	  }
	  if (inkey == 'h') {
	    prints ("Wman hist\n");
	    printtab (whmanweights + 1);
	    prints ("Bman hist\n");
	    printtab (blmanweights + 1);
	    while (getkey () != ' ');
	    prints ("K hist\n");
	    printtab (kingweights + 1);
	  }
	  if (inkey == 1) {
	    for (temp = 0; temp <= ngame; temp ++) {
	      printsi (",",leapsq [temp]);
	    }
	  }
	  if (inkey == 2) {
	    markleapsq (Greysq);
	  }
	  if (inkey == 3) {
	    markleapsq (0);
	  }
	} while (inkey != ' ');
	buildpos ();		/* Build piece-lists */
	prints ("\n200,000 blk mvgens..(1/10sec) = ");
	xtime = readtime ();
	for (tcount = 1; tcount <= 200000; tcount ++) {
	  jumpflag = 0;
	  genblackmoves ();
	  if (jumpflag && testflag == 0) recurgen ();
	}
	printl (((readtime () - xtime) * 100) / 182);
	prints ("\n200,000 blk jumpgens..(1/10sec) = ");
	xtime = readtime ();
	for (tcount = 1; tcount <= 200000; tcount ++) {
	  genblackjumps ();
	  if (jumpflag && testflag == 0) recurgen ();
	}
	printl (((readtime () - xtime) * 100) / 182);
	while (getkey () != ' ');
}
#endif		/* DEBUG */

int PalBuf [48];	// Temp buf for palette vars..
int PalOff [] = {0,21,45,18,42,9,27,33,-1};
	// PALETTE DIALOG controls
TBUTTONINFO iPALETTE [30] = {
 184, 120, 64,22, 13,13,  NULL,3,		// Text button (OK)
 376, 120, 72,22, 27,27,  NULL,3,		// Text button (CANCEL)
 DISABLE,0,0,0,0,0,NULL,0			// (SPINS AUTO-FILLED HERE)
};

TBUTTONHEADER hdPALETTE = {	// Descriptive header..
 iPALETTE,			// Struct with button details..
 0,0,				// topleft of toolbox (set by prog)
 0,0,	 			// size of bmp
 624,160, 			// Mouse-activity area
 NULL,				// no Bitmap of tools..
 0,0,0,				// no Info-display area..
 "",0,0,0,0,			// no edit field
 "\0OK\0\0RESET\0\0\x01",	// End of strings..
};


void UpdatePalette ()
{
	int cspin;
	for (cspin = 0; cspin < 48; cspin ++) {  // Copy orig colours..
	  palz [cspin] = PalBuf [cspin];
	}
	loadvgapal (palz);	// Load in 16 RGB colours..
}

	// Dialog box to set palettes..
void DlgPalette ()
{
	TBUTTONINFO *iPAL;
	int cspin,ccol;
	long ctick = 0;
	for (cspin = 0; cspin < 48; cspin ++) {  // Copy orig colours..
	  PalBuf [cspin] = palz [cspin];
	}
	iPAL = &iPALETTE [2];
	for (cspin = 0; cspin <= 7; cspin ++) {
	  for (ccol = 0; ccol <= 2; ccol ++) {
	    iPAL->x = cspin * 80 + 8;
	    iPAL->y = ccol * 30;
	    iPAL->lx = iPAL->ly = 0;
	    iPAL->type = DLGSPIN;
	    iPAL->lkey = 0;
	    iPAL->rkey = 63;
	    iPAL->var = &PalBuf [PalOff [cspin] + ccol];
	    iPAL ++;	// Next palette entry..
	  }
	}
	iPAL->x = DISABLE;	// TERMINATE END_TAG ON DLG-CTRLS..
	msgPrintf (PRNRET | 80,280,&hdPALETTE,"%s",STdlgpalette);
	do {
	  inkey = ProcessToolKey (&hdPALETTE,2);	// Read button/keystroke..
	  if (ctick != readtime () && ActionHit) {
	    ctick = readtime ();
	    UpdatePalette ();
	  }
	} while (inkey != 13 && inkey != 27);
	UpdatePalette ();
	if (inkey == 27) palReset ();
}

char *GameTypeStr ()		// Ret ptr to current game type-string..
{
    char *cstr = STgametypestr + 1; 
    int ctype = gametype;
    while (ctype) {		// Scan to find game string
      while (*cstr) cstr ++;
      cstr ++;
      ctype --;
    }
    return (cstr);
}

void statline ()		/* Update status line */
{
	char *cstr;
	ProcessToolKey (&hdTools,0);	// Redraw tool box..
	if (twoplaymode) {
	  cstr = ST2player;
	} else {
	  cstr = "           ";
	}
	MoveBox (1);
	prnat (rmarg,24,-1,PRNSTAT,cstr);
	if (inflag) {
	  prnat (rmarg,25,-1,PRNSTAT,STinfinite);
	} else {
	  printfat (rmarg,25,-1,PRNSTAT,STtimeshow,timepermove);
	}
	if (ccolor == White) {
	  cstr = STwhitemove;
	} else {
	  cstr = STblackmove;
	}
	prnat (rmarg,21,-1,PRNSTAT,cstr);
	printfat (rmarg,23,-1,PRNSTAT,"Cursor:%s=%d  ", 
	printpos (pxpos,pypos),sqnums [pxpos + pypos * bmult]);
}

void printaflag (char *istr, int cflag)
{
	if (cflag == 0) {
	  printfat (rmarg,22,-1,PRNRED,"%sOff",istr);
	} else if (cflag == 1) {
	  printfat (rmarg,22,-1,PRNRED,"%sOn ",istr);
	} else {
	  printfat (rmarg,22,-1,PRNRED,"%s%d",cflag - 2);
	}
	dink ();
}

void SideMessage (char *istr)
{
	printfat (rmarg,22,-1,PRNRED,"%15s",istr);
}

void newautogame ()	/* Start a new auto game */
{
	int csqr;
	getpal (10);
	gotoxy (1,1); printsi ("W.Win",nww);
	printsi (" B.win",nbw); printsi (" Drawn",ndr);
	pause (50); newboard (1);
	if (rand () & 1) ccolor = White;
	csqr = 1 + rand () % menperside;	/* 19 man game.. */
	board [sqpos [csqr]] = board [sqpos [nsqrs + 1 - csqr]] = 0;
	drawboard ();
	automode = 1;
}

void setautogame ()	/* Set params for auto-games.. */
{
	int qpar;
	autopar = 0;
	clrvdu (); getpal (2);
	autogames = 0;
	prints ("Select Parameter key (A..Z)\n");
	do {
	  qpar = toupper (getkey ());
	  if (qpar == 27) return;
	} while (isalpha (qpar) == 0);
	promptin (50,100,"\nEnter White Value :",szTemp,4);
	if (inkey == 27) return;
	wval = atoi(szTemp);
	promptin (50,100,"\nEnter Black Value :",szTemp,4);
	if (inkey == 27) return;
	bval = atoi(szTemp); autopar = qpar; bookflag = 0;
	autogames = 1; nww = nbw = ndr = 0;
	automode = 1; cmdkey = '=';
	srand ((int) readtime ());
	newautogame ();
}

void swaptimes ()	/* Swap Wht/Blk times */
{
	static int temp; static long ltemp;
	temp = timermoves; timermoves = alttimermoves; alttimermoves = temp;
	ltemp = totaltime; totaltime = alttotaltime; alttotaltime = ltemp;
}

void execcompmove ()		/* Find and execute comp move */
{
      if (autogames) {
	swaptimes ();
	if (ccolor == Black) {
	  setparameters (autopar,bval);
	} else {
	  setparameters (autopar,wval);
	}
	if (autogames && ngame > 110 && (ngame > 180 || abs (itereval) < 20)) {
	  if (itereval < -150) {
	    nbw ++;
	  } else if (itereval > 150) {
	    nww ++;
	  } else {
	    ndr ++;
	  }
	  newautogame ();
	}
      }
      statline ();
      targettime = timepermove;
      targetticks = (targettime * 182) / 10;
      if (timemode && timermoves && timepermove) {	/* Av over game.. */
	targettime = ((timermoves * timepermove) - totaltime) * 2;
	if (fullgame && ngame < 15) targettime = targettime / 2;
	targettime += timepermove * 9;
	if (targettime < 7 * timepermove) targettime = 7 * timepermove;
	if (targettime > 20 * timepermove) targettime = 20 * timepermove;
	targetticks = (targettime * 182) / 100;
	targettime = targettime / 10;
      }

      zapticks = (targetticks * 5) / 2;	/* Kill off search time */
      if (inflag) {	/* Infinite search */
	targetticks = zapticks = 999999999; targettime = zapticks / 18;
      }
      resignflag = 0;		/* This is set if computer resigns */
      multijump = 0;		/* Initialise jump status for 1st ply */

      extime = readtime ();	/* Overall move exec time */
      if (hashflag) {
	hashptr = hashtab;
	for (lhash = 0; lhash < hashsize; lhash ++) {
	  hashptr [0] = 0;
	  hashptr ++;
	}
      }
      initptrs ();		/* Init movelist pointers */
      buildpos ();		/* Build piece-lists */
      GenerateMoves
      countpieces ();		/* Initialise piece-count vars */

      do {				/* Loop for Multi-jump */
	buildpos ();		/* Build piece-lists */
	zapcount = zapmove = zapiq = 0;
	fulltime = readtime ();
	windowlo = -32767; windowhi = 32767;
	for (cmove = 1; cmove < Mply - 4; cmove ++)	/* Clr killers */
	  tbestmove [cmove] = 0;

	aborted = 0;
	if (bookflag) {		/* BOOK-MOVE ? */
	  findbookmove ();
	  if (bookmove ) {
	    movefrom = sqpos [bookmove / 100];
	    moveto = sqpos [bookmove % 100];
	    movedir = moveto - movefrom;
	    tbestmove [1] = movefrom;
	    tbestdir [1] = movedir;
	    tbesteval [1] = 0;
	    tjumpflag [1] = 0;
	    if (islegal (movefrom,moveto)) {
	      if (getkey () == 27)
		aborted ++;
	      tjumpflag [1] = jumpflag;
	      goto dobook;
	    } else {
	      Beep
	      SideMessage ("Bad Book!");
	    }
	  }
	}
	bookmove = 0;
	findcompmove ();		/* Find sage move for pos */
	if (nmoves == 0) {
	  resignflag = 1;
	  SideMessage (STyouwin);
	  Beep
	  automode = 0;
	  if (autogames) {
	    if (ccolor == Black) { nww ++;
	    } else { nbw ++;
	    }
	    newautogame ();
	  }
	  return;
	}

dobook:
	if (aborted == 1) {	/* Abort key hit ? */
	  automode = 0;
	  ccolor = ToggleWB - ccolor;
	  click ();
	  while (getkey () == 27);
	  return;
	}
	fulltime = readtime () - fulltime;	/* Calc sage move time */
	otime = (10 * fulltime) / 182;
						/* Time regulation on? */
	totaltime += otime ;

	movefrom = tbestmove [1];
	moveto = movefrom + tbestdir [1];
	printfat (rmarg,26,79,PRNSTAT,"(%d/%lu)",timermoves + 1, totaltime);
	showanal (2);		// Final analysis..
	//printwsidei ("#Mov: ",timermoves + 1,Rstat + 6);
	//printwside ("#Sec: ",Rstat + 7); printl (totaltime);
	//printwside ("Sec: ",Rstat + 2); printl (otime);
	//printwside ("Pos: ",Rstat + 3); printl (termnodes);
	//Setink (15);
	//printwside ("Best: ",Rstat + 4);
	//printmove (tbestmove[1],tbestdir [1]); printc (32);
	//printwside ("Eval: ",Rstat + 5); printi (tbesteval [1]);
	//printwside ("",Rstat + 6);

	piecewas = board [movefrom];		/* Save old piece val */

	if ( doamove (movefrom,moveto,1) ) {	  /* Do move on board */
	  printsi ("BUG! HIT SPC! BAD comp move :",movefrom);
	  printsi ("-",moveto);
	  while (getkey () != ' ');
	  return ;
	}
	if (multijump) {
	  continue;		/* OK, Do next multijump */
	}
	break;			/* Otherwise not multijump */
      } while (1);		/* End of multijump loop */
      extime = readtime () - extime;
      timermoves ++;
}

void getdir (int cpos)
{
	xdir = hxdir [cpos];		/* Get dir moved */
	ydir = hydir [cpos];
	if (boardflip) {
	  xdir =- xdir; ydir =- ydir;
	}
}

void flashmoves (int cstate)
{
	int cmove,xpiece,xp2;
	xpiece = board [mvbrd [1]]; xp2 = 0;
	if (cstate) {
	  xp2 = xpiece; xpiece = 0;
	}
	gputat (mvbrd [1], xpiece);
	for (cmove = 1; (UINT) cmove <= nmoves; cmove++) {
	  gputat (mvbrd [cmove] + mvdir [cmove], xp2);
	}
}

int msto,kmove,hcount;

void humanside (int mode)
{
	if (mode) {
	  hidemouse ();
	  flashmoves (1);
	  if (kmove) {
	    bputat (pxpos,pypos,Gcur);
	    printside ("Select Target",20);
	    printside ("& hit Return",21);
	  } else {
	    printside ("Select Direction",20);
	    printside ("(Hit 1,3,7,9)",21);
	  }
	  showmouse ();
	} else {
	  hidemouse ();
	  flashmoves (0);
	  if (kmove) {
	    bputat (pxpos,pypos,-1);
	  }
	  printwside ("",20);
	  printwside ("",21);
	  showmouse ();
	}
}

int humanmove ()
{
      int cdir;
      movefrom = pxpos + pypos * bmult;
      if (islegal (movefrom,-1) == 0) {	/* No possibles */
	getpal (12);
	if (jumpflag) {
	  printwside ("YOU MUST JUMP!",21);
	} else {
	  printwside ("BAD MOVE!",21);
	}
	return (0);
      }
      if ((board [movefrom] & ccolor) == 0) return (0);
      genforsq (movefrom);		/* Gen moves for 1 sqr */
      do {				/* Multi jump loop */
	if (jumpflag && testflag == 0) {   /* Scan jumps, del illegal */
	  filtergen ();
	}
	printwside ("",21);
	if (nmoves == 0) {
	  return (0);
	}
	kmove = (board [movefrom] & 1);		/* Flag King-move */
	hcount = 0;			/* Count ticks.. */
	showmouse ();
	do {
	  if (nmoves == 1) {		/* Do it! */
	    inkey = -1;
	    cdir = mvdir [1];
	    break;
	  }
	  inkey = getkey ();
	  if (hcount == 1) {
	    soundit (100 + (pxpos + pypos) * 50,2);
	    humanside (1);
	  } else {
	    spause (2);
	  }
	  if (hcount == 9) humanside (0);		/* Disp Info */
	  hcount ++;
	  if (hcount > 15) hcount = 0;
	  if (inkey == 27 || inkey == 32) { humanside (0); return (0); }
	  kcmd = inchr ("12346789OPQKMGHI",inkey);
	  if (kmove) {			/* Cursor select KING DEST */
	    if (kcmd > -1) {
	      if (kcmd > 7) kcmd -= 8;
	      if (kcmd < 8) {
		if (hcount > 0) humanside (0);
		bputat (pxpos,pypos,-1);
		getdir (kcmd);		/* Get x/ydir */
		pxpos += xdir; pypos += ydir;
		if (pxpos < 1 || pypos < 1 || pxpos > boardx || pypos > boardy) {
		  pxpos -= xdir; pypos -= ydir;
		}
		bputat (pxpos,pypos,Gcur);
		hcount = -25;
		kcmd = -1;
		continue;
	      }
	    }
	    if (inkey == 13) {
	      inkey = -1;
	      cdir = (pxpos + pypos * bmult) - movefrom;
	      break;
	    }
	  } else {		/* Man move.. */
	    if (inkey == 13) { humanside (0); return (0); }
	  }
	  if (getmouse () == 1) {		/* Left button */
	    msto = mouse2sqr (mousex, mousey);
	    if (msto && msto != movefrom) {	/* Legal move.. */
	      inkey = -1;
	      cdir = msto - movefrom;
	      break;
	    }
	  }
	} while (kcmd < 0 );
	humanside (0);
	hidemouse ();
	if (kcmd > 7) kcmd -= 8;
	if (inkey > 0) {
	  getdir (kcmd);		/* Get x/ydir */
	  cdir = xdir + ydir * bmult;
	  if (jumpflag) cdir += cdir;
	}
	moveto = movefrom + cdir;
	printwside ("Move:",21);
	printmove (movefrom,cdir);
	if (doamove (movefrom, moveto, 1)) {
	  return (0);
	}
	if (multijump) {	/* Multijump? */
	  movefrom = moveto;
	  pxpos = movefrom % bmult;
	  pypos = movefrom / bmult;
	  continue;		/* OK, Do next multijump */
	}
	return (1);		/* Otherwise done */
      } while (1);		/* End of multijump loop */
}

void displaymodes ()
{
	printsi ("\n/S: Short look-ahead stops @ IQ ",shortflag);
	printsi ("\n/K: Killer mode = ",killerflag);
	printsi ("\n/P: Deep-scan pref-moves = ",prefflag);
	printsi ("\n/V: Varied play mode = ",varyflag);
	printsi ("\n/B: Opening book mode = ",bookflag);
	printsi ("\n/D: End-game Database = ",usedb);
	printsi ("\n/A: Bestline display = ",bestflag);
	printsi ("\n/G: Doublegen = ",gen2flag);
	printsi ("\n/X: Extend Prime Variant = ",pvflag);
	printsi ("\n/C: Extend Crown Search= ",crownflag);
	printsi ("\n/E: Extend forced seq= ",enpriseflag);
	#if Deluxe
	 printsi ("\n/M: Man Value = ",manvalue); printsi (", /N: 1st King val = ",kingvalue);
	 printsi ("\n/Z: Book variety = ",bookrand); prints ("% (100=best only... 40=variety");
	 printsi ("\n/U: Upper IQ limit = ",maxiq);
	 printsi (", /H: Hash table mode/depth = ",hashflag);
	#endif
	printsi ("\n/W: Window size = ",windowsize);
	printsi ("\n/I:IQ level = ",iqcutoff);
	printsl (",  /T: Time per move = ",timepermove);
	printsl ("\n(Last move = ",(100 * fulltime) / 182);
	prints ("/10 sec.)");
}

void setparameters (int inparam, int inval)
{
      static int parakey;
      do {
	if (inparam > 0) {
	  parakey = inparam;
	} else {
	  srand (0);
	  clrvdu ();
	  displaymodes ();
	  prints ("\n\nAlter Parameter - Which One (a-z,ESC) ? ");
	  do {
	    parakey = getkey ();
	    if (parakey == 27 || parakey == 13) return;
	    if (parakey > 'Z') parakey -= 32;
	  } while (parakey < 'A' || parakey > 'Z');
	  printc (parakey);
	  prints ("\nEnter New Value :");
	  linput (szTemp,4);
	  if (inkey == 27) return;
	  inval = atoi(szTemp);
	}
	if (parakey == 'A') bestflag = inval;
	if (parakey == 'S') shortflag = inval;
	if (parakey == 'K') killerflag = inval;
	if (parakey == 'P') prefflag = inval;
	if (parakey == 'R') srand ( inval % 37);
	if (parakey == 'V') varyflag = inval;
	if (parakey == 'B') bookflag = inval;
	if (parakey == 'D') usedb = inval;
	if (parakey == 'I') iqcutoff = inval;
	if (parakey == 'T') timepermove = inval;
	if (parakey == 'G') gen2flag = inval;
	if (parakey == 'E') enpriseflag = inval;
	if (parakey == 'U') euron = inval;
	if (parakey == 'X') pvflag = inval;
	if (parakey == 'C') crownflag = inval;
	if (parakey == 'M') manvalue = max (inval,40);
	if (parakey == 'N') kingvalue = max (inval,120);
	if (parakey == 'Z') bookrand = max (inval,25);
	if (parakey == 'U') maxiq = inval;
	if (parakey == 'H' && hashtab != NULL) hashflag = inval;
	if (parakey == 'W') windowsize = inval;
	if (inparam > 0) return;
      } while (1);
}

