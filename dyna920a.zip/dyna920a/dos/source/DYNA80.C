  /*  DYNAMO-DRAUGHTS - EUROPEAN CHECKERS game */
  /* Copyright A.Millett, 1990-2024. */

/* History:- Take BLITZ22 (23.3.92 (EXE=36774) Onto WtPC May 92))
 Imp experimental EURO flag, Change mvgenerators. -> BLITZ23, 28.3.92
 Imp REPLAY/SAVE/LOAD game -> BLITZ24, 29.3.92
 Split out separate EURO version. Imp KING-MOVE generators,
 conv DOAMOVE, Imp MVCAPT & assort.
-> EURO10, 29-30.3.92
 Imp RECURGEN and FILTERGEN - gen FULLY LEGAL jumps, ie. max jump.
 Debug above.  -> EURO11, 31.3-1.4.92
 Dont Crown till end-  change MULTIJUMP, DOAMOVE, Debug RECURGEN.
-> EURO12, 2-3.4.92
 WHITE Moves FIRST! Imp proper BOOK. Write TITLE/HELPSCREENS
 Debug HUMANMOVE, imp HUMANSIDE. Test game v DGM-lost. -> EURO14, 3.4.92
 Optomise MVGEN, Improve weights & parameters. Wins game v DGM.
-> EURO15, 3-4.4.92
 More BOOKmvs, new adscreens for DYNAMO - new name! Imp BOARDFLIP.
-> DYNA16, 4.4.92
 Tidy Helpscreens. -> DYNA17, 4-5.4.92
 Reduce Shortblag, Imp MANLINKS, Imp Fastgen. -> DYNA18, 5.4.92
 Imp GENCOUNT. -> DYNA19, 5-6.4.92
 No OREO if boardy>9. More wts earlier. -> DYNA20, 6-7.4.92
 Tidy HELPSCREEN, Imp MUST-JUMP txt. -> DYNA21, 7.4.92
 BUG - Called GENERATEMOVES twice in compmove! -> DYNA22, 8.4.92
 Reduce IQ increment. Trim weights. -> DYNA23, 9-10.4.92
 Imp PROTECTON from SAGE/BLITZ.
-> DYNA24, 11.4.92 (& try install on GP1, but..)
 Imp 3-line manlinks. Reduce Bridgeval. Inc KINGVAL. (DVGM14.E)
-> DYNA25, 14.4.92
 BAD MOVE BUG!! imp LEAPSQ[] list, & MARK/UNMARK LEAPSQ (), NLEAP, etc.
 CHECKPROTECT bug - doesn't work!
-> DYNA26, 18.4.92
 Bug - Proper color in mid-Multijump when Undo.
 Move islegal,doamove,replay,openbook to DYMVxx.C.
 Imp Abort (y,n) query before abort.
 Lost DVGM15 badly - more conservative wgts.
 Played DVGM16 better.
-> DYNA27, 18-19.4.92
 Imp central Oreo, with a value. Bigger Dogval. Imp CLAMPS.
-> DYNA28, 19.4.92
 9th rank too high - can sacrafice a man!
 Only show think after 1 sec..
-> DYNA29,19-20.4.92
 Imp color ADSCREENS, SOUNDFLAG,TWOPLAYMODE, SMOUSE (0) & Mousemenus,
-> DYNA30, 16.6.92
 Imp JUMPTYPE flag - 0=jump most,1=Pool/Russian. Imp DIROF[],MAXDIR[]
 Imp FILTEROTHER for FILTERGEN.
-> DYNA31, 7.7.92
 Imp FLYINGKINGS flag. Debug FILTEROTHER.
-> DYNA32.C, 8.7.92
 Imp Spanish gam, BACKJUMPS flag. Save/Load GAMETYPE.
-> DYNA33.C, 9-10.7.92
 Imp BESTLINE, Smaller 10x10 vert sqr for xtra line 25.
-> DYNA34, 15-16.9.92
 Imp ZAPMOVE, CTRL-F/ESC instant abort. SPACE toggle BESTVIEW.
 Big BACK & Inv numbers for SPANISH.
-> DYNA35, 16.9.92
 BUG! Kings ALWAYS FLYING, even in 10x10! Adjust DOAMOVE & RECURGEN
-> DYNA36, 17.9.92-22.9.92
 POOL BUG! Sometimes disallows legal jumps. B:1,11,13,24.W:30,26,27,20,15.
 B.Move, 1118 disallowed.Put Blk10,not11, then OK! (Letter.R.Price.)
 MAXDIR[] inadequate! Extend to MAXDIR[Mbrd] whole brd, for each sqr.
 Adjust HUMANMOVE-dont DOAMOVE twice.
-> DYNA37, 3-4.11.92
 Imp Portgame flag for PORTUGESE (JUANA) game, as gametype 5.
-> DYNA38, 21.11.92
 Imp SPOOLGAME, +/-/HOME/END in REPLAYGAME. Imp TPRINTFLAG/Out to Prn.
 Imp DGENxx.C, move Gen I/O to this.
-> DYNA39, 22.11.92
 Experiment with palette for wht/blk. Imp Portugese language text.
-> DYNA40, 18.12.92
 Imp JUAN.EGA/CGA/SPR,JUANDAT.C (mod SAF20 overlays).
-> DYNA41, 30.12.92
 Imp Pieces on Wht sqrs, with border (JUAN.EGA & CGA).
 Imp Output game to File. Imp Move-Numbering.
-> DYNA42, 1-2.1.93
 Bug in replay CCOLOR val - correctit.
-> DYNA43, 3.1.93 (Beta release to Govert Westerveld - JUAN43,SH)
 Fewer adscreens, TC frontscr. Tidy grafx, Imp BOX.CGA.
-> DYNA44, 28-29.1.93
 Imp DELUXE flag. Imp cmdline auto-replay func. Imp loadable DYNABOOK.TXT.
-> DYNA45, 30-31.1.93
 Debug LOADBOOK - imp Book-Comments.
-> DYNA46, 2.2.93
 Imp new portugesee txt from Govert.Inc Bridgeval.
 Imp portflag & long diag bonus.
-> DYNA47, 3.2.93
 Imp Serial Number (-PARS.DAT)
-> DYNA48, 4-5.2.93
 Imp better JUAN.EGA graphics. Imp SOFIA flag & new text.
-> DYNA49, 27.2.93
 Imp new gametypes 6,7 for Minidama/Brazilian.
-> DYNA50, 28.2-1.3.93
 Imp Pseudo Dbase. Move NMOVES==0 test. Imp PVFLAG - deep prime/var.
-> DYNA51, 2-3.3.93
 Imp Pseudo 2k v 1k Dbase. Adjust val kings and INITWEIGHTS.
-> DYNA52, 4.3.93 (out to G.Westerveld - 10xJUANA, 1xSOFIA)
 Re-spell SOPHIA as SOFIA. Add some text provided by Govert.
-> DYNA53, 12.4.93
 Imp HARDSCROLL. Imp SPACE for VGA. Imp new CHECKPROTECT.
-> DYNA54, 1.5.93
 BUG:Bad COMP MOVE in multijump when ZAPMOVE used in 1st (CTRL-F/Timeout)
 put ZAPMOVE=0 within Multijump loop.
 Adj initweights. Adj kweights+=50, compensate kvals -= 50.
 Imp CROWNMOVES/KINGMOVES, extend search if any CROWNMOVES.
-> DYNA55, 2.5.93
 Move ADSCR,FRONTSCR,INITSPR to DGENxx.C. Adj initwgts - more cent bias.
 Imp Centmask- only use MANLINKS in board center. Less Edge bias.
 Play game v Dam - still loses - uneven defence line.
-> DYNA56, 3.5.93
 Imp VGAPAL - fine tune 18bit palette. Imp NULLMOVE search near krank mv.
 Imp WTARG/BTARG for even defence.
-> DYNA57, 5-6.5.93
 Adj MANLINKS, INITWEIGHTS. Reduce XEVAL if W&B have K. Imp LASTBEST
 Futher param tune-up. Kill BRIDGE/OREO?DOGHOLE vals.
-> DYNA58, 7-8.5.93
 Imp bigger clamp vals, reduce side penalty. Reduce early timepermove.
 Replace msg in REPLAYG.
-> DYNA59, 9-13.5.93
 Bug in ESC/OUTPUTGAME. Imp OUTPUTPOS. Imp POOLBOOK.
-> DYNA60, 9.9.93
 Imp new graphics, CHBIG01.SAF.
-> DYNA61, 13.10.93
 Imp PRINTAFLAG, better PRINTBOARD graphics for printer.
 Allow {COMMENT on start book-line. Enhance book.
 CTRL-K - Invert notation bot/top.
-> DYNA62, 02.12.93
 Enhance book. Imp CTRL-O. Decrease Dogvals. Imp ENPRISEFLAG deepscan.
 Adjust IQADD vals. Increase ZAPTICKS margin. Debug OUTPUTGAME/BETWEENFLAG.
-> DYNA63, 26.12.93-7.1.94
 Imp sep DYBK64.C - book module.
 Imp CTRL-X - don't scan jumps deep (Gil.D)
 Imp Piece-list functions from SAGE.
-> DYNA64, 26.1.94..25.2.94
 Imp new HASHTAB. Imp AUTOGAMES statistical analyser.
-> DYNA65, 26.2.94..2.2.94
 Imp WINDOWSIZE of 45.
 Imp 12x12 Canadian draughts.
-> DYNA67, 3.2.94..
 Convert to Microsoft-VC..
 VC cannot take str >2K, so redo graphics.. imp seperate .SPR files
-> DYNA70A, 11.4.95..
 Imp MYSEG for more data storage,,,
 Imp showanal - display analysis as line at bottom..
 Imp ToolButtons - general ProcessToolKey () sub..
 Imp TGA03 to translate TGA files to 4-plane SPR files for dynamo
 Design new BMPs for prog - Tape ctls, Disk icons, etc.
 Imp button-movements
 Imp stepmove - to step thro game
 Speed up prn board - remove slow PALON from brd routine.
 Make buttons active..
-> DYNA70B, 15.4.95
 Imp PRINTFAT - fast printf-at substitute. Can handle inv-video
 Imp Text-buttons in Tool-routine - like real win buttons!
 Imp MSGPRINTF - pop-up dialog..
-> DYNA70C, 17.4.95
 Imp EDIT field in Toolbox routine.
 Imp pop-up edit boxes for load/save..
-> DYNA70D, 18.4.95
 Del replaygame.
 Re-write statline, repos all output.
 Imp GameTypeStr function.
 Redo SHOWANAL - use printfat in grey box.
 Start on spins.
-> DYNA70E, 19.4.94
 Finish spins, make them work in new SET PARAMS box.
 Imp WINBAR - windows-style title bar, with header text.
-> DYNA70F, 19.4.94
 Imp new TITLESCREEN with spins, buttons, etc..
 Imp MoveBox - display last few moves..
-> DYNA70G, 20.4.94
-> DYNA80A, 22.4.95
 Bug in spin-buttons on palette control
 Imp ActionHit - delay before first repeat.
-> DYNA80B, 22.4.95
 Quick tidyup for release..
 Imp Multi-language support..
 Imp HelpScreen viewer
 Debug mem alloc
-> DYNA80C, 7.10.95
 Write new manual/help text.
-> DYNA80D, 10.10.95
 Final touches - Imp PDN VIEW/LOAD option.
 Imp all 8 game types in 1 program.
 Imp better protection, writes back -PARAM file.
-> DYNA80E, 12.10.95..
 Bug in protect - imp separate file -PARAD.DAT
 Bug in move-box- shows move#*2 - correct it..
 Bug in 'Z' command - corrct it.
-> DYNA80E, 13.10.1995, release final EXE..
 Rebuild project files.
-> DYNA80F2, 16.6.2015
 Alter anyfly no hardware refresh sync.
-> DYNA80G, 16.6.2015
-> DYNA80H, 16.6.2015
 Set as full pro version, remove old Advert/Shareware/ProtectOn code..
 
-> DYNA80I, 17.6.2015
  Tidy up display texts, small changes.
-> DYNA814, 9.7.2024
  Make clmak15m.bat  build medium model using cmd line. (ie: clmak15m d:\msvc15 dyna80.c)
-> DYNA815, 9.7.2024


NOTE: Engine test: Enter params /V0 H0 B0 T0 I100  for fixed depth IQ=100, no randomisation.
Then autoplay from new: 31-27 (178597 nodes) 19-23 (206509 node) 33-28 (133177 node) 17-22 (194059 node)
(new console test version DYNA918 should be the same nodecount.)
  
------------------------------------------------------------------------------------------    
rem clmak15m.bat   (command line build for DYNAMO)
echo clmak15m msvc152-path dosprog.c [dosprog2.c ..]
echo   ie: clmak15m d:\msvc15 dyna80.c
echo    Build DOS program by directly using MSVC 1.52 CL.EXE.. 
%1\bin\cl.exe /AM /nologo /Gs /G3 /FR /FPi87 /W3 /Oe /O1 /Ot /Ox /D "_DOS" /I%1\include %2 %3 %4 %5 %6 %7  -link /NOI /STACK:5120  %1\lib\oldnames.lib %1\lib\mlibc7.lib 
------------------------------------------------------------------------------------------    

*/                                                                                   


#define PROG_VERSION "8.15"

#include <stdio.h>
#include <dos.h>	/* Defines union REGS, INT86 */
#include <stdlib.h>	/* RAND,MIN,MAX */
#include <conio.h>	/* _inp.. */
#include <malloc.h>	/* _fmalloc.. */
#include <string.h>
#include <ctype.h>	/* ISDIGIT */
#include <stdarg.h>	// va_list..

#include "dyna80.h"	// Forward declarations,,

#define DYMODEL 2	// 0=share,1=std,2=pro version build.

#if (DYMODEL == 0)	// Shareware
 #define Advert 1
 #define Shareware 1
 #define Noload 0
 #define Debug 0
 #define ProtectOn 0
 #define Serno 0
 #define Fastgen 1
 #define Othergames 1
 #define Deluxe 0
#endif

#if (DYMODEL == 1)	// Standard
 #define Advert 0
 #define Shareware 0
 #define Noload 0
 #define Debug 0
 #define ProtectOn 0
 #define Serno 0
 #define Fastgen 1
 #define Othergames 1
 #define Deluxe 0
#endif

#if (DYMODEL == 2)	// Pro version
 #define Advert 0
 #define Shareware 0
 #define Noload 0
 #define Debug 0
 #define ProtectOn 0
 #define Serno 0
 #define Fastgen 1
 #define Othergames 1
 #define Deluxe 1
#endif

#if Shareware	
 #define LANGUAGE_FILE "DSLANG1.TXT"	// Language file..
 char szLASTGAMEFILE [] = "$DYNAOLD.DAT";
 char szHelpFile [] = "DYNAMO1.DOC\0\0\0"	// help file name.,.
  "'C^IFJH'nt'Dhw~un`os'fic'Punssbi'e~'Fcunfi'Jnkkbss+'WD'THKRSNHIT)"; 
#else
 #define LANGUAGE_FILE "DYLANG1.TXT"	// Language file..
 char szLASTGAMEFILE [] = "$DYNAOLD.DAT";
 char szHelpFile [] = "DYNAMO1.DOC\0\0\0"	// help file name.,.
  "'C^IFJH'nt'Dhw~un`os'fic'Punssbi'e~'Fcunfi'Jnkkbss+'WD'THKRSNHIT)";
#endif

//#define regv _DX	/* Fast INT register var (REGISTER INT) */
unsigned int regv;	/* Above don't work with all C's so use this. */

#define outport _outpw
#define outportb _outp
#define inport _inpw
#define inportb _inp

#if Deluxe
 #define MAXX 12
#else
 #define MAXX 10
#endif

#define Progname "DYNAMO"

char szTemp [SIZEszTemp + 40];

SETTINGS lastg;		// Last-game settings..
BYTE language = 0;	// 0=eng,1=spanish..
                                                         
char PROGRAM [] = Progname " " PROG_VERSION ".";
char *WinBar = PROGRAM;
int boardx = 10;		/* Board size */
int boardy = 10;
int maxboard = 143;		// Maximum board pos
int menperside = 20;
int charx = 6;
int chary = 38;
int chrsize = 8;
int topy = 1;		/* Top of board */
int topx = 1;
int botx,boty;
int rmarg = 60;		/* Right Margin */
int nprint;		// Used in prints for wrap..
int curx,cury;		// Current cursor pos
int bmult = 21;		/* Multiplier */
int boardflip = 1;	/* Board upside-down */

int kcmd;		/* Command key hit */
int inkey,cmdkey;
int pxpos,pypos; 	/* Player posn */
int cxpos,cypos;	/* Computer posn */
int cpos;
int xpos,ypos;		/* General pos */
int xdir,ydir;
int yoff;
int ccolor;		/* White = 4, Black = 2 */
int StartCol = 4;	// Start-colour for given game-type..
int cpiece;
int temp,temp2;
long ltemp;

int bxpos,bypos;	/* Best xy pos */
int beval;		/* Best score */
int xeval;		/* Comp term eval score */
int ceval,zeval;	/* Temp eval score */
int automode = 0;

int twoplaymode = 0;
int cornmode = 0;	/* Grid of unused squares */
int losemode = 0;	/* Play to lose option */
long tloc;		/* Temp used in time access */
long xtime;

int cdir;
int tpos;
int leval;
int opcolor;
int execmove;

int mouseflag = 1;
int mousex,mousey,mbutton = 0;
int cursorflag = 1;	/* Cursor on.. */
			/* Search-vars */
int cply;
int xeval;
int xbrd;
int gamestage;		/* % board filled */

int xweight;
int cmove,zmove;
int multijump;
int ccut;
int knockdown;
int aborted;
int qcrowned;
int xpiece;
int knockflag = 1;
int xtaken;
int xcapt;			/* Capture sq*/
int xdest;
int killermove,killerdir;
int iqwas;
int piecewas;
int debugflag = 0,debugline;

unsigned char far *Vdu = MK_FP (0xa000,0);	// Pointer to screen 
UINT far *Vdui;

int iqcutoff = 20;

#define Mply 60		/* Absolute max ply depth */
#define Mbrd 300
#define Mlist 700	/* Size of move lists */

int jumpflag,oppjumpflag;
unsigned int nmoves;
int kingmoves,crownmoves,oppcrownmoves;
int dirul,dirur,dirdl,dirdr;		/* Dirs Up-left.. */
int dir2ul,dir2ur,dir2dl,dir2dr;
int gencount;

int alphaflag = 2;	/* Indicates alpha-beta pruning on/off */
int killerflag = 2;	/* Indicates killer mode */
int prefflag = 1;	/* Deep scan prefered moves on 1st ply */
int windowlo,windowhi;  /* Norm limits to alpha-beta window */
int windowsize = 55;
int awindlo,awindhi;
int retry;
int shortflag = 30;	/* Flag sets short look ahead and sort depth */
int halfshort;
int doingshort = 0;	/* Global flag tells deeper plys short in process */
int qdest;		/* Temp store for destination */
int materialdif;	/* Difference in material + for wh */
int nowhite,noblack;
int tempiq;		/* Store for iq when doing short look */
int shortply;		/* No cuts on this ply */
int lowshortply;
int templo,temphi;	/* Temp window store */

int thinkflag = 1;	/* Indicates computer display of thinking */
int varyflag = 1;	/* Randomise opening play */
int resignflag = 0;	/* Set when computer resigns */
int autonumber = 0;	/* Display board numbering */
int loseflag = 0;	/* Play to lose option! */
int anyflag = 1;	/* Use ANYJUMPS fast search */
int trimflag = 1;	/* Trim window bounds as we look */
int drawflag = 1;
int iterate = 1;	/* Iterative deepening flag */
int itereval;
int xflag = 0;		/* Double mvgen */
int maxiq = 0;
int docrown = 1;	/* Crown kings */
int diskerror = 0;
int initcolor;
int testflag = 0;
int gen2flag = 0;	/* Double mvgens */
int usedb = 1;		/* Use Pseudo Databases */
int blkpos,whtpos;
int whtx,whty,blkx,blky;
int pvflag = 0;		/* Extend Prime variant search */
int crownflag = 1;
int manlink = 1;	/* Man-bond strength */
int euroflag = 1;	/* Indicates 10x10 game */
int euron = 1;
int portflag = 0;	/* Spainish/Port game ? */
int poolflag = 0;	/* Pool 8x8 type board ? */
int jumptype = 0;	/* 0=Jump most, 1=POOL/Russian.. */
int flyingkings = 0;	/* for RUSSIAN game.. */
int backjumps = 1;	/* Allow backward-jumps (non in spanish) */
int gametype = 0;	/* 0 =International 10x10,1=Spain,2=Pool,3=Russian */

#if Shareware
 const int maxGameType = 3;	// Highest game type allowed..
#else
 #if Deluxe
  const int maxGameType = 8;
 #else
  const int maxGameType = 4;
 #endif
#endif

int bestflag = 15;	/* Disp Best-line flag/depth */
int bestview = 1;
int lastbest;
#define Togglebestline bestview = 1 - bestview
int numflag = 0;	/* Invert numbering */
int tprintflag = 0;	/* Redirects all print to printer */
int narg;
char argv1 [40];
int autoload = 0;
int wtarg,btarg;	/* Target back-defence */
int invertcol = 0;	/* Invert sqr color CTRL-I */
int betweenflag = 0;		/* Show in-between squares.. */
int enpriseflag = 0;		/* Entend forced move sequences */

int zapiq;
int zapmove;
long zapticks;		/* Kill off search after this time */
int zapcount;
int bmove,bdir;

int movefrom,moveto,movedir;	/* Curr mv */

unsigned long termnodes = 0;	/* Count of terminal nodes */
unsigned long avnodes = 0;	/* Alt time control */
unsigned int  nkillers = 0;	/* Count of killer moves */
unsigned int  nalphas = 0;	/* Count of alpha cuts */
int deepest;			/* Deepest ply hit */
int manvalue = 120;		/* Valuation for a man */
int kingvalue = 320;		/* Val for 1st king */
int bookrand = 50;
int fwdflag = 1;		/* std/prob mode */
int inflag = 0;			/* Infinite mode */
int huge *hashtab;		/* Hash table address */
int far *hashptr;
long hashsize = 65700;
long lhash;
unsigned int hashval;
int hashflag = 5;		/* Depth to stop hash table usage */
unsigned int hashboard [Mbrd];	/* Random vals for hashing */
int rndoffset [67];
char huge *charptr;

int doneeval;		/* Struct eval vars.. */
int zoneboard [Mbrd];
int zonetotal [4], zonepercent [4], zonesqrs [4];
int div3,zmin,zmax;
int tflag;
int autogames = 0,nww,nbw,ndr,autopar,wval,bval;

long otime;
int percent;
long extime;		/* Timer for complete move (All multijumps) */
long fulltime;		/* Time with fractions for part-move */
#if Shareware
 long timepermove = 4;	/* Auto-time target per move */
#else
 long timepermove = 6;
#endif
long targetticks = 0;	/* Target for current move (1/18 sec) */
long targettime = 10;
int timemode = 1;	/* Game averaging flag */
int timermoves = 0;	/* No of moves for time calc */
long totaltime;
long alttotaltime; int alttimermoves;

int tnomoves  [Mply];	/* No of moves at given ply */
int tcmove    [Mply];	/* Move under examination at g. ply */
int tccut     [Mply];	/* Accumulated cut off val at g. ply */
int tcolor    [Mply];	/* Color who moves at g. ply */
int toldpiece [Mply];   /* Value of moved piece at g. ply */
int ttaken    [Mply];	/* Value of taken piece at g. ply */
int tjumpflag [Mply];	/* Stash for jump flag */
int tweight   [Mply];	/* Storage for running weight val at g. ply */
int tbestmove [Mply];	/* Best move so far at g. ply */
int tbestdir  [Mply];	/* Best dir so far at g. ply */
int tbesteval [Mply];	/* Best eval so far at g. ply */
int twindlo   [Mply];	/* Window low value */
int twindhi   [Mply];	/* Window high value */
int tmbrd     [Mply];	/* Actual piece moved on board at g.ply */
int tmdir     [Mply];	/* Actual dir moved on board at g.ply */
int tmostjumps [Mply];	/* Score for most-jump search */
int tcurjumps [Mply];
unsigned int thashval [Mply];	/* Hash code for posn */
int curjumps;

int tnblkmen  [Mply];	/* No of Black men on board at g. ply. */
int tnwhtmen  [Mply];	/* No of White men on board at g. ply. */
int tnblkking [Mply];   /* No of Black kings on board at g. ply. */
int tnwhtking [Mply];   /* No of White kings on board at g. ply. */

int piececount [10] ; 	/* Running count for pieces - [2] for Bman, etc */
int kingvals [50] ;	/* Value of 1 king, 2 kings, etc.. */
int manvals [50] ;	/* Value of 1 man, 2 men, etc.. */
int blmanweights [Mbrd];	/* Weight squares for Black MAN moves */
int whmanweights [Mbrd];
int kingweights [Mbrd];		/* Weight of each square for KING moves */

int *mvbrd, *mvdir, *mveval, *mvcapt, *mvtot, *mvindex;

int xmvbrd [Mlist] ;	/* Move list - co-ord of each movable piece */
int xmvdir [Mlist] ;	/* Move list - dir for each move */
int xmveval [Mlist] ;	/* Spot eval for each move, for short look */
int xmvcapt [Mlist] ;	/* Capt location for K's */
int xmvtot [Mlist] ;	/* Maximum jump-count for mv */
int xmvindex [Mlist] ;	/* Pointer to WH/BL pos.. */
			/* int xmvlink [Mlist] ; */

#define Mgame 1000
int mgame [Mgame + 4] = {0,0};	/* Game move */
int vgame [Mgame + 4] = {0,0};
int ngame;
int fullgame,tfull;	/* Assort Replay vars.. */
int tgame,xgame;
int initcolor;
int qckcol;		// Init-new board color..
int endbrd;
int leapsq [Mgame];	/* Used to mark out used sqrs in mv generation */
int nleap,cleap,xleap;

int board [Mbrd];	/* Playing area */
int qckbrd [Mbrd];	// Fast-loading new-board 
int initbrd [Mbrd];
int crownsqrs [Mbrd];	/* Flag any crowning sqrs */
int sqnums [Mbrd];	/* Square numbers */
int sqpos  [Mbrd];	/* Xref list of SQNUMS */
//int sqxy [Mbrd];	/* Chess not. */
char gamenote [220] = "";	/* Game comments */
int nsqrs,csqr,cnum;
int dirof [512];	/* Direction 1,2,3,4 for any brd dir */
int maxdir [Mbrd];	/* XREF array used in FILTEROTHER */
int pow2 [] = {1,2,4,8,16,32,64,128,256};
int bestline [257] = {0,0,0,0};	// Best-line storage.. 

#define Mfilebuf 10000
unsigned int cfilebuf = 0;
long freeram;
char far *bigmem;

long serno = 17;
int notateflag = 0;	/* Use chess notation ? */
int botline;

#define Bestline(Ply,Deep) bestline [((Ply) << 4) + Deep]


BYTE MYSEG toolbmp [14000];  // Tool bmps
BYTE MYSEG tempbmp [3000];	// Temp work..
BYTE MYSEG sprites [7000];	// Sprites in use 
BYTE MYSEG disksprites [7000];// Sprite data 
char MYSEG xfilebuf [Mfilebuf + 200];	// File-Spool store..

	// Bitmap of Spin-control button (16x25, 16 color)
char spinbmp [] =
"\0\000���~~|>x\036p\016����\0\000����p\016"
"x\036|>~~���\0\0\0\000���~~|>x\036p\016���"
"�\0\000����p\016x\036|>~~���\0\0\0\000�"
"��~~|>x\036p\016����\0\000����p\016x\036|>~~"
"���\0\0\0\000�@\000@\000@\000@\000@\000@\000O"
"�@\000@\000@\0\0\000�@\000@\000@\000@\000@\020@ "
"@@@�@\000@\0\0\0";

	// Bitmap of Windows open/close system icon..(24x20,16 colour)
char winbmp [] = 
"\0\0\000��������������`\000�o��`\000�������"
"�������������\0\0\000��������������`\000�o��"
"`\000��������������������\0\0\000���������"
"�����`\000�o��`\000������������������������\0\000"
"�\0\000�\0\000�\0\000�\0\000�\0\000�\0\000�"
"\0\000��\000�\0\000�\0\000�\0\000�\0\000�\0"
"\000�\0\000�\0\000�\0\000�\0\000���";

TBUTTONINFO iTools [] = {	// MAIN TOOLBOX - Info on each button..
  3, 2,30,26, 128,129,NULL,0,	// TAPE ctrls..
 34, 2,30,26, 130,131,NULL,0,
 65, 2,30,26, 132,133,NULL,0,
 96, 2,30,26, 134,135,NULL,0,
  3,29,40,39, 's',0,NULL,0,	// SAVE
 44,29,40,39, 'l',0,NULL,0,	// LOAD
 85,29,40,39, 'n','&',NULL,0,	// NEW/CLR
  3,70,40,39, '@','.',NULL,0,	// INV/NUM
 44,70,40,39, 20,'>', NULL,0,	// CLOCK
 85,70,40,39, ';','D', NULL,0,	// HELP/SHOW
  3,111,40,39, 'g','=',NULL,0,	// COMPUTE/AUTO
 44,111,40,39, 'p','m',NULL,0,	// COLOR
 85,111,40,39, 4,0,   NULL,0,	// BOOK
  3,152,40,39, 'o',0,NULL,0,	// PRN
 44,152,40,39, '/',0,NULL,0,
 85,152,40,39,  27,0,NULL,0,	// eXit
 DISABLE,0,0,0,0,0,NULL,0,			// Terminator
 DISABLE,0,0,0,0,0,NULL,0			// Terminator
};

TBUTTONHEADER hdTools = {	// Descriptive header for main toolbox..
 iTools,			// Struct with button details..
 496,20,			// topleft of toolbox
 128,194, 			// size of bmp
 128,200, 			// Mouse-activity area
 toolbmp,			// Bitmap of tools..
 0,-20,128,			// Info-display area..
 "",0,0,0,0,			// no edit field
 "" // STtoolboxtext
};

TBUTTONINFO iPARAM [] = {	// MAIN TOOLBOX - Info on each button..
  0, 0, 96, 4, 40,200,&manvalue,DLGSPIN,	// SPIN Man-eval
200,0,  296,4, 40,500,&kingvalue,DLGSPIN,	// SPIN king-eval
  0,40, 96,44, 20,100,&bookrand,DLGSPIN,	// SPIN book rand chance
 96,110, 64,22, 13,13,NULL,3,		// Text button (OK)
240,110, 64,22, 27,27,NULL,3,		// Text button (CANCEL)
 DISABLE,0,0,0,0,0,NULL,0			// Terminator
};

TBUTTONHEADER hdPARAM = {	// Descriptive header for main toolbox..
 iPARAM,			// Struct with button details..
 0,0,				// topleft of toolbox (set by prog)
 0,0,	 			// size of bmp
 400,150, 			// Mouse-activity area
 NULL,				// no Bitmap of tools..
 0,0,0,				// no Info-display area..
 "",0,0,0,0,			// no edit field
 "Man value\0\0King value\0\0Book probability\0\0\0OK\0\0CANCEL\0\0"
 "\0\0\x01",	// End of strings..
};

	// TITLESCREEN controls..
TBUTTONINFO iTITLE [] = {	
  0, 4, 72, 4, 0,1,&cornmode,DLGSPIN,	// SPIN corner
160,4,  232,4, 4,MAXX,&boardx,DLGSPIN,	// SPIN width
320,4,  392,4, 4,MAXX,&boardy,DLGSPIN,	// SPIN height
480,4,  552,4, 1,35,&menperside,DLGSPIN, // SPIN #men/side
  64, 50, 64,22, 13,13,  NULL,3,		// Text button (PLAY)
 184, 50, 64,22, 27,27,  NULL,3,		// Text button (EXIT)
 304, 50, 64,22, 'A','A',NULL,3,		// Text button (GAME-TYPE)
 424, 50, 64,22, ';',';',NULL,3,		// Text button (HELP)
 DISABLE,0,0,0,0,0,NULL,0			// Terminator
};

TBUTTONHEADER hdTITLE = {	// Descriptive header for main toolbox..
 iTITLE,			// Struct with button details..
 0,0,				// topleft of toolbox (set by prog)
 0,0,	 			// size of bmp
 568,74, 			// Mouse-activity area
 NULL,				// no Bitmap of tools..
 0,0,0,				// no Info-display area..
 "",0,0,0,0,			// no edit field
 "", // STtitlebittons "Corner\0\0Width\0\0Height\0\0Men\0\0\0PLAY\0\0EXIT\0\0GAME\0\0HELP\0\0"
};

int ActionHit;		// Flag incremented when a Dlg-button hit..

int hxdir [20] = { -1, 0, 1, -1, 1, -1, 0, 1};
int hydir [20] = { 1, 1, 1, 0, 0, -1, -1, -1};

int Oreoval = 6;	/* Oreo triangle 2,3,7 */
int Backval = 6;	/* Triangle 1,2,6 */
int Bridgeval = 6;	/* Bridge 1,3 */
int Dogval1 = 30;	/* Dog-Hole cramps (1,5) */
int Dogval2 = 18;	/* 2nd Dog-Hole cramps (3,12) */

#define Greysq -8
#define Edge -8

#define Bman 2		/* Val of black man  on board */
#define Bking 3		/* Val of black king on board */
#define Wman 4		/* Val of white man  on board */
#define Wking 5		/* Val of white king on board */

#define Ggrey 6
#define Gcur 7

#define White 4		/* Board vals */
#define Black 2
#define Whtorblk 6
#define ToggleWB 6

#define C1black 8	/* 1 away from crown */
#define C1white 16
#define C2black 32
#define C2white 64
#define Centmask 128

#define Nblkmen piececount[2]	/* Alt for No of black men. */
#define Nblkking piececount[3]	/* Alt for No of black kings. */
#define Nwhtmen piececount[4]   /* Alt for No of white men. */
#define Nwhtking piececount[5]  /* Alt for No of white kings. */
#define Nmen piececount[2]+piececount[4]
#define Nkings piececount[3]+piececount[5]
#define Nblack piececount[2]+piececount[3]
#define Nwhite piececount[4]+piececount[5]

#define Msprite 4900
int Ssize = 912;	/* Sprite size */

#define Setboard(Xpos,Ypos,Cpiece) \
	board [(Xpos) + (Ypos) * bmult] = Cpiece;

#define Getboard(Xpos,Ypos) \
	board [(Xpos) + (Ypos) * bmult]

#define Posof(Xpos,Ypos) ((Xpos) + (Ypos) * bmult)

#define InvertPos(Cpos) (maxboard - (Cpos))

			/* Macro to Swap 2 moves in move table */
#define Swapmoves(Move1,Move2) \
	regv = mvbrd [Move1];\
	mvbrd [Move1] = mvbrd [Move2];\
	mvbrd [Move2] = regv;\
	regv = mveval [Move1];\
	mveval [Move1] = mveval [Move2];\
	mveval [Move2] = regv;\
	regv = mvcapt [Move1];\
	mvcapt [Move1] = mvcapt [Move2];\
	mvcapt [Move2] = regv;\
	regv = mvindex [Move1];\
	mvindex [Move1] = mvindex [Move2];\
	mvindex [Move2] = regv;\
	regv = mvdir [Move1];\
	mvdir [Move1] = mvdir [Move2];\
	mvdir [Move2] = regv;

void initptrs ()		/* Initialise movelist pointers */
{
	mvbrd = xmvbrd;
	mvdir = xmvdir;
	mvcapt = xmvcapt;
	mveval = xmveval;
	mvtot = xmvtot;
	mvindex = xmvindex;
	cply = 1;
}

void addleap (int jumpsq)	/* Stash capt sq, for correct mv gen */
{
	nleap ++;
	if (ccolor == Black) {
	  leapsq [nleap] = -jumpsq;
	} else {
	  leapsq [nleap] = jumpsq;
	}
}

void markleapsq (int sqfill)	/* MARK any prev multi-jump capt with FILL */
{
	int cleap = nleap;
	if (ccolor == Black) {
	  while (cleap > 0) {
	    if ((xleap = leapsq [cleap]) >= 0) return;
	    board [-xleap] = sqfill;
	    cleap --;
	  }
	} else {
	  while (cleap > 0) {
	    if ((xleap = leapsq [cleap]) <= 0) return;
	    board [xleap] = sqfill;
	    cleap --;
	  }
	}
}

/* ------------------------------------------------------------------------------------------ */

#include "dgen80.c"		/* GENERAL I/O */
#include "dymv80.c"		/* GAME-SEARCH FUNCTIONS */
#include "dybk80.c"		/* BOOK & sundries.. */

long lasttime = 0;

void playgame ()
{
      Hidescreen		/* Clr brd/vdu */
      gamenote [0] = 0;
      newboard (1);
      initcolor = ccolor;
      pxpos = boardx / 2;
      pypos = boardy / 2;
      if (mouseflag) smouse (0);	/* Init mouse */
      twoplaymode = 0;
      if (autoload) {		/* Cmd line auto-view */
	Showscreen
	loadgame ();
	//inkey = cmdkey = 3;
	//return;
      }
      drawboard ();
      getpal (14);
      Showscreen
      do {		/* Main playing loop */
        showanal (2);
	statline ();
	inkey = 0;
	if (cursorflag && automode == 0) bputat (pxpos,pypos,Gcur);
	showmouse ();
	do {
	  inkey = cmdkey = getkey ();
	  if (cmdkey == 3) return;
	  if (cmdkey == 27 && automode) {
	    automode = 0; cmdkey = 0;
	  }
	  if (automode && cmdkey) automode = 0;
	  if (lasttime != (readtime () & 4)) {
	    lasttime = readtime () & 4;
	    if (cursorflag) {
	      syncfly ();
	      hidemouse ();
	      if (readtime () & 4) {	/* Cursor */
		bputat (pxpos,pypos,-1);
	      } else {
		bputat (pxpos,pypos,Gcur);
	      }
	      showmouse ();
	    }
	  }
	  if (cursorflag == 0 && inchr ("wbWBek\x0d",cmdkey) >= 0) {
	    cmdkey = inkey = 0;
	    cursorflag = 1;
	  }
	  if (mouseflag && cmdkey == 0) {
	    int kbut = 0;
	    mouse (3, &mbutton, &mousex, &mousey);
	    if (mbutton) {
	      kbut = ProcessToolKey (&hdTools,1);		// Tool box hit?
	    }
	    if (kbut) {		// Pass tool-box selection as key-code..
	      inkey = cmdkey = kbut;
	      kcmd = 100;
	    } else if (mbutton == 1) {		/* Left button */
	      temp = mouse2sqr (mousex, mousey);
	      if (temp) {		/* Legal move.. */
		hidemouse ();
		bputat (pxpos,pypos,-1);
		showmouse ();
		pxpos = temp % bmult;
		pypos = temp / bmult;
		kcmd = 100; cmdkey = 13;
	      }
	    } else if (mbutton == 2) {
	      temp = mousemenu (20,(int) STmenutext[0],STmenutext + 1);
	      shutwindow (20,12);
	      if (temp) {		/* Menu selected */
		kcmd = 100; cmdkey = inkey;
		if (inkey == 'q') return;
	      }
	      showmouse ();
	    }
	  }
	} while (cmdkey == 0 && automode == 0);
	hidemouse ();
		// Cursor movement?
	kcmd = inchr ("12346789OPQKMGHI",cmdkey);
	if (kcmd > 7) kcmd -= 8;
	bputat (pxpos,pypos,-1);
	if (kcmd >= 0 && automode == 0) {	/* Cursor move.. */
	  getdir (kcmd);		/* Get x/ydir */
	  pxpos += xdir; pypos += ydir;
	  if (pxpos < 1 || pypos < 1 || pxpos > boardx || pypos > boardy) {
	    pxpos -= xdir; pypos -= ydir;
	    continue;
	  }
	  continue;
	}
	if (automode && cmdkey != 27) cmdkey = '<';
	
       switch (cmdkey) {
	case 7:
	  mouseflag = 1 - mouseflag;
	  printaflag ("Mouse ",mouseflag);
	  
	  #if Debug
	  {
	   { int cc = 0; long ct; int ttt;
	    ttt = msgPrintf (PRNCENT | 40,80,&hdOKCANCEL,"New method?");
	    ct = readtime ();
	    while (readtime () - ct < 182) {
	      if (ttt == 13) {
	        gotoxy (1,1);
	        printsi ("Text here",12345);
	        printsi ("Text here",12345);
	        printsi ("Text here",12345);
	      } else {
	        prnat (0,0,79,PRNWHT,"Text here12345Text here12345Text here12345");
	      }
	      cc++;
	    }
	    printside ("#=",14); printi (cc); prints ("  ");
	    waitspc ();
	   }
	  }
	  #endif
	  break;
	  
	case  14:
	  notateflag = 1 - notateflag;
	  printaflag (STchessnot,notateflag);
	  break;
	    
	case  4:	// CTRL-D Opening book 
	  bookflag = 1 - bookflag;
	  printaflag (STbook,bookflag);
	  break;
	  
	case  11:	// CTRL-K invert num 
	  numflag = 1 - numflag;
	  printaflag ("Invert# ",numflag);
	  break;

	#if Deluxe
	  case 12:
	    if (bigtype >= 0) {		// CTRL-L load book.. 
	      promptin (60,120,STloadopeningbook, bookname, 45);
	      drawboard ();
	      if (bookname [0]) {
	        clrvdu ();
	        loadbook (bookname);
	        hitspace ();
	        clrvdu ();
	        drawboard (); statline ();
	      }
	    }
	    break;
	    
	  case 23:		// CTRL-W 
	    debugflag = 1 - debugflag;
	    printaflag ("Debug ",debugflag);
	    break;
	    
	#endif
	 
	#if Debug
	  #if 0
	  if (cmdkey == 20) {
	    testflag = 1 - testflag; printaflag ("Non maxjmp ",testflag);
	  }
	  if (cmdkey == 21) {
	    jumptype = 1 - jumptype; printaflag ("Pool jumps ",jumptype);
	  }
	  if (cmdkey == 22) {
	    flyingkings = 1 - flyingkings; printaflag ("Flying kings ",flyingkings);
	  }
	  #endif
	  
	  case 26:	// CTRL-Z 
	    gotoxy (1,1);
	    countpieces ();
	    initptrs ();
	    buildpos ();		/* Build piece-lists */
	    for (ypos = 0; ypos < boardy + 2; ypos ++) {
	      printsi ("\n",ypos * bmult); printc(':');
	      for (xpos = 0; xpos < boardx + 2; xpos ++) {
		temp = xpos + ypos * bmult;
		printi (board [temp]); printc (',');
	      }
	    }
	    cply = 0;
	    structeval ();
	    printsi ("\n\nStruct eval = ",seval);
	    break;
	    
	 #endif
	 
	case 27:	// ESC - abort
	  click ();
	  temp = msgPrintf (PRNCENT | 40,120,&hdOKCANCEL,STabortgame);
	  if (temp == 13) return;	// abort game..
	  drawboard ();
	  break;

	case  2:
	  qclrvdu ();
	  drawboard ();
	  Togglebestline;
	  printaflag (STbestline,bestview);
	  break;

	case  '?':
	  twoplaymode = 1- twoplaymode;
	  printaflag (ST2player,twoplaymode);
	  break;

	case  'A':
	  soundflag = 1 - soundflag;
	  printaflag (STsound,soundflag);
	  break;

	case  'p':		// Palette set
	  DlgPalette ();	// Edit palette colours..
	  hidemouse ();
	  qclrvdu ();
	  drawboard ();
	  break;
	  
	case  'n':
	case  18:	/* CTRL-R -new game */
	   gamenote [0] = 0;
	   newboard (1);
	   initcolor = ccolor;
	   clrvdu ();
	   drawboard ();
	   twoplaymode = 0;
	  break;

	case  13:	/* Return, move made.. */
	  if ( humanmove ()) {
	    ccolor = ToggleWB - ccolor;
	    if (twoplaymode == 0) {
	      execcompmove ();
	      ccolor = ToggleWB - ccolor;
	    }
	  }
	  break;
	
	case  20:		// Set time per move..
	  #if Shareware
	    timepermove = (timepermove & 3) + 1;	// 1..4 secs move
	    dink ();
	  #else
	    szTemp [0] = 0;
	    promptin (60,120,STplaylevel, szTemp, 20);
	    if (szTemp [0]) {
	      timepermove = atoi (szTemp);
	    }
	  #endif
	  totaltime = 0;
	  timermoves = 0;
	  drawboard ();
	  break;
	
	case  'c':		// Game comment..
	  dink ();
	  promptin (74,150,STentercomment, gamenote, 196);
	  drawboard ();
	  break ;
	  
	case 'l':		// PDN select game..
	  pdnLoad ("",0);
	  drawboard ();
	  break;
	  
	case 'a':		// PDN load next game..
	  pdnLoad (pdnDataBase,pdnCurGame + 1);
	  drawboard ();
	  break;
	  
      #if (Shareware == 0)
	case 's':		// PDN save..
	  pdnSave ("");
	  drawboard ();
	  break;
	  
	case  'y':		// Old load
	  szTemp [0] = 0;
	  promptin (60,120,STloadfile, szTemp, 45);
	  drawboard ();
	  if (szTemp [0]) {
	    loadgame ();
	  }
	  break;
	
	case  'z':		// Old save
	  szTemp [0] = 0;
	  promptin (60,120,STsavefile, szTemp, 45);
	  drawboard ();
	  if (szTemp [0]) {
	    savegame ();
	  }
	  break;
	  
	case  10:	// CTRL-J - Show Between jumps. 
	  betweenflag = 1 - betweenflag;
	  printaflag ("Full-jump ",betweenflag);
	  break;
	  
        case 'k':
        case 'e':
        case 'w':
        case 'b':
        case 'W':
        case 'B':
        case '&':
        case 'x':
	  if (cmdkey == 'k') Setboard (pxpos,pypos,Edge);
	  if (Getboard (pxpos,pypos) != Edge) {
	    if (cmdkey == 'e') Setboard (pxpos,pypos,0);
	    if (cmdkey == 'w') Setboard (pxpos,pypos,Wman);
	    if (cmdkey == 'b') Setboard (pxpos,pypos,Bman);
	    if (cmdkey == 'W') Setboard (pxpos,pypos,Wking);
	    if (cmdkey == 'B') Setboard (pxpos,pypos,Bking);
	  }
	  if (cmdkey == 'x') ccolor = ToggleWB - ccolor;
	  if (cmdkey == '&') {
	    newboard (0);
	    drawboard ();
	  } else {
	    saveinitbrd ();
	    initcolor = ccolor;
	    totaltime = 0;
	    timermoves = 0;
	    fullgame = 0;
	    nleap = ngame = 0;
	    soundit (1000,2);
	  }
	  break;
	  
	case  'o':
	  outputgame (1);
	  clrvdu ();
	  drawboard ();
	  break;
	
	#if Deluxe
	case 'Z':	// Automatic game-play.. 
	  setautogame ();
	  clrvdu (); drawboard ();
	  if (autopar) {
	    getpal (3);
	    gotoxy (23,1); prints ("Param./"); printc (autopar);
	    printsi (" White=",wval); printsi (", Black=",bval);
	  }
	  break;
	  
	case 'i':
	  iqcutoff = ((iqcutoff / 5 + 1) % 30) * 5;
	  break;
	
	case 'v':		// View a database
	  pdnView (pdnDataBase);
	  drawboard ();
	  break;
	  
	case  5:	// CTRL-E Infinite search 
	  inflag = 1 - inflag;
	  printaflag (STinfinite,inflag);
	  statline ();
	  break;
	  
	case 25:	// CTRL-Y  stats.. 
	  countpieces ();
	  msgPrintf (PRNCENT | 72,100,&hdOK,"#White:%d, #Black:%d Book\x22%s\x22, Size = %d",
	  	nowhite, noblack, bookname,nbook);
	  drawboard ();
	  break;
	  
	case 19:		// Parameters
	  msgPrintf (PRNCENT | 60,220,&hdPARAM,"%s",STalterengineparameters);
	  drawboard ();
	  break;
	  
	case  '/':	/* Parameters */
	  setparameters (0,0);
	  clrvdu ();
	  drawboard ();
	  break;
	
	case  24:	// CTRL-X play mode 
	  fwdflag = 1 - fwdflag;
	  if (fwdflag) {
	    SideMessage ("Standard play");
	  } else {
	    SideMessage ("Problem solve");
	  }
	  dink ();
	  break;
	  
	case  16:	/* CTRL-P  - print board pos */
	  printboard (1);
	  hitspace ();
	  clrvdu ();
	  drawboard ();
	  break;
	  
	case  15:	/* CTRL-O  - Output printer control codes */
	  clrvdu ();
	  getpal (10);
	  prints ("Enter control code numbers or text to send to printer - hit ESC when done.\n"
	  "ie. 27 [RETURN] 116 [RETURN] 49 [RETURN] [ESC] gives IBM char on STAR printers\n"
	  "See your printer manual for full details of control codes for your machine.\n\n");
	  getpal (12);
	  prints ("PLEASE MAKE SURE YOUR PRINTER IS ON LINE NOW - or hit ESC to exit.\n\n");
	  getpal (7);
	  click ();
	  do {
	    prints ("Enter:");
	    linput (szTemp,70);
	    if (isdigit (szTemp [0]) ) {
	      tprintflag = 1;
	      printc (atoi (szTemp));
	      tprintflag = 0;
	    } else if (szTemp [0]) {
	      tprintflag = 1;
	      prints (szTemp); prints ("\n");
	      tprintflag = 0;
	    }
	  } while (szTemp [0]);
	  clrvdu (); drawboard ();
	  break;
	  
	case  'd':
          searchbook (0);
	  clrvdu (); drawboard ();
	  break;
	  
	case  22:
          searchbook (1);
	  clrvdu (); drawboard ();
	  break;
	
	#endif  // Deluxe
      #endif  // Shareware

	case  9:	/* CTRL-I  Invert sqr */
	  invertcol = 1- invertcol;
	  palon ();
	  break;
	  
	case  '.':
	  if (xgamode == 2) {
	    numberboard ();
	    showmouse ();
	    waitspc ();
	    hidemouse ();
	    drawboard ();
	  }
	  break;
	
	case 128:
	  stepmove (-10); break;
	case 129:
	  stepmove (-9999); break;
	case 'u':
	case '-':
	case 130:
	  stepmove (-1); break;
	case 131:
	  stepmove (-2); break;
	case '+':
	case 132:
	  stepmove (1); break;
	case 133:
	  stepmove (2); break;
	case 134:
	  stepmove (10); break;
	case 135:
	  stepmove (9999); break;
	
	case  '@':	// F6- Inv board 
	  boardflip = 1 - boardflip;
	  drawboard ();
	  break;

	case  'D':	// F10- SHOW MOVES 
	  initptrs ();
	  buildpos ();		/* Build piece-lists */
	  GenerateMoves
	  if (jumpflag && testflag == 0) {   /* Scan jumps, del illegal */
	    filtergen ();
	  }
	  SideMessage (SThitspacemouse);
	  for (cmove = 1; (UINT) cmove <= nmoves; cmove ++) {
	    gputat (mvbrd [cmove], Gcur);
	  }
	  Beep 
	  showmouse ();
	  waitspc ();
	  hidemouse ();
	  drawboard ();
	  break;

	#if Debug
	  case  '!':
	    tester ();
	    clrvdu ();
	    drawboard ();
	    break;
	    
	  case  '^':
	    clrvdu ();
	    temp2 = 0;
	    for (temp = 1; temp <= nbook; temp ++) {
	      printsi (",",book [temp]);
	      if (book [temp] == 0) {prints ("\n>"); temp2 ++;}
	      if (temp2 > 12) {
		temp2 = 0;
		do {
		  inkey = getkey ();
		  if (inkey == 27) temp = nbook;
		} while (inkey != ' ' && inkey != 27);
	      }
	    }
	    hitspace ();
	    clrvdu (); drawboard ();
	    break;
	  
	  case  '%':
	    findbookmove ();
	    printwside ("Book:",Rmsg);
	    printi (bookmove);
	    break;
	    
	  case 34:		// Colour prn test
	   {	
	    char is[20]; int ccol,xcol,cy;
	    gotoxy (1,1);
	    linput (is,7);
	    xcol = atoi (is);
	    cy = 10;
	    for (ccol = xcol; ccol < xcol + 16; ccol ++) {
	      fillobject ( 0,cy,     70,16,0,ccol);
	      fillobject ( 0,cy + 16,70,16,255,ccol);
	      printfat (PRNPIX | 1,cy,-1,ccol,"%d:Non-invert,0x00=",ccol);
	      printfat (PRNPIX | PRNINV | 1,cy+ 16,-1,ccol,"     Invert,0xff=");
	      cy += 32;
	    }
	    waitspc ();
	    qclrvdu ();
	    drawboard ();
	   }
	   break;
	     
	#endif

	case '=':
	  automode = 1;
	case '<':
	case 'g':	// Computer go ..
	  execcompmove ();
	  ccolor = ToggleWB - ccolor;
	  break;

	case  'C':
	  cursorflag = 1 - cursorflag;
	  printaflag ("Cursor ",cursorflag);
	  break;

	case  ';':
	case  'h':	// F1 - HELP 
	  qclrvdu ();
	  helpscreen ();
	  qclrvdu ();
	  drawboard ();
	  break;
	  
	  
	}	// End of switch
      } while (1);
}

void calcmen ()
{
	menperside = (((boardy - 2) / 2) * boardx) / 2;
}

  // Set up vars for given game type..
void AssertGameType ()
{
		// Scan to get legal game type
	do {
	  gametype = gametype % maxGameType;
	  if (*GameTypeStr ()) break;	// found a game type!
	  gametype ++;
	} while (gametype);	// Always allow game type zero..
	invertcol = 0;
	notateflag = 0;
	if (gametype == 5) {	// Portgame - Portugese..
	  invertcol = 1;	//* Invert sqr color CTRL-I 
	  gametype = 5;
	  cornmode = 1;
	  boardflip = 1;
	  numflag = 1;
	  boardx = boardy = 8;
	  menperside = 12;
	  return;
	}
	if (gametype >= 6) {	// Sofia - others..
	  cornmode = 0; boardflip = 1; numflag = 0; notateflag = 0;
	  boardx = boardy = 10;
	  boardx = boardy = 8;
	  notateflag = 1;
	  numflag = 1;	/* Inv num */
	  calcmen ();
	  if (gametype == 6) {	/* Minidama */
	    menperside = 8; cornmode = 1;
	  }
	  return;
	}
	cornmode = 0;
	boardflip = 0;
	numflag = 0;
	if (gametype) {
	  boardx = boardy = 8;
	} else {
	  boardx = boardy = 10;
	}
	if (gametype == 4) {
	  boardx = boardy = 12;
	  boardflip = 1;
	}
	if (gametype == 1) {
	  cornmode = 1; numflag = 1;
	}
	if (gametype < 2) boardflip = 1;
	calcmen ();
}

void titlescreen ()
{
	clrvdu ();
titleloop:
	inkey = msgPrintf (PRNRET | PRNBOX | 80,470,&hdTITLE,
 "        Copyright A.Millett 1992-2024. Released as FREEWARE under GPL3.\n\n"
 "     DYNAMO plays the INTERNATIONAL, US POOL and SPANISH variations of\n"
 "     DRAUGHTS, which are popular games in their countries - and it plays\n"
 "     a fairly good game too!\n"
 "       For RULES and HELP on this game hit the F1 key NOW - you should\n"
 "     do this if you are new to the game. There are many variations\n"
 "     to choose from - press the GAMES button, or try changing the\n"
 "     board width/heights, men per side, and corner configuration.\n"
 "\n%s"
 "                  (Hit RETURN to play, ESC to Exit)\n\n\n"
 "                            (%s game)\n",STextratitle,GameTypeStr ()
	);
	do {
	  inkey = ProcessToolKey (&hdTITLE,2);	// Read button/keystroke..
	  if (inkey == 27 || inkey == 13 || inkey == 3) {
	    initsprites ();		// Select correct piece set
	    bmult = boardx + 2;
	    return;
	  }
	  if (inkey == '!') {
	    gotoxy (1,1);
	    prints (Progname " is Copyright and Written by A.Millett.");
	  }
	  //if (inkey == '<') {
	  //  losemode = 1 - losemode;
	  //}
	  
	  if (inkey == 'A') {	// CHANGE GAME TYPE..
	    do {
	      #if Shareware
	        gametype = (gametype + 1) % 3;
	      #else
	        #if Deluxe
		  gametype = (gametype + 1) % 8;
	        #else
		  gametype = (gametype + 1) % 4;
	        #endif
	      #endif
	    } while (*GameTypeStr () == 0);
	    mgame [1] = 0;
	    AssertGameType ();
	    pdnResetName ();		// Default database name..
	    goto titleloop;
	  }
	  if (inkey == ';') {
	    hidemouse ();
	    helpscreen ();
	    goto titleloop;
	  }
	} while (1);
}

void main (int argc, char *argv [])
{
	narg = argc; strcpy (argv1, argv [1]); strcpy (szTemp, argv [2]);
	testfly ();
	InitSetPtrs ();
	srand ( (int) readtime ( ) );	/* Init random seed */
	graphmode (3);
	if (ReadLanguageFile (0) == 0) {		// Load ENGLISH file to start..
	  return;
	}

	resetmouse ();	// See if mouse exists..
	if (mouseflag) cursorflag = 0;		// No cursor if mouse found
	#if (Noload == 0)
	  farloaddata ("dyna.spr", disksprites, sizeof (disksprites) - 3);
	  if (diskerror) return;
	  farloaddata ("dytools.spr", toolbmp, sizeof (toolbmp) - 3);
	  if (diskerror) return;
	  //floaddata ("mini.spr", minisprites, 1000);
	#endif
	
	freeram = 0x70000L;	// 448K..
	charptr = (char huge *) farmalloc (freeram - 4096);
	if (charptr == NULL && farmallocmax) {
	  freeram = farmallocmax;
	  charptr = (char huge *) farmalloc (freeram - 4096);
	}
	bigmem = (char far *) charptr;
	printl (freeram); prints (" Bytes free. \n\n");
	if (charptr == NULL) {
	  prints ("Out of memory!\n");
	  return;
	}
	
	#if Deluxe
	  lbook = Mbook + Mbook + 100;
	  if (freeram > lbook) {
	    headbigbook = (int huge *) charptr;	// Start of book header info
	    freeram = freeram - 0x10000;
	    charptr += 0x10000;		// Allow 64k for book..
	    bigbook = headbigbook + 16;		// Start actual book..
	    loadbook (bookname);
	  }
	  if (hashflag && freeram > hashsize + hashsize + 100) {
	    hashtab = (int huge *) charptr;
	    hashptr = (int far *) hashtab;
	    freeram = freeram - (hashsize << 1) - 50;
	    charptr += (hashsize << 1) + 100;
	    prints ("\nHash table allocated..\n");
	  } else {
	    hashflag = 0;
	    hashtab = NULL;
	    prints ("\nNot enough memory for hash-table.. \n");
	  }
	#else
	  hashflag = 0; hashtab = NULL;
	#endif        
	pause (22);
	initsprites ();
	frontscreen (1);
		// Clear & load last-game settings..
	memset (&lastg,0,sizeof (lastg));
	farloaddata (szLASTGAMEFILE,&lastg,sizeof (lastg));
		// Load language file..
	ReadLanguageFile (language);
	hdTITLE.txt = STtitlebuttons;
	hdTools.txt = STtoolboxtext;
	hdSCRPRN.txt = STscreenprinter;
	hdEDIT.txt = STokcancel;
	hdOKCANCEL.txt = STokcancel;
	{ 		// Read tool-box keys..
	  int x = 0; BYTE *cstr = STtoolboxkeys;
	  do {
	    if (*cstr == 0) break;
	    iTools [x].lkey = cstr[0];
	    iTools [x].rkey = cstr[1];
	    if (iTools[x].x == DISABLE) break;
	    cstr += 2;
	    x++;
	  } while (1);
	}
	AssertGameType ();	// Init vars for given game type..
	pdnResetName ();
	clrvdu ();
	do {
	  titlescreen ();
	  if (inkey == 3) {
	    graphmode (3);
	    return;
	  }
	  if (inkey == 27) break;
	  playgame ();
	  if (inkey == 3) {
	    graphmode (3);
	    return;
	  }
	} while (inkey != 3);
	graphmode (3);
}
