  /* DGENxx.C  General I/O functions for DYNAMO, (C) A.Millett 1990-2024 */

#define Beep click();
#define Wht 0
#define Yel 1
#define Dgrey 7
#define Pur 10
union REGS inr,outr;	/* Define register access */
struct SREGS sregs;	/* Segment regs */
BYTE prbuffer [10];	/* Buffer for int-print */

typedef unsigned char BYTE;     /* A convenient new data type */

const int xgamode = 2;	/* Graphic adapter 0 = CGA, 1 = EGA, 2 = VGA.. */

_inline long readtime ()	/* Read 32 bit system clock in 1/18 secs */
{
	return ( *((long far *) MK_FP (0,0x046c)));
}

long CODESEG freadtime ()	/* Read 32 bit system clock in 1/18 secs */
{
	return ( *((long far *) MK_FP (0,0x046c)));
}

void FASTCALL pause (int ticks)		// Wait n*1/18.2 secs..
{
	long temp = readtime () + ticks;
	while ( temp - readtime () > 0);
}

long farmallocmax;

  // Patch to get malloc(long) with visual C medium/small models.
void far * farmalloc (long csize)
{
	csize = csize >> 4;
	inr.h.ah = 0x48;	// Funct int21/48h, allocate mem..
	inr.x.bx = (int) csize;
	int86 (0x21,&inr,&outr);
	if (outr.x.cflag & 1) {	// Carry flag set, alloc error..
	  farmallocmax = 0;
	  if (outr.x.ax == 8) {		// Supply mem free..
	    farmallocmax = ((long) outr.x.bx) << 4;
	  }
	  return NULL;
	}
	return MK_FP (outr.x.ax,0);
}	

void FASTCALL graphmode(int mode)	/* Set Screen Graphics mode */
{
	inr.x.ax = mode;
	int86 (0x10,&inr,&outr);	/* INT 10, function 0 */
}

_inline void plot (int xpos, int ypos, int color)	/* Plot graphics */
					/* XOR if bit 7 COLOR set */
{
	inr.h.ah = 0x0c;
	inr.x.cx = xpos;
	inr.x.dx = ypos;
	inr.h.al = color;
	int86 (0x10,&inr,&outr);	/* INT 10, function 0c */
}

	// Plot straight line, -1 for same end pos..
void FASTCALL plotline (int xtop, int ytop, int xend, int yend, int color)
{
	if (xend < 0) xend = xtop;
	if (yend < 0) yend = ytop;
	do {
	  plot (xtop,ytop,color);
	  if (xtop < xend) xtop ++;
	  if (xtop > xend) xtop --;
	  if (ytop < yend) ytop ++;
	  if (ytop > yend) ytop --;
	} while (xtop != xend || ytop != yend);
}

  // 3d-style box about text..
void FASTCALL boxit (int xtop, int ytop, int xend, int yend, int gap)
{
	int xpos,ypos;
	for (xpos = xtop; xpos <= xend; xpos ++) {
	  plot (xpos,ytop,15);
	  plot (xpos,ytop+gap,8);
	  plot (xpos,yend,8);
	  plot (xpos,yend-gap,15);
	}
	for (ypos = ytop; ypos <= yend; ypos ++) {
	  plot (xtop,ypos,15);
	  plot (xtop+gap,ypos,8);
	  plot (xend,ypos,8);
	  plot (xend-gap,ypos,15);
	}
}

#define Setmode(Cmode) outport (0x03ce,Cmode);

void setmode (int cmode)	/* lo = register, hi = data */
{
	Setmode (cmode)
}

#define Setplanes(Cplane) 	/* Specify write planes */\
	outport (0x03c4,Cplane);

	/* Setplanes (0x0302);  Set reg 2 = 3 */

//-----------------------------------------------------------------------
//
//  PALETTE functions
//


int FASTCALL getpal (int pal)
{
	if (xgamode == 0) return (1);	/* CGA.. */
	inr.h.ah = 16;
	inr.h.al = 7;
	inr.h.bl = pal;
	int86 (0x10,&inr,&outr);	/* INT 10, function 16 */
	return (outr.h.bh);
}

#define Setink(Cink) getpal(Cink)

_inline void palette (int pal, int col)
{
	if (xgamode < 2) return ;	/* CGA.. */
	inr.h.ah = 16;
	inr.h.al = 0;
	inr.h.bl = pal;
	inr.h.bh = col;
	int86 (0x10,&inr,&outr);	/* INT 10, function 16 */
}



// Col0=BLK,Col6/14=BMAN, Col7/15=WMAN,Col11=DIALOGBOX,Col3/9=DK/LT-SQRCOLS.
char palz [] = {	// RGB for DAC regs 
 0,0,0, 0,0,42, 0,42,0, 5,25,25, 42,0,0, 42,0,42, 44,22,4, 42,42,42, 27,27,27,
 9,35,35, 21,63,21, 43,45,50, 63,21,21, 63,21,63, 58,29,7, 57,57,57,
 0,0,0, 0,0,42, 0,42,0, 20,25,25, 42,0,0, 40,0,42, 42,42,10, 42,42,42, 27,27,27,
 27,35,35, 21,63,21, 43,45,50, 63,21,21, 63,21,63, 58,58,12, 57,57,57,
 0,0,0,0,0,0};
 
char palorig [] = {	// Orig RGB for DAC regs 
 0,0,0, 0,0,42, 0,42,0, 5,25,25, 42,0,0, 42,0,42, 44,22,4, 42,42,42, 27,27,27,
 9,35,35, 21,63,21, 43,45,50, 63,21,21, 63,21,63, 58,29,7, 57,57,57,
 0,0,0, 0,0,42, 0,42,0, 20,25,25, 42,0,0, 40,0,42, 42,42,10, 42,42,42, 27,27,27,
 27,35,35, 21,63,21, 43,45,50, 63,21,21, 63,21,63, 58,58,12, 57,57,57,
 0,0,0,0,0,0};

// NORMAL PALETTE COLOURS:
//0,0,0, 0,0,42, 0,42,0, 0,42,42, 42,0,0, 42,0,42, 42,42,0, 42,42,42, 21,21,21,
//21,21,63, 21,63,21, 21,63,63, 63,21,21, 63,21,63, 63,63,21, 63,63,63,

	// Load block 16VGA registers
void FASTCALL loadvgapal (char *vpal)
{
	static char vbuf [60];
	void far *vb = (char far *) vbuf;
	if (xgamode < 1) return ;	// not VGA.. 
	memcpy (vbuf, vpal, 48);
	if (invertcol) {	// Swap reg 9&3 - invert board colour
	  vbuf [9] = vpal [27];vbuf [10] = vpal [28]; vbuf [11] = vpal [29];
	  vbuf [27] = vpal [9];vbuf [28] = vpal [10]; vbuf [29] = vpal [11];
	}
	inr.h.ah = 16;
	inr.h.al = 18;
	inr.x.bx = 0;		// Start reg 
	inr.x.cx = 16;		// #VGA registers
	inr.x.dx = FP_OFF (vb);	// Pallete regs 
	sregs.es = FP_SEG (vb);
	int86x (0x10,&inr,&outr,&sregs);	// INT 10, function 16 
}


#define palr(Cpal) palz[(Cpal) * 3]
#define palg(Cpal) palz[1 + (Cpal) * 3]
#define palb(Cpal) palz[2 + (Cpal) * 3]
//
void paloff ()
{
	int cpal;
	for (cpal = 0; cpal < 16; cpal ++) {
	  palette (cpal,0);
	}
}

int normpal [] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
int palmode = 0;

void palon ()
{
	int cpal;
	for (cpal = 0; cpal < 16; cpal ++) {
	  palette (cpal,normpal [cpal] );
	}
	loadvgapal (palz /*+ (palmode * 48)*/);	// Load in 16 RGB colours..
	//col1 = 3; col2 = 57; if (invertcol) {col1 = 57; col2 = 3;}
	//if (palmode) {
	//  vgapal (6,30,30,2); vgapal (62,45,45,2); vgapal (col1,10,25,25); vgapal (col2,15,35,35);
	//} else {
	//  vgapal (6,40,20,5); vgapal (62,58,29,7); vgapal (col1,5,25,25); vgapal (col2,8,35,35);
	//}
	//vgapal (63,58,58,58);vgapal (59,43,45,47);
}

void palReset () 
{
	memcpy (palz,palorig,sizeof (palz));
	loadvgapal (palz);	// Load in 16 RGB colours..
}

//-----------------------------------------------------------------------
//
//  BITMAP drawing functions
//

void FASTCALL object (int xtop, int ytop, int xlen, int ylen, char far *objarray)
{
	static int xpos,ypos;
	static int cobj;
	static int yoff;
	static int ploff,cplane,xpl;
	cobj = 0;
	if (xgamode == 2) {		/* EGA/VGA... */
	  Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	  Setmode (1)		/* Bit planes to effect - reg 1 */
	  ploff = 0; xpl = 256;
	  for (cplane = 0; cplane < 4; cplane ++) {
	    Setplanes (xpl + 2)	/* Reg 2 = plane */
	    xpl = (xpl << 1);
	    for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	      yoff = ypos * 80;
	      for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
		Vdu [yoff + xpos] = objarray [cobj];
		cobj ++;
	      }
	    }
	    Setplanes (0x0f02)	/* Reg 2 = 15, Enable all write planes */
	    ploff += (Ssize >> 2);
	  }
	  return ;
	}
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  yoff = (ypos >> 1) * 80 + ((ypos & 1) << 13);
	  for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	    Vdu [yoff + xpos] = objarray [cobj];
	    cobj ++;
	  }
	}
}

#define Readplane(Cplane) \
	outport (0x03ce,Cplane);

	// Read data from screen into array..
void FASTCALL getobject (int xtop, int ytop, int xlen, int ylen, char far *objarray)
{
	int xpos,ypos;
	int cobj = 0;
	int yoff;
	static int cplane;
	if (xgamode) {		/* EGA/VGA... */
	  for (cplane = 4; cplane < 1024; cplane += 256) {
	    Readplane (cplane)	/* Reg 4 = plane */
	    for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	      yoff = ypos * 80;
	      for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	        objarray [cobj] = Vdu [yoff + xpos];
	        cobj ++;
	      }
	    }
	  }
	  return ;
	}
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  yoff = (ypos >> 1) * 80 + ((ypos & 1) << 13);
	  for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	    objarray [cobj] = Vdu [yoff + xpos];
	    cobj ++;
	  }
	}
}

void FASTCALL fillobject (int xtop, int ytop, int xlen, int ylen, int pattern, int color)
		/* Fill an object on screen with char pattern */
{
	int xpos,ypos;
	int yoff;
	if (xgamode == 2) {		/* EGA/VGA... */
	  Setplanes (0x0f02)	/* Enable ALL planes - Reg 2 = 15 */
	  Setmode (color & 0xff00)	/* RESET/SET fix pattern - reg 0 */
	  Setmode ((color << 8) | 1)	/* Bit planes to effect - reg 1 */
	  for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	    yoff = ypos * 80;
	    for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	      Vdu [yoff + xpos] = pattern;
	    }
	  }
	  Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	  Setmode (1)		/* Bit planes to effect - reg 1 */
	  return ;
	}
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  yoff = (ypos >> 1) * 80 + ((ypos & 1) << 13);
	  for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	    Vdu [yoff + xpos] = pattern;
	  }
	}
}

int anyfly = 0;
void testfly ()		/* Test for hardware flyback */
{             
   #if 0
	long temp = readtime () + 3;
	UINT test = inport (0x3da) & 8;
	while ( readtime () < temp) {
	  if (test != ( inport (0x3da) & 8)) return;
	}    
   #endif
   anyfly = 0;
}

void syncfly ()		/* 03da bit 3 set during flyback - bot to top bdr */
{
	if (anyfly) {
	  while (inport (0x3da) & 8);
	  while ((inport (0x3da) & 8) == 0);
	}
}

void spause (int ticks)
{
	int ctick;
	if (anyfly) {
	  for (ctick = 1; ctick <= ticks; ctick ++) {
	    syncfly ();
	  }
	} else {
	  if (ticks > 1) ticks = ticks >> 1;
	  pause (ticks);
	}
}

int soundflag = 1;
int savesound;
void soundon ()
{
	savesound = inportb (0x61);		/* Keep setting */
	if (soundflag)
	  outportb (0x61, savesound | 3);	/* Speaker on */
}

MYINLINE void setfreq (int hertz)
{
	int outfreq = (int) ((long) 1331000/hertz);	/* Calc port val */
	outportb (0x43, 0xb6);		/* Set mode */
	outportb (0x42, outfreq & 0xff);	/* Write lo */
	outportb (0x42, outfreq >> 8);		/* Write hi */
}

void soundoff ()
{
	outportb (0x61,savesound);	/* restore setting */
}

void FASTCALL soundit (int hertz, int ticks)
{
	setfreq (hertz);
	soundon ();
	spause (ticks);
	soundoff ();
}

void click ()
{
	soundit (500,1); soundit (1000,1);
	soundit (700,1);
}

_inline void dink ()
{
	soundit (2000,1);
}

_inline void plink ()
{
	soundit (700,3);
}

		/* Special Char set func */
char far *chset;
int setchsize;
char far *set16;
char far *set8;

	// Get ptr to char set from VGA-ROM..
	// 0 for 8x16..1 for 8x8
void SelectSet (int set)
{
	//long far *tempptr;
	//tempptr = (long far *) MK_FP(0,0x010c);	/* INT 43h =chrset ptr */
	//chset = (char far*) (*tempptr);
	if (set) {
	  chset = set8;
	  setchsize = 8;
	} else {
	  chset = set16;
	  setchsize = 16;
	}
	
}

	// Get ptrs to char sets in ROM..
void InitSetPtrs ()
{
	long far *tempptr;
	graphmode (18);	// Mode 18 = 640*480 16col 
		// Read 8x8 set ROM loc->INT43 ptr
	inr.x.ax = 0x1123;
	inr.x.bx = 0x0003;
	int86 (0x10,&inr,&outr);	// INT 10h/func11/23h
	tempptr = (long far *) MK_FP(0,0x010c);	/* INT 43h =chrset ptr */
	set8 = (char far*) (*tempptr);
		// Read 8x16 set ROM loc->INT43 ptr
	inr.x.ax = 0x1124;
	inr.x.bx = 0x0002;
	int86 (0x10,&inr,&outr);	// INT 10h/func11/24h
	tempptr = (long far *) MK_FP(0,0x010c);	/* INT 43h =chrset ptr */
	set16 = (char far*) (*tempptr);
}

	// Set fore/back colour for quickprint (0 to reset to normal)
	// lobye = col, hibye=back..
_inline void qpcolor (int ccolor)	
{
	Setplanes (0x0f02)	//* Enable ALL planes - Reg 2 = 15 
	Setmode (ccolor & 0xff00)	// RESET/SET fix pattern - reg 0 
	Setmode ((ccolor << 8) | 1)	// Bit planes to effect - reg 1 
	//  Setmode (0);Setmode (1);	will reset to norm..
}

	// Quick-plot a char at pos..
_inline void qpchr (int xtop, int ytop, int cchr, BYTE mask)
{
	int ypos;
	char far *ptrset = chset + (cchr * setchsize);	// Ptr to cur chr..
	char far *pVdu = Vdu + (xtop + ytop * 80);
	for (ypos = 0; ypos < setchsize; ypos += 2) {
	  *pVdu = (*ptrset) ^ mask;
	  pVdu += 80; ptrset ++; 
	  *pVdu = (*ptrset) ^ mask;
	  pVdu += 80; ptrset ++;
	}
}

			// PRINT_CTRLS - OR to XPOS in prn commands
#define PRNINV 0x8000		// Invert video out
#define PRNREL 0x4000		// x/ypos rel to last prn
#define PRNPIX 0x2000		// YPOS in pixels, not chrs
#define PRNCENT 0x1000		// Center text
#define PRNNOBAR 0x0800		// Dont Create win-style title bar
#define PRNRET 0x0400		// No process-loop - immediate return..
#define PRNBOX 0x0200		// Show box around toolbar..

#define PRNBLK 15
#define PRNGREY 8
#define PRNDGREY 7
#define PRNDLG 4	// Dialog box color
#define PRNANAL 4	// Anal txt col
#define PRNANLO	774	// Anal lo-lite col (also try 772 on..)	
#define PRNANLO2 773	// Anal lo-lite col 
#define PRNSTAT 4	// stats txt col.
#define PRNRED 3	// Red colour
#define PRNWHT 0

	// Fast Print at (xy) pos in chars in given fore/back color
	// at pos (0,0=top left)
	// set PRNINV XPOS for invert prn..
	// PRNREL for Relative ypos, PRNPIX for Ypos in pixels
void FASTCALL prnat (int ixpos, int iypos, int xend, int ccolor, char *istr)
{
	int cpos,cchr;
	static int ypos;
	int xpos = ixpos & 0x03ff;	// Mask out any flags..
	int xbeg;
	BYTE mask = 0;
	if (ixpos & PRNCENT) {		// Auto-center string..
	  xpos -= (strlen (istr) >> 1);
	}
	if (!(ixpos & PRNPIX)) {	// y-in is in chars, conv to pixels
	  iypos *= setchsize;
	}
	if (ixpos & PRNREL) {	// Just move rel to last prn..
	  ypos += iypos;
	} else {
	  ypos = iypos;
	}
	if (ixpos & PRNINV) {		// Invert..
	  mask = 0xff;
	}
	if (xend < xpos) xend = 79;
	xbeg = xpos;		// save start pos
	if (xgamode < 2) {		// CGA..
	  gotoxy (xpos + 1, 1 + (ypos / 8));
	  prints (istr);
	  return;
	}
	qpcolor (ccolor);	// Set to print in a given colour
	cpos = 0; 
	do {
	  cchr = istr[cpos];
	  if (cchr == 0) break;
	  if (cchr == 10 || xpos > xend) { 	// End of line..
	    xpos = xbeg; ypos += setchsize;
	    if (ypos >= 480) break;		// End of screen
	    if (cchr == 10) {cpos ++; continue;}
	  }
	  qpchr (xpos, ypos, cchr,mask);
	  xpos ++; cpos ++;
	} while (1);
	qpcolor (0);		// Back to normal
}

	// Fast printf string at loc, with color etc..
void printfat (int xpos, int ypos, int xend, int ccolor, char *format,...)
{
	char prbuf[1500];	// tmp buf for printing..
	va_list argptr;		// define var ptr to args..
	va_start (argptr,format);
	_vsnprintf (prbuf,sizeof (prbuf) - 10,format, argptr);
	va_end (argptr);
	prnat (xpos, ypos, xend, ccolor, prbuf);
}

void clrvdu ()		/* Wipe hires screen/board */
{
	rmarg = charx * boardx + 4;
	if (rmarg < 52) rmarg = 52;
	if (rmarg > 64) rmarg = 64;
	chrsize = 8; botline = 25;
	if (xgamode == 2) {
	  botline = 30;
	  Vdu = (BYTE far *) 0xa0000000;	/* Ptr to EGA/VGA screen */
	  graphmode (18);	/* Mode 18 = 640*480 16col */
	  chrsize = 16;
	  Vdui = (UINT far *) Vdu;
	  Setplanes (0x0f02)	/* Enable ALL planes - Reg 2 = 15 */
	  Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	  Setmode (1)		/* Bit planes to effect - reg 1 */
	  topy = 18;
	  palon (); // very slow statement!
	  getpal (7);		/* Wht ink */
	} else {
	  Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	  graphmode (6);
	  topy = 2;
	}
	SelectSet (0);
}

void qclrvdu ()	// Quick screen-wipe..
{
	if (xgamode == 2) {
	  fillobject (0,0,80,480,0,0);
	} else {
	  graphmode (6);
	}
}

#define Hidescreen hardscroll (1);
#define Showscreen hardscroll (0);

void hardscroll (int mode)	/* 1=hide,  0=reappear  */
{
	if (mode) clrvdu ();
	if (xgamode < 2) return;
	if (mode) {
	  paloff ();
	} else {
	  palon ();
	}
	return;
}

void FASTCALL clrcol (int col, int cline)	/* Set text scr colors,0=whole scr */
{
	int xpos;
	Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	if (cline) {
	  cline = cline * 160 - 159;
	  for (xpos = cline; xpos < cline + 160; xpos += 2) {
	    Vdu [xpos] = col;
	  }
	} else {
	  graphmode (3);
	  for (xpos = 1; xpos < 4000; xpos += 2) {
	    Vdu [xpos] = col;
	  }
	}
}

void FASTCALL gotoxy (int xloc, int yloc)	/* Goto to loc X,Y on VDU */
{
	curx = xloc; cury = yloc;
	inr.h.bh = 0;
	inr.h.dl = xloc - 1;
	inr.h.dh = yloc - 1;
	inr.h.ah = 0x02;
	int86 (0x10,&inr,&outr);	/* INT 10, function 02 */
}

int wherex ()
{
	return (curx);
}

int wherey ()
{
	return (cury);
}

void FASTCALL printc (int ichr)		/* Print a Char to vdu/prn/buf */
{
	nprint ++;
	if (ichr == 0) ichr = 32;
	if (tprintflag > 2 && cfilebuf < Mfilebuf) {	/* Out to buffer */
	  xfilebuf [cfilebuf] = ichr;
	  cfilebuf ++;
	  xfilebuf [cfilebuf] = 32;
	  return;
	}
	if (tprintflag != 1) {		/* Output to screen */
	  inr.h.ah = 0x0e;
	  inr.h.al = ichr;
	  int86 (0x10,&inr,&outr);	/* INT 10, function 0e */
	  if (tprintflag == 0) return;
	}
	inr.h.ah = 0x05;	/* Print to printer */
	inr.h.dl = ichr;
	int86 (0x21,&inr,&outr);
}

void FASTCALL prints (char *istr)	/* Print a null-term string */
{
	int cchr;
	for (cchr = 0; istr [cchr]; cchr ++) {
	  if (istr [cchr] == 10) printc (13);
	  printc ( istr [cchr]);
	}
}

void FASTCALL println (long iint, int npr)	/* Print a signed int */
{
	int cchr;
	npr = nprint + npr;
	if (iint == 0) {
	  printc ('0');
	} else {
	  if (iint < 0) {
	    printc ('-');
	    iint = -iint;
	  }
	  for (cchr = 0; iint; cchr ++) {
	    prbuffer [cchr] = (BYTE) ((long) 48 + (iint % 10));
	    iint /= 10;
	  }
	  prbuffer [cchr] = 0;
	  while (cchr) {
	    cchr --;
	    printc ( prbuffer [cchr]);
	  }
	}
	while (nprint - npr < 0) {
	  printc (' ');
	}
}

void FASTCALL printl (long iint) 
{
	println (iint,0);
}

void FASTCALL printi (int iint)
{
	printl ((long) iint);
}

void FASTCALL printsi (char *istr, int iint)		/* Composite short cut */
{
	prints (istr);
	printi (iint);
}

void FASTCALL printsn (char *istr, int iint, int npr)	// Composite short cut 
{
	prints (istr);
	println ((long) iint, npr);
}

void FASTCALL printis (int iint, char *istr)		/* Composite short cut */
{
	printi (iint);
	prints (istr);
}

void FASTCALL printsl (char *istr, long iint)		/* Composite short cut */
{
	prints (istr);
	printl (iint);
}

void FASTCALL rjust (int count)		/* Right-justify.. */
{
	while (nprint < count) {
	  printc (' ');
	}
}

void FASTCALL printwside (char *istr, int cline)		/* Wipe side & print */
{
	gotoxy (rmarg,cline);
	nprint = rmarg;
	rjust (80);
	gotoxy (rmarg,cline);
	prints (istr);
}

void FASTCALL printwsidei (char *istr, int iint, int cline)
{
	gotoxy (rmarg,cline);
	nprint = rmarg;
	rjust (80);
	gotoxy (rmarg,cline);
	prints (istr);
	printi (iint);
}

void FASTCALL printside (char *istr, int cline)
{
	gotoxy (rmarg,cline); prints (istr);
}

/*int abs (int x)
{
	if (x < 0) return (-x);
	return (x);
}*/

int getkey ()
{
	inr.h.ah = 0x06;
	inr.h.dl = 0xff;
	int86 (0x21,&inr,&outr);	/* INT 21, function 6 */
	return (outr.h.al);
}

void FASTCALL farloaddata (char *filename,void far *brddata,int datasize)
{						/* Load data from disk */
	int chandle;
	diskerror = 0;
	inr.x.dx = (unsigned int) filename;
	inr.h.ah = 0x3d;
	inr.h.al = 0;		/* 0=read,1=write,2=rnd */
	int86 (0x21,&inr,&outr);	/* INT 21, 3d OPEN */
	chandle = outr.x.ax;
	if (outr.x.cflag & 1) { 	/* Carry set ? */
	  diskerror ++;
	  return ;
	}

	inr.x.bx = chandle;
	inr.x.cx = datasize;
	inr.h.ah = 0x3f;
	inr.x.dx = FP_OFF (brddata);	/* Disk buffer */
	sregs.ds = FP_SEG (brddata);
	int86x (0x21,&inr,&outr,&sregs);	/* INT 21, 40 Write */

	inr.x.bx = chandle;
	inr.h.ah = 0x3e;
	int86 (0x21,&inr,&outr);	/* INT 21, 3e CLOSE */
}

void FASTCALL floaddata (char *filename,void *brddata,int datasize)
{
	farloaddata (filename,(void far *) brddata,datasize);
}

void FASTCALL farsavedata (char *filename,void far *brddata,int datasize)
{
	int chandle;
	diskerror = 0;
	inr.x.dx = (unsigned int) filename;
	inr.h.ah = 0x3c;
	inr.x.cx = 0;
	inr.h.al = 0;
	int86 (0x21,&inr,&outr);	/* INT 21, 3c CREATE */
	chandle = outr.x.ax;
	if (outr.x.cflag & 1) { 	/* Carry set ? */
	  diskerror ++;
	  return ;
	}

	inr.x.bx = chandle;
	inr.x.cx = datasize;
	inr.h.ah = 0x40;
	inr.x.dx = FP_OFF (brddata);	/* Disk buffer */
	sregs.ds = FP_SEG (brddata);
	int86x (0x21,&inr,&outr,&sregs);	/* INT 21, 40 Write */
	inr.x.bx = chandle;
	inr.h.ah = 0x3e;
	int86 (0x21,&inr,&outr);	/* INT 21, 3e CLOSE */
}

void FASTCALL fsavedata (char *filename,void *brddata,int datasize)
{
	farsavedata (filename,(void far *) brddata,datasize);
}

  // Ret 1 if file exists, 0 if it does not exists.
int FileExists (char *ifile)
{
	FILE *hFile;
	hFile = fopen (ifile,"r");
	if (hFile) fclose (hFile);
	return (hFile != NULL);
}

void FASTCALL linput (char *istr, int maxlen)	/* Simple Alt to scanf */
{
	int cchr = 0;
	istr [0] = 0;
	do {
	  prints ("_\b");	/* Underline cursor */
	  do {
	    inkey = getkey ();
	  } while (inkey == 0);
	  istr [cchr] = 0;
	  if (inkey > 127)
	    continue;
	  if (inkey > 31) {		/* Norm char, display and add */
	    if (cchr >= maxlen)		/* Too long ? */
	      continue;
	    printc (inkey);
	    istr [cchr] = inkey;
	    cchr ++;
	    continue;
	  }
	  if (inkey == 8 && cchr > 0) {		/* Delete key ? */
	    cchr --;
	    istr [cchr] = 0;
	    prints (" \b\b \b");
	  }
	} while (inkey != 13 && inkey != 27);
	prints (" \n");
	if (inkey == 27)
	  istr [0] = 0;
}

int FASTCALL inchr (char *bigstr, int fchr)	/* Find char in BIGSTR (-1 fail) */
{
	int scount;
	for (scount = 0; bigstr [scount] != 0; scount ++)
	  if (bigstr [scount] == fchr)
	    return (scount);
	return (-1);
}
	/* End of Gen I/O */


MYINLINE void qputat (int xpos, int ypos, int cpiece)	/* Simple PUTAT */
{
	xpos = xpos * charx - charx + topx;
	ypos = ypos * chary - chary + topy;
	object ( xpos, ypos, charx, chary, sprites + cpiece * Ssize);
}

void FASTCALL putat (int xpos, int ypos, int cpiece)
{		/* 2/3=B,4/5=W,6=Ggrey,7=Gcur */
	if (boardflip) {
	  xpos = boardx + 1 - xpos;
	  ypos = boardy + 1 - ypos;
	}
	xpos = xpos * charx - charx + topx;
	ypos = ypos * chary - chary + topy;
	if (xgamode < 2) {
	  if (cpiece == 0) {
	    fillobject (xpos, ypos,charx,chary,0,0);
	    return;
	  }
	  if (cpiece == Ggrey ) {
	    fillobject (xpos, ypos,charx,chary,0xaa,0);
	    return;
	  }
	  if (cpiece == Gcur) {
	    fillobject (xpos, ypos,charx,chary,0xff,0);
	    return;
	  } else {
	    cpiece -= 2;
	  }
	} else {
	  if (cpiece == Ggrey ) {
	    fillobject (xpos, ypos,charx,chary,0xff,6);
	    return;
	  }
	  if (cpiece == 0 ) {
	    fillobject (xpos, ypos,charx,chary,0xff,12);
	    return;
	  }
	  if (cpiece == Gcur) cpiece --;
	  cpiece -= 2;
	}
	object ( xpos, ypos, charx, chary, sprites + cpiece * Ssize);
}

void FASTCALL bputat (int xpos, int ypos, int cpiece)
{
	if (cpiece == -1) {		/* -1, so take from board [] */
	  cpiece = Getboard (xpos,ypos) ;
	  if (cpiece == Edge)
	    cpiece = Ggrey;
	}
	putat (xpos, ypos, cpiece);
}

void FASTCALL gputat (int xbrd, int cpiece)
{
	bputat (xbrd % bmult, xbrd / bmult, cpiece);
}

	// Build an ASC int 000 format 
	// FORM - # digits, (bit 4 set = no leading zeros)
	// bit 5=left justify, bit 6=null-terminate
void CODESEG int2asc (char *cptr, int cval, int form)
{
	int leadflag = form;
	int termchr = 32;
	if (leadflag & 64) termchr = 0;
	form &= 15;
	cptr [form] = termchr;	// Put terminator on end
	if (leadflag & 32) {	// Left justify
	  int cv = cval;
	  while (form) {
	    form --;
	    cptr [form] = termchr;
	  }
	  form = 0;
	  while (cv) {
	    cv = cv / 10; form ++;
	  } 
	}
	while (form) {
	  form --;
	  if ((leadflag & 16) && cval == 0) {	// no leading zeros
	    cptr [form] = 32;
	  } else {
	    cptr [form] = (cval % 10) + 48;
	  }
	  cval = cval / 10;
	}
}

MYINLINE char *printpos (int txpos, int typos)
{
	char static cstr [10];
	if (numflag) {
	  txpos = boardx + 1 - txpos;
	  typos = boardy + 1 - typos;
	}
	cstr [0] = 64 + txpos;
	int2asc (cstr + 1, boardy + 1 - typos, 2 | 32 | 64);
	return cstr;
}

  // Covnvert board-pos to null term string (numeric or chess not)
void FASTCALL Pos2Str (char *ostr, int cpos)
{
	if (notateflag) {	// Use chess notation?
	  cpos = sqpos [cpos];
	  if (numflag) cpos = InvertPos (cpos);
	  ostr[0] = 96 + (cpos % bmult);
	  int2asc (ostr + 1, bmult - 1 - cpos / bmult, 2 | 32 | 64);
	} else {
	  int2asc (ostr, cpos, 2 | 32 | 64);
	}
}

	// Ret null-term string with move..
	// (shift str-ptr on for multi-calls..)
char * FASTCALL Move2Str (int mfrom, int mdir)
{
	static char oostr [40];
	static int spos;
	char *ostr = oostr + ((spos & 3) << 3);
	char *cstr = ostr;
	if (mfrom == 0) return ("     ");
	spos ++;
	Pos2Str (ostr, sqnums [mfrom]);
	while (*cstr) cstr ++;
	*cstr = '-'; cstr ++;
	Pos2Str (cstr, sqnums [mfrom + mdir]);
	return (ostr);
}

	// Convert book-move to string..
#define BookMove2Str(CMV) \
  Move2Str (((UINT) (CMV)) >> 8,((CMV) & 0xff) - (((UINT) (CMV)) >> 8))

void FASTCALL printnpos (int cpos)	/* Print pos in right notation */
{
	if (notateflag) {	// Use chess notation?
	  cpos = sqpos [cpos];
	  if (numflag) cpos = (boardx + 2) * (boardy + 2) - cpos - 1;
	  printc (64 + (cpos % bmult));
	  printi (bmult - 1 - cpos / bmult);
	} else {
	  printi (cpos);
	}
}

void FASTCALL printmove (int mfrom, int mdir)
{
	int np = nprint;
	printnpos (sqnums [mfrom]);
	printc ('-');
	printnpos (sqnums [mfrom + mdir]);
	while (nprint - np < 5) printc (' ');
}

_inline int far bpos (int xpos, int ypos)
{
	return (xpos + ypos * bmult);
}

void boxboard ()
{
	int t1,t2;
	botx = charx * boardx + topx;
	boty = chary * boardy + topy;
	t1 = 0xff; t2 = 0x01;
	if (xgamode == 0) {
	  t1 = 0xaa; t2 = 0x02; /* boty --; */
	}
	fillobject (topx,topy-1,botx-topx,1,t1,Dgrey);
	fillobject (topx,boty,botx-topx,1,t1,Dgrey);
	fillobject (topx-1,topy,1,boty-topy,t2,Dgrey);
	fillobject (botx,topy,1,boty-topy,0x80,Dgrey);
}

static long Seed_ = 1;

void srand (unsigned seed)	// Seed rnd num generator
{
        Seed_ = seed;
}

void CODESEG fsrand (unsigned seed)	// Far version..
{
        Seed_ = seed;
}

int rand (void)		// Get rnd # 0..32767
{
        Seed_ = 0x015a4e35L * Seed_ + 1;
        return ((int) (Seed_ >> 16) & 0x7fff);
}

int CODESEG frand (void)
{
        Seed_ = 0x015a4e35L * Seed_ + 1;
        return ((int) (Seed_ >> 16) & 0x7fff);
}

void drawboard ()
{
	// palon (); // very slow statement!
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    bputat (xpos,ypos, -1);
	  }
	}
	boxboard ();
}

void shutwindow (int xlen, int ylen)	/* Redraw part screen */
{
	xlen = (xlen / charx) + 1;
	ylen = ((ylen * chrsize) / chary) + 1;
	for (xpos = 1; xpos <= xlen; xpos ++) {
	  for (ypos = 1; ypos <= ylen; ypos ++) {
	    if (boardflip) {
	      xpos = boardx + 1 - xpos;
	      ypos = boardy + 1 - ypos;
	    }
	    bputat (xpos,ypos, -1);
	    if (boardflip) {
	      xpos = boardx + 1 - xpos;
	      ypos = boardy + 1 - ypos;
	    }
	  }
	}
	boxboard ();
}

//-----------------------------------------------------------------------
//
//  MOUSE API functions..
//


void mouse (int mode, int *button, int *xpos, int *ypos)
{
	if (mouseflag == 0) {	// No mouse, so button always zero
	  *button = 0; return;
	}
	inr.x.ax = mode;
	int86 (0x33,&inr,&outr);	/* INT 33, Mouse functions.. */
	*button = outr.x.bx;
	*xpos   = outr.x.cx;
	*ypos   = outr.x.dx;
}

void resetmouse ()	// Test to see if mouse exists-if not, MOUSEFLAG off
{
	inr.x.ax = 0;
	int86 (0x33,&inr,&outr);	/* INT 33, Mouse functions.. */
	if (outr.x.ax == 0) {
	  mouseflag = 0;
	}
}

void smouse (int mode)		/* Init mouse 1=show, 2=hide */
{
	inr.x.ax = mode;
	int86 (0x33,&inr,&outr);	/* INT 33, Mouse functions.. */
}

void showmouse ()
{
	if (mouseflag) smouse (1);	/* Show mouse */
}

void hidemouse ()
{
	if (mouseflag) smouse (2);	/* Hide mouse */
}

int getmouse ()
{
	mbutton = 0;
	if (mouseflag) {
	  mouse (3, &mbutton, &mousex, &mousey);
	}
	return (mbutton);
}

int mouse2sqr (int xloc, int yloc)	/* Conv Mouse to sqr no. */
{
	xloc = (xloc - 8 * topx) / (charx * 8) + 1;
	yloc = (yloc - topy) / chary + 1;
	if (xloc < 1 || xloc > boardx || yloc < 1 || yloc > boardy)
	  return (0);
	if (boardflip) {
	  xloc = boardx + 1 - xloc;
	  yloc = boardy + 1 - yloc;
	}
	return (xloc + yloc * bmult);
}


//-----------------------------------------------------------------------
//
//  PULL-DOWN MENU routines..
//

	
void printbit (char *istr, int endchr, int nchr)
{
	char ctext [40];
	int cchr,cmode = 0;
	for (cchr = 0; cchr < nchr; cchr ++) {
	  if (istr [cchr] == endchr) cmode ++;
	  if (cmode) {
	    ctext [cchr] = ' ';
	  } else {
	    ctext [cchr] = istr [cchr];
	  }
	}
	ctext [cchr] = 0;
	prints (ctext);
}

void menuprint (int menuwidth, int nmenu, char *mmenu)
{
	int cmenu;
	int nptr;
	int cptr = 0;
	gotoxy (2,1);
	printbit ("*", '*',menuwidth);
	for (cmenu = 1; cmenu <= nmenu; cmenu ++) {
	  gotoxy (2,1+cmenu);
	  printc (' ');
	  printbit (mmenu + cptr, '[',menuwidth-1);
	  nptr = inchr (mmenu + cptr,']');
	  if (nptr < 0) return;
	  cptr += nptr + 1;
	}
	gotoxy (2,2 + nmenu);
	printbit ("*", '*',menuwidth);

	fillobject (0,0,1,(nmenu + 2) * chrsize, 0xc0, Yel);
	fillobject (menuwidth+1,0,1,(nmenu + 2) * chrsize,0x03, Yel);
	fillobject (0,0,menuwidth+2,1,0xff, Yel);
	fillobject (0,(nmenu + 2) * chrsize, menuwidth+2,1,0xff, Yel);
}

int mousemenu (int menuwidth, int nmenu, char *mmenu)
{
	int temphi,cchr;
	int tempx,tempy;
	int hilite = 0;
	getpal (10);
	tempx = wherex (); tempy = wherey ();
	hidemouse ();
	menuprint (menuwidth, nmenu, mmenu);
	showmouse ();
	getpal (15);
	while (getmouse () == 2) {		/* Wait for button release */
	  temphi = mousey / chrsize;
	  if (mousex > menuwidth * 8 || mousey > nmenu * chrsize + chrsize - 2)
	    temphi = 0;
	  if (temphi != hilite) {
	    hidemouse ();
	    if (hilite) {
	      gotoxy (2,hilite + 1);
	      printc (' ');
	    }
	    hilite = temphi;
	    if (hilite) {
	      gotoxy (2,hilite + 1);
	      printc ('*');
	    }
	    showmouse ();
	  }
	}		/* Button released */
	hidemouse ();
	gotoxy (1,1);
	printc (' ');
	if (hilite) {
	  cchr = 0;
	  for (temphi = 1; temphi <= hilite; temphi ++) {
	    cchr += inchr (mmenu + cchr, '[') + 1;
	  }
	  inkey = mmenu [cchr];
	}
	gotoxy (tempx, tempy);
	fillobject (0,0,menuwidth + 2, 1 + (nmenu + 2) * chrsize, 0, Wht);
	/* fillobject (0,0,menuwidth + 2, 2, 0, Wht); */
	return (hilite);
}

//-----------------------------------------------------------------------
//
//  TOOL/BUTTON/DIALOG-BOX routine..
//

  
	// Shift screen-part down by nmov pixels..
void ShiftVdu (int ixtop, int ytop, int ixlen, int ylen, int nmov)
{
	static BYTE mask[] = {0,1,3,7,0x0f,0x1f,0x3f,0x7f,0xff};
	static int xtop,xlen;
	int xpos,ypos,cpl;
	int cloc,coff,cmask1,cmask2;
	xtop = ixtop >> 3; 
	xlen = ((8 + ixlen + ixtop) >> 3) - xtop;
		// trim height to ensure no overflow..
	ylen = min (ylen, ((int) sizeof (tempbmp) - 200) / xlen);
	getobject (xtop,ytop,xlen,ylen,tempbmp); 	// Read from VDU
	coff = xlen * nmov;
	cmask1 = mask [(~ixtop) & 7];
	cmask2 = ~mask [(~(ixtop + ixlen + 8)) & 7];
	for (cpl = 3; cpl >= 0; cpl --) {
	  for (ypos = ylen - nmov - 1; ypos >= 0; ypos --) {
	    cloc = (cpl * ylen + ypos) * xlen;
	    tempbmp [cloc + coff] = ((~cmask1) & tempbmp [cloc + coff])
	  	|  (cmask1 & tempbmp [cloc]);
	    for (xpos = 1; xpos < xlen - 1; xpos ++) {
	      tempbmp [cloc + xpos + coff] = tempbmp [cloc + xpos];
	    }
	    cloc += (xlen - 1);
	    tempbmp [cloc + coff] = ((~cmask2) & tempbmp [cloc + coff])
	  	|  (cmask2 & tempbmp [cloc]);
	  }
	}
	object (xtop,ytop,xlen,ylen,tempbmp); 	// Put onto VDU
}

char * GetToolStr (char *istr, int index)
{
	while (index) {
	  if (*istr == 1) return "";	// not found..
	  while (*istr) istr ++;
	  istr ++;
	  index --;
	}
	return istr;
}

void ShowButton (int xpos, int ypos, int xlen, int ylen, char *istr) 
{
	char clen = strlen (istr);
	xpos &= (~7); xlen &= (~7);
	fillobject (xpos >> 3, ypos, xlen >> 3, ylen, 0xff, PRNGREY);
	prnat (PRNCENT | PRNINV | PRNPIX | ((xpos + xpos + xlen) >> 4), 
		(ypos + ypos + ylen - setchsize + 2) >> 1,0, PRNGREY, istr);
	fillobject (xpos >> 3, ypos, xlen >> 3, 2, 0xff, PRNWHT);
	fillobject (xpos >> 3, ypos + ylen - 2, xlen >> 3, 2, 0xff, PRNDGREY);
	plotline (xpos,ypos + 2, -1, ypos + ylen - 1,15);
	plotline (xpos + 1,ypos + 2, -1, ypos + ylen - 2,15);
	plotline (xpos + xlen - 1,ypos + 1, -1, ypos + ylen - 1,8);
	plotline (xpos + xlen - 2,ypos + 2, -1, ypos + ylen - 1,8);
		// black outline
	fillobject (xpos >> 3, ypos - 1, xlen >> 3, 1, 0xff, PRNBLK);
	fillobject (xpos >> 3, ypos + ylen, xlen >> 3, 1, 0xff, PRNBLK);
	plotline (xpos - 1,ypos - 1, -1, ypos + ylen,0);
	plotline (xpos + xlen,ypos - 1, -1, ypos + ylen,0);
}

  // if mode, repaint background
void ShowEditField (TBUTTONHEADER *hBut, int mode)
{
	int xpos = hBut->edx;
	int ypos = hBut->edy;
	int xlen = hBut->edlx << 3;
	int ylen;
	char *istr = hBut->edit;
	char clen = strlen (istr);
	if (xpos < 0) {		// Reletive to top/left of bmp-block..
	  xpos = hBut->x - xpos;
	  ypos = hBut->y - ypos;
	}
	if (xlen + xpos >= 640) xlen = 640 - xpos;
	ylen = setchsize * ((hBut->edmax + 3 + (xlen >> 4)) / (xlen >> 3)) + 2;
	xpos &= (~7); xlen &= (~7);
	if (mode & 1) fillobject (xpos >> 3, ypos, xlen >> 3, ylen, 0xff, PRNWHT);
	prnat (PRNINV | PRNPIX | (xpos >> 3), ypos + 1,
		(xpos + xlen - 8) >> 3, PRNWHT, istr);
	if (mode & 1) {		// black outline
	  fillobject (xpos >> 3, ypos - 1, xlen >> 3, 1, 0xff, PRNBLK);
	  fillobject (xpos >> 3, ypos + ylen, xlen >> 3, 1, 0xff, PRNBLK);
	  plotline (xpos - 1,ypos - 1, -1, ypos + ylen,0);
	  plotline (xpos + xlen,ypos - 1, -1, ypos + ylen,0);
	}
}

void ShowSpinField (TBUTTONHEADER *hBut, int cspin)
{
	int xpos,ypos,xlen,ylen = setchsize + 2;
	TBUTTONINFO *iBut = hBut->bi + cspin;	// Ptr to individual button data
	int *cvar = (int *) iBut->var;		// Ptr to variable
	char *cstr;
	xpos = hBut->x + iBut->x; 	// Pos of spin-field..(rel to topleft)
	ypos = hBut->y + iBut->y;	
		// Calc length of spin-text field..(in pixels)
	xlen = 16; temp = iBut->rkey;
	do {
	  temp = temp / 10; xlen += 8;
	} while (temp);
	xpos &= (~7);
		// keep var within range
	*cvar = min (iBut->rkey, max (iBut->lkey, *cvar));
	object (xpos >> 3, ypos, 2, 25,spinbmp);	// SPIN-BUTTON
	xpos += 24; ypos += 4;	// Move to top-left number field..
		// Now print number-field box..
	fillobject (xpos >> 3, ypos, (xlen >> 3), ylen, 0xff, PRNWHT);
	printfat (PRNINV | PRNPIX | (xpos >> 3) + 1, ypos + 1,-1, PRNWHT, 
		"%d",*cvar);
		// Black outline..
	fillobject (xpos >> 3, ypos - 1, xlen >> 3, 1, 0xff, PRNBLK);
	fillobject (xpos >> 3, ypos + ylen, xlen >> 3, 1, 0xff, PRNBLK);
	plotline (xpos - 1,ypos - 1, -1, ypos + ylen,0);
	plotline (xpos + xlen,ypos - 1, -1, ypos + ylen,0);
		// Now get & print text field..
	cstr = GetToolStr (hBut->txt,cspin + cspin);
	if (*cstr) {
	  prnat (PRNINV | PRNPIX | (hBut->x + iBut->lx) >> 3, hBut->y + iBut->ly, -1, PRNDLG, cstr);
	}
}

	// Shortcut to set pos & draw..
#define DrawToolsAt(HEAD,HX,HY) \
	HEAD.x = (HX) & (~7); HEAD.y = HY; ProcessToolKey (&HEAD,0);

  // Mode = 0 for repaint
  // Mode = 1 for check action (mbutton,mousex/y) & service
  // Mode = 2 for also read mouse pos & get keystroke..
  // Mode = 3 for process until button/escape hit..
  // ret asc key code for function, or 0 for none
int ProcessToolKey (TBUTTONHEADER *hBut, int mode)
{
	TBUTTONINFO *iBut = hBut->bi;	// Ptr to individual button data
	UINT cbut;
	UINT htx = hBut->x;	// Top x/y of bmp..
	UINT hty = hBut->y;
	UINT cbx,cby,cblx,cbly;		// cur button..
	UINT ctype,nextpause;
	int spinc;		// spin-increment..
	int *cvar;		// spin/tick-variable
	char *cstr;
	int res = 0;
	if (mode == 0) {	// Repaint
	  ActionHit = 0;	// Flag incr when button hit..
	  cbut = 0;
	  while (iBut[cbut].x != DISABLE) {	// Print any text buttons..
	    ctype = iBut[cbut].type;
	    if (ctype == 2) {	// Spin field
	      ShowSpinField (hBut, cbut);
	    } else if (ctype) {	// txt button..
	      cstr = GetToolStr (hBut->txt,cbut + cbut + 1);
	      ShowButton (htx + iBut[cbut].x,hty + iBut[cbut].y,
	      	iBut[cbut].lx,iBut[cbut].ly,cstr);
	    }
	    cbut ++;
	  }
	  if (hBut->edlx) {	// Active edit field, show edit window
	    ShowEditField (hBut,1);
	  }
	  if (hBut->lx) {	// There is a tools-bmp, so show it..
	    object (htx >> 3,hty,(hBut->lx >> 3) + 1,hBut->ly,hBut->bmp);
	  }
	  return 0;
	}
	
	if (mode == 2) {		// Also get key/mouse stroke..
	  res = getkey ();
	  if (res) return (res);	// return key-stroke..
	  mouse (3, &mbutton, &mousex, &mousey);  // look at mouse..
	  if ((mbutton & 3) == 0) return 0;	// No but down..
	}
		// Outside area range?
	if (((UINT) mousex) - htx > hBut->ax 
	 || ((UINT) mousey) - hty > hBut->ay) {
	  return 0;
	}
	if (mbutton) {
	  cbut = 0;
	  while (iBut[cbut].x != 0x8000) {	// Test if mouse in range each button
	    cbx = iBut[cbut].x; cby = iBut[cbut].y;
	    ctype = iBut[cbut].type;
	    cblx = iBut[cbut].lx; cbly = iBut[cbut].ly;
	    if (ctype == 2) {	// Spin - fixed 16x25 size.
	      cblx = 16;cbly = 25;
	    }
	    if (((UINT) mousex) - htx - cbx <= cblx) {
	      if (((UINT) mousey) - hty - cby <= cbly) {
	        goto pHit;	// Process sucsessful hit..
	      }
	    }
	    cbut ++;
	  }
	}
	return 0;
pHit:			// Hit found on cbut..
	ActionHit ++;
	if (ctype == 2) goto SpinHit;		// Spin button hit..
	if (mbutton == 2) {	// Right mouse key..
	  res = iBut[cbut].rkey;
	} else {
	  res = iBut[cbut].lkey;
	}
	hidemouse ();
	cbx += htx; cby += hty;
		// Kill hilite..
	plotline (cbx,cby,cbx + cblx,cby,8);
	plotline (cbx,cby,cbx + cblx,cby + 1,7);
	plotline (cbx,cby,cbx,cby + cbly,8);
	plotline (cbx,cby,cbx + 1,cby + cbly,7);
		// Simulate key press- move vdu down..
	ShiftVdu (cbx,cby + 1, cblx,cbly - 1,3);
		// Now show any help-info..
	cstr = "";
	if (mbutton == 2 && iBut[cbut].type == 0) {
	  cstr = GetToolStr (hBut->txt,cbut + cbut + 1);
	}
	if (cstr [0] == 0) {	// No str, so try 1st string..
	  cstr = GetToolStr (hBut->txt,cbut + cbut);
	}
	if (cstr[0] && hBut->infolx) {	// Show help-info line..
	  prnat (PRNPIX | ((htx + hBut->infox) >> 3),hty + hBut->infoy,
		-1,PRNGREY, cstr);
	}
	showmouse ();
	do {		// Wait till button release..
	  mouse (3, &mbutton, &mousex, &mousey);
	} while (mbutton);
	hidemouse ();
	if (cstr[0] && hBut->infolx) {	// Wipe help-info line..
	  fillobject ((htx + hBut->infox) >> 3,hty + hBut->infoy,
	  	hBut->infolx >> 3,15,0,0);
	}
	ProcessToolKey (hBut, 0);	// Repaint toolbox..
	showmouse ();
		// If mouse moved outside area, dont exec button.
	if (((UINT) mousex) - cbx > cblx || ((UINT) mousey) - cby > cbly) res = 0; 
	return (res);
SpinHit:
	cvar = iBut[cbut].var;		// ptr to spin val-variable..
	spinc = 1;
	if (mbutton & 2) spinc *= 10;
	if (((UINT) mousey) - hty - cby > (cbly >> 1)) spinc =-spinc;
	showmouse ();
	nextpause = 5;
	do {
		// ADD INCREMENT, keep var within range
	  *cvar = min (iBut[cbut].rkey, max (iBut[cbut].lkey, (*cvar) + spinc));
	  printfat (PRNINV | PRNPIX | ((cbx + 32 + htx) >> 3) , 
	  	cby + 5 + hty, -1, PRNWHT, "%d ",*cvar);
	  
	  pause (nextpause);
	  mouse (3, &mbutton, &mousex, &mousey);
	  nextpause = 1;
	} while (mbutton);
	return (0);
}

	// Process a dialog box with input..
int ProcessDialog (TBUTTONHEADER *hBut)	
{
      int edlen = hBut->edmax;	// len edit field (0=none)
      int cpos;			// cursor pos
      char *edstr = hBut->edit;	// 
      int edkey;
      if (edlen) cpos = strlen (edstr);
      ProcessToolKey (hBut,0);
      while (1) {
	edkey = ProcessToolKey (hBut,2);
	if (edkey == 27) {
	  edstr [0] = 0;
	  return edkey;
	}
	if (edkey == 13 || edkey > 200) return edkey;
	if (edlen == 0 && edkey != 0) return edkey;
	if (edlen) {
	  if (edkey == 8 && cpos > 0) {	// Delete
	    cpos --;
	    edstr [cpos] = '_'; edstr [cpos + 1] = 0;
	    ShowEditField (hBut,1);
	    edstr [cpos] = 0;
	  }
	  if (edkey >= 32) {		// normal char hit..
	    if (cpos < edlen) {
	      edstr [cpos] = edkey;
	      cpos ++;
	      edstr [cpos] = '_'; edstr [cpos + 1] = 0;
	      ShowEditField (hBut,0);
	      edstr [cpos] = 0;
	    }
	  }
	}
      }
}

	// Draw Windows style title bar
void winbar (int xtop, int ytop, int xlen, char *barstr)
{
	int txtx = (xlen - strlen (barstr) - 3) >> 1;
		// Draw '-' topleft win-BMP..
	object (xtop, ytop, 3, 20, winbmp);
	xtop += 3; xlen -= 3;
	fillobject (xtop , ytop + 1, xlen, 18, 0xff, PRNGREY);
	prnat (PRNINV | PRNPIX | txtx + xtop, ytop + 2, -1, PRNGREY,barstr);
	fillobject (xtop, ytop, xlen, 1, 0xff, PRNDGREY);
	fillobject (xtop, ytop + 19, xlen, 1, 0xff, PRNWHT);
	plotline (((xtop + xlen) << 3) - 1,ytop + 1, -1, ytop + 18,8);
}

	// Show 3d dialog
void box3d (int xtop, int ytop, int xlen, int ylen)
{
	fillobject (xtop, ytop, xlen, ylen, 0xff, PRNDLG);
	fillobject (xtop, ytop, xlen, 1, 0xff, PRNWHT);
	fillobject (xtop, ytop + ylen - 1, xlen, 1, 0xff, PRNDGREY);
	plotline (xtop << 3,ytop + 2, -1, ytop + ylen - 1,15);
	plotline (((xtop + xlen) << 3) - 1,ytop + 1, -1, ytop + ylen - 1,8);
}

TBUTTONINFO iOK [] = {
 0,0,64,22,13,13,NULL,3,		// Text button (OK)
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};
TBUTTONHEADER hdOK = {
 iOK,
 0,0,0,0,64,26,NULL,
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 "\0OK\0\0\x01"
};

int MPxtop, MPytop, MPxlen, MPylen;

void clrMP ()		// Clear dialog box window..
{
	fillobject (MPxtop, MPytop, MPxlen, MPylen,0,0);	// clr space..
}

  // Show dialog with message, await & return button hit..
int FASTCALL msgPrint (int xlen, int ylen, TBUTTONHEADER *hdBUT, char *prbuf, BYTE mode)
{
	int xflag;		// Top flag-bits of xlen..
	xflag = xlen & 0xff00;
		// Calc xy/pos/size of dialog box..
	MPxlen = xlen & 0xff;	// hibits used for modes..
	MPylen = ylen;
	MPxtop = 40 - (MPxlen >> 1); 
	MPytop = 240 - (MPylen >> 1);
	if (mode & 1) {		// Draw dialog box..
	  box3d (MPxtop, MPytop, MPxlen, MPylen);
	  if (!(xflag & PRNNOBAR)) {
	    winbar (MPxtop + 1, MPytop + 3, MPxlen - 2, WinBar);  // Title bar..
	  }
	}
	temp = MPxtop + 2;
	if (xflag & PRNCENT) {
	  temp = (80 - strlen (prbuf)) >> 1;
	}
	prnat (PRNINV | PRNPIX | temp, MPytop + 40, MPxtop + MPxlen - 2, 
		PRNDLG, prbuf);
	if (mode & 1) {
	  int tx = 320 - (hdBUT->ax >> 1);
	  int ty = MPytop + MPylen - hdBUT->ay - 16;
	  DrawToolsAt ((*hdBUT),tx,ty);	// Draw buttons..
	  if (xflag & PRNBOX) {
	    boxit (tx - 16,ty - 8,tx + 16 + hdBUT->ax, ty + 8 + hdBUT->ay,2);
	  }
	}
	showmouse ();
	if (xflag & PRNRET) {		// No process loop, return now.
	  return 0;
	}
	//do {
	//  inkey = ProcessToolKey (hdBUT,2);	// Read button/keystroke..
	//} while (inkey != 13 && inkey != 32 && inkey != 27);
	inkey = ProcessDialog (hdBUT);
	hidemouse ();
	if (mode & 1) {
	  clrMP ();		// Clear dialog box window..
	}
	return inkey;
}

  // PRINTF Show dialog with message, await button return..
int msgPrintf (int xlen, int ylen, TBUTTONHEADER *hdBUT, char *format,...)
{
	char prbuf [1500];	// tmp buf for printing..
	int nchar;
	va_list argptr;
	va_start (argptr,format);
	nchar = _vsnprintf (prbuf,sizeof (prbuf) - 10,format, argptr);
	va_end (argptr);
	if (nchar > sizeof (prbuf) - 3) {	// Overflow!
	  Beep
	  return 0;
	}
	return (msgPrint (xlen,ylen,hdBUT,prbuf,1));
}

  // Display short message
void msgPrintBox (char *istr)
{
	int xlen = min (80,strlen (istr) + 16);
	msgPrint (xlen | PRNCENT, 120,&hdOK,istr,1);
}

TBUTTONINFO iAUTO [10] = {
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};

TBUTTONHEADER hdAUTO = {
 iAUTO,
 0,0,0,0,160,60,NULL,	// no bmp..
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field (to be put in)
 ""	// STokcancel
};

TBUTTONINFO iOKCANCEL [] = {
 0,0,64,22,13,13,NULL,3,		// Text button (YES)
 96,0,80,22,27,27,NULL,3,		// Text button (NO)
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};
TBUTTONHEADER hdOKCANCEL = {
 iOKCANCEL,
 0,0,0,0,176,26,NULL,	// no bmp..
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 ""  // STokcancel
};

TBUTTONINFO iEDIT [] = {
 0,10,64,22,13,13,NULL,3,		// Text button (OK)
 96,10,64,22,27,27,NULL,3,		// Text button (CANCEL)
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};

TBUTTONHEADER hdEDIT = {
 iEDIT,
 0,0,0,0,160,42,NULL,	// no bmp..
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field (to be put in)
 ""	// STokcancel
};

	// Simple dialog text-input..
	// Ret exit key
int promptin (int xlen, int ylen, char *iprompt,char *istr, int maxlen)
{
	int xtop,ytop;
	char edbuf [400];
	strncpy (edbuf, istr, sizeof (edbuf) - 4);
	hdEDIT.edit = edbuf;
	hdEDIT.edmax = min (maxlen,sizeof (edbuf) - 2);
	hdEDIT.edlx = min (xlen - 8, maxlen + 1);
	//ylen = maxlen / hdEDIT->edlx;
	//xlen = max (max (maxlen,strlen (iprompt)),20);
		// Center dialog box on screen..
	xtop = 40 - (xlen >> 1); ytop = 240 - (ylen >> 1);
	box3d (xtop, ytop, xlen, ylen);
	hdEDIT.edx = (xtop + 2) << 3;
	hdEDIT.edy = ytop + 40;
	temp = (80 - strlen (iprompt)) >> 1;
	prnat (PRNINV | PRNPIX | temp, ytop + 16, xtop + xlen - 2, 
		PRNDLG, iprompt);
	DrawToolsAt (hdEDIT,320 - (hdEDIT.ax >> 1),
		ytop + ylen - hdEDIT.ay - 7);	// Draw buttons..
	showmouse ();
	dink ();
	inkey = ProcessDialog (&hdEDIT);		// Process input.
	hidemouse ();
	fillobject (xtop, ytop, xlen, ylen,0,0);	// clr space..
	if (inkey != 27) {	// Re-get old string
	  strncpy (istr, edbuf, maxlen);
	}
	return inkey;
}

//-----------------------------------------------------------------------
//
//  General IO..
//


#define DSKBUFSIZE 256
BYTE pDskBuf [DSKBUFSIZE + 4];
int cDskBuf,maxDskBuf;

void BufReset ()
{
	maxDskBuf = DSKBUFSIZE;
	cDskBuf = DSKBUFSIZE;	// Force read on 1st use..
}

MYINLINE int BufGetChar (FILE *ifile)	// Read 1 char from file, -1=EOF/error..
{
	if (cDskBuf >= DSKBUFSIZE) {
	  maxDskBuf = fread (pDskBuf,1,DSKBUFSIZE,ifile);
	  if (maxDskBuf < 1) return -1;		// Error/EOF..
	  cDskBuf = 0;
	} else {
	  if (cDskBuf >= maxDskBuf) {	// overflow partial buffer?
	    return (-1);		// Error/EOF..
	  }
	}
	cDskBuf ++;
	return (pDskBuf [cDskBuf - 1]);		// return char 0-255
}

  // Buffered Input an asc line (term CR/LF) from file.
  // Ret nchars read, or -1 for EOF.. ilen ABS max to read
  // mode set for buffering
int LineInput (FILE *ifile, char *istr, int ilen)
{
	int tlen = ilen;	// Countdown of max chars
	int cl;
	do {
		// Read 1 char..
	  cl = BufGetChar (ifile);
	  istr [0] = cl;
	  if (cl < 1) {
	    istr [0] = 0;
	    if (tlen == ilen) return (-1);	// EOF on 1st char..
	    break;				// Allow process line so far.
	  }
		//  printc (*istr); if (curx > 75) prints ("\n");
	  if (*istr == 13) break;	// CR= End of line
	  if (*istr == 10) continue;	// Skip LF..
	  if (tlen) {			// Count until max chrs
	    tlen --;
	    istr ++;
	  }
	} while (1);
	*istr = 0; 	// Replace CR/LF with null string end.
	return (ilen - tlen);
}

	// Convert string in given base to a val..
long str2val (char far *istr, int base, int ndigits)
{
	long ret = 0;
	UINT tmp;
	while (ndigits) {
	  tmp = *istr - 48;
	  if (tmp > 9) {
	    if (tmp < 17) break;
	    tmp -= 7;
	  }
	  if (tmp > (UINT) base - 1) break;
	  ret = ret * ((long) base) + tmp;
	  ndigits --; istr ++;
	}
	return ret;
}

	// Copy string until " or NULL, converting \n, \0, \t, \xnn to asc..
int StrConvCpy (char far *szDest, char far *szSrc, int maxlen)
{
	int ncpy = 0;
	int cchr;
	do {
	  cchr = *szSrc;
	  if (cchr == 0 || cchr == 34) break;	// End of string
	  if (cchr == 92) {		// '\', special character..
	    szSrc ++;
	    cchr = *szSrc;
	    if (cchr == 0) break;	// Hit str end..
	    switch (cchr) {
	      case 'n': cchr = 10; break;
	      case '0': cchr = 0; break;
	      case 't': cchr = 9; break;
	      case 'r': cchr = 13;break;
	      case 'a': cchr = 7; break;
	      case 'x':		// 2 digits of hex..
	        szSrc ++;
	        cchr = (BYTE) str2val (szSrc,16,2);
	        szSrc ++;
	        break;
	      case ' ':		// 4 digits of hex..(2-byte)
	        szSrc ++;
	        cchr = (UINT) str2val (szSrc,16,4);
	        szSrc += 3;
	        szDest [ncpy] = cchr & 0xff;
	        ncpy ++;
	        cchr >>= 8;
	        break;
	      case ',':		// Decimal..2-byte..
	        szSrc ++;
	        cchr = (UINT) str2val (szSrc,10,5);	// Conv to DECIMAL..
	        szDest [ncpy] = cchr & 0xff;
	        ncpy ++;
	        cchr >>= 8;
	        while (isdigit (*szSrc)) szSrc ++;
	        szSrc --;
	        break;
	    }
	  }
	  szDest [ncpy] = cchr;
	  szSrc ++; ncpy ++;
	} while (ncpy < maxlen - 1);
	szDest [ncpy] = 0;
	ncpy ++;
	return ncpy;
}

  // General Parse token from string..(ret 0 for no match found)
  // Param=ptr to token list (DOUBLE NULL-TERM)
  // Param2 = pointer to text string to search
  // Ret1..n token# from list (tutTokens) in LOBYTE
  // Ret len of token in HIBYTE
  // ret 0 if no token found
int FASTCALL genParseToken (BYTE *ptok, BYTE far *instr)
{
	BYTE far *pcode;		// ptr to code
	int ctoken = 0;			// Cur token #
	while (*ptok) {			// Until null terminate
	  ctoken ++;
	  pcode = instr;
	  while (*ptok && *ptok == *pcode) {	// See if chars match..
	    ptok ++; pcode ++;
	  }
	  if (*ptok < 31) {	// Matched to end of token, found it?
	  	// Only allow if not in middle of alpha-name..
	    if (isalnum (*pcode) == 0 || isalnum (*(pcode - 1)) == 0) {
	      //tutTokFlag = *ptok;	// Get Token flag from end
	      return (ctoken + ((_FP_OFF (pcode) - _FP_OFF (instr)) << 8));
	    }
	  }
	  while (*ptok >= 31) ptok ++;	// scan to try next token
	  ptok ++;
	}
	return (0);		// No token found.
}

//-----------------------------------------------------------------------
//
//  MULTI-LINGUAL SUPPORT
//

char StrSpace [SIZEStrSpace + 100];	// Alloc some local space for them..
char *Strings[50];	// Array of pointers to multi-language strings..
char szLangFile[] = LANGUAGE_FILE;	// Language file name..

	// Read text for language (clang)(0-n) into StrSpace
int ReadLanguageFile (int clang)
{
	char *szDest = StrSpace;	// Write to lang-string-space
	int cline = 0;		// Count of lines inputed
	int cstr = 0;		// Count of strings..
	int cchr;		// Gen vars
	char *szIn;
	int nin;
	FILE *hLangFile;
	BYTE appendit;
	for (cstr = 0; cstr < aSizeOf (Strings) - 3; cstr ++) {
	  Strings [cstr] = "";
	}
	cstr = 0;
	for (cchr = 0; cchr + cchr < SIZEszTemp; cchr ++) { // Wipe in-array..
	  szTemp [cchr] = 0;
	}
	
	do {	// If FOPEN fails, loop to try english file..
	  szLangFile [6] = 49 + clang;
	  hLangFile = fopen (szLangFile,"rb");
	  if (hLangFile != NULL) break;	// OK!
	  	// cannot read source
	  if (clang == 0) goto LangError;
	  clang = 0;
	} while (1);
	BufReset ();		// Reset input buffer..(for LineInput)
	do {		// Read & process, chunk by chunk
	  szIn = szTemp;
	  nin = LineInput (hLangFile, szTemp, SIZEszTemp);
	  if (nin == -1) goto LangError;
	  while (*szIn == ' ') szIn ++;	// Strip leading spc
	  cline ++;
	  appendit = (*szIn == '+');	// Append string..
	  if (appendit) szIn ++;
	  cchr = szIn [0];
	  if (szIn [0] == 34) {		// " - start of language string..
	    if (appendit) {		// append to previous string..
	      if (cstr) {		// Only if prev string exists
	        szDest --; cstr --;
	      }
	    } else {
	      Strings [cstr] = szDest;	// Save ptr to string start..
	    }
	    cchr = StrConvCpy (szDest, szIn + 1, 400);
	    szDest += cchr;
	    cstr ++;
	  } else if (szIn [0] == '/') {	// '/' - rem or command..
	    cchr = szIn [2];
	    if (cchr == '<') break;	// OK, reached EOF sucsesfully
	    if (cchr == '=') {
	      cstr = atoi (szIn + 3);
	    }
	    if (cchr == '+') {
	      cstr += atoi (szIn + 3);
	    }
	  }
	  if (cstr < 0 || cstr >= aSizeOf (Strings) 
	  	|| szDest - StrSpace > SIZEStrSpace) goto LangError;
	} while (1);
	fclose (hLangFile);
	return 1;
LangError:
	if (hLangFile != NULL) fclose (hLangFile);
	printf ("ERROR/OVERFLOW in language file %s line %d\n Hit Space..\x07",szLangFile,cline);
	while (getkey () != ' ');
	return 0;
}

//-----------------------------------------------------------------------
//
//  View a (help) file..
//

TBUTTONINFO iVIEW [] = {
   0,1,64,22,13,13,NULL,3,		// Text button (OK)
  96,1,24,22,KEY_PGUP,KEY_PGUP,NULL,3,	// Text button (<)
 128,1,24,22,KEY_UP,KEY_UP,NULL,3,	// Text button (-)
 160,1,24,22,KEY_DOWN,KEY_DOWN,NULL,3,	// Text button (+)
 192,1,24,22,KEY_PGDN,KEY_PGDN,NULL,3,	// Text button (>)
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};
TBUTTONHEADER hdVIEW = {
 iVIEW,
 0,0,0,0,212,24,NULL,	// no bmp..
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 "\0OK\0\0<\0\0-\0\0+\0\0>\0\0\1"
};

TBUTTONINFO iPDNLOAD [] = {
   0,1,64,22,13,13,NULL,3,		// Text button (LOAD)
  96,1,64,22,27,27,NULL,3,		// Text button (CANCEL)
 192,1,24,22,KEY_PGUP,KEY_PGUP,NULL,3,	// Text button (<)
 224,1,24,22,KEY_UP,KEY_UP,NULL,3,	// Text button (-)
 256,1,24,22,KEY_DOWN,KEY_DOWN,NULL,3,	// Text button (+)
 288,1,24,22,KEY_PGDN,KEY_PGDN,NULL,3,	// Text button (>)
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};

TBUTTONHEADER hdPDNLOAD = {
 iPDNLOAD,
 0,0,0,0,308,24,NULL,	// no bmp..
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 "\0LOAD\0\0CANCEL\0\0<\0\0-\0\0+\0\0>\0\0\1"
};

long viewgamenum;

  // View a text file szFile in a window, show prompt.
  // if mode set, pdn game load mode..
int FASTCALL ViewTextFile (int vlenx, int vleny, char *szFile, BYTE mode)
{
	char prbuf [2100];
	FILE *hFile;
	int nin;
	char *cstr;
	long topline,curline;
	long xgame;
	int xline;
	int ckey = 27;
	TBUTTONHEADER *hdBut = &hdVIEW;
	if (mode) hdBut = &hdPDNLOAD;
	hFile = fopen (szFile,"rb");
	if (hFile == NULL) return 27;	// failed..
	topline = 0;
	// hidemouse ();
	msgPrint (vlenx | PRNBOX | PRNRET,474,hdBut,"",1);// Draw blank dialog, ret immediately
	hidemouse ();
	do {
	  BufReset ();
	  viewgamenum = 1;	// game# for game at top..
	  fseek (hFile,0,SEEK_SET);
	  curline = 0;
	  while (curline < topline) {		// Scan past first lines..
	    nin = LineInput (hFile, prbuf, 300);
	    if (nin == -1) {
	      topline = curline - 1; break;
	    }
	    if (*prbuf == '*') viewgamenum ++;
	    curline ++;
	  }
nextpage:
	  cstr = prbuf;
	  xgame = viewgamenum;
	  for (xline = 0; xline < vleny; xline ++) {
	    nin = LineInput (hFile, cstr, 300);
	    if (nin == -1) {	// End of file..
	      while (xline < vleny) {	// Pad out extra lines
	        memset (cstr, 32, vlenx - 2);
	        cstr += (vlenx - 3);
	        *cstr = 10; cstr ++;
	        xline ++;
	      }
	      break;
	    }
	    if (*cstr == '*') xgame ++;
	    if (nin < vlenx - 3) {	// Pad short lines with spaces..
	      memset (cstr + nin, 32, vlenx - nin - 1);
	    } 
	    cstr += (vlenx - 3);
	    *cstr = 10; cstr ++;
	    curline ++;
	  }
	  *cstr = 0;
ignorekey:
	  if (mode) {		// Load mode
	    char ostr [15];
	    prnat (PRNINV | PRNPIX | 5,436,80,PRNANLO2,STpdnselect);
	    sprintf (ostr,"# %lu   ",viewgamenum);
	    prnat (PRNINV | PRNPIX | 5,452,80,PRNANLO2,ostr);
	  }
	  ckey = msgPrint (vlenx,474,hdBut,prbuf,0);	// Print text..
	  if (ckey == 13 || ckey == 27) break;
	  if (curline > topline + 1) {
	    if (ckey == KEY_DOWN) {
	      topline ++; continue;
	    }
	    if (ckey == KEY_PGDN) {
	      topline += max (1,min (curline - topline, (long) vleny));
	      viewgamenum = xgame;	// Keep track of game #
	      goto nextpage;
	    }
	  }
	  if (ckey == KEY_UP) {
	    topline = max (0,topline - 1); continue;
	  }
	  if (ckey == KEY_PGUP) {
	    topline = max (0,topline - (long) vleny); continue;
	  }
	  goto ignorekey;
	} while (1);
	fclose (hFile);
	return ckey;
//ViewError:
	if (hFile) fclose (hFile);
}

void helpscreen ()
{
	szHelpFile [6] = 49 + language;
	if (FileExists (szHelpFile) == 0) {	// Lang dont exist, try english
	  szHelpFile [6] = 49;
	}
	if (FileExists (szHelpFile) == 0) {	// Help dont exist
	  Beep 
	  msgPrintf (PRNCENT | 72,100,&hdOK,"Help file %s not found",szHelpFile);
	  return;
	}
	ViewTextFile (80,23,szHelpFile,0);
}

//-----------------------------------------------------------------------
//
//  COPY PROTECTION
//

 // Return absolute month count Jan1980==0, Jan1996==192.
UINT getthedate ()
{
	inr.h.ah = 0x2a;		// DOS func 2a 
	int86 (0x21,&inr,&outr);	// INT 21 
			// CX=year 1980.., DH=1-12.month, DL=1-31 day
	return ((outr.x.cx - 1980) * 12 + outr.h.dh - 1);
}


//-----------------------------------------------------------------------
//
//  ADVERT/FRONTSCREENS..
//

void waitspc ()		// Await mouse hit/space
{
	int inkey;
	do {		// Await release first..
	  mouse (3, &mbutton, &mousex, &mousey);
	} while (mbutton);
	do {
	  inkey = getkey ();
	  mouse (3, &mbutton, &mousex, &mousey);
	} while (mbutton == 0 && inkey != ' ');
	do {		// Await release.. 
	  mouse (3, &mbutton, &mousex, &mousey);
	} while (mbutton);
}

void hitspace ()
{
	click ();
	prints (STspacetocont);
	waitspc ();
}

TBUTTONINFO iLANGUAGE [] = {
 0,5,80,22,13,13,NULL,3,		// Text button (ENGLISH)
 96,5,80,22,49,49,NULL,3,		// Text button (SPANISH)
 192,5,80,22,50,50,NULL,3,		// Text button (DUTCH)
 288,5,80,22,51,51,NULL,3,		// Text button (FRENCH)
 384,5,80,22,52,52,NULL,3,		// Text button (GERMAN)
 DISABLE,0,0,0,0,0,NULL,0,		// Terminator
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};
TBUTTONHEADER hdLANGUAGE = {
 iLANGUAGE,
 0,0,0,0,464,33,NULL,	// no bmp, active area (x,y) centered
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 "",	// STlanguages+1
};

TBUTTONINFO iLANGUAGE2 [] = {
 0,5,88,22,13,13,NULL,3,		// Text button (ENGLISH)
 112,5,96,22,49,49,NULL,3,		// Text button (LANGUAGE2)
 DISABLE,0,0,0,0,0,NULL,0,		// Terminator
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};
TBUTTONHEADER hdLANGUAGE2 = {
 iLANGUAGE2,
 0,0,0,0,208,33,NULL,	// no bmp, active area (x,y) centered
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 "",	// STlanguages+1
};

void frontscreen (int mode)
{
	int sel;
	TBUTTONHEADER *hdBut = &hdLANGUAGE;
	if (STlanguages [0] < '3') {
	  hdBut = &hdLANGUAGE2;
	}
	clrvdu ();
	hdBut->txt= STlanguages + 1;
	sel = msgPrintf (PRNBOX | 80,470,hdBut,
  "                    DYNAMO-DRAUGHTS " PROG_VERSION ".\n"
  "                   -----------------------\n\n"
  "             Written by & Copyright A.Millett 1993-2024.\n\n"
  "    DYNAMO is now released as free software under the GPL3 license.\n"
  "    (see DYNAMO1.DOC for details.)\n"
  );
	switch (sel) {
	  case 13: 
	    language = 0;break;
	  default:
	    language = sel - 48; break;
	}
	if (mode == 2) return;
}

// NEW ADSCREENS..

  // Special palette for advert screens - pal0=grey..
void adpalon ()
{
        int normpal [] = {7,1,2,3,4,5,6,56,0,57,58,59,60,61,62,63};
	int cpal;
	for (cpal = 0; cpal < 16; cpal ++) {
	  palette (cpal,normpal [cpal] );
	}
}

void FASTCALL lboxit (int xtop, int ytop, int xend, int yend, int gap)	/* 1 line only */
{
	int xpos;
	for (xpos = xtop; xpos <= xend; xpos ++) {
	  plot (xpos,ytop,15);
	  plot (xpos,ytop+gap,8);
	}
}

void FASTCALL boxtext (char *istr, int xtop, int ytop, int xbot, int ybot)
{
	boxit (xtop * 8 - 6, ytop * 16 - 10, xbot * 8 - 6, ybot * 16 - 10,6);
	gotoxy ((xtop + xbot - strlen (istr)) >> 1, ytop);
	prints (istr);
}

void FASTCALL lboxtext (char *istr, int xtop, int ytop, int xbot, int ybot)
{
	lboxit (xtop * 8 - 6, ytop * 16 - 10, xbot * 8 - 6, ybot * 16 - 10,6);
	gotoxy ((xtop + xbot - strlen (istr)) >> 1, ytop);
	prints (istr);
}

void FASTCALL boxhead (char *istr, int xpos, int ypos)
{
	int slen = strlen (istr);
	if (xpos < 0) xpos = (80 - slen) / 2;	/* Auto center */
	gotoxy (xpos, ypos);
	prints (istr);
	boxit (xpos  * 8 - 12, ypos * 16 - 28,
		(xpos + slen) * 8 - 4, ypos * 16 + 10,6);
}

void FASTCALL printk (unsigned char *istr)	/* Print string with color-codes */
{
	int cchr;
	static int temp;
	for (cchr = 0; istr [cchr]; cchr ++) {
	  temp = istr [cchr];
	  if (temp == 128) {
	    cchr ++; temp = istr [cchr];
	    if (temp != '+') {
	      getpal (temp & 15);
	    }
	  } else {
	    printc (temp);
	  }
	  if (istr [cchr] == 10) printc (13);
	}
}

#define Dept "DYN"
#define clr80vdu graphmode(18); paloff ()
#define Colmain "�8"
#define Colhi "�4"


void initsprites ()	//  Correctly Scale a piece set..
{
	int xstart;
	  if (xgamode == 2) {		/* VGA... */
	    charx = 6;
	    chary = 48;
	    Ssize = 4 * charx * chary;	/* On-disk size */
	    for (xpos = 0; xpos < Ssize * 5; xpos ++) {
	      sprites [ xpos ] = disksprites [xpos];
	    }
	    if (boardy > 9) {
	      temp2 = temp = 0;
	      xstart = 24; if (boardy > 10) xstart = 30;
	      for (ypos = xstart; ypos < Ssize * 5; ypos += 6) {
		for (xpos = 0; xpos < 5; xpos ++) {
		  sprites [temp + xpos] = (disksprites [ypos + xpos] << 4)
					+ (disksprites [ypos + xpos + 1] >> 4);
		}
		temp += 5; temp2 ++;
		if (boardy > 10) {
		  if (temp2 >= 37) { temp2 = 0; ypos += 66;}
		} else {
		  if (temp2 >= 40) { temp2 = 0; ypos += 48;}
		}
	      }
	      charx = 5;
	      chary = 40;
	      if (boardy > 10) chary = 37;
	      Ssize = 4 * charx * chary;	/* On-disk size */
	    }
	    palon ();
	  } else {
	    charx = 7;
	    chary = 23;
	    Ssize = charx * chary;	/* On-disk size */
	    for (xpos = 0; xpos < Ssize * 6; xpos ++) {
	      sprites [ xpos ] = disksprites [xpos + 5760];
	    }
	    if (boardx > 8 || boardy > 8) {
	      temp = 0; temp2 = 0;
	      for (ypos = 14; ypos < Ssize * 6; ypos += 7) {
		for (xpos = 0; xpos < 6; xpos ++) {
		  sprites [temp + xpos] = (disksprites [5760 + ypos + xpos] << 4)
			+ (disksprites [5760 + ypos + xpos + 1] >> 4);
		}
		temp += 6;
		temp2 ++;
		if (temp2 >= 19) { temp2 = 0; ypos += 28;}
	      }
	      charx = 6;
	      chary = 19;
	      Ssize = charx * chary;	/* On-disk size */
	    }
	  }
}

void getgame (int cgame)
{
	movefrom = (mgame [cgame] >> 8) & 255;
	moveto = mgame [cgame] & 255;
}


void opos (int vcolor, int *brdptr)
{
	char tmpstr [20];
	int comma = 0;
	for (cnum = 1; cnum <= nsqrs; cnum ++) {
	  temp = brdptr [sqpos [cnum]];
	  if (temp & vcolor) {
	    if (comma) printc (',');
	    comma = 1;
	    if (temp & 1) printc ('K');
	    Pos2Str (tmpstr,cnum);
	    prints (tmpstr);
	  }
	}
}

  // Print diagram, prntype=diagram type 
void outputpos (int *brdptr, int prntype)
{
	int xpos,ypos;
	if (prntype < 2) {
	  if (prntype == 0) {
	    printc ('�');
	    for (xpos = 1; xpos <= boardx; xpos ++) {
	      prints ("���");
	    }
	    prints ("�\n");
	  } else {
	    printc ('+');
	    for (xpos = 1; xpos <= boardx; xpos ++) {
	      prints ("---");
	    }
	    prints ("+\n");
	  }
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    if (prntype == 0) {
	      prints ("�");
	    } else {
	      prints ("|");
	    }
	    for (xpos = 1; xpos <= boardx; xpos ++) {
	      temp = xpos + ypos * bmult;
	      if (boardflip) temp = bmult * bmult - temp - 1;
	      temp = brdptr [temp]; if (temp == Edge) temp = 1;
	      if (prntype) {
		prints ("   \0:::\0 x \0(x)\0 o \0(o)\0" + temp * 4);
	      } else {
		prints ("   \0���\0 x \0(x)\0 o \0(o)\0" + temp * 4);
	      }
	    }
	    if (prntype == 0) {
	      prints ("�\n");
	    } else {
	      prints ("|\n");
	    }
	  }
	  if (prntype == 0) {
	    printc ('�');
	    for (xpos = 1; xpos <= boardx; xpos ++) {
	      prints ("���");
	    }
	    prints ("�\n");
	  } else {
	    printc ('+');
	    for (xpos = 1; xpos <= boardx; xpos ++) {
	      prints ("---");
	    }
	    prints ("+\n");
	  }
	  return;
	}
	prints ("White: ");
	opos (White, brdptr);
	prints ("Black: ");
	opos (Black, brdptr);
}

int ptemp;
void printboard (int mode)
{
	int temp2;
	if (mode) {
	  clrvdu ();
	  tprintflag = 0;
	  prints ("Printout board to Screen or Printer (s,p,ESC) ?\n");
	}
	do {
	  inkey = getkey ();
	  if (inkey == 27) return;
	  ptemp = inchr ("sp",inkey);
	} while (ptemp < 0);
	prints ("Print current position: Diagram, ASCII or List (d,a,l,ESC) ?\n");
	do {
	  inkey = getkey ();
	  if (inkey == 27) return;
	  temp2 = inchr ("dal\x0d",inkey);
	} while (temp2 < 0);
	tprintflag = ptemp;
        outputpos (board,temp2);
	tprintflag = 0;
}

//------------------------------------------------------------------
// PDN routines..
//


MYINLINE void pdnPrintHead ()
{
	char *hstr = STpdnheader;
	char *cstr = gamenote;
	char csep = *STpdnheader;
	char cchr;
	int chead = 0;
	while (*hstr) hstr ++;	// Next string
	hstr ++;
		// Print Event,White,Black,Result
	do {
	  if (*hstr == 0) return;
	  printc ('[');
	  prints (hstr);
	  while (*hstr) hstr ++;	// Next string
	  hstr ++;
	  printc (' '); printc (34);
	  do {			// Break up comment (event;white;black;result)
	    cchr = *cstr;
	    if (cchr == 0 || cchr == csep) break;
	    printc (cchr);
	    cstr ++;
	  } while (1);
	  cstr ++;
	  prints ("\x22]\n");
	  if (cchr == 0) break;
	  chead ++;
	} while (chead < 5);
	if (fullgame) return;	// No setup pos..
	  // Generate pos in form [FEN "W:WK4,30:B27,22."]
	printc ('[');
	prints (STpdnheader + 1);
	prints (" \x22");
	printc (initcolor == White ? 'W' : 'B');
	prints (":W");
	opos (White, initbrd);
	prints (":B");
	opos (Black, initbrd);
	prints (".\x22]\n");
}

  // Write current game to pdn format, 
  // (outform) 0=simple,1=numberd (PDN),2=tabbed,
  // prnmode=0 for scr,1 for prn 3 write to mem.
  // fullmulti set to show in-between jumps..
  // Return text at (xfilebuf), cfilebuf chars..
  
void FASTCALL pdnExport (BYTE outform, int prnmode, BYTE fullmulti)
{
	static int cgame,ptemp,nextfrom;
	int halfmove;
	tprintflag = prnmode;		// Print to vdu/prn/mem..
	cfilebuf = 0;		// # chars written..
	prints ("\n");
	pdnPrintHead ();
	prints ("\n");
	halfmove = ptemp = nprint = 0;
	for (cgame = 1; cgame <= ngame; cgame ++) {
	  getgame (cgame);
	  nextfrom = 0;
	  if (cgame < ngame) nextfrom = (mgame [cgame + 1] >> 8) & 255;
	  if (movefrom == ptemp) {	/* Same as last dest, multijump..*/
	    if (fullmulti || moveto != nextfrom) {
	      printc ('-'); printnpos (sqnums [moveto]);
	    }
	  } else {
	    if (outform && (halfmove & 1) == 0) {	/* Numbered? */
	      if (outform == 2) {
		if (nprint > 40) {
		  prints ("\n"); nprint = 0;
		}
		while (nprint % 20) {
		  printc (' ');
		}
	      }
	      if (halfmove < 18) printc (' ');
	      printsi (" ",(halfmove >> 1) + 1);
	      prints (".");
	    }
	    printc (' '); printnpos (sqnums [movefrom]);
	    if (fullmulti || moveto != nextfrom) {
	      printc ('-'); printnpos (sqnums [moveto]);
	    }
	    halfmove ++;
	  }
	  ptemp = moveto;
	  if (nprint > 67 && outform != 2) {
	    prints ("\n"); nprint = 0;
	  }
	}
	prints ("\n*\n");
	tprintflag = 0;
}

  // Write from far mem, ret 1 if OK.
MYINLINE int farfwrite (BYTE far *pdat, int blksize, FILE *wrFile)
{
	char wbuf [522];
	int csize,cret;
	if (blksize == 0) return 0;
	do {
	  csize = min (sizeof (wbuf) - 10, blksize);
	  if (csize == 0) return 1;
	  _fmemcpy (wbuf,pdat,csize);
	  cret = fwrite (wbuf,1,csize,wrFile);
	  if (cret != csize) return 0;
	  blksize -= csize;
	  pdat += csize;
	} while (1);
}

char pdnDataBase [100] = "dbase.pdn";
long pdnCurGame = 1;

  // Append game to current PDN database..
  // Ret 0=fail,1=ok.
int pdnSave (char *ifile)
{
	int ckey;
	FILE *hFile;
	if (*ifile == 0) {
	  ckey = promptin (70,120,STpdnsave, pdnDataBase, 64);
	  ifile = pdnDataBase;
	  if (ckey == 27) return 0;
	} 
	pdnExport (2,3,1);
	hFile = fopen (ifile,"ab");
	if (hFile == NULL) {
	  msgPrintBox (STfileaccesserror); return 0;
	}
	farfwrite (xfilebuf,cfilebuf,hFile);
	fclose (hFile);
}
  
  // Decode a square val (either chess/numeric), 
  // ret: LOWORD sqr val, HIWORD len.  Ret 0 for error..
long FASTCALL decodesqr (char *cstr)
{
	int cval = 0;
	int clen = 0;
	int xp;
	if (isdigit (*cstr)) {
	  do {
	    cval = cval * 10 + cstr [clen] - 48;
	    clen ++;
	  } while (isdigit(cstr [clen]));
	  if (cval < 1 || cval > nsqrs) return 0;
	  return ((long) cval + (((long) clen) << 16));
	} else if (isalpha (*cstr)) {
	  xp = cstr [0] & 31;
	  if (xp > boardx) return 0L;
	  clen ++;
	  if (isdigit (cstr [clen]) == 0) return 0;
	  do {
	    cval = cval * 10 + cstr [clen] - 48;
	    clen ++;
	  } while (isdigit(cstr [clen]));
	  if (cval < 1 || cval > boardy) return 0;
	  cval = Posof (xp,bmult - 1 - cval);
	  if (numflag) cval = InvertPos (cval);
	  cval = sqnums [cval];
	  return ((long) cval + (((long) clen) << 16));
	}
	return 0L;
}

  // Read in a position from ascii source into given board
  // return 0 if error, or #chars read..
int ext_decode_asc_pos (char *cstr, int *cbrd, int *side2move)
{
	char cside;
	char cpiece;
	int cpos;
	int bpos;	// Brd pos
	long codepos;
	if (cstr [0] == 'W') {
	  *side2move = White;
	} else if (cstr [0] == 'B') {
	  *side2move = Black;
	} else {
	  return 0;
	}
	if (cstr [1] != ':' || cstr [2] != 'W') {
	  return 0;	// Illegal format
	}
	//sidetomove = ((FlagInitCol == 0) ^ cside); // Set if 2nd side moves 1st
	  	// Wipe board clear..
	for (cpos = 0; cpos < Mbrd - 5; cpos ++) { 
	  cbrd [cpos] = Edge;
	}
		// Etch out play area..
	for (cpos = 1; cpos <= nsqrs; cpos++) {
	  cbrd [sqpos [cpos]] = 0;
	}
	cpos = 3;
	cside = White;	// Always start with white
	do {
	  cpiece = cside;
	  if (cstr [cpos] == 'K') {
	    cpos ++; cpiece ++;
	  }
	  codepos = decodesqr (cstr + cpos);
	  if (codepos == 0) return 0;		// illegal sqr..
	  cpos += HIWORD (codepos);
	  bpos = sqpos [LOWORD (codepos)];	// Convert..
	  if (bpos < 0 || bpos >= maxboard || cbrd [bpos]) {
	    return 0;	// Error..
	  }
	  cbrd [bpos] = cpiece;		// Place piece..
	  if (cstr [cpos] == ',') cpos ++;
	  if (cstr [cpos] == ':') {	// Now black pieces..
	    cpos ++;
	    if (cstr [cpos] != 'B') return 0;
	    cpos ++;
	    cside = Bman;
	  }
	} while (cstr [cpos] != '.');	// Ends position..
	cpos ++;
	return (cpos);
}

  // Read header info
  // ret 0=fail,1=ok,2=setuppos read..
MYINLINE int pdnReadHeader (FILE *hFile, char *prbuf, char *szHead, int sizehead, int *setbrd, int *side2move)
{
	int nin;
	#define pdnSTRMAX 110
	char headstr [6] [pdnSTRMAX] = {"","","","","",""};  //fen/Event/wh/bl/res
	char *cstr;
	int cpos;
	int headpos;
	do {
	  nin = LineInput (hFile, prbuf, 450);
	  if (nin == -1) return -1;	// Past end..
	  cstr = prbuf;
	  while (*cstr == 32) cstr ++;
	  if (*cstr == '[') {
	    int clen;
	    char *ostr;
	    char cchr;
	    cstr ++;
	    clen = genParseToken (STpdnheader + 1,cstr);
	    if (clen && LOBYTE (clen) < 6) {
	      //headstr [LOBYTE (clen)],
	      cstr += HIBYTE (clen);		// Add len of token..
	      while (*cstr == 32) cstr ++;	// scan space
	      if (*cstr == 34) cstr ++;		// scan quote
	      ostr = headstr [LOBYTE (clen) - 1]; // copy to this temp str
	      cpos = 0;
	      do {
	        cchr = *cstr;
	        if (cchr == 0 || cchr == 34) break;
	        if (cpos >= pdnSTRMAX - 2) break;
	        ostr [cpos] = cchr;
	        cpos ++; cstr ++;
	      } while (1);
	      ostr [cpos] = 0;
	    }
	  } else if (*cstr != 0) { 
	    break;
	  }
	} while (1);
	    // OK, have filled headstr[][] with FEN/Event/wh/bl/res
	    // Now move to szHead, in correct order..
	headpos = 0;		// pos in szHead
	for (cpos = 1; cpos <= 4; cpos ++) {
	  int clen; // calc max that can be copied..
	  clen = min ((int) strlen (headstr [cpos]),sizehead - headpos);
	  memcpy (szHead + headpos, headstr [cpos], clen);
	  headpos += clen;
	  if (headpos >= sizehead - 1) break;	// Too long!
	  szHead [headpos] = ';';
	  headpos ++;
	}
	szHead [headpos] = 0;		// null term
	if (headstr [0] [0]) {		// FEN set, so decode..
	  int cstat;
	  cstat = ext_decode_asc_pos (headstr [0],setbrd,side2move);
	  if (cstat == 0) return 0;
	  return 2;		// Set up pos..
	} else {
	  *side2move = 0;
	}
	return 1;
}


MYINLINE int pdnReadGame (FILE *hFile)
{
	int cstat;
        char prbuf [500];
        int nin;
        char cchr;
        char *cstr;
        long codepos;
	newboard (1);
	mgame [1] = 0;
	cstat = pdnReadHeader (hFile, prbuf, gamenote, sizeof (gamenote) - 2,initbrd,&initcolor);
	if (cstat == -1) return -1;	// EOF..
	if (cstat == 0) {
	  return 0;
	}
	if (cstat == 2) {
	  ccolor = initcolor;
	  memcpy (board,initbrd,sizeof (board));
	  fullgame = 0;
	}
      		// OK header read, now read in moves..
	do {		// Parse lines.. (first line ALREADY in (prbuf))
	  cstr = prbuf;
	  do {			// Parse 1 line..
	    while (*cstr == 32) cstr ++;
	    cchr = *cstr;
	    if (cchr == '*') { // Game loaded ok!
	      return 1;
	    }
	    if (cchr == 0) break;	// line ends..
	    if (isdigit (cchr)) {
	      int zpos = 0;
	      do {
	        zpos ++;
	      } while (isdigit (cstr [zpos]));
	      if (cstr [zpos] == '.') {
	        cstr = cstr + zpos + 1;
	        continue;
	      }
	    }
	    codepos = decodesqr (cstr);	// Decode sqr #..1-99,A1-H8
	    if (codepos) {	// Possible legal move..
	      int mfrom,mto;
	      cstr += HIWORD (codepos);
	      if (*cstr != '-') return 0;
	      cstr ++;
	      mfrom =  sqpos [LOWORD (codepos)];
	      do {		// multijump loop..
	        if (mfrom >= maxboard) return 0;
	        codepos = decodesqr (cstr);	// Decode sqr #..1-99,A1-H8
	        if (codepos == 0) return 0;
	        cstr += HIWORD (codepos);
	        mto =  sqpos [LOWORD (codepos)];
		ccolor = ToggleWB & board [mfrom];
	        cstat = doamove (mfrom,mto,0);
	        if (cstat == 1) return 0;	// Bad move..
	        if (*cstr != '-') break;	// no multijumps..
	        cstr ++;
	        mfrom = mto;			// multijump..
	      } while (1);
	      ccolor = ToggleWB - ccolor;
	      continue;
	    }
	    if (*cstr == '{') {		// Comment?
	      do {
	        if (*cstr == '}') break;
	        if (*cstr == 0) {	// next line
	          nin = LineInput (hFile, prbuf, 450);
	  	  if (nin == -1) return 0;	// Past end..
		  cstr = prbuf;
	        }
	        cstr ++;
	      } while (1);
	      cstr ++;
	      continue;
	    }
	    return 0;		//  Illegal char, error..
	  } while (1);
	  	// Read next line..
	  nin = LineInput (hFile, prbuf, 450);
	  if (nin == -1) return 0;	// Past end..
	} while (1);
}

  // Scan past ngames in file
  // ret 1 if OK, 0 for EOF hit..
MYINLINE int pdnSkipGames (FILE *hFile, long ngame)
{
	int nin;
	char prbuf [500];
	do {
	  if (ngame <= 0) return 1;	// OK all scanned past..
	  do {
	    nin = LineInput (hFile, prbuf, 300);
	    if (nin == -1) return 0;	// Past end..
	  } while (*prbuf != '*');
	  ngame --;
	} while (1);
}

  // Load game from db..
  // ret 1 if ok..
int pdnLoad (char *ifile, long cgame)
{
	int ckey;
	int cstat;
	FILE *hFile = NULL;
	#if Shareware
	  ifile = pdnDataBase;
	#else 
	  if (*ifile == 0 || FileExists (ifile) == 0) {
	    ckey = promptin (70,120,STpdnload, pdnDataBase, 64);
	    ifile = pdnDataBase;
	    if (ckey == 27) return 0;
	  } 
	#endif
	if (FileExists (ifile) == 0) {
	  goto pdnfail;
	}
	if (cgame == 0) {
	  ckey = ViewTextFile (80,23,pdnDataBase,1);
	  qclrvdu ();
	  if (ckey == 27) return 0;
	  cgame = viewgamenum;
	}
	#if Shareware
	  if (cgame > 30) cgame = 1;
	#endif
	hFile = fopen (ifile,"rb");
	if (hFile == NULL) return 0;	// failed
	BufReset ();
	if (pdnSkipGames (hFile,cgame - 1) == 0) goto pdnfail;
	cstat = pdnReadGame (hFile);
	if (cstat == -1) {
	  click ();
	  cgame = 1;
	}
	if (cstat == 0) goto pdnfail;
	fclose (hFile);
	pdnCurGame = max (1,cgame);
	if (fullgame ==0) stepmove (-9999);	// To start of problem.
	return 1;
pdnfail:
	dink ();
	fclose (hFile);
	qclrvdu ();
	msgPrintBox (STfileaccesserror);
	pdnCurGame = 1;
	return 0;
}

  // View current PDN database..
void pdnView (char *ifile)
{
	int ckey;
	if (FileExists (ifile) == 0) {
	  ckey = promptin (70,120,STpdnload, pdnDataBase, 64);
	  ifile = pdnDataBase;
	  if (ckey == 27) return ;
	}
	ViewTextFile (80,23,pdnDataBase,0);
	qclrvdu ();
}


TBUTTONINFO iSCRPRN [] = {
 0,0,88,22,13,13,NULL,3,		// Text button (YES)
 112,0,88,22,27,27,NULL,3,		// Text button (NO)
 DISABLE,0,0,0,0,0,NULL,0		// Terminator
};
TBUTTONHEADER hdSCRPRN = {
 iSCRPRN,
 0,0,0,0,176,26,NULL,	// no bmp..
 0,0,0,			// no info-display
 "",0,0,0,0,		// no edit field
 ""  // STscreenprinter
};

void outputgame (int rmode)
{
	int ckey;
	ckey = msgPrintf (70,120,&hdSCRPRN,"Screen or Printer?");
	if (ckey == 13) {
	  pdnExport (2,1, LOBYTE (betweenflag));
	  return;
	}
	clrvdu ();
	pdnExport (2,0, LOBYTE (betweenflag));
	prints ("\nHit SPACE.");
	while (getkey () != ' ');
}

  // make default name..
void pdnResetName ()
{
	sprintf (pdnDataBase,"dbase%d.pdn",gametype);
}

//------------------------------------------------------------------
//
//

	// Calc move# from start for pos (npos) 0=1st,2=2nd..
int CalcMoveNum (int npos)
{
	int cpos;
	UINT last = 0;
	UINT cur;
	int mno = 0;
	for (cpos = 1; cpos <= npos; cpos ++) {
	  cur = (UINT) mgame [cpos]; 	// hibyte=from, lobyte=dest.
	  if ((last ^ cur) & 0xff00) mno ++;  // Not djump, increment
	  last = cur << 8;
	}
	return (mno);
}

	// Get from (mgame), cutting out-jump sqrs..
_inline int GetMove (int *cpos)
{
	int msrc,mdest;
	int cur;
	mdest = msrc = mgame [*cpos];
	if (msrc == 0) return 0;
	do {
	  (*cpos) ++;
	  cur = mgame [*cpos];
	  if ((cur ^ (msrc << 8)) & 0xff00) break;
	  mdest = cur;		// Save last destination
	} while (1);
	return ((msrc & 0xff00) | (mdest & 0x00ff));
}

	// Find (cgame) rec # for given move number..
int FindMove (int nmov)
{
	UINT last = 0;
	UINT cur;
	int cpos = 1;
	int mno = 0; 
	while (mno < nmov) {
	  cur = (UINT) mgame [cpos]; 	// hibyte=from, lobyte=dest.
	  if ((last ^ cur) & 0xff) mno ++;  // Not djump, increment
	  last = cur << 8;
	  cpos ++;
	}
	return (cpos);
}

const int MBtx = 62;	// Move box topleft pos (pixels)
const int MBty = 220;
const int MBlx = 16;
const int MBly = 10;

void MoveBox (int mode)
{
	int snum;	// Start game #
	int sgame;	// Start game pos..
	int cxpos,cypos;
	int mv1;
	int MBcol = PRNANAL;
	if (mode) {	// Fill dialog..
	  fillobject (MBtx, MBty - 4, MBlx, 1, 0xff, PRNWHT);
	  fillobject (MBtx, MBty - 3, MBlx, 6 + MBly + (MBly << 3), 0xff, PRNANAL);
	  fillobject (MBtx, MBty + 3 + MBly + (MBly << 3), MBlx, 1, 0xff, PRNDGREY);
	}
	snum = max (0,(CalcMoveNum (ngame) - MBly - MBly + 2) & (~1));
	sgame = FindMove (snum);	// Find that move #
	cxpos = MBtx; cypos = MBty;
	SelectSet (1);		// 8x8 char set..
	snum = snum >> 1;
	while (1) {		// Now get & print out moves..
	  snum ++;
	  mv1 = GetMove (&sgame);
	  printfat (PRNPIX | PRNINV | cxpos, cypos,-1,MBcol,"%3d:%5s ",
	  	snum, BookMove2Str (mv1));
	  if (sgame > ngame) MBcol = PRNANLO;	// lolite colour
	  mv1 = GetMove (&sgame);
	  prnat (PRNPIX | PRNINV | cxpos + 10, cypos,-1,MBcol,BookMove2Str (mv1));
	  if (sgame > ngame) MBcol = PRNANLO;	// lolite colour
	  cypos += 9;
	  if (cypos >= MBty + MBly + (MBly << 3)) break;
	  if (mgame [sgame] == 0) {		// Wipe remainder..
	    fillobject (MBtx,cypos, MBlx, 9 * MBly + MBty - cypos - 1,0xff,PRNANAL);
	    break;
	  }
	}
	SelectSet (0);
}

void saveinitbrd ()
{
	memcpy (initbrd,board,sizeof (initbrd));
	//for (cpos = bmult * (boardy + 2); cpos >=0; cpos --) initbrd [cpos] = board [cpos];
}


void spoolgame (int spoolpoint)
{
	int movefrom,moveto;
	UINT xgame;
	int cpos;
	FastNewBoard ();
	if (fullgame == 0) {	// Load init pos/color
	  for (cpos = 0; cpos < bmult * (boardy * 2); cpos ++) {
	    board [cpos] = initbrd [cpos];
	  }
	  ccolor = initcolor;
	}
	//if (ngamewas == 0) return;
	if (spoolpoint < 1) return;
	for (xgame = 1; xgame <= (UINT) spoolpoint; xgame ++) {
	  temp = mgame [xgame];
	  if (temp == 0) break;
	  movefrom = (temp >> 8) & 255;
	  moveto = temp & 255;
	  ccolor = ToggleWB & board [movefrom];
	  if ( doamove (movefrom, moveto, 8) == 1 ) {  // bad move?
	    break;
	  }
	}
	ccolor = ToggleWB - ccolor;
	if (board [mgame [ngame]]) {	// Try Pickup next colour..
	  int tcol = board [mgame [ngame + 1]] & Whtorblk;
	  if (tcol) ccolor = tcol;
	}
}

void stepmove (int cstep)
{
	ngame = max (0,ngame + cstep);
	spoolgame (ngame);
        drawboard ();
}

char *tempstr;

void loadgame ()
{
	int cpos,topdata;
	endbrd = bmult * (boardy + 2);
	for (cpos = 0; cpos < Mgame - 1; cpos ++)
	  mgame [cpos] = 0;
	floaddata (szTemp, mgame, Mgame * 2 - 2);
	if (diskerror) return;
	/*  tempstr = (char *) mgame; */
	/*  for (cpos = 0; cpos < 100; cpos ++) printsi (",",mgame[cpos]); */
	/*  for (cpos = 0; cpos < 200; cpos ++) printc (tempstr[cpos]); */
	temp = mgame [0];
	if (temp < 7000 || temp > 8000) return;
	tgame = temp - 7000;
	boardx = mgame [tgame + 1];
	boardy = mgame [tgame + 2];
	bmult = boardx + 2;
	endbrd = bmult * (boardy + 2);
	cornmode = mgame [tgame + 3];
	menperside = mgame [tgame + 6];
	gametype = mgame [tgame + 7] - 55;
	if (gametype < 0 || gametype > 7) gametype = 0;
	newboard (1);
	ngame = tgame;
	fullgame = mgame [ngame + 4];
	topdata = (ngame + 10) << 1;
	if (fullgame == 0) {
	  initcolor = mgame [ngame + 5];
	  for (cpos = 0; cpos <= endbrd; cpos ++) {
	    initbrd [cpos] = board [cpos] = mgame [ngame + 8 + cpos] ;
	  }
	  topdata = (ngame + endbrd + 10) << 1;
	}
	cpos = 0;		/* Read Gamenote */
	tempstr = (char *) mgame;
	do {
	  temp = gamenote [cpos] = tempstr [topdata] ;
	  cpos ++; topdata ++;
	} while (temp);
	initsprites ();
	clrvdu ();
	spoolgame (ngame);	// Spool game up to current pos..
	pxpos = pypos = 1;
	drawboard ();
}

void savegame ()
{
	int cpos,topdata;
	if (ngame < 0) return;
	endbrd = bmult * (boardy + 2);
	mgame [0] = ngame + 7000;
	mgame [ngame + 1] = boardx;
	mgame [ngame + 2] = boardy;
	mgame [ngame + 3] = cornmode;
	mgame [ngame + 4] = fullgame;
	mgame [ngame + 5] = initcolor;
	mgame [ngame + 6] = menperside;
	mgame [ngame + 7] = gametype + 55;
	if (fullgame) {
	  topdata = (ngame + 10) << 1;
	} else {
	  for (cpos = 0; cpos <= endbrd; cpos ++) {
	    mgame [ngame + 8 + cpos] = initbrd [cpos];
	  }
	  topdata = (ngame + endbrd + 10) << 1;
	}
	cpos = 0;
	tempstr = (char *) mgame;
	do {
	  temp = tempstr [topdata] = gamenote [cpos];
	  cpos ++; topdata ++;
	} while (temp);
	fsavedata (szTemp, mgame, topdata );
}


void numberboard ()
{
	int cnum;
	SelectSet (1);		// 8x8 chars
	for (cnum = 1; cnum <= nsqrs; cnum ++) {
	  cpos = sqpos [cnum]; xpos = cpos % bmult;
	  ypos  = cpos / bmult;
	  if (boardflip) {
	    xpos = boardx + 1 - xpos;
	    ypos = boardy + 1 - ypos;
	  }
	  xpos = xpos * charx - charx + topx;
	  ypos = ypos * chary - chary + topy;
	  printfat (PRNINV | PRNPIX | xpos, ypos, -1, 12,"%2d",cnum);
	}
	SelectSet (0);		// Normal 16x8 chars
}

// End of file..
