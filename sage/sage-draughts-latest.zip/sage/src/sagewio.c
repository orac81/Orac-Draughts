//  SAGWIO.C - Generic Windows C routines. Copyright A.Millett 1996-2025

#define STRICT                // strict type checking
#include <windows.h>
//#include <winuser.h>	// for wvsprintf
#include <commdlg.h>	// for GetOpenFileName

#include <stdio.h>		// Standard C routines..
#include <string.h>		//for memcpy,memmove, memcmp
#include <stdlib.h>		//for atoi
#include <malloc.h>		// for malloc..

#include <stdarg.h>		// for wvsprinf (16bit)
#include <process.h>	// _beginthread..
#include <time.h>

#include "sageio.h"	// General non-genius specific code..
#include "sagewio.h"	// General non-genius specific windows code..

//---------------------------------------------------------------
// MODULE:msg_  msg box/printing functions..
//---------------------------------------------------------------


  // Print to a loc on DC, or dialog if DC is NULL..
  //  if DC==NULL (Dlg) & (xpos)==msg_OPTIONS, ypos=Dlg flag (MB_OKCANCEL etc)
  //    if (xpos)==msg_ABORT then exit prog after dialog
  // Return len of text printed
short msg_Printf (HDC hDC, short xpos, short ypos, char *titleDat, char *format,...)
{
	static char prbuf [1024];
	short vlen;
	va_list argptr;
	if (titleDat == NULL) titleDat = "Error";
	va_start (argptr,format);
	vlen = wvsprintf ((char far *) prbuf,format, argptr);
	va_end (argptr);
	if (hDC == NULL) {	// Display string in popup window..
	  if (xpos & msg_OPTIONS) { // Extra option flags set in ypos..
	    return (MessageBox (NULL, prbuf, titleDat, MB_TASKMODAL | ypos));
	  }
	  //MessageBox (NULL, prbuf, Progname, MB_OK | MB_TASKMODAL);
	  MessageBox (NULL,prbuf,titleDat,MB_TASKMODAL);
	} else {
	  TextOut (hDC, xpos, ypos, (LPSTR) prbuf, lstrlen (prbuf));
	}
	if (xpos & msg_ABORT) exit (0);
	return (vlen);
}	


void msg_Box (char *szStr, char *szTitle)
{
    if (*szTitle == 0) szTitle = "Error";
    MessageBox (NULL, szStr, szTitle, MB_OK | MB_TASKMODAL);
}


//---------------------------------------------------------------
// MODULE:font_  misc font functions..
//---------------------------------------------------------------

	// Calc current fixed-font size..
//void wio_CalcFontSize (HFONT hFont, short *chx, short *chy)
void font_CalcSize (HFONT hFont, short *chx, short *chy)
{
	TEXTMETRIC txtmet;
	HDC hDC = GetDC (NULL);
	SelectObject(hDC, hFont);	// select it 
	GetTextMetrics (hDC, &txtmet);	// Get font size..
	*chx = (short) txtmet.tmAveCharWidth;
	*chy = (short) txtmet.tmHeight;
	ReleaseDC (NULL,hDC);
}

  // Calc extent of text using a font on screen..
void font_CalcExtent (HFONT hFont, char *szTxt, MYPOINT *pSize)
{
        SIZE tsize;
	HDC hDC = GetDC (NULL);
	SelectObject(hDC, hFont);	// select it 
        GetTextExtentPoint32 (hDC,szTxt,strlen (szTxt),&tsize);
	ReleaseDC (NULL,hDC);
        pSize->x = (short) tsize.cx;
        pSize->y = (short) tsize.cy;
}

	// Calc current fixed-font size..
//void wio_CalcFontSizeFromName (char *szFont, short size, short *chx, short *chy)
void font_CalcSizeFromName (char *szFont, short size, short *chx, short *chy)
{
    HFONT hFont;
    LOGFONT lfont;
    memset (&lfont, 0, sizeof (LOGFONT));	// clr struct
    lfont.lfHeight = size;
    strncpy (lfont.lfFaceName,szFont,32);
    hFont = CreateFontIndirect (&lfont);
    if (hFont == NULL) {	// Could not do it, select system..
      hFont = (HFONT) GetStockObject (SYSTEM_FONT);
    }
    font_CalcSize (hFont, chx, chy);
    DeleteObject (hFont);
}

  // For given size, select the correct size font..
HFONT font_ForSize (char *szFont, ULONG style, MYPOINT insize, MYPOINT *outsize)
{
      LOGFONT logfont;
      HFONT hFont;
      memset (&logfont,0,sizeof (LOGFONT));
      strcpy (logfont.lfFaceName,szFont);	// Font name to select
      logfont.lfHeight = insize.y;
      logfont.lfWidth = insize.x;
      logfont.lfWeight = (style & FONT_BOLD) ? FW_BOLD : FW_NORMAL;
      if (style & FONT_ITALIC) logfont.lfItalic = TRUE;
      hFont = CreateFontIndirect(&logfont);
      if (hFont == NULL) {		// Could not do it, select system..
	hFont = (HFONT) GetStockObject (SYSTEM_FIXED_FONT);
      }
      if (outsize) {
        font_CalcSize (hFont, &outsize->x, &outsize->y);
      }
      return hFont;
}

//---------------------------------------------------------------
// MODULE:wio_ Misc windows i/o support funtions..
//---------------------------------------------------------------
  // Calc size of a windows borders..
MYPOINT wio_WindowBorderSize(HWND hWnd)
{
    RECT crect,wrect;
    MYPOINT border;
    GetClientRect (hWnd,&crect);	// Size of client area
    GetWindowRect (hWnd,&wrect);	// Total size of window..
    border.x = (short) ((long) (wrect.right - wrect.left) - crect.right);
    border.y = (short) ((long) (wrect.bottom - wrect.top) - crect.bottom);
    return border;
}                                                        

  // Convert pos within window client to pos within parent..
void wio_Window2Parent (HWND hWnd, POINT *pPt)
{
    ClientToScreen (hWnd,pPt);
    ScreenToClient (GetParent (hWnd),pPt);
}

  // Get abs size of window, inc borders etc..
POINT wio_GetWindowSize (HWND hWnd)
{
    POINT pt;
    RECT cur;
    GetWindowRect (hWnd,&cur);
    pt.x = (cur.right - cur.left);
    pt.y = (cur.bottom - cur.top);
    return pt;
}

  // Get pos of window within parent client area
POINT wio_GetWindowPos (HWND hWnd)
{
    POINT pt;
    RECT cur;
    GetWindowRect (hWnd,&cur);
    pt.x = cur.left;
    pt.y = cur.top;
    ScreenToClient (GetParent (hWnd),&pt);
    return pt;
}

int wio_use = 0;   // A precaution to prevent loops - abort if too many attempts..
clock_t wio_clk = 0;

  // For a given window, set a pos within it parent so it does not fall outside
  //  IN: pR = extra non-overlap area around top/bot/left/right of parent 
  //  OUT: pR = new window position and size used in SetWindowPos..
void wio_SetSafeRect (HWND hWnd, RECT *pR)
{
    RECT par;
    POINT wtop;	// top of cur window
    POINT wsiz;	// Size of cur window
    int tx,ty,lx,ly;	// New computed top/size
    int dif;

    wtop = wio_GetWindowPos  (hWnd);   // Pos rel to parent client area
    wsiz = wio_GetWindowSize (hWnd);	// Size of complete window
    GetClientRect (GetParent (hWnd),&par);
    if (par.right - par.left < 100 || par.bottom - par.top < 100) return; // Parent too small, dont try..
    tx = wtop.x;
    ty = wtop.y;
    lx = wsiz.x;
    ly = wsiz.y;

    if (tx < pR->left) tx = pR->left;
    if (ty < pR->top) ty = pR->top;
      // Now do these new top pos coords push bot beyond bounds?
    dif = (par.right - pR->right) - (tx + lx);   // calc X Difference
    if (dif < 0) lx += dif;			 // If over, reduce len
    dif = (par.bottom - pR->bottom) - (ty + ly); // calc Y Difference
    if (dif < 0) ly += dif;			 // If over, reduce len
    if (wio_clk != clock () / CLOCKS_PER_SEC) {
      wio_clk = clock () / CLOCKS_PER_SEC; wio_use = 0;
    }
    if (wio_use < 30 && (tx != wtop.x || ty != wtop.y || lx != wsiz.x || ly != wsiz.y)) {
      wio_use ++;
      if (GetKeyState (VK_CONTROL) & 0x8000) {	// Ctrl key
        wio_use ++;
      }
      SetWindowPos (hWnd, NULL,tx,ty,lx,ly,SWP_NOZORDER);
    }
    pR->top    = ty;
    pR->left   = tx;
    pR->right  = lx;
    pR->bottom = ly;
}

/*        { RECT cur,main;
	  int miny = tb_Main.ttop.y + tb_Main.tlen.y;
	  POINT pt = {0,0};
          GetWindowRect (hWnd,&cur);
          GetClientRect (GetParent (hWnd),&main);
	  wio_Window2Parent (hWnd, &pt);

          if (pt.y < miny) {
            SetWindowPos (hWnd, NULL,pt.x,miny,0,0,SWP_NOZORDER | SWP_NOSIZE);
          }
        }
*/

  // Get low-level info on desktop/screen size, resolution, colours..
  //  call with HORZRES, VERTRES, BITSPIXEL, PLANES
  //  returns size in appropiate units
int wio_DesktopInfo (int nIndex)
{
    int cret;
    HDC hDC = GetDC (NULL);
    cret = GetDeviceCaps(hDC, nIndex);
    ReleaseDC (NULL,hDC);
    return cret;
}

  // Service the WM_PALETTECHANGED/WM_QUERYNEWPALETTE messages for a 
  // window with a palette.. If ret TRUE, (wndproc) should return (*lr)
BOOL wio_PaletteServe (LRESULT *lr, HWND hWnd, UINT wMsg, WPARAM wParam, HPALETTE hPal)
{
   HPALETTE hpalT;	// old pal handle
   HDC hDC;
   *lr = 0;
   switch (wMsg) {
     case WM_PALETTECHANGED:
       if (hPal == NULL) break;
       if ( (HWND) wParam == hWnd) return TRUE;
     case WM_QUERYNEWPALETTE:
         // If realizing the palette causes the palette to change,
         // redraw completely.
       if (hPal == NULL) break;
       hDC = GetDC (hWnd);
       hpalT = SelectPalette (hDC, hPal, FALSE);
       *lr = RealizePalette (hDC); 	// # entries that changed 
       SelectPalette (hDC, hpalT, TRUE);	// Orig back in..
  	// If any palette entries changed, repaint the window.
       if (*lr > 0) InvalidateRect (hWnd, NULL, TRUE);
       ReleaseDC (hWnd, hDC);
       return TRUE;
    }
    return FALSE;
}

  // draw 3d box..
void wio_Box3d (HDC hDC, HPEN hPen1, HPEN hPen2, int tx, int ty, int lex, int ley,int add,int mode)
{
    lex += (tx - 1 + add) ; ley += (ty - 1 + add);
    tx -= add; ty -= add;
    SelectObject (hDC,hPen2);
    MoveToEx (hDC, tx, ley,NULL);
    LineTo (hDC, tx, ty); 
    LineTo (hDC, lex, ty); 
    SelectObject (hDC,hPen1);
    LineTo (hDC, lex, ley); 
    LineTo (hDC, tx, ley);
    if (mode) {		// Black border..
      tx -= 1; ty -= 1;
      lex +=1; ley += 1;
      SelectObject (hDC,(HPEN) GetStockObject (BLACK_PEN));
      MoveToEx (hDC, tx, ley,NULL);
      LineTo (hDC, tx, ty); 
      LineTo (hDC, lex, ty); 
      LineTo (hDC, lex, ley); 
      LineTo (hDC, tx, ley);
    }
}

 // TextOut() replacement - FAST printing only updated bits..
 // cmode bit 0 set to force print all anyway..
 // cmode bit 1 set do not update shadow-buffer (also prn all..)
 // clen = -1 calc str len, -2 = auto center
 // ccolor = color to print, -1=no colour change

void wio_TextOutRefresh (HDC hDC, short xpos, short ypos, 
	char *pTxt, char *pShadow,	// Strings - to prn, old str..
	short clen, short cchrx, 	// length, char-width
	short cmode, COLORREF ccolor)	// mode & txt color
{
	short cpos;		// current char pos..
	short stpos;		// start pos..
	if (clen < 0) {		// -1= calc len null str, -2=auto-center str
	  cpos = strlen (pTxt);
	  if (clen == -2) xpos -= ((cpos * cchrx) >> 1);
	  clen = cpos;
	}
	if (clen == 0) return;	// no string to print..
	if (cmode & (WIO_PRINTALL | WIO_NOSHADOW)) {		// Simple flush all..
	  if (ccolor != WIO_NO_COLOR) {
	    SetTextColor (hDC, ccolor);	// Set text colour
	  }
	  TextOut (hDC, xpos, ypos, pTxt,clen);
		// Save old string for next time..
	  if (!(cmode & WIO_NOSHADOW) && pShadow != NULL) {
	    for (cpos = 0; cpos < clen; cpos ++) {
	      pShadow [cpos] = pTxt [cpos];
	    }
	  }
	} else {		// Selective print update..
	  cpos = 0;
	  do {
		// While buffers match, scan until mis-match..
	    while (cpos < clen && pTxt [cpos] == pShadow [cpos]) {
	      cpos ++;
	    }
	    if (cpos >= clen) break;
	    stpos = cpos;	// save start print position..
	    if (!(cmode & WIO_NOSHADOW)) pShadow [cpos] = pTxt [cpos];	// save update..
	    cpos ++;
		// Now scan mismatch, until match found..
	    while (cpos < clen && pTxt [cpos] != pShadow [cpos]) {
	      if (!(cmode & WIO_NOSHADOW)) pShadow [cpos] = pTxt [cpos];	// save update..
	      cpos ++;
	    }
		// Now print mis-matching section..
	    if (ccolor != WIO_NO_COLOR) {
	      SetTextColor (hDC, ccolor);	// Set text colour
	      ccolor = (COLORREF) -1L;			// Ensure only do once..
	    }
	    TextOut (hDC, xpos + stpos * cchrx, ypos, pTxt + stpos, cpos - stpos);
	    cpos ++;
	  } while (cpos < clen); // Loop to try to find another section
	}
}

  // Return size of physical RAM, in bytes..
ULONG wio_MaxRam ()
{
    MEMORYSTATUS memstat;
    memset (&memstat,0,sizeof (MEMORYSTATUS));
    memstat.dwLength = sizeof (MEMORYSTATUS);
    GlobalMemoryStatus (&memstat);
    return memstat.dwTotalPhys;
}


//---------------------------------------------------------------
// MODULE:snd_ Sound play functions..
//---------------------------------------------------------------

char *snd_szFiles = "\0\0";

void snd_Init (char *szSndFiles)
{
    snd_szFiles = szSndFiles;
}

void snd_Play (short sound)
{
    char *szFile;
    szFile = str_GetNth (snd_szFiles,sound);
    if (file_Exists (szFile) == FALSE) return; 
    sndPlaySound (szFile, SND_ASYNC);
}

//---------------------------------------------------------------
// MODULE:ctl_  For adding std controls on a non-dlg window..
//---------------------------------------------------------------


#define CTL_ITEM_MAX 40
#define CTL_STATUS 0x5543   // Unique status id..

typedef struct {
  CTL_INFO *pCtl[20];	// List of ptr to controls in use..
  int nctl;		// # in use..
  HFONT hFont;	        // Default font
  MYPOINT font;		// Size of font used..
  int NextIDD;
} CTL_DATA;

CTL_DATA ctl_dat;

void ctl_Reset ()
{
    memset (&ctl_dat,0,sizeof (CTL_DATA));
    ctl_dat.hFont = (HFONT) GetStockObject (SYSTEM_FONT);
    font_CalcSize (ctl_dat.hFont, &ctl_dat.font.x, &ctl_dat.font.y);   
    ctl_dat.NextIDD = CTL_IDD_AUTO;
}

void ctl_Init (CTL_INFO *pCtl, HWND hParent)
{
    int cpos;
    if (pCtl->status == CTL_STATUS) {
      ctl_Close (pCtl);
    }
    for (cpos = 0; cpos < ctl_dat.nctl; cpos ++) {
      if (pCtl == ctl_dat.pCtl [cpos]) {
        return;	    // Already exists
      }
    }
    ctl_dat.pCtl [ctl_dat.nctl] = pCtl;	    // Add to list..
    ctl_dat.nctl ++;
    pCtl->status = CTL_STATUS;		// Activate..
    pCtl->pItem = (CTL_ITEM *) malloc (4 * sizeof (CTL_ITEM));   // Alloc mem..
    pCtl->hOwner = hParent;
}

   // Alloc spc for a new item, ret address of new item
CTL_ITEM *ctl_AllocItem (CTL_INFO *pCtl)
{
    pCtl->nitems ++;
    pCtl->pItem = (CTL_ITEM *) realloc (pCtl->pItem,(pCtl->nitems + 4) * sizeof (CTL_ITEM));
    if (pCtl->pItem ==NULL) return NULL;
    return (&pCtl->pItem[pCtl->nitems-1]);
}

BOOL ctl_IsIdUsed (int cID)
{
    int cctl,citem,cwnd;
    for (cctl = 0; cctl < ctl_dat.nctl; cctl ++) {
      CTL_INFO *pCtl = ctl_dat.pCtl[cctl];
      for (citem = 0; citem < pCtl->nitems; citem ++) {
        CTL_ITEM *pItem = pCtl->pItem + citem;
        for (cwnd = 0; cwnd < pItem->nwnd; cwnd ++) {
          if (pItem->pSubItem[cwnd].id == cID) return TRUE;	    // ID is in use..
        }
      }
    }
    return FALSE;
}

int ctl_FindAnID ()
{
    int cID;
    cID = ctl_dat.NextIDD; 
    while (1) {
      if (ctl_IsIdUsed (cID) == FALSE) break;
      cID ++;
    }
    ctl_dat.NextIDD = cID + 1;	// To check next time..
    return cID;
}


  // Add Control items - add an item (group of buttons, etc)
  //  return TRUE if ok, or FALSE if error..
int ctl_AddItem (CTL_INFO *pCtl, CTL_ITEM *pItem)
{
    int slen,cstat;
    int cID;
    MYPOINT cpos,clen;
    char *pStr = pItem->str;
    HINSTANCE hInstance;
    CTL_ITEM *pNewItem;
    int cwnd=0;

    hInstance = GetInstance (pCtl->hOwner);
    if (pItem->id == 0) {
      pItem->id = ctl_FindAnID ();
    }
    cID = pItem->id;
    pItem->pSubItem = (CTL_SUBITEM *) malloc ((pItem->num + 4) * sizeof (CTL_SUBITEM));
    switch ((pItem->type) & 0xff) {
      case CTL_TyTEXT: {
        long flags;
        slen = strlen (pStr);
        if (pItem->len.x & CTL_AUTOCALC) pItem->len.x = ctl_dat.font.x * slen;   // Autocalc
        if (pItem->len.y & CTL_AUTOCALC) pItem->len.y = ctl_dat.font.y + 6;   // Autocalc
        cpos = pItem->top; clen = pItem->len;
        pItem->nwnd = 1;
        if (pItem->type & CTL_TyGROUPBOX) {     // Put group-box around it..
          pItem->nwnd ++;
        }
        pItem->pSubItem[cwnd].id = cID;
        flags = WS_CHILD | WS_VISIBLE | 
                ((pItem->type & CTL_TyCENTER) ? SS_CENTER : SS_LEFT);
        pItem->pSubItem[0].hWnd = CreateWindow ("STATIC",pStr,
            flags,
            cpos.x,cpos.y,clen.x, clen.y, 
	    pCtl->hOwner, (HMENU) cID, hInstance,NULL);
        if (pItem->pSubItem[0].hWnd == NULL) return FALSE;
        pItem->bot.x = cpos.x + clen.x;	// Save final pos..
        pItem->bot.y = cpos.y + clen.y; 
        break;
      }
      case CTL_TyBUTTON: {
        if (pItem->len.y & CTL_AUTOCALC) pItem->len.y = ctl_dat.font.y + 6;   // Autocalc
        if (pItem->add.y & CTL_AUTOCALC) pItem->add.y = pItem->len.y + (pItem->add.y & 0xfff);	    // Autocalc
        cpos = pItem->top; clen = pItem->len;
        pItem->nwnd = pItem->num;
        for (cwnd = 0; cwnd < pItem->num; cwnd ++) {
          slen = strlen (pStr);
          if (slen == 0) break;
          if (clen.x == CTL_AUTOCALC) clen.x = slen * ctl_dat.font.x + 7;	// Autocalc
          pItem->pSubItem[cwnd].id = cID;
          pItem->pSubItem[cwnd].hWnd = CreateWindow ("BUTTON",pStr,
        	WS_CHILD | WS_TABSTOP | WS_VISIBLE | BS_PUSHBUTTON,
		cpos.x,cpos.y,
		clen.x,clen.y,
		pCtl->hOwner, (HMENU) cID, hInstance,NULL);
          if (pItem->pSubItem[cwnd].hWnd == NULL) return FALSE;	// Error..
          cID ++;	    // Next identifier
          cpos.x += pItem->add.x; cpos.y += pItem->add.y;
          pStr += (slen + 1);   // Next string..
        }
        pItem->bot.x = cpos.x;	// Save final pos..
        pItem->bot.y = cpos.y; 
        break;
      }
      case CTL_TyCHECKBOX: {
        if (pItem->len.x & CTL_AUTOCALC) pItem->len.x = (ctl_dat.font.x * (pItem->len.x & 0xfff));	// Autocalc, width in chars..
        if (pItem->len.y & CTL_AUTOCALC) pItem->len.y = (ctl_dat.font.y + (pItem->len.y & 0xfff)) * (pItem->num+1) + 8;	// Autocalc
        if (pItem->add.x & CTL_AUTOCALC) pItem->add.x = 0;
        if (pItem->add.y & CTL_AUTOCALC) pItem->add.y = (pItem->len.y - 8) / (pItem->num+1);
        cpos = pItem->top; clen = pItem->len;
        pItem->nwnd = pItem->num;
        if (pItem->type & CTL_TyGROUPBOX) {     // Put group-box around it..
          int gID = ctl_FindAnID ();
          cwnd = pItem->num;
          pItem->pSubItem[cwnd].id = gID;
          pItem->pSubItem[cwnd].hWnd = CreateWindow ("BUTTON",pStr,
                BS_GROUPBOX | WS_CHILD | WS_VISIBLE,
                cpos.x,cpos.y,
                clen.x, clen.y, 
		pCtl->hOwner, (HMENU) gID, hInstance,NULL);
          pItem->nwnd ++;
          pStr += strlen(pStr) + 1;
          cpos.x += 8;
          cpos.y += (clen.y - pItem->add.y * pItem->num) / 2 + pItem->add.y / 4;
        }
        clen.x -= 10; clen.y = pItem->add.y;
        for (cwnd = 0; cwnd < pItem->num; cwnd ++) {
          HWND hWnd;
          slen = strlen (pStr);
          if (slen == 0) break;
          pItem->pSubItem[cwnd].id = cID;
          hWnd = pItem->pSubItem[cwnd].hWnd = CreateWindow ("BUTTON",pStr,
                WS_CHILD | WS_TABSTOP | WS_VISIBLE | BS_AUTOCHECKBOX,
		cpos.x,cpos.y,
		clen.x,clen.y,
		pCtl->hOwner, (HMENU) cID, hInstance,NULL);
          if (hWnd == NULL) return FALSE;	// Error..
        	// Set init status of check boxes..
          cstat = pItem->val & (1 << cwnd) ? MF_CHECKED : MF_UNCHECKED;
	  CheckDlgButton (pCtl->hOwner, cID, cstat);
          cID ++;	    // Next identifier
          cpos.x += pItem->add.x; cpos.y += pItem->add.y;
          pStr += (slen + 1);   // Next string..
        }
        pItem->bot.x = cpos.x;	// Save final pos..
        pItem->bot.y = cpos.y; 
        break;
      }

      case CTL_TyRADIOBOX: {
        if (pItem->len.x & CTL_AUTOCALC) pItem->len.x = (ctl_dat.font.x * (pItem->len.x & 0xfff));	// Autocalc, width in chars..
        if (pItem->len.y & CTL_AUTOCALC) pItem->len.y = (ctl_dat.font.y + (pItem->len.y & 0xfff)) * (pItem->num+1) + 8;	// Autocalc
        if (pItem->add.x & CTL_AUTOCALC) pItem->add.x = 0;
        if (pItem->add.y & CTL_AUTOCALC) pItem->add.y = (pItem->len.y - 8) / (pItem->num+1);
        cpos = pItem->top; clen = pItem->len;
        pItem->nwnd = pItem->num;
        if (pItem->type & CTL_TyGROUPBOX) {     // Put group-box around it..
          pItem->nwnd ++;
          pStr += strlen(pStr) + 1;
          cpos.x += 8;
          cpos.y += (clen.y - pItem->add.y * pItem->num) / 2 + pItem->add.y / 4;
        }
        clen.x -= 10; clen.y = pItem->add.y;
        for (cwnd = 0; cwnd < pItem->num; cwnd ++) {
          HWND hWnd;
          slen = strlen (pStr);
          if (slen == 0) break;
          pItem->pSubItem[cwnd].id = cID;
          hWnd = pItem->pSubItem[cwnd].hWnd = CreateWindow ("BUTTON",pStr,
                BS_RADIOBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,	// Radio buttons
 		cpos.x,cpos.y,
		clen.x,clen.y,
		pCtl->hOwner, (HMENU) cID, hInstance,NULL);
          if (hWnd == NULL) return FALSE;	// Error..
          cID ++;	    // Next identifier
          cpos.x += pItem->add.x; cpos.y += pItem->add.y;
          pStr += (slen + 1);   // Next string..
        }
        if (pItem->type & CTL_TyGROUPBOX) {     // Put group-box around it..
          int gID = ctl_FindAnID ();
          pItem->pSubItem[cwnd].id = gID;
          pItem->pSubItem[cwnd].hWnd = CreateWindow ("BUTTON",pItem->str,
                BS_GROUPBOX | WS_CHILD | WS_VISIBLE,
                pItem->top.x,pItem->top.y,
                pItem->len.x, pItem->len.y, 
		pCtl->hOwner, (HMENU) gID, hInstance,NULL);
        }
            // Set init val..
	CheckRadioButton (pCtl->hOwner, pItem->id, pItem->id + pItem->num -1,
                pItem->id + pItem->val);
        pItem->bot.x = cpos.x;	// Save final pos..
        pItem->bot.y = cpos.y; 
        break;
      }
      case CTL_TyEDIT: {        // Define an edit box..
        if (pItem->len.y & CTL_AUTOCALC) pItem->len.y = ctl_dat.font.y + 6;   // Autocalc
        cpos = pItem->top; clen = pItem->len;
        slen = strlen (pStr);
        pItem->nwnd = 1;
        pItem->pSubItem[cwnd].id = cID;
        pItem->pSubItem[0].hWnd = CreateWindow ("EDIT",pStr,
            ES_LEFT | WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP,
            cpos.x,cpos.y,clen.x, clen.y, 
	    pCtl->hOwner, (HMENU) cID, hInstance,NULL);
        if (pItem->pSubItem[0].hWnd == NULL) return FALSE;
        pItem->bot.x = cpos.x + clen.x;	// Save final pos..
        pItem->bot.y = cpos.y + clen.y; 
        break;
      }


      default:
        return FALSE;
    }
    pNewItem = ctl_AllocItem (pCtl);
    if (pNewItem == NULL) return FALSE;
    *pNewItem = *pItem;	// Copy over to save it..
    return TRUE;
}

  // Search for ID..
int ctl_FindID (CTL_INFO *pCtl, long cID)
{
    int citem,cwnd;
    for (citem = 0; citem < pCtl->nitems; citem ++) {
      CTL_ITEM *pItem = pCtl->pItem + citem;
      for (cwnd = 0; cwnd < pItem->nwnd; cwnd ++) {
        if (pItem->pSubItem[cwnd].id == cID) return citem;
      }
    }
    return -1;
}

  // Change ctl text on the fly..
void ctl_ChangeText (CTL_INFO *pCtl, long cID,char *pTxt)
{
    SendDlgItemMessage (pCtl->hOwner,cID,WM_SETTEXT,0,(LPARAM) pTxt);
}
  
  // Hook service fn for Owner window..
  // Return TRUE if serviced, FALSE if not..
BOOL ctl_Service (CTL_INFO *pCtl,HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    CTL_ITEM *pItem;
    if (pCtl->hOwner != hWnd) return FALSE;

    switch (wMsg) {
      case WM_COMMAND: {
        int citem = ctl_FindID (pCtl, wParam);
        if (citem < 0) return FALSE;    // We do not process this message..
        pItem = pCtl->pItem + citem;
        if ((pItem->type & 0xff) == CTL_TyRADIOBOX) {
	  pItem->val = wParam - pItem->id;      // Set new val..
	  CheckRadioButton (pCtl->hOwner, pItem->id, pItem->id + pItem->num-1,
                pItem->id + pItem->val);
          return TRUE;
        }
      }
    }
    return FALSE;
}

  // Get result for given ctl ID..
long ctl_GetVal (CTL_INFO *pCtl, long cID)
{
    CTL_ITEM *pItem;
    int citem = 0;
    int cwnd;
    long result;

    while (1) {
      pItem = pCtl->pItem + citem;
      if (citem >= pCtl->nitems) return 0;      
      if (pItem->id == cID) break;      // Found ID..
      citem ++;
    }
    switch (pItem->type & 0xff) {
      case CTL_TyCHECKBOX: {
        result = 0;
        for (cwnd = 0; cwnd < pItem->num; cwnd ++) {
		// Read status of check boxes..
          if (SendDlgItemMessage (pCtl->hOwner,
            pItem->pSubItem[cwnd].id,BM_GETSTATE, 0, 0L) & 0x0003) {
              result |= (1 << cwnd);        // Set result bit..
          }
        }
        break;
      }
      case CTL_TyRADIOBOX: {
        result = pItem->val;
        break;
      }
    }
    return result;
}

  // Get result for edit str..
BOOL ctl_GetStr (CTL_INFO *pCtl, long cID, char *pTxt, long size)
{
    CTL_ITEM *pItem;
    int citem = 0;
    int result = FALSE;

    while (1) {
      pItem = pCtl->pItem + citem;
      if (citem >= pCtl->nitems) return 0;      
      if (pItem->id == cID) break;      // Found ID..
      citem ++;
    }
    switch (pItem->type & 0xff) {
      case CTL_TyEDIT: {
        GetWindowText (pItem->pSubItem->hWnd,pTxt,size);
        result = TRUE;
        break;
      }

    }
    return result;
}


  // Find index of pCtl in list in (ctl_dat)
int ctl_Find (CTL_INFO *pCtl)
{
    int cpos;
    for (cpos = 0; cpos < ctl_dat.nctl; cpos ++) {
      if (pCtl == ctl_dat.pCtl [cpos]) return cpos;
    }
    return -1;	// Not found..
}

  // Close all controls..
void ctl_Close (CTL_INFO *pCtl)
{
    int cpos,cwnd;
    cpos = ctl_Find (pCtl);
    if (cpos == -1) return;   // Not found..
	// Delete ctl from list in (ctl_dat)
    ctl_dat.nctl --;
    while (cpos < ctl_dat.nctl) {
      ctl_dat.pCtl [cpos] = ctl_dat.pCtl [cpos + 1];
      cpos ++;
    }
    if (IsWindow (pCtl->hOwner)) {   // Parent still exists..
	// Close windows for ctl..
      for (cpos = 0; cpos < pCtl->nitems; cpos ++) {
        CTL_ITEM *pItem = pCtl->pItem + cpos;
        if (pItem->pSubItem) {
          for (cwnd = 0; cwnd < pItem->nwnd; cwnd ++) {
            DestroyWindow (pItem->pSubItem[cwnd].hWnd);
          }
          free (pItem->pSubItem);
        }
      }
    }
    free (pCtl->pItem);	    // Release mem.
    memset (pCtl,0,sizeof (CTL_INFO));	// Clr struct.
    ctl_dat.NextIDD = CTL_IDD_AUTO;
}

//---------------------------------------------------------------
// MODULE:con_ Generic (Debugging) Console style I/O routines..
//---------------------------------------------------------------
		// Some local variables..
static HWND con_hWnd = NULL;		// Console win handle	
static HWND con_hEdWnd = NULL;		// Console win handle	
static HWND con_hParent = NULL;		// Console win handle	
static BOOL con_RegClass = FALSE;	// Class not yet registered
static char con_szClass [] = "CONCLASS";// Unique win class name
#define CON_MAXCHR 10000
char con_buff [CON_MAXCHR];
int con_nchr;

LRESULT CALLBACK con_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    switch(wMsg) {                      // which message?
      case WM_CREATE: {
        HINSTANCE hInstance = GetInstance (hWnd);
        memset (con_buff,0,sizeof(con_buff));
        con_hEdWnd  = CreateWindow ("EDIT","",
	   WS_CHILD | WS_BORDER | WS_TABSTOP | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_LEFT | ES_MULTILINE | ES_READONLY, //| ES_AUTOVSCROLL | ES_AUTOHSCROLL,
	   1,1,640,480,hWnd,(HMENU) 123,hInstance,NULL);
	con_nchr = 0;
        return 0L;

      }
      case WM_SIZE: {
        int nWidth = LOWORD(lParam);  // width of client area 
	int nHeight = HIWORD(lParam); // height of client area 
        SetWindowPos (con_hEdWnd,NULL,1,1,nWidth,nHeight,SWP_NOZORDER);
	break;
      }
      case WM_PAINT:
        break;
        
    }   

    return( DefWindowProc(hWnd, wMsg, wParam, lParam) );
} 

void con_SetTitle (char *szTxt)
{
    SetWindowText (con_hWnd, szTxt);
}

BOOL con_isOpen () 
{ return (con_hWnd != NULL); }

short con_open (HWND hParent, char *szTitle)
{
    WNDCLASS wndclass;           // window class structure
    HINSTANCE hInstance = GetInstance (hParent);
    if (con_hWnd) return 0;	// Console Window already open..
    con_hParent = hParent;
    if (con_RegClass == FALSE) {               // if this is first such window
      con_RegClass = TRUE;
      //con_hFont = (HFONT) GetStockObject (ANSI_FIXED_FONT);

      wndclass.style         = CS_HREDRAW | CS_VREDRAW;  // style
      wndclass.lpfnWndProc   = (WNDPROC) con_WndProc; // WndProc address
      wndclass.cbClsExtra    = 0;            // no extra class data
      wndclass.cbWndExtra    = 0;            // no extra window data
      wndclass.hInstance     = hInstance;    // which program?
					     // stock arrow cursor
      wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
					     // stock blank icon
      wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
      wndclass.lpszMenuName  = NULL;   // menu name
					     // white background
      wndclass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
      wndclass.lpszClassName = con_szClass;   // window class name

      RegisterClass(&wndclass); // register the class
    }

    con_hWnd = CreateWindow(con_szClass,           // window class name
		szTitle,           // caption
		WS_OVERLAPPEDWINDOW,  // style
		-1,95,		// xy pos
		90,230,		// xy len
		hParent,              // parent's handle
		NULL,                 // menu handle
		hInstance,            // which program?
		NULL);                // no init data
    ShowWindow (con_hWnd, SW_SHOWMAXIMIZED);      // make window visible
    SetFocus (con_hWnd);
    return (1);
}

void con_close ()
{
    if (con_hWnd) {
      DestroyWindow (con_hWnd);
    }
    con_hWnd = NULL;
}

short con_printf (char *format,...)
{
    TEXTMETRIC txtmet;
    short fontx,fonty;
    short vlen;
    short cpos;
    RECT rwin;
    HDC hDC;
    va_list argptr;
	// Turn variable len format into a szString..
    va_start (argptr,format);
    vlen = wvsprintf (con_buff + con_nchr,format, argptr);
    va_end (argptr);
    if (con_hWnd == NULL) return 0;	// No console window..
    con_nchr += vlen;
    if (con_nchr > CON_MAXCHR - 1024) {  // Scroll, remove early data..
      int ndel = con_nchr - (CON_MAXCHR - 1024);
      int delpos;
      for (delpos = ndel; delpos < con_nchr; delpos ++) {
        if (con_buff [delpos] < 32) break;
      }
      con_nchr -= delpos;
      memmove (con_buff, con_buff+delpos, con_nchr);   // Delete front section..
    }
    con_buff [con_nchr] = 0;
    SendMessage (con_hEdWnd,WM_SETTEXT,0,(LPARAM) con_buff);
    //SendMessage (con_hEdWnd,WM_KEYDOWN,VK_NEXT,0L);
    //SendMessage (con_hEdWnd,WM_KEYDOWN,VK_NEXT,0L);
    //SendMessage (con_hEdWnd,WM_KEYDOWN,VK_NEXT,0L);
    SendMessage (con_hEdWnd,WM_KEYDOWN,VK_NEXT,0L);
    if (0) {
      SCROLLINFO si;
      memset (&si,0,sizeof(SCROLLINFO));
      si.cbSize = sizeof (SCROLLINFO);
      si.fMask = SIF_PAGE;//  | SIF_PAGE;
      si.nPos = 100;

      SetScrollInfo (con_hEdWnd, SB_VERT, &si, TRUE);	// Force scroll bars default bottom.
    }
}

/*   OLD VERSION..

		// Some local variables..
static short con_x,con_y;		// X/Y positions of printing
static HWND con_hWnd = NULL;		// Console win handle	
static HWND con_hEdWnd = NULL;		// Console win handle	
static HWND con_hParent = NULL;		// Console win handle	
static BOOL con_RegClass = FALSE;	// Class not yet registered
static char con_szClass [] = "CONCLASS";// Unique win class name
static unsigned short con_nkey = 0;	// #chars in keybrd input buff
static char con_keybuff [80];		// keyboard input buffer..
static char con_input [80];		// keyboard input buffer..
static HFONT con_hFont;			// Font for console
#define CON_MAXX 100
#define CON_MAXY 40
static BYTE con_vdu [CON_MAXY][CON_MAXX];		// Vitual screen
void con_redraw (HDC);


LRESULT CALLBACK con_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    switch(wMsg) {                      // which message?
      case WM_CREATE:
        return 0L;
        
      case WM_PAINT: {
	HDC hDC;
	PAINTSTRUCT ps;
        hDC = BeginPaint (hWnd, &ps);
        con_redraw (hDC);
	EndPaint (hWnd, &ps);
        return 0;
      }
        
      case WM_KEYDOWN:
        break;
      
      case WM_CHAR:
        {
	  HDC hDC;
	  if (wParam == 8 && con_nkey) {	// Delete..
	    con_keybuff [con_nkey] = 32;
	    con_nkey --;
	    con_keybuff [con_nkey] = 0;
	  }
          if (con_nkey < sizeof (con_keybuff) - 1 && wParam >= 32) {
 	    con_keybuff [con_nkey] = (char) wParam;
	    con_nkey ++;
	    con_keybuff [con_nkey] = 0;
	  }
	  if (wParam == CHR_CR) {	// CR..
	    memcpy (con_input, con_keybuff, sizeof (con_input));
	    memset (con_keybuff,32,sizeof (con_keybuff));
	    con_nkey = 0;
	    con_keybuff [0] = 0;
	    PostMessage (con_hParent, WM_CON_INPUT, (WPARAM) WM_CON_INPUT, (LPARAM) ((LPSTR) con_input));
	  }
	  hDC = GetDC (hWnd);
	  if (hDC == NULL) return 0;
	  SelectObject(hDC, con_hFont);	// select it 
	  SetTextColor (hDC, RGB (0,0,255));
	  con_keybuff [con_nkey] = '_';
	  TextOut (hDC, 0, 0, (LPSTR) con_keybuff, sizeof (con_keybuff));
	  con_keybuff [con_nkey] = 0;
	  ReleaseDC (con_hWnd,hDC);
	}
        break;
        
      default:                      // handled by DefWindowProc
	return( DefWindowProc(hWnd, wMsg, wParam, lParam) );
    }   

    return 0L;                       // return if we handled wMsg
} 

void con_SetTitle (char *szTxt)
{
    SetWindowText (con_hWnd, szTxt);
}

BOOL con_isOpen () 
{ return (con_hWnd != NULL); }

short con_open (HWND hParent, char *szTitle)
{
    WNDCLASS wndclass;           // window class structure
    HINSTANCE hInstance = GetInstance (hParent);
    if (con_hWnd) return 0;	// Console Window already open..
    con_hParent = hParent;
    if (con_RegClass == FALSE) {               // if this is first such window
      con_RegClass = TRUE;
      con_hFont = (HFONT) GetStockObject (ANSI_FIXED_FONT);

      wndclass.style         = CS_HREDRAW | CS_VREDRAW;  // style
      wndclass.lpfnWndProc   = (WNDPROC) con_WndProc; // WndProc address
      wndclass.cbClsExtra    = 0;            // no extra class data
      wndclass.cbWndExtra    = 0;            // no extra window data
      wndclass.hInstance     = hInstance;    // which program?
					     // stock arrow cursor
      wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
					     // stock blank icon
      wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
      wndclass.lpszMenuName  = NULL;   // menu name
					     // white background
      wndclass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
      wndclass.lpszClassName = con_szClass;   // window class name

      RegisterClass(&wndclass); // register the class
    }
    con_x = con_y = 0;
    memset (con_keybuff,32,sizeof (con_keybuff));
    con_nkey = 0;
    con_keybuff [0] = 0;
    memset (con_vdu,32,sizeof (con_vdu));	// Fill with spc..

    con_hWnd = CreateWindow(con_szClass,           // window class name
		szTitle,           // caption
		WS_OVERLAPPEDWINDOW,  // style
		-1,95,		// xy pos
		90,230,		// xy len
		hParent,              // parent's handle
		NULL,                 // menu handle
		hInstance,            // which program?
		NULL);                // no init data
    ShowWindow (con_hWnd, SW_SHOWMAXIMIZED);      // make window visible
    con_hEdWnd  = CreateWindow ("EDIT","",
	 WS_CHILD | WS_TABSTOP | WS_VISIBLE | ES_LEFT | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
	 0,0,640,480,con_hWnd,(HMENU) 123,hInstance,NULL);
    //ShowWindow (con_hWnd, SW_SHOWNORMAL);      // make window visible
    SetFocus (con_hWnd);
    return (1);
}

void con_close ()
{
    if (con_hWnd) {
      DestroyWindow (con_hWnd);
    }
    con_hWnd = NULL;
}

void con_redraw (HDC hDC)
{
    TEXTMETRIC txtmet;
    short fontx,fonty;
    RECT rwin;
    int y;
    
    SelectObject(hDC, con_hFont);	// select it 
    GetTextMetrics (hDC, &txtmet);	// Get font size..
    fontx = (short) txtmet.tmAveCharWidth;
    fonty = (short) txtmet.tmHeight;
    GetClientRect (con_hWnd, &rwin);	// Get window size..
    for (y = 0; y < CON_MAXY; y ++) {
      TextOut (hDC, 0, y * fonty, (LPSTR) con_vdu [y], CON_MAXX);
    }
}

short con_printf (char *format,...)
{
    TEXTMETRIC txtmet;
    char prbuf [1024];
    short fontx,fonty;
    short vlen;
    short cpos;
    RECT rwin;
    HDC hDC;
    va_list argptr;
	// Turn variable len format into a szString..
    va_start (argptr,format);
    vlen = wvsprintf ((char far *) prbuf,format, argptr);
    va_end (argptr);
    if (con_hWnd == NULL) return 0;	// No console window..
    hDC = GetDC (con_hWnd);
    if (hDC == NULL) return 0;
    SelectObject(hDC, con_hFont);	// select it 
    GetTextMetrics (hDC, &txtmet);	// Get font size..
    fontx = (short) txtmet.tmAveCharWidth;
    fonty = (short) txtmet.tmHeight;
    GetClientRect (con_hWnd, &rwin);	// Get window size..
	// Write each char from the string..
    for (cpos = 0; cpos < vlen; cpos ++) {
      char cchr = prbuf [cpos];
      		// CR/LF or linewrap..
      if (cchr == 10 || (cchr >= 32 && con_x + fontx >= rwin.right)) {
        con_x = 0; 
	con_y += fonty;
	if (con_y > rwin.bottom - fonty) {	// Scroll window..
	  char szSpc [] = "                                                                                                       ";
	  ScrollWindowEx (con_hWnd,0,-fonty,NULL,NULL,NULL,NULL,0);
	  { int x,y;
	    
	    for (y = 1; y < CON_MAXY; y ++) {
	      for (x = 0; x < CON_MAXX; x ++) {
	        con_vdu [y -1][x] = con_vdu [y][x];
	      }
	    }
	  }
	  //BitBlt (hDC, 0,fonty, rwin.right, rwin.bottom, hDC, 0, 2*fonty,SRCCOPY);
	  while (con_y > rwin.bottom - fonty) con_y -= fonty;
          TextOut (hDC, con_x, con_y, (LPSTR) szSpc, strlen (szSpc) - 1);
	}
	continue;
      }
      if (cchr == 1) {		// Ctrl-A up 1 line..
        con_x = 0;
        con_y = max (0,con_y - fonty);
        continue;
      }
      if (cchr >= 32) {
        TextOut (hDC, con_x, con_y, (LPSTR) &cchr, 1);
        if (con_y / fonty < CON_MAXY - 3) {
          con_vdu [con_y / fonty] [con_x / fontx] = cchr;
        }
	con_x += fontx;
      }
    }
    ReleaseDC (con_hWnd,hDC);
    return vlen;	// # chars..
}
*/

//---------------------------------------------------------------
// MODULE: menu_ MENU handle & strings allocation routines..
//---------------------------------------------------------------


  // Initialise a menu, stored in a param file..
  // IN:MENU_INFO..
  // RET: TRUE/FALSE, menu handle.
int menu_Init (MENU_INFO *pMenuFirst, char *szParFile)
{
    #define MENU_MAXSUB 3
    char szStr [128];
    char szSubMenu [MENU_MAXSUB] [128];
    int cret;
    void *pret;
    HMENU hSubMenu [MENU_MAXSUB];
    int cMI;
    int mlevel;
    if (pMenuFirst->nMI < 1) pMenuFirst->nMI = 1;

    pret = par_Open (szParFile);
    if (pret == NULL) return FALSE;	// error opening file..

    for (cMI = 0; cMI < pMenuFirst->nMI; cMI ++) {
      MENU_INFO *pMenu = &pMenuFirst [cMI];
      char szMnu [] = "MENU0";

      szMnu[4] = (char) '0' + cMI + (cMI > 9) * 7;  // upto 36 menus - 0..9,A..Z
      pMenu->nmenu = 0;
      pMenu->pIdm      = (WORD *) malloc (1000);
      pMenu->pGreyBits = (long *) malloc (1000);
      
      cret = par_GotoBlock (szMnu,0);	// Go to menu block..
      if (cret == FALSE) goto menu_error;
      hSubMenu [0] = CreateMenu ();
      mlevel = 0;	
      while (1) {
        cret = par_ReadStr (szStr,sizeof (szStr),NULL);
        if (cret == FALSE) goto menu_error;
        if (cret != TRUE) break;	// End of block.. menu ends ok..
        if (strcmp (szStr,"SUB") == 0) {	// SUB-MENU header..
          mlevel ++;	// Up one level..
	  if ((UINT) mlevel >= MENU_MAXSUB) goto menu_error;
	  cret = par_ReadStr (szSubMenu [mlevel],sizeof (szStr),NULL);
	  if (cret == FALSE) goto menu_error;
	  hSubMenu[mlevel] = CreatePopupMenu ();
        }  else if (strcmp (szStr,"END") == 0) {	// Attach last group to prev level..

  	  if ((UINT) mlevel >= MENU_MAXSUB) goto menu_error;
          if (hSubMenu [mlevel]) {		// Add prev menu to main..
	    AppendMenu (hSubMenu [mlevel - 1],MF_ENABLED | MF_POPUP, (UINT) hSubMenu [mlevel],szSubMenu[mlevel]);
	  }
	  if (mlevel < 1) break;	// All done..
          mlevel --;	// Up one level..
        }  else if (strcmp (szStr,"SEP") == 0) {	// Seperator
  	  AppendMenu (hSubMenu [mlevel],MF_SEPARATOR,0,"");
        } else {
          long cidm,cgrey;
        
	  if ((UINT) mlevel >= MENU_MAXSUB) goto menu_error;
          cidm = str_2val (szStr,10,4,NULL);
          if (cidm < 1) goto menu_error;
       	  cret = par_ReadStr (szStr,sizeof (szStr),NULL);
	  if (cret != TRUE) goto menu_error;
          cgrey = str_2val (szStr,2,15,NULL);
          pMenu->pGreyBits[pMenu->nmenu] = cgrey;
          pMenu->pIdm[pMenu->nmenu] = (WORD) cidm;
          pMenu->nmenu ++;
	  cret = par_ReadStr (szStr,sizeof (szStr),NULL);
	  if (cret != TRUE) goto menu_error;
	  AppendMenu (hSubMenu [mlevel],MF_STRING,(UINT) cidm,szStr);
        }
      }
      pMenu->hMenu = hSubMenu [0];	// Attach lowest level to id..
    }
    par_Close ();
    
    return TRUE;		// OK, no error

menu_error:			// Menu load error
    par_Close ();
    menu_Close (pMenuFirst);
    return FALSE;
}

void menu_Close (MENU_INFO *pMenuFirst)
{
    int cMI;
    for (cMI = 0; cMI < pMenuFirst->nMI; cMI ++) {
      MENU_INFO *pMenu = &pMenuFirst [cMI];
      if (pMenu->hMenu) {		// Kill any old one
        DestroyMenu (pMenu->hMenu);
        pMenu->hMenu = NULL;
      }
      if (pMenu->pGreyBits) {
        free (pMenu->pGreyBits);
        pMenu->pGreyBits = NULL;
      }
      if (pMenu->pIdm) {
        free (pMenu->pIdm);
        pMenu->pIdm = NULL;
      }
      memset (pMenu,0,sizeof(MENU_INFO));
    }
}

void menu_Set1Tick (MENU_INFO *pMenuFirst, short menuitem, short cstatus)	// Update 1 menu item
{
    int cMI;

    for (cMI = 0; cMI < pMenuFirst->nMI; cMI ++) {
      MENU_INFO *pMenu = &pMenuFirst [cMI];
      if (cstatus) {
        CheckMenuItem (pMenu->hMenu,menuitem,MF_BYCOMMAND | MF_CHECKED);
      } else {
        CheckMenuItem (pMenu->hMenu,menuitem,MF_BYCOMMAND | MF_UNCHECKED);
      }
    }
}

   // Read a string from the menu, filter out unwanted chars..
   // Ret len & String in (szStr)
char * menu_GetString (MENU_INFO *pMenuFirst, int menuid)
{
    int cpos,dpos,clen;
    static char szStr [128];
    int cMI;

    for (cMI = 0; cMI < pMenuFirst->nMI; cMI ++) {
      MENU_INFO *pMenu = &pMenuFirst [cMI];
      clen = GetMenuString (pMenu->hMenu, menuid, szStr, sizeof(szStr),MF_BYCOMMAND);
      if (clen) goto foundit;
    }
    return "";	// None found.

foundit:
	// Filter out unwanted chars..
    dpos = 0;
    for (cpos = 0; cpos < clen; cpos ++) {
      if (szStr [cpos] == '&') continue;
      if ((BYTE) szStr [cpos] < 32) {
        szStr [dpos] = 32;
      } else {
        szStr [dpos] = szStr [cpos];
      }
      dpos ++;
    }
    szStr [dpos] = 0;
    return (szStr);
}

  // Set menu graying according to status bits..
void menu_Greying (MENU_INFO *pMenuFirst, long curGreyBits)
{
    short cmenu;
    int cMI;
    int cgrey;
    int cstat;

    for (cMI = 0; cMI < pMenuFirst->nMI; cMI ++) {
      MENU_INFO *pMenu = &pMenuFirst [cMI];
    	// Ok, scan menu data, graying/ungraying items..    
      for (cmenu = 0; cmenu < pMenu->nmenu; cmenu ++ ) {
        cgrey = pMenu->pGreyBits [cmenu];
        cstat = MF_ENABLED;
	if (cgrey & curGreyBits) {   // Should it be disabled?
	  cstat = MF_DISABLED | MF_GRAYED;	// Grey..
	}
        EnableMenuItem (pMenu->hMenu, pMenu->pIdm [cmenu], MF_BYCOMMAND | cstat);
      }
    } 
}
  
  // Find greying bits for given IDM code..
  //  ret -1 if not found..
long menu_GetGreyBits (MENU_INFO *pMenuFirst, long cidm)
{
    short cmenu;
    int cMI;

    for (cMI = 0; cMI < pMenuFirst->nMI; cMI ++) {
      MENU_INFO *pMenu = &pMenuFirst [cMI];
    	// Ok, scan menu data for idm code
      for (cmenu = 0; cmenu < pMenu->nmenu; cmenu ++ ) {
        if (pMenu->pIdm [cmenu] == cidm) {  // FOUND IT..
          return pMenu->pGreyBits [cmenu];
	}
      }
    }
    return MENU_NOT_FOUND;
}

//---------------------------------------------------------------
// MODULE: lang_ LANGUAGE strings allocation routines..
//---------------------------------------------------------------

static char *lang_pMem = NULL;	// Ptr to language memory..
char lang_szError [128];	// Error code..

  // Load in language file..
  // IN: filename, Ptr to strings array, max# lang str
  // RET:TRUE/FALSE.

int lang_Init (char *szParFile, char **szLang, int nLang)
{
    long cLang;
    char *pStr = NULL;
    void *pret;
    int cret;
    long lsize;
    memset (lang_szError,0,sizeof(lang_szError));
    for (cLang = 0; cLang < nLang; cLang ++) {	// Wipe all strings..
      szLang [cLang] = "";
    }
    if (lang_pMem) free (lang_pMem);	// Release old string space..
    lsize = file_Length (szParFile);
    if (lsize < 0) return FALSE;
    lsize += lsize / 3;
    lang_pMem = (char *) malloc (lsize);
    if (lang_pMem == NULL) goto lang_error;
    pret = par_Open (szParFile);
    if (pret == NULL) goto lang_error;	// error opening file..
    cret = par_GotoBlock ("TEXT",0);	// Go to TEXT block..
    if (cret == FALSE) goto lang_error;
    pStr = lang_pMem;
    cLang = 0;
    while (1) {
      long clen;
      szLang [cLang] = pStr;
      cret = par_ReadStr (pStr,2048,&clen);
      if (cret == FALSE) goto lang_error;
      if (cret != TRUE) break;	// End of block.. menu ends ok..
      pStr += clen ;
      cLang ++;
      if (cLang >= nLang || (long) (pStr - lang_pMem) + 2048 > lsize) goto lang_error;
    }
    par_Close ();	
    return TRUE;	// Ok, loaded..

lang_error:			// Menu load error
    if (pStr) {		// Save error info..
      int cpos;
      char *szErr = pStr - (sizeof (lang_szError)/2);
      if (lang_pMem > szErr) szErr = lang_pMem;
      for (cpos = 0; cpos < sizeof (lang_szError) - 3; cpos ++) {
        char cchr;
	cchr = *szErr;
	if (cchr < 32) cchr = '.';
        if (szErr == pStr) {
	  memcpy (lang_szError + cpos,">ERROR<",7);
	  cpos += 7;
	}
        lang_szError [cpos] = cchr;
	szErr ++;
      }
      lang_szError [cpos] = 0;   // NULL term
    }
    if (*lang_pMem) {		// Kill any old one
      lang_pMem = NULL;
    }
    par_Close ();
    return FALSE;
}


//---------------------------------------------------------------
// MODULE:tool_ Toolbar support routines..
//---------------------------------------------------------------
//  instead of CreateToolbarEx..

static TOOL_DATA tool_dat;	// Contains tool_ once-off data..

LRESULT CALLBACK tool_WndProc (HWND, UINT, WPARAM, LPARAM);  // Toolbar servicing..
LRESULT CALLBACK tool_tipWndProc (HWND, UINT, WPARAM, LPARAM);  // Tooltip servicing..

VOID CALLBACK tool_TimerProc(HWND, UINT, UINT, DWORD); 
void tool_tipKillOld ();
void tool_tipService ();
void tool_int_Close (TOOL_BAR *);

  // Global initialisation, called once..
  //  also sets up prog instance, ptr to default palette & bmp..
void tool_Reset (HINSTANCE hInstance, HPALETTE *hPal, HDC *hBmpDC)
{
    WNDCLASS wndclass;           // window class structure
    memset ((void *) &tool_dat, 0, sizeof (TOOL_DATA));
    tool_dat.hFont = (HFONT) GetStockObject (SYSTEM_FONT);

    tool_dat.vdu.x = wio_DesktopInfo (HORZRES);	// Get screen width
    tool_dat.vdu.y = wio_DesktopInfo (VERTRES);	// Get screen height
	// Colors of background/lowlite (note-if changed, must be in palette)
    tool_dat.colBack = RGB (192,192,192);
    tool_dat.colLow =  RGB (128,128,128);
    tool_dat.hBrushBack = (HBRUSH) GetStockObject (LTGRAY_BRUSH);
    tool_dat.hPenBack = CreatePen (PS_SOLID,1,tool_dat.colBack);
    tool_dat.hPenLow = CreatePen (PS_SOLID,1,tool_dat.colLow);
	// Initialise a timer..
    tool_dat.timerid = SetTimer (NULL,0,400,&tool_TimerProc);
    	// Init ptrs to default BMPDC/Palette..
    tool_dat.hPal = hPal;
    tool_dat.hBmpDC = hBmpDC;
    
	// Register the toolbar class.
    tool_dat.szClass = "TOOLCLASS9";	// Name of default class..
    wndclass.style         = CS_HREDRAW | CS_VREDRAW;  // style
    wndclass.lpfnWndProc   = (WNDPROC) tool_WndProc; // WndProc address
    wndclass.cbClsExtra    = 0;            // no extra class data
    wndclass.cbWndExtra    = 0;            // no extra window data
    wndclass.hInstance     = hInstance;    // which program?
    wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);// stock arrow cursor
    wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION); // stock blank icon
    wndclass.lpszMenuName  = NULL;   // menu name
    wndclass.hbrBackground = (HBRUSH) GetStockObject(NULL_BRUSH);
    wndclass.lpszClassName = tool_dat.szClass;   // window class name
    RegisterClass(&wndclass); // register the class

		// Now create/register tool-tip class
    //tool_dat.szTipClass = "TOOLCLASS8";	// Name of default class..
    //wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_SAVEBITS;  // style
    //wndclass.lpszClassName = tool_dat.szTipClass;   // window class name
    //wndclass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
    //wndclass.lpfnWndProc   = (WNDPROC) tool_tipWndProc; // WndProc address
    //RegisterClass(&wndclass); // register the class
}

  // Global uninstall, call once
void tool_Kill ()
{
    DeleteObject (tool_dat.hBrushBack);
    DeleteObject (tool_dat.hPenBack);
    DeleteObject (tool_dat.hPenLow);
    KillTimer (NULL,tool_dat.timerid);
}

  // Create a new toolbar..
BOOL tool_Create (TOOL_BAR *pTool)
{
    RECT rPar;		// Parent client area size..
    DWORD cStyle;
    MYPOINT wlen;	// Window len..
    MYPOINT wtop;	// Window top pos..
    if (tool_dat.nTbars >= TOOL_BAR_MAX) return FALSE;
    if (pTool->hWndMsg == NULL) pTool->hWndMsg = pTool->hParent;
      // Add toolbar to end of list
    tool_dat.pTbars [tool_dat.nTbars] = pTool;
    tool_dat.nTbars ++;
    if (pTool->nTbut == 0 && pTool->pTbut) {
      int cbut = 0;
      while (pTool->pTbut[cbut].fsStyle != TOOL_STY_END) {
        cbut ++;
      }
      pTool->nTbut = cbut;
    }
      // Get parent window size
    GetClientRect (pTool->hParent, &rPar);
    if (pTool->sepsize == 0) {	// Default sep size == 1/3 button size..
      pTool->sepsize = pTool->but.x / 3;
    }
    if (pTool->tlen.x == 0) {	// Auto-calc window size
      long csize;
      csize = tool_FindPos (pTool,0,0,2);
      pTool->tlen.x = LOWORD (csize);
      pTool->tlen.y = HIWORD (csize);
      if (pTool->tooltype & TOOL_TYPE_RESIZE) {	// Resize to parent width?
        pTool->tlen.x = (short) rPar.right;
      }
      //pTool->tlen.y = pTool->but.y + pTool->border * 2;
    }
    wlen = pTool->tlen;
    wtop = pTool->ttop;
    if (pTool->tooltype & TOOL_TYPE_FLOAT) {	// Floating window..
      #if _WIN32		// Windows 95..
        wlen.x += GetSystemMetrics (SM_CXEDGE) * 2 + GetSystemMetrics (SM_CXBORDER);
        wlen.y += GetSystemMetrics (SM_CYCAPTION) + GetSystemMetrics (SM_CYEDGE) * 2 + GetSystemMetrics (SM_CYBORDER);
      #else
        wlen.x += GetSystemMetrics (SM_CXBORDER) * 2;
        wlen.y += GetSystemMetrics (SM_CYCAPTION) + GetSystemMetrics (SM_CYBORDER);
      #endif
      if (pTool->tooltype & TOOL_TYPE_CHILD) {	// Child window?
        cStyle = WS_VISIBLE | WS_BORDER | WS_CAPTION | WS_SYSMENU 
        	| WS_CHILD | WS_CLIPSIBLINGS;
      } else {
        POINT relpos = {0,0};
        cStyle = WS_VISIBLE | WS_BORDER | WS_CAPTION | WS_SYSMENU 
        	| WS_OVERLAPPED; //| WS_THICKFRAME;
	ClientToScreen (pTool->hParent, &relpos);
	wtop.x += (short) relpos.x;
	wtop.y += (short) relpos.y;
      }
    } else {
      cStyle = WS_CHILD /*| WS_BORDER*/ | WS_VISIBLE;
    }
    pTool->hWnd = CreateWindow(		// Create toolbar main win
        tool_dat.szClass,	// window class name
	pTool->szTitle,		// caption
	cStyle,			// style
	wtop.x,wtop.y, 		// Top x,y
	wlen.x,wlen.y, 		// Size x,y
	pTool->hParent,		// parent's handle
	NULL,			// menu handle
	GetInstance (pTool->hParent),  // which program?
	NULL
    );
    ShowWindow (pTool->hWnd, SW_SHOWNORMAL);      // make window visible
    SetFocus (pTool->hWnd);
    return TRUE;	// Toolbar created ok!
}

  // Close a toolbar
void tool_Close (TOOL_BAR *pTool)
{
    if (pTool->hWnd) {
      DestroyWindow (pTool->hWnd);
    } else {
      tool_int_Close (pTool);		// Internal version - clean up..
    }
}

void tool_int_Close (TOOL_BAR *pTool)
{
    int cbar;
    pTool->hWnd = NULL;
    	// Find this toolbar in list..
    for (cbar = 0; cbar < tool_dat.nTbars; cbar ++) {
      if (pTool == tool_dat.pTbars [cbar]) {
        goto found;
      }
    }
    return;	// No match found..
found:		// Delete 1, Move all others up one to fill gap..
    while (cbar < tool_dat.nTbars) {
      tool_dat.pTbars [cbar] = tool_dat.pTbars [cbar + 1];
      cbar ++;
    }
    tool_dat.pTbars [cbar] = NULL;
    tool_dat.nTbars --;
}

  // Redraw all active toolbars.. (Use after palette change, bmp reload, etc)
void tool_RedrawAll ()
{
    int cbar;
    for (cbar = 0; cbar < tool_dat.nTbars; cbar ++) {
      InvalidateRect (tool_dat.pTbars[cbar]->hWnd,NULL,TRUE);
    }
}

#define TOOL_DRAWONE 0x8000	// Redraw just 1 item

  // For given Button, get full info (xy pos in bmp)
static void tool_GetButtonItem (TOOL_BAR *pTool, int iBut, TOOL_ITEMS *pItem)
{
    int cindex = (int) pTool->pTbut [iBut].iIndex;
    	// No data defined? generate default..
    if (pTool->pItems == NULL || cindex >= pTool->nItems) {
      pItem->pStr = NULL;
      pItem->topy = pTool->autopos.y;
      pItem->topx = cindex * pTool->bmp.x + pTool->autopos.x;
      return;
    }
    //memcpy ((void *) pItem, (void *) &pTool->pItems [cindex],sizeof (TOOL_ITEMS));	// Copy over index entry..
    *pItem = pTool->pItems [cindex];	// Copy over index entry..
}

  // Find position of:-
  //  if (mode=0) of Active Button corrosponding to mouse click..
  //     ret 0..n-1, or -1 for no button found..
  // if (mode=1) find position of Button index in xpos, 
  //   ret LOWORD = x, HIWORD = y..
  // if (mode=2) calc total size of button group..
long tool_FindPos (TOOL_BAR *pTool, int xpos, int ypos, short mode)
{
    TOOL_ITEMS tItem;
    TOOL_BUTTON *pBut;
    int outx,outy;
    int cBut;		// Start button #..
    int eBut;
    cBut = 0;
    outx = pTool->tborder; 
    outy = pTool->tborder; //(pTool->tlen.y - pTool->but.y + 1)/2;
    eBut = pTool->nTbut;
    if (mode == 1) eBut = min (eBut, xpos);	// Find pos of individual button..
    while (cBut < eBut) {
      tool_GetButtonItem (pTool, cBut, &tItem);  // Get full data on cur button..
      pBut = &pTool->pTbut [cBut];
      if (pBut->fsStyle == TOOL_STY_SEP) {
        outx += pTool->sepsize;
      } else if (pBut->fsStyle == TOOL_STY_WRAP) {	// New line..
        outx = pTool->tborder;
        outy += pTool->but.y;
      } else {
        switch (pBut->fsState) {
	  case TOOL_IS_PRESSED:		// Depressed button
	  case TOOL_IS_NORMAL:		// Normal button
	    if (mode == 0) {
	      if ((UINT) (xpos - outx) < (UINT) pTool->but.x) {
	        if ((UINT) (ypos - outy) < (UINT) pTool->but.y) {
	          return cBut;	// Found mouse-hit button..
	        }
	      }
	    }
            outx += pTool->but.x;
	    break;
        }
      }
      cBut ++;
    }
    if (mode == 1) {	// Return pos of individual button..
      return (MAKELONG (outx,outy));
    }               	
    if (mode == 2) {	// Return computed size of WHOLE button group..
      outx += pTool->tborder;
      outy += pTool->but.y + pTool->tborder;
      return (MAKELONG (outx,outy));
    }
    return -1;	// no button found..
}

void tool_Resize (TOOL_BAR *pTool, int tx, int ty, int lx) 
{
    pTool->ttop.x = tx; pTool->ttop.y = ty;
    pTool->tlen.x = lx; 
    SetWindowPos (pTool->hWnd,NULL,pTool->ttop.x,pTool->ttop.y,pTool->tlen.x,pTool->tlen.y,SWP_NOZORDER | SWP_NOCOPYBITS);
}

  // Redraw toolbar buttons.
  // hDC = NULL for get own one & palette for win..
  // iBut = item to redraw (TOOL_DRAWONE = just draw 1 button)
static void tool_Redraw (TOOL_BAR *pTool, HDC hIDC, int iBut)
{
    TOOL_ITEMS tItem;
    TOOL_BUTTON *pBut;
    int outx,outy;
    int offx,offy;	// x/y offset for bmp draw
    int cBut;		// Start button #..
    HDC hDC = hIDC;		// Working HDC
    HPEN hPenGray,hPenLtGray,hPenWht,hPenBlk,hPenNull;
    HBRUSH hLtGrayBrush = (HBRUSH) GetStockObject (LTGRAY_BRUSH);
    cBut = 0;
    hPenGray = CreatePen (PS_SOLID,1,RGB (128,128,128));
    hPenLtGray = CreatePen (PS_SOLID,1,RGB (192,192,192));
    hPenWht = (HPEN) GetStockObject (WHITE_PEN);
    hPenBlk = (HPEN) GetStockObject (BLACK_PEN);
    hPenNull = (HPEN) GetStockObject (NULL_PEN);

    if (hIDC == NULL) {
      hDC = GetDC (pTool->hWnd);
      if (TOOL_HPAL(pTool)) {
	SelectPalette (hDC, *TOOL_HPAL(pTool), TRUE);	// get palette for window
	RealizePalette (hDC);		// Refresh palette.. 
      }
    }
    //BitBlt (hDC, 0,0,640,40,pTool->hBmpDC,0,0,SRCCOPY);
    outx = pTool->tborder; 
    outy = pTool->tborder; //(pTool->tlen.y - pTool->but.y + 1)/2;
    offx = (pTool->but.x - pTool->bmp.x - 1)/2;	// BMP Centering offsets..
    offy = (pTool->but.y - pTool->bmp.y)/2;
    while (cBut < pTool->nTbut) {
      tool_GetButtonItem (pTool, cBut, &tItem);  // Get full data on cur button..
      pBut = &pTool->pTbut [cBut];
      if (pBut->fsStyle == TOOL_STY_SEP) {
        outx += pTool->sepsize;
      } else if (pBut->fsStyle == TOOL_STY_WRAP) {	// New line..
        outx = pTool->tborder;
        outy += pTool->but.y;
      } else {
	SelectObject (hDC,hLtGrayBrush);
	SelectObject (hDC,hPenNull);
        switch (pBut->fsState) {
	  case TOOL_IS_PRESSED:		// Depressed button
	    Rectangle (hDC, outx,outy,outx+pTool->but.x,outy + pTool->but.y);
	    BitBlt (hDC, 
		outx+offx+1,outy+offy+1,
		pTool->bmp.x,pTool->bmp.y,
		*TOOL_HBMPDC(pTool),
		tItem.topx,tItem.topy,
		SRCCOPY);
	    wio_Box3d (hDC, hPenWht, hPenBlk, outx,outy,pTool->but.x,pTool->but.y,0,0);
	    wio_Box3d (hDC, hPenLtGray, hPenGray, outx,outy,pTool->but.x,pTool->but.y,-1,0);
            outx += pTool->but.x;
	    break;

	  case TOOL_IS_NORMAL:		// Normal button
	    Rectangle (hDC, outx,outy,outx+pTool->but.x,outy + pTool->but.y);
	    BitBlt (hDC, 
		outx+offx,outy+offy,
		pTool->bmp.x,pTool->bmp.y,
		*TOOL_HBMPDC(pTool),
		tItem.topx,tItem.topy,
		SRCCOPY);
	    wio_Box3d (hDC, hPenBlk, hPenWht, outx,outy,pTool->but.x,pTool->but.y,0,0);
	    wio_Box3d (hDC, hPenGray, hPenLtGray, outx,outy,pTool->but.x,pTool->but.y,-1,0);
            outx += pTool->but.x;
	    break;
        }
      }
      if (iBut & TOOL_DRAWONE) break;	// Just draw one item..
      cBut ++;
    }
    SelectObject (hDC, hPenWht);
    if (hIDC == NULL) {
      ReleaseDC (pTool->hWnd,hDC);
    }
    DeleteObject (hPenGray);
    DeleteObject (hPenLtGray);
}

  // Find given toolbar from supplied window handle..
static TOOL_BAR * tool_GetWndToolbar (HWND hWnd)
{
    int cbar;
    for (cbar = 0; cbar < tool_dat.nTbars; cbar ++) {
      if (hWnd == tool_dat.pTbars [cbar]->hWnd) {
        return tool_dat.pTbars [cbar];		// Found it!
      }
    }
    return NULL;	// Cannot find toolbar..
}

  // Kill last toolbar key pressed.
void tool_PressKill ()
{
    TOOL_BAR *pTool;
    pTool = tool_dat.pPressedBar;
    if (pTool == NULL) return;	// None pressed..
    pTool->pTbut [tool_dat.PressedBut].fsState = TOOL_IS_NORMAL;
    tool_dat.pPressedBar = NULL;		// Clr status flag..
    tool_Redraw (pTool, NULL, 0);	 // Redraw all toolbar items..
    ReleaseCapture ();
}

void tool_ButtonProcess (UINT wMsg, TOOL_BAR *pTool, int xpos, int ypos)
{ 
    int cBut;
    cBut = (int) tool_FindPos (pTool, xpos, ypos,0);
    if (wMsg == WM_LBUTTONDOWN || wMsg == WM_RBUTTONDOWN) { // Click on toolbar?
      if (cBut >= 0) {	// Activate button..
        tool_PressKill ();	// Kill prev button..
        pTool->pTbut [cBut].fsState = TOOL_IS_PRESSED;
        tool_dat.pPressedBar = pTool;
	tool_dat.PressedBut = cBut;
	tool_dat.rmouse = (wMsg == WM_RBUTTONDOWN);
        tool_Redraw (pTool, NULL, 0);  // Redraw all toolbar items..
        tool_dat.PressedRepeat = 0;
	SetCapture (pTool->hWnd);	// Toolbar to take all mouse hits..
      }
    }
    if (cBut < 0) {		// No legal button
      tool_PressKill ();	// Kill prev button..
      return;
    }
    if (tool_dat.pPressedBar == NULL) {	// No button pressed, do nothing
      return;
    } 
    if (cBut != tool_dat.PressedBut || pTool != tool_dat.pPressedBar) {
      tool_PressKill ();	// Wrong button..
      return;
    }
    if (wMsg == WM_LBUTTONUP || wMsg == WM_RBUTTONUP) {	// Release button?
      if (pTool->pTbut [cBut].fsState == TOOL_IS_PRESSED) {
        TOOL_BUTTONHIT ccmd;
        ccmd.idCommand = pTool->pTbut [cBut].idCommand;
        ccmd.nrep   = tool_dat.PressedRepeat;
        ccmd.rmouse = tool_dat.rmouse;
        if (ccmd.nrep < 1) ccmd.nrep = 1;
        tool_PressKill ();	// Kill button..
        //pTool->pTbut [cBut].fsState = TOOL_IS_NORMAL;
        //tool_Redraw (pTool, NULL, 0);  // Redraw all toolbar items..
        	// SEND COMMAND BACK TO FRONT END..
        if (pTool->pfnServiceTool) {	// Call service procedure..
          (pTool->pfnServiceTool) (TOOLSERV_WM_COMMAND,(void *) &ccmd);
        } else {
          PostMessage (pTool->hWndMsg, WM_COMMAND,(WPARAM) ccmd.idCommand,0L);
        }
      }
    }
}

   // Called by timer routine, service any button-repeats..
void tool_ServiceRepeat ()
{
    TOOL_BUTTONHIT ccmd;
    TOOL_BAR *pTool = tool_dat.pPressedBar;
    if ((pTool->tooltype & TOOL_TYPE_REPEAT) == 0) return;  // No repest mode
    tool_dat.PressedRepeat ++;
    ccmd.idCommand = pTool->pTbut [tool_dat.PressedBut].idCommand;
    ccmd.nrep   = tool_dat.PressedRepeat;
    ccmd.rmouse = tool_dat.rmouse;
    if (tool_dat.PressedRepeat < 2) return;	// 1st repeat, no repeat messages..
        	// SEND COMMAND BACK TO FRONT END..
    if (pTool->pfnServiceTool) {	// Call service procedure..
      (pTool->pfnServiceTool) (TOOLSERV_WM_COMMAND,(void *) &ccmd);
    } else {
      PostMessage (pTool->hWndMsg, WM_COMMAND,(WPARAM) ccmd.idCommand,0L);
    }
}

  // Service toolbar actions..
LRESULT CALLBACK tool_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    TOOL_BAR *pTool;
    switch (wMsg) {	// Reject messages we dont handle first
      case WM_GETMINMAXINFO: { 	// Set minimize window size..
	MINMAXINFO *lpmmi;	// ptr to min/max info structure, for minimize..
        lpmmi = (MINMAXINFO FAR *) lParam;
        lpmmi->ptMinTrackSize.x = 10;// Never smaller than this..
        lpmmi->ptMinTrackSize.y = 20;
	return 0L;
      }
      case WM_KEYDOWN:		// These messages simply sent to Parent..
      case WM_CHAR:
      case WM_PALETTECHANGED:	// All the messages we handle..
      case WM_QUERYNEWPALETTE:
      case WM_PAINT:
      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:	
      case WM_LBUTTONUP:	
      case WM_RBUTTONDOWN:	// Click on toolbar?
      case WM_RBUTTONUP:	// Release click on toolbar?
      case WM_DESTROY: 
      case WM_SIZE:
        break;

      default:                      // Rest handled by DefWindowProc
	return( DefWindowProc(hWnd, wMsg, wParam, lParam) );
    }
    
      // OK, now scan for (hWnd) to find what toolbar we are serving..
    pTool = tool_GetWndToolbar (hWnd);
    if (pTool == NULL) return 0;	// Cannot find it!

    switch(wMsg) {                      // which message?
      
      //case WM_KEYDOWN:		// These messages simply sent to Parent..
      case WM_CHAR:
        PostMessage (pTool->hParent, wMsg, wParam, lParam);
        break;

      case WM_PALETTECHANGED:
      case WM_QUERYNEWPALETTE:
	{ LRESULT lr;	// serve WM_PALETTECHANGED/WM_QUERYNEWPALETTE msgs
	  if (wio_PaletteServe (&lr,hWnd,wMsg,wParam,*TOOL_HPAL(pTool))) {
	    return lr;
	  }
	}
        break;

      case WM_PAINT:
        {
	 PAINTSTRUCT ps;
	 HDC hDC;
	 RECT crct;
	 tool_tipKillOld ();
	 GetClientRect (hWnd, &crct);
	 hDC = BeginPaint (hWnd,&ps);
	 if (TOOL_HPAL(pTool)) {
	   SelectPalette (hDC, *TOOL_HPAL(pTool), TRUE);  // get palette for window
 	   RealizePalette (hDC);		// Refresh palette.. 
	 }
	 if (pTool->tborder) {	// Is there a border to fill?
	   SelectObject (hDC,tool_dat.hBrushBack);
	   SelectObject (hDC,tool_dat.hPenLow);
	   Rectangle (hDC,0,0,crct.right,crct.bottom);
	   SelectObject (hDC,GetStockObject (WHITE_PEN));
	   MoveToEx (hDC, 0, 1,NULL);
	   LineTo (hDC, crct.right,1); 
	 }
	 tool_Redraw (pTool, hDC, 0);	 // Redraw all toolbar items..
	 EndPaint (hWnd,&ps);
	}
        return 0L;

      /*case WM_SIZE:	// Asertain parent window size, adjust accordingly..
        if (pTool->tooltype <= TOOL_BAR_FLOAT) {
	  RECT rparent;
	  GetClientRect (pTool->hParent, &rparent);
	  pTool->tlen.x = rparent.right;
	  SetWindowPos (hWnd,NULL,pTool->ttop.x,pTool->ttop.y,pTool->tlen.x,pTool->tlen.y,SWP_NOZORDER | SWP_NOCOPYBITS);
	}
	break;*/

      case WM_RBUTTONDOWN:	// Click on toolbar?
      case WM_RBUTTONDBLCLK:	// Click on toolbar?
      case WM_RBUTTONUP:	// Release click on toolbar?
        if ((pTool->tooltype & TOOL_TYPE_RMOUSE) == 0) break;
      case WM_LBUTTONDOWN:	// Click on toolbar?
      case WM_LBUTTONDBLCLK:	// Click on toolbar?
      case WM_LBUTTONUP:	// Release click on toolbar?
      case WM_MOUSEMOVE:	// Move mouse..
        tool_tipKillOld ();   // Kill any old tool-tip..
        tool_ButtonProcess (wMsg, pTool, (int) LOWORD(lParam), (int) HIWORD(lParam));
        //tool_tipService ();
        return 0L;

      case WM_DESTROY: {	// TOOLBAR closing, tidy up..
        if (pTool->pfnServiceTool) {	// Warn front-end..
          (pTool->pfnServiceTool) (TOOLSERV_CLOSING,(void *) &pTool);
        }
        tool_int_Close (pTool);	 // Internal close - remove TOOLBAR from stack, tidy up..
        break;
      }
    }   
    return( DefWindowProc(hWnd, wMsg, wParam, lParam) );
} 

  // Load toolbar info from parameter file..
BOOL tool_Load (TOOL_BAR *pTool, char *szParFile, char *szBlock, int maxbut)
{
    int cret;
    void *pret;
    char szStr [128];
    short *pPar = (short *) &szStr;
    int cbut;

    pret = par_Open (szParFile);
    if (pret == NULL) return FALSE;	// error opening file..
    cret = par_GotoBlock (szBlock,0);	// Go to menu block..
    if (cret == FALSE) goto tool_err;
    cret = par_ReadStr ((char *) pPar,20,NULL);
    if (cret == FALSE) goto tool_err;
   
    pTool->bmp.x = pPar[0];
    pTool->bmp.y = pPar[1];
    pTool->but.x = pPar[2];
    pTool->but.y = pPar[3];
    pTool->tborder = pPar[4];

    memset (pTool->pTbut,0,maxbut * sizeof (TOOL_BUTTON));
    for (cbut = 0; cbut < maxbut; cbut ++) {
      TOOL_BUTTON *pBut = &pTool->pTbut [cbut];
      long ctok;
      
      cret = par_ReadStr (szStr,sizeof (szStr),NULL);
      if (cret == FALSE) goto tool_err;
      ctok =  str_ParseToken ("BUT\0SEP\0CHK\0WRAP\0END\0\0", szStr);
      switch (LOWORD (ctok)) {
        case 1:
          pBut->fsStyle = TOOL_STY_BUTTON; 
          cret = par_ReadShort ((short *) &pBut->idCommand);
          if (cret == FALSE) goto tool_err;
          cret = par_ReadShort ((short *) &pBut->iIndex);
          if (cret == FALSE) goto tool_err;
	  break;
	case 2:
          pBut->fsStyle = TOOL_STY_SEP; break;
	case 3:
          pBut->fsStyle = TOOL_STY_CHECK; break;
	case 4:
          pBut->fsStyle = TOOL_STY_WRAP; break;
	case 5:
          pBut->fsStyle = TOOL_STY_END; break;
	default:
	  goto tool_err;
      }
      if (pBut->fsStyle == TOOL_STY_END) break;
    }
    par_Close ();
    return TRUE;

tool_err:
    par_Close ();
    return FALSE;
}


void tool_tipKillOld ()
{
    TOOL_TIPTEXT *pTip = &tool_dat.tip;
    HDC hDC;
    if (pTip->hMemDC) {
      hDC = GetDC (pTip->hWnd);
      if (hDC) {	// restore orig screen..
        BitBlt (hDC,pTip->itop.x,pTip->itop.y,pTip->ilen.x,pTip->ilen.y,pTip->hMemDC,0,0,SRCCOPY);
        ReleaseDC (pTip->hWnd,hDC);
      }
      DeleteDC (pTip->hMemDC);
      DeleteObject (pTip->hBitmap);
      memset ((void *) pTip,0,sizeof (TOOL_TIPTEXT));
    }
}
  
void tool_tipCreate ()
{
    TOOL_TIPTEXT *pTip = &tool_dat.tip;
    HDC hDC;
    int tlen = strlen (pTip->szText);
    SIZE tsize;

    hDC = GetDC (pTip->hWnd);
    if (hDC == NULL) return;
    SelectObject (hDC,(HBRUSH) GetStockObject (WHITE_BRUSH));
    SelectObject (hDC,(HPEN) GetStockObject (BLACK_PEN));
    SelectObject (hDC,(HFONT) GetStockObject (ANSI_VAR_FONT));
    if (pTip->ilen.x == 0) {	// Auto calc size/pos..
      GetTextExtentPoint32 (hDC,pTip->szText,tlen,&tsize);
      pTip->ilen.x = tsize.cx + 8;
      pTip->ilen.y = tsize.cy + 4;
	// Adjust so it doesnt go off edge..
      if (pTip->itop.x + pTip->ilen.x >= tool_dat.vdu.x - 10) {
        pTip->itop.x -= pTip->ilen.x;
      }
      pTip->itop.y += 20;
      if (pTip->itop.y + pTip->ilen.y >= tool_dat.vdu.y - 10) {
        pTip->itop.y -= (22 + pTip->ilen.y);
      }
    }
	// Create a DC/Bmp to save screen under pop-up text..
    pTip->hMemDC = CreateCompatibleDC (hDC);
    pTip->hBitmap = CreateCompatibleBitmap (hDC,pTip->ilen.x,pTip->ilen.y);
    SelectObject (pTip->hMemDC,pTip->hBitmap);
    BitBlt (pTip->hMemDC,0,0,pTip->ilen.x,pTip->ilen.y,hDC,pTip->itop.x,pTip->itop.y,SRCCOPY);
	// Ok, now draw pop-up window..
    Rectangle (hDC, pTip->itop.x, pTip->itop.y, pTip->itop.x + pTip->ilen.x, pTip->itop.y + pTip->ilen.y);
    TextOut (hDC,pTip->itop.x+4, pTip->itop.y+2, pTip->szText,tlen);
    ReleaseDC (pTip->hWnd,hDC);
}

  // Service tool-tips text..
void tool_tipService ()
{
    HWND hWnd;
    static POINT ptOld;
    POINT pt; 
    TOOL_BAR *pTool;
    int cBut;
    BOOL unmoved;
    TOOL_TIPTEXT *pTip = &tool_dat.tip;

    GetCursorPos(&pt);		// Get mouse pos abs desktop coords
    unmoved = ((pt.x == ptOld.x) && (pt.y == ptOld.y));	// Pos of mouse unchanged?
    ptOld = pt;		// Save last position.
    /*if (tool_dat.pPressedBar) {		// Button pressed.. kill old tip..
      tool_tipKillOld ();
      return;
    }*/
    if (unmoved == FALSE) {		// mouse moving..
      if (pTip->hMemDC) {		// Tip exists, kill it..
        tool_tipKillOld ();
      }
      return;
    }
    if (pTip->hMemDC) return;		// Tip already exists..

    hWnd = WindowFromPoint (pt);	// Find window underneath mouse
    pTool = tool_GetWndToolbar (hWnd);	// Find if its a toolbar window..
    if (pTool) {		// Yes..
      POINT wpt = pt;	// Point within window
      ScreenToClient (hWnd, &wpt);	// Find mouse pos in that window
      cBut = (int) tool_FindPos (pTool, wpt.x, wpt.y,0);	// See if above button..
      if (cBut >= 0) {	// Yes..
		// Same as last tip?
        if (pTool != pTip->pBar || cBut != pTip->iBut) {
          tool_tipKillOld ();   // Not same as prev tip, kill old one first..
	  pTip->pBar = pTool;
	  pTip->iBut = cBut;
	  pTip->idCommand = pTool->pTbut[cBut].idCommand;
		// Ask parent window to provide text string..
          if (pTool->pfnServiceTool) {	// Call service procedure..
            (pTool->pfnServiceTool) (TOOLSERV_NEEDTEXT,(void *) &tool_dat.tip);
          } else {
	    SendMessage (pTool->hWndMsg,TOOL_NEEDTEXT,(WPARAM) TOOL_NEEDTEXT,(LPARAM) &tool_dat.tip);
          }
	  if (pTip->szText[0] == 0) return;	// No text..
	  pTip->itop.x = (short) pt.x;	// Save mouse pos..
	  pTip->itop.y = (short) pt.y;
	  pTip->hWnd = NULL; //pTool->hParent;
	  //if (pTip->hWnd) {
          //  ScreenToClient (pTip->hWnd, &pt);	// Find mouse pos in that window
	  //}
	  tool_tipCreate ();
	}
	return;
      }
    } 
    tool_tipKillOld ();   // Kill old tip..
    
}

// Service timer for pop-up windows toolbar help tip..
  // Called every fract of a sec to service toolbar..
VOID CALLBACK tool_TimerProc( 
    HWND hwnd,        /* handle of window for timer messages */ 
    UINT message,     /* WM_TIMER message                    */ 
    UINT idTimer,     /* timer identifier                    */ 
    DWORD dwTime)     /* current system time                 */ 
{ 
    if ((UINT) tool_dat.nTbars >= (UINT) TOOL_BAR_MAX) return;
    tool_tipService ();
    if (tool_dat.pPressedBar) {
      tool_ServiceRepeat ();	// Service any button-repeats..
    }
}

#ifdef _WIN32

//---------------------------------------------------------------
// MODULE:rtf_ Rich Text Format display box contols..
//---------------------------------------------------------------

LRESULT CALLBACK rtf_WndProc (HWND, UINT, WPARAM, LPARAM);  // RTF servicing..

#define RTF_WIN_MAX 10

typedef struct {	// Once off static data..
  char *szClass;	// RTF Window class name
  int nRtf;		// no of RTF windows
  RTF_WIN *pRtf [RTF_WIN_MAX];  // Pointers to a list of RTF windows
  COLORREF colBack;	// Color of main backdrop (192)
  COLORREF colLow;	// Color of low-lite (128)
  HBRUSH hBrushBack;	// Brush for main background
  HPEN hPenBack;	// Pen for background
  HPEN hPenLow;		// Pen for lowlite..
} RTF_DATA;

static RTF_DATA rtf_dat;	// Once off static data..

  // Global initialisation, called once..
void rtf_Reset (HINSTANCE hInstance)
{
    WNDCLASS wndclass;           // window class structure
    memset ((void *) &rtf_dat, 0, sizeof (RTF_DATA));
	// Colors of background/lowlite (note-if changed, must be in palette)
    rtf_dat.colBack = RGB (255,255,255);// RGB (192,192,192);
    rtf_dat.colLow =  RGB (128,128,128);
    rtf_dat.hBrushBack = (HBRUSH) CreateSolidBrush (rtf_dat.colBack);
    //rtf_dat.hBrushBack = (HBRUSH) GetStockObject (LTGRAY_BRUSH);
    rtf_dat.hPenBack = CreatePen (PS_SOLID,1,rtf_dat.colBack);
    rtf_dat.hPenLow = CreatePen (PS_SOLID,1,rtf_dat.colLow);
	// Register the rich text class.
    rtf_dat.szClass = "RTFCLASS9";	// Name of default class..
    wndclass.style         = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;  // style
    wndclass.lpfnWndProc   = (WNDPROC) rtf_WndProc; // WndProc address
    wndclass.cbClsExtra    = 0;            // no extra class data
    wndclass.cbWndExtra    = 0;            // no extra window data
    wndclass.hInstance     = hInstance;    // which program?
    wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);// stock arrow cursor
    wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION); // stock blank icon
    wndclass.lpszMenuName  = NULL;   // menu name
    wndclass.hbrBackground = (HBRUSH) GetStockObject(NULL_BRUSH);
    wndclass.lpszClassName = rtf_dat.szClass;   // window class name
    RegisterClass(&wndclass); // register the class
}

BOOL rtf_WinCreate (RTF_WIN *pRtf)
{
    RECT rPar;		// Parent client area size..
    DWORD cStyle;
    if (rtf_dat.nRtf >= RTF_WIN_MAX) return FALSE;
      // Add WTF window to end of list
    rtf_dat.pRtf [rtf_dat.nRtf] = pRtf;
    rtf_dat.nRtf ++;
      // Set up window style
    cStyle = pRtf->dwStyle;
    if (cStyle == 0) {
      cStyle = WS_CHILD | WS_BORDER | WS_VISIBLE | WS_VSCROLL;
    }
      // Get parent window size
    GetClientRect (pRtf->hParent, &rPar);
    /*if (pRtf->lenx == 0) {	// Auto-calc win X size..
      pRtf->lenx = rPar.right;
    }
    if (pRtf->leny == 0) {	// Auto-calc win Y size..
      pRtf->leny = pRtf->buty + 9;
    }*/
    pRtf->hWnd = CreateWindow(		// Create RTF main win
        rtf_dat.szClass,	// window class name
	pRtf->szTitle,		// caption
	cStyle,			// style
	pRtf->topx,pRtf->topy, // Top x,y
	pRtf->lenx,pRtf->leny, // Size x,y
	pRtf->hParent,		// parent's handle
	NULL,			// menu handle
	GetInstance (pRtf->hParent),  // which program?
	NULL
    );
    if (pRtf->hWnd == NULL) return FALSE;
    ShowWindow (pRtf->hWnd, SW_SHOWNORMAL);      // make window visible
    SetFocus (pRtf->hWnd);
    return TRUE;	// RTF window created ok!
}


  // Close a RTF Window
void rtf_Close (RTF_WIN *pRtf)
{
    int crtf;
    DestroyWindow (pRtf->hWnd);
    pRtf->hWnd = NULL;
	// Move all resources up one..
    for (crtf = 0; crtf < rtf_dat.nRtf; crtf ++) {
      if (pRtf == rtf_dat.pRtf [crtf]) {
        goto found;
      }
    }
    return;
found:		// Delete 1, Move all others up one to fill gap..
    while (crtf < rtf_dat.nRtf) {
      rtf_dat.pRtf [crtf] = rtf_dat.pRtf [crtf + 1];
      crtf ++;
    }
    rtf_dat.pRtf [crtf] = NULL;
    rtf_dat.nRtf --;
}

  // Find given RTF WIN from supplied window handle..
static RTF_WIN * rtf_GetWndRtf (HWND hWnd)
{
    int crtf;
    for (crtf = 0; crtf < rtf_dat.nRtf; crtf ++) {
      if (hWnd == rtf_dat.pRtf [crtf]->hWnd) {
        return rtf_dat.pRtf [crtf];		// Found it!
      }
    }
    return NULL;	// Cannot find RTF Window..
}

void rtf_Resize (RTF_WIN *pRtf, int tx, int ty, int lx, int ly) 
{
    pRtf->topx = tx; pRtf->topy = ty;
    pRtf->lenx = lx; pRtf->leny = ly;
    SetWindowPos (pRtf->hWnd,NULL,pRtf->topx,pRtf->topy,pRtf->lenx,pRtf->leny,SWP_NOZORDER | SWP_NOCOPYBITS);
}

#define RTF_SCROLLMAX 1000L
#define RTF_SLACKPIXELS (pRtf->npixels - pRtf->rect.ly + pRtf->spcsize)


  // Select a new font (unless same as old one..
void rtf_SelectFont (RTF_WIN *pRtf, HDC hDC, int cflag)
{
    static HFONT hLast;
    HFONT hFont;
    int cfont = cflag & ~RTF_FORCE;
    if (cfont >= pRtf->nFonts) cfont = 0;	// Use first default if overruns max
    if (pRtf->phFont == NULL) {
      hFont = (HFONT) GetStockObject (ANSI_VAR_FONT);
    } else {
      hFont = pRtf->phFont [cfont];
    }
    if (hFont != hLast || (cflag & RTF_FORCE)) {
      SelectObject (hDC, hFont);	// Start with default font..
    }
    hLast = hFont;
}

void rtf_SelectColour (RTF_WIN *pRtf, HDC hDC, int icol)
{
    static COLORREF cLast;
    COLORREF ccol;
    if (pRtf->pColFonts == NULL) {
      ccol = RGB (0,0,0);
    } else {
      ccol = pRtf->pColFonts [icol & ~ RTF_FORCE];
    }
    if (ccol != cLast || (ccol & RTF_FORCE)) {
      SetTextColor (hDC, ccol);
    }
    cLast = ccol;
}

   // Draw prepared RTF text, 
   // mode = RTF_REDRAWALL, RTF_MOUSEHIT..
void rtf_DrawText (RTF_WIN *pRtf, HDC hDC, int mode)
{
    char *pTxt = pRtf->pTxt;
    char *pOldTxt = pTxt;
    int tline = 0;		// Count of tot lines.
    int clen;
    int liny = 0;	// Height of cur line
    int lastliny = 0;
    char szWord [160];	// Current word..
    SIZE csize;		// Current size of word/item
    SIZE cpos;		// Current absolute document pos of output..
    int outmode = 0;	// 0=above window,1=in window (PRINT),2=past window..

    pRtf->markPos = 0;	// Cursor mark found in print window?
    cpos.cx = cpos.cy = 0;	// Top of document..
    GetTextExtentPoint32 (hDC," ",1,&csize);
    pRtf->startpos = 0;
    pRtf->spcsize = csize.cy;	// Default char height
    while (*pTxt) {		// Until NULL teminator..
      pOldTxt = pTxt;
      if (*pTxt == '\\') {	// RTF control character
      }
      if ((BYTE) *pTxt < 9) {		// Fast-Select a new font/colour
	if (/*outmode == 1 &&*/ (mode & RTF_REDRAW)) {  // In window, print..
          rtf_SelectFont (pRtf, hDC, *pTxt - 1);
          rtf_SelectColour (pRtf, hDC, *pTxt - 1);
	}
	pTxt ++;
	continue;
      }
      if (*pTxt == CHR_MARK) {		// Cursor mark char in print window?
        pRtf->markPos = cpos.cy;
        if (outmode == 0) {
          pRtf->markPos |= RTF_MARK_BEFORE_WIN;
	}
        if (outmode == 1) {
          pRtf->markPos |= RTF_MARK_IN_WIN;	// Cursor was within window..
	}
        if (outmode == 2) {
          pRtf->markPos |= RTF_MARK_AFTER_WIN;
	}
	pTxt ++;
	continue;
      }

      if (*pTxt == 9) {		// Tab..
        SIZE siz;
        int tabsize;
        GetTextExtentPoint32 (hDC,"M",1,&siz);
	tabsize = (siz.cx * 6) - 3;
        csize.cx = tabsize - (cpos.cx % tabsize) - 1;
        pTxt ++;
	clen = 0;
        if (cpos.cx + csize.cx >= pRtf->rect.lx) {   // Word wraps, next line..
          csize.cy = csize.cx = 0;	// No word, no len..
	  goto newline;
	}
	goto tabloop;
      }
      if (*pTxt == 10) {	// Line feed (\n)
        pTxt ++;
        clen = 0;
        csize.cy = csize.cx = 0;	// No word, no len..
        goto newline;
      }
	// Scan a word..
      clen = 0;
      while ((BYTE) *pTxt > 32) {
	szWord [clen] = *pTxt;
	clen ++; pTxt ++;
	if (clen >= sizeof (szWord)-3) break;
      }
      //if (*pTxt == 32) {	// Skip & add sep if space..
        szWord [clen] = 32; clen ++; pTxt ++;
      //}
longwordloop:
      GetTextExtentPoint32 (hDC,szWord,clen,&csize);
tabloop:
      if (cpos.cx + csize.cx >= pRtf->rect.lx) {   // Word wraps, next line..
        SIZE siz;
	if (csize.cx >= pRtf->rect.lx && clen > 1) {	// Word too long for line!!
          pTxt = pOldTxt + 1;
	  clen = 1;
	  goto longwordloop;	// Try 1 char at a time..
	}
newline:
        tline ++;
	cpos.cx = 0; cpos.cy += liny;
	lastliny = liny;
	if (pRtf->linefwd == -1) pRtf->linefwd = liny;
        GetTextExtentPoint32 (hDC," ",1,&siz);
	liny = siz.cy;	// New line must be at least height of space..
      }
      if (csize.cy > liny) liny = csize.cy;	// Max height
      if (outmode < 2) {	// Not past end of view-window..
        if (outmode == 0 && cpos.cy >= pRtf->startpixel) {
	  outmode = 1;		// Reached view window, start print..
	  pRtf->startpos = cpos.cy;
	  pRtf->startline = tline;
	  pRtf->lineback = lastliny;
	  pRtf->linefwd = -1;
        }
	if (outmode == 1 && (cpos.cy - pRtf->startpos >= pRtf->rect.ly)) {
	  outmode = 2;		// Past end of view window..
	  pRtf->endpos = cpos.cy;
	  pRtf->endline = tline;
	}
	if (outmode == 1) {	// In view-port of window..
	  if (mode & RTF_REDRAW) {	// In print mode?
	    TextOut (hDC, pRtf->rect.tx + cpos.cx, 
		pRtf->rect.ty + cpos.cy - pRtf->startpos, szWord, clen);
	  }
	  if ((mode & RTF_MOUSEHIT) && pRtf->mouse_charpos < 0) {	// Found mouse-hit position?
	    if ((UINT) pRtf->mousehit.x - cpos.cx < (UINT) csize.cx &&
		(UINT) pRtf->mousehit.y - (cpos.cy - pRtf->startpos) < (UINT) csize.cy) {
	      pRtf->mouse_charpos = (long) (pOldTxt - pRtf->pTxt);
	    }
	  }
	}
      }		//RTF_WIN
      cpos.cx += csize.cx;
    }
    pRtf->nlines = tline;
    pRtf->npixels = cpos.cy;
}

  // Fill RTF win with background colour
void rtf_DrawBackground (RTF_WIN *pRtf, HDC hDC, RECT rct)
{
    SelectObject (hDC,rtf_dat.hBrushBack);
    SelectObject (hDC,rtf_dat.hPenLow);
    Rectangle (hDC,0,0,rct.right,rct.bottom);
    SelectObject (hDC,GetStockObject (WHITE_PEN));
    MoveToEx (hDC, 0, 1,NULL);
    LineTo (hDC, rct.right,1); 
}

  // dmode = RTF_MOUSEHIT, RTF_REDRAWALL..
void rtf_Draw (RTF_WIN *pRtf, HDC hIDC, int dmode)
{
    HDC hDC = hIDC;
    RECT rct;
    const int marg = 4;
    if (hIDC == NULL) {
      hDC = GetDC (pRtf->hWnd);
    }
    if (dmode & RTF_REDRAW) {
      if (pRtf->hPal) {
	SelectPalette (hDC, pRtf->hPal, TRUE);	// get palette for window
	RealizePalette (hDC);		// Refresh palette.. 
      }
    }
	// Calc target area..
    GetClientRect (pRtf->hWnd, &rct);
    if (dmode & RTF_REDRAWALL) {
      rtf_DrawBackground (pRtf, hDC, rct);
    }
    pRtf->rect.tx = (short) rct.left;
    pRtf->rect.ty = (short) rct.top;
    pRtf->rect.lx = (short) (rct.right - rct.left);
    pRtf->rect.ly = (short) (rct.bottom - rct.top);
    pRtf->rect.tx += marg; pRtf->rect.ty += marg; 
    pRtf->rect.lx -= 2 * marg; pRtf->rect.ly -= 2 * marg; 
    if (pRtf->rect.lx < 20 || pRtf->rect.ly < 20) return;		// Too small..
    rtf_SelectFont (pRtf, hDC,0 | RTF_FORCE);
    rtf_SelectColour (pRtf, hDC,0 | RTF_FORCE);

    //SetTextColor (hDC, pRtf->pColFont [0]);
    SetBkColor (hDC, COLORREF_PAL (rtf_dat.colBack));
    rtf_DrawText (pRtf, hDC, dmode);
       // Keep cursor in window?
    if ((dmode & RTF_KEEP_CUR) && !(pRtf->markPos & RTF_MARK_IN_WIN)) {
      long oldstart = pRtf->startpixel;
      long slackpixels = RTF_SLACKPIXELS;
        // Compute a new (startpixel) pos..
      if (pRtf->markPos & RTF_MARK_AFTER_WIN) {  // Mark after top..
        pRtf->startpixel = (pRtf->markPos & RTF_MARK_MASK) - pRtf->rect.ly + pRtf->spcsize * 2;
      } else {   // Before win..
        pRtf->startpixel = (pRtf->markPos & RTF_MARK_MASK) - pRtf->spcsize;
      }
      if (pRtf->startpixel > slackpixels) {		// Past end of view win..
        pRtf->startpixel = slackpixels;
      }
      if (pRtf->startpixel < 0) pRtf->startpixel = 0;
      rtf_DrawBackground (pRtf, hDC, rct);
      rtf_DrawText (pRtf, hDC, dmode);  // Redraw with cursor in view..
    }
    if (hIDC == NULL) {
      ReleaseDC (pRtf->hWnd,hDC);
    }
	// Set Scrollbar position..
    if ((dmode & RTF_NOSCROLLBAR) == 0) {
      SCROLLINFO si;
      long slackpixels;		// Dif between viewport & abs len of txt..
      si.cbSize = sizeof (SCROLLINFO);
      slackpixels = RTF_SLACKPIXELS;
      if (slackpixels <= 0) {
        si.fMask = SIF_DISABLENOSCROLL;
      } else {
        si.fMask = SIF_POS;//  | SIF_PAGE;
        si.nPos = (pRtf->startpixel * RTF_SCROLLMAX) / slackpixels;
        //si.nPage = (pRtf->rect.ly * RTF_SCROLLMAX) / slackpixels;
      }
      SetScrollInfo (pRtf->hWnd, SB_VERT, &si, TRUE);	// Force scroll bars default bottom.
    }
}

  // Scroll RTF window..
void rtf_ScrollWin (RTF_WIN *pRtf, WPARAM wParam)
{
    long slackpixels;		// Dif between viewport & abs len of txt..
    //long wpage;
    if (pRtf->npixels <= 0) return;
    slackpixels = RTF_SLACKPIXELS;
    if (slackpixels > 0) {
      switch (LOWORD (wParam)) {		// Which scroll bar ctrl hit?
        case SB_THUMBTRACK:	// SB_THUMBTRACK or SB_THUMBPOSITION
	  //wpage = (RTF_SCROLLMAX * slackpixels) / pRtf->npixels;
          pRtf->startpixel = MUL_DIV (HIWORD (wParam),slackpixels, RTF_SCROLLMAX);	// Pos moved to by user
          break;
        case SB_LINEDOWN:		// down 1 line
          pRtf->startpixel += pRtf->linefwd;
          break;
        case SB_LINEUP:		// up 1 line
          pRtf->startpixel -= pRtf->lineback;
          break;
        case SB_PAGEDOWN:		// down 1 page
          pRtf->startpixel += pRtf->rect.ly;
          break;
        case SB_PAGEUP:		// up 1 page
          pRtf->startpixel -= pRtf->rect.ly;
          break;
        default:
          return;	// no action on others..
      }
    }
	// Keep within a range..
    if (pRtf->startpixel < 0) pRtf->startpixel = 0;
    if (pRtf->startpixel > slackpixels ) pRtf->startpixel = slackpixels;

    rtf_Draw (pRtf, NULL, RTF_REDRAWALL);   // Redraw all RTF Window items..
}


  // Mouse hit in RTF win, calc pos of hit & send to front end..
void rtf_MouseHit (RTF_WIN *pRtf, int msg, short mxpos, short mypos)
{
    if (pRtf->pfnServiceRtf == NULL) return;	// No service procedure..
    pRtf->mousehit.x = mxpos - pRtf->rect.tx;		// Save mouse x/y pos in strucure..
    pRtf->mousehit.y = mypos - pRtf->rect.ty;
    pRtf->mousemsg = msg;	// WM_LBUTTONDOWN or WM_LBUTTONDBLCLK
    pRtf->mouse_charpos = -1;
    rtf_Draw (pRtf, NULL, RTF_REDRAWTEXT | RTF_MOUSEHIT);   // Go through redraw procedure to find mouse hit pos..
    if (pRtf->mouse_charpos >= 0) {	// Found a hit position..
      (pRtf->pfnServiceRtf) ((void *) pRtf, RTF_SERV_MOUSEHIT);  // Service mouse hit..
    }
}

  // Service RTF Window actions..
LRESULT CALLBACK rtf_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    RTF_WIN *pRtf;
    switch (wMsg) {	// Reject messages we dont handle first
      case WM_CREATE:
        { SCROLLINFO si;
	  si.cbSize = sizeof (SCROLLINFO);
	  si.fMask = SIF_RANGE;
	  si.nMin = 0;
	  si.nMax = RTF_SCROLLMAX;
          SetScrollInfo (hWnd, SB_VERT, &si, TRUE);	// Force scroll bars default bottom.
	}
        return 0;

      case WM_KEYDOWN:		// These messages simply sent to Parent..
      case WM_CHAR:
      case WM_PALETTECHANGED:	// All the messages we handle..
      case WM_QUERYNEWPALETTE:
      case WM_PAINT:
      case WM_LBUTTONDOWN:
      case WM_LBUTTONDBLCLK:
      case WM_RBUTTONDOWN:
      case WM_MOUSEMOVE:	
      case WM_LBUTTONUP:	
      case WM_SIZE:
      case WM_VSCROLL:
        break;

      default:                      // Rest handled by DefWindowProc
	return( DefWindowProc(hWnd, wMsg, wParam, lParam) );
    }
    
      // OK, now scan for (hWnd) to find what RTF window we are serving..
    pRtf = rtf_GetWndRtf (hWnd);
    if (pRtf == NULL) return 0;	// Cannot find it!

    switch(wMsg) {                      // which message?
      
      case WM_RBUTTONDOWN:
      case WM_KEYDOWN:		// These messages simply sent to Parent..
      case WM_CHAR:
        PostMessage (pRtf->hParent, wMsg, wParam, lParam);
        break;

      case WM_PALETTECHANGED:
      case WM_QUERYNEWPALETTE:
	{ LRESULT lr;	// serve WM_PALETTECHANGED/WM_QUERYNEWPALETTE msgs
	  if (wio_PaletteServe (&lr,hWnd,wMsg,wParam,pRtf->hPal)) {
	    return lr;
	  }
	}
        break;

      case WM_PAINT:
        {
	 PAINTSTRUCT ps;
	 HDC hDC;
	 RECT crct;
	 long slackpixels;
	 GetClientRect (hWnd, &crct);
	 hDC = BeginPaint (hWnd,&ps);
	 /*if (pRtf->hPal) {
	   SelectPalette (hDC, pRtf->hPal, TRUE);  // get palette for window
 	   RealizePalette (hDC);		// Refresh palette.. 
	 }*/
	 rtf_Draw (pRtf, hDC, RTF_REDRAWALL);	 // Redraw all RTF Window items..
	 slackpixels = RTF_SLACKPIXELS;
	 if (pRtf->startpixel > slackpixels ) {		// Past end of view win..
	   pRtf->startpixel = slackpixels;
	   rtf_Draw (pRtf, hDC, RTF_REDRAWALL);	
	 }
	 EndPaint (hWnd,&ps);
	}
        break;

      case WM_VSCROLL:
        rtf_ScrollWin (pRtf, wParam);
	return 0L;

      /*case WM_SIZE:	// Asertain parent window size, adjust accordingly..
        if (pRtf->tooltype <= RTF_WIN_FLOAT) {
	  RECT rparent;
	  GetClientRect (pRtf->hParent, &rparent);
	  pRtf->lenx = rparent.right;
	  SetWindowPos (hWnd,NULL,pRtf->topx,pRtf->topy,pRtf->lenx,pRtf->leny,SWP_NOZORDER | SWP_NOCOPYBITS);
	}
	break;*/

      case WM_LBUTTONDBLCLK:
      case WM_LBUTTONDOWN:	// Click on RTF Window?
        rtf_MouseHit (pRtf,wMsg,LOWORD(lParam),HIWORD(lParam));  // Calc pos in file, return to front end..
        break;

      case WM_LBUTTONUP:	// Release click 
      case WM_MOUSEMOVE:	// Move mouse..
        break;

    }   
    return 0L;                       // return if we handled wMsg
} 


//---------------------------------------------------------------
// MODULE:lbox_ User List-Box with 3d effect headers
//---------------------------------------------------------------

LRESULT CALLBACK lbox_WndProc (HWND, UINT, WPARAM, LPARAM);  // List-box servicing..

#define LBOX_WIN_MAX 10
#define LBOX_SCROLLMAX 1000L

typedef struct {	// Once off static data..
  char *szClass;	// LISTBOX Window class name
  int nLbox;		// no of RTF windows
  LBOX_WIN *pLbox [LBOX_WIN_MAX];  // Pointers to a list of LBOX windows
  HINSTANCE hInstance;	// Program instance..
  LBOX_WIN *pElastic;	// ptr to cur elastic box being processed (NULL=none)
  short elastic_field;
  long elastic_xpos;
} LBOX_DATA;

static LBOX_DATA lbox_dat;	// Once off static data..

  // Global initialisation, called once..
void lbox_Reset (HINSTANCE hInstance)
{
    WNDCLASS wndclass;           // window class structure
    memset ((void *) &lbox_dat, 0, sizeof (LBOX_DATA));
    lbox_dat.hInstance = hInstance;
	// Register the rich text class.
    lbox_dat.szClass = "LBOXCLASS9";	// Name of default class..
    wndclass.style         = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;  // style
    wndclass.lpfnWndProc   = (WNDPROC) lbox_WndProc; // WndProc address
    wndclass.cbClsExtra    = 0;            // no extra class data
    wndclass.cbWndExtra    = 0;            // no extra window data
    wndclass.hInstance     = hInstance;    // which program?
    wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);// stock arrow cursor
    wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION); // stock blank icon
    wndclass.lpszMenuName  = NULL;   // menu name
    wndclass.hbrBackground = (HBRUSH) GetStockObject(NULL_BRUSH);
    wndclass.lpszClassName = lbox_dat.szClass;   // window class name
    RegisterClass(&wndclass); // register the class
}

  // Create a list-box view control, 
  // details filled in (LBOX_WIN) struct..
BOOL lbox_WinCreate (LBOX_WIN *pLbox)
{
    RECT rPar;		// Parent client area size..
    DWORD cStyle;
    short cfield;
    static HFONT hFont;
    if (lbox_dat.nLbox >= LBOX_WIN_MAX) {
      return FALSE;
    }
      // Add LBOX window to end of list
    lbox_dat.pLbox [lbox_dat.nLbox] = pLbox;
    lbox_dat.nLbox ++;
	// Init color resources..
    { int ccol;
      if (pLbox->setcolours == FALSE) {		// Set up default colors..
        static COLORREF defcol [] = {LBOX_COL_DEFAULT};
	memcpy (pLbox->color,defcol,sizeof(pLbox->color));
      }
		// Create pens/brushes..
      for (ccol = 0; ccol < LBOX_COL_MAX; ccol ++) {
        pLbox->hPen[ccol] = CreatePen (PS_SOLID,1,pLbox->color[ccol]);
        pLbox->hBrush[ccol] = CreateSolidBrush (pLbox->color[ccol]);
      }
    }
    hFont = (HFONT) GetStockObject (SYSTEM_FONT);
    if (pLbox->phFont == NULL || *pLbox->phFont == NULL) {
      pLbox->phFont = &hFont;	// No font supplied, use default system..
    }
    font_CalcSize (*pLbox->phFont, &pLbox->sfont.x, &pLbox->sfont.y);
	// Pre-calc turn "average char widths" into pixels..
    for (cfield = 0; cfield < pLbox->nFields; cfield ++) {
      if (pLbox->headx [cfield] < 0) {		// In av char widths *2..
        pLbox->headx [cfield] = (-pLbox->headx [cfield] * pLbox->sfont.x) / 2;
      }
    }
      // Set up window style
    cStyle = pLbox->dwStyle;
    if (cStyle == 0) {
      cStyle = WS_CHILD | WS_BORDER | WS_VISIBLE;
    }
    if (pLbox->lboxtype & LBOX_TYPE_VERTSCROLL) {  // Vertical scroll bar
      cStyle |= WS_VSCROLL;
    }
      // Get parent window size
    GetClientRect (pLbox->hParent, &rPar);

    if (pLbox->pfnServiceLbox) {	// Initialise box access..
      long cret = (pLbox->pfnServiceLbox) (LBOXSERV_ACCESS_START,(void *) pLbox);
      if (cret == TRUE) {
        (pLbox->pfnServiceLbox) (LBOXSERV_ACCESS_END,(void *) pLbox);
      }
    }

    if ((pLbox->lboxtype & LBOX_TYPE_VERTSCROLL) 
	&& (pLbox->lboxtype & LBOX_TYPE_INVERT)) {	// Set start window pos to end..
      pLbox->StartOffset = pLbox->totLines;
    }

    pLbox->hWnd = CreateWindow(		// Create LBOX main win
        lbox_dat.szClass,	// window class name
	pLbox->szTitle,		// caption
	cStyle,			// style
	pLbox->ltop.x,pLbox->ltop.y, // Top x,y
	pLbox->llen.x,pLbox->llen.y, // Size x,y
	pLbox->hParent,		// parent's handle
	NULL,			// menu handle
	GetInstance (pLbox->hParent),  // which program?
	NULL
    );
    if (pLbox->hWnd == NULL) return FALSE;
    ShowWindow (pLbox->hWnd, SW_SHOWNORMAL);      // make window visible

    if (pLbox->lboxtype & LBOX_TYPE_VERTSCROLL) {  // Init Vertical scroll bar
      SCROLLINFO si;
      memset (&si,0,sizeof (SCROLLINFO));
      si.cbSize = sizeof (SCROLLINFO);
      si.fMask = SIF_RANGE | SIF_POS;
      //si.nMin = 0; // Implicit - Already cleared..
      si.nMax = LBOX_SCROLLMAX;
      if (pLbox->lboxtype & LBOX_TYPE_INVERT) {
        si.nPos = LBOX_SCROLLMAX;
      }
      SetScrollInfo (pLbox->hWnd, SB_VERT, &si, TRUE);	// Force scroll bars default bottom.
    }
    SetFocus (pLbox->hWnd);
    return TRUE;	// LBOX window created ok!
}


  // Close a LBOX Window
void lbox_Close (LBOX_WIN *pLbox)
{
    int clbox,ccol;
    DestroyWindow (pLbox->hWnd);
    pLbox->hWnd = NULL;
		// Kill all pens/brushes for this box..
    for (ccol = 0; ccol < LBOX_COL_MAX; ccol ++) {
      DeleteObject (pLbox->hPen[ccol]);
      DeleteObject (pLbox->hBrush[ccol]);
      pLbox->hPen[ccol] = NULL;
      pLbox->hBrush[ccol] = NULL;
    }
    pLbox->pfnServiceLbox = NULL;
	// Move all resources up one..
    for (clbox = 0; clbox < lbox_dat.nLbox; clbox ++) {
      if (pLbox == lbox_dat.pLbox [clbox]) {
        goto found;
      }
    }
    return;
found:		// Delete 1, Move all others up one to fill gap..
    while (clbox < lbox_dat.nLbox) {
      lbox_dat.pLbox [clbox] = lbox_dat.pLbox [clbox + 1];
      clbox ++;
    }
    lbox_dat.pLbox [clbox] = NULL;
    lbox_dat.nLbox --;
}

  // Find given LBOX WIN from supplied window handle..
static LBOX_WIN * lbox_GetWndLbox (HWND hWnd)
{
    int clbox;
    for (clbox = 0; clbox < lbox_dat.nLbox; clbox ++) {
      if (hWnd == lbox_dat.pLbox [clbox]->hWnd) {
        return lbox_dat.pLbox [clbox];		// Found it!
      }
    }
    return NULL;	// Cannot find LBOX Window..
}

void lbox_Resize (LBOX_WIN *pLbox, int tx, int ty, int lx, int ly) 
{
    pLbox->ltop.x = tx; pLbox->ltop.y = ty;
    pLbox->llen.x = lx; pLbox->llen.y = ly;
    SetWindowPos (pLbox->hWnd,NULL,pLbox->ltop.x,pLbox->ltop.y,pLbox->llen.x,pLbox->llen.y,SWP_NOZORDER | SWP_NOCOPYBITS);
}


  // Height of titleDat-bar (0=none)
//#define lbox_TitleHeight (pLbox) ((pLbox->lboxtype & LBOX_TYPE_NOTITLE) ? \
//	0 : (pLbox->sfont.y + 1))

MYINLINE int lbox_TitleHeight (LBOX_WIN *pLbox)
{
    if (pLbox->lboxtype & LBOX_TYPE_NOTITLE) return 0;
    return (pLbox->sfont.y + 2);
}

MYINLINE long lbox_DisplayLines (LBOX_WIN *pLbox)
{
    long npix = pLbox->rect.ly - lbox_TitleHeight (pLbox) + pLbox->sfont.y / 4;
    if ((pLbox->lboxtype & LBOX_TYPE_VERTSCROLL) == 0) {
      npix += pLbox->sfont.y / 4;
    }
    npix =  npix / pLbox->sfont.y;
    return npix;
}

   // Convert lbox internal line # to external caller #
   //  only changes if inverted listbox.
MYINLINE long lbox_CallerLine(LBOX_WIN *pLbox, long cline)
{
    if ((pLbox->lboxtype & LBOX_TYPE_INVERT)==0) return cline; 
    if (cline == 0) return 0;	// Title line always 0..
    return pLbox->totLines - cline + 1;
}

  // Compute max start offset (0..n)
MYINLINE long lbox_MaxStartOffset (LBOX_WIN *pLbox)
{
    long mline = pLbox->totLines - lbox_DisplayLines (pLbox);
    if (mline < 0) mline = 0;
    return mline;
}

#define lbox_ADDFIELD 1

  // Calc pos/len of screen line/field
void lbox_CalcRectOf (LBOX_WIN *pLbox, WRECT *cpos, int iline, short ifield)
{
    short cfield;
    cpos->ty = pLbox->rect.ty;
    cpos->ly = lbox_TitleHeight (pLbox) - 1;
    if (iline) {	// Not Title bar..
      cpos->ty += (iline - 1) * pLbox->sfont.y + lbox_TitleHeight (pLbox);
      cpos->ly = pLbox->sfont.y;
    }
    cpos->tx = 0;
    for (cfield = 0; cfield < ifield - 1; cfield ++) {
      cpos->tx += pLbox->headx [cfield] + lbox_ADDFIELD;
    }
    cpos->lx = pLbox->headx [cfield];
}

void lbox_DrawText (LBOX_WIN *pLbox, HDC hDC, int iline)
{
    int cline;
    short cfield;
    int clen;
    int viewlo,viewhi;		// Start/end line of viewport..
    int linhi,linlo;		// start/end line to display
    long cret = 0;
    LBOX_FIELD oField;		// Field-item object
    WRECT cpos;
    RECT rclip;

    memset (&oField,0,sizeof (LBOX_FIELD));
    if (pLbox->pfnServiceLbox == NULL) return;	// No callback, do nothing
    //nlines = lbox_DisplayLines (pLbox);	// # screen lines..
	// Calc viewport start/end line
    viewlo = pLbox->StartOffset + 1; viewhi = viewlo + lbox_DisplayLines (pLbox) - 1;
    viewhi = min (pLbox->totLines, viewhi);	// Ensure never over max..
    linlo = viewlo; linhi = viewhi;
    iline = lbox_CallerLine(pLbox, iline);
    if (iline) {	// Just 1 line..
      if (iline < viewlo || iline > viewhi) return;	// Not in viewport
      linlo = linhi = iline;
    }
    for (cline = linlo; cline <= linhi; cline ++) {
      if (cline == pLbox->SelectedLine) {	// Is this the "selected" line?
        SetTextColor (hDC, pLbox->color[LBOX_COL_TEXT_SEL]);
        SetBkColor (hDC, pLbox->color[LBOX_COL_BACK_SEL]);
      } else {
        SetTextColor (hDC, pLbox->color[LBOX_COL_TEXT]);
        SetBkColor (hDC, pLbox->color[LBOX_COL_MAIN]);
      }
	// Tell caller that we are starting a new line..
      oField.rline = lbox_CallerLine(pLbox, cline);
      pLbox->pField = &oField;
      cret = (pLbox->pfnServiceLbox) (LBOXSERV_STARTLINE,(void *) pLbox);
      if (cret == TRUE) {	// Only display if valid line..
        for (cfield = 1; cfield <= pLbox->nFields; cfield ++) {
          if (pLbox->headx [cfield-1] < 1) continue;   // Field too small..
          lbox_CalcRectOf (pLbox, &cpos, cline - pLbox->StartOffset, cfield);
	  WRECT2RECT (&cpos,&rclip);
	  oField.pTxt = oField.szTxt;
		// Supply Req field/line # to caller..
	  oField.rline = lbox_CallerLine(pLbox, cline);
	  oField.rfield = cfield;
	  //oField.lineValid = TRUE;
          pLbox->pField = &oField;
 	  cret = (pLbox->pfnServiceLbox) (LBOXSERV_NEEDFIELD,(void *) pLbox);
	  if (cret == FALSE) break;	// bad data, skip to next line..
	  if (oField.lineColour) {	// Select different text colour..
            SetTextColor (hDC, pLbox->color[oField.lineColour]);
	    oField.lineColour = 0;
	  }
	  clen = strlen (oField.pTxt);
	  SetTextAlign (hDC, TA_LEFT);
	  ExtTextOut (hDC, cpos.tx+1, cpos.ty,ETO_CLIPPED | ETO_OPAQUE,
		&rclip,oField.pTxt,clen,NULL);
	}
      } //else {  // Not a valid line, show blank line..
        //for (cfield = 1; cfield <= pLbox->nFields; cfield ++) {
        //  if (pLbox->headx [cfield-1] < 1) continue;   // Field too small..
        //  lbox_CalcRectOf (pLbox, &cpos, cline - pLbox->StartOffset, cfield);
	//  Rectangle (hDC, cpos.tx, cpos.ty, cpos.tx + cpos.lx, cpos.ty + cpos.ly);
	//}
        //}
    }
}


void lbox_DrawTitle (LBOX_WIN *pLbox, HDC hDC)
{
    short cfield;
    WRECT cpos;
    RECT rclip;
    char *szTitle = pLbox->pHeadTxt;
    if (pLbox->lboxtype & LBOX_TYPE_NOTITLE) return;	// No titleDat bar..
    SelectObject (hDC,pLbox->hBrush[LBOX_COL_TITLE]);
    SelectObject (hDC,(HPEN) GetStockObject (NULL_PEN));
    /*Rectangle (hDC, pLbox->rect.tx - 1, pLbox->rect.ty -1,
	pLbox->rect.tx + pLbox->rect.lx,
	pLbox->rect.ty + LBOX_TITLE_HEIGHT);*/
    SetTextAlign (hDC, TA_LEFT);
    for (cfield = 1; cfield <= pLbox->nFields; cfield ++) {
      int clen;
      lbox_CalcRectOf (pLbox, &cpos, 0, cfield);
      cpos.ty --; cpos.tx --;
      WRECT2RECT (&cpos,&rclip); 
      clen = strlen (szTitle);
      ExtTextOut (hDC, cpos.tx+4, cpos.ty+2,ETO_CLIPPED | ETO_OPAQUE,
		&rclip,szTitle,clen,NULL);
      if (*szTitle) szTitle += clen + 1;	// Next titleDat..
      wio_Box3d (hDC, pLbox->hPen[LBOX_COL_LO],pLbox->hPen[LBOX_COL_HI],
	cpos.tx, cpos.ty, cpos.lx,cpos.ly,1,1);
    }
}

void lbox_Draw (LBOX_WIN *pLbox, HDC hIDC, int dmode)
{
    HDC hDC = hIDC;
    RECT rct;
    const int marg = 0;
    if (hIDC == NULL && pLbox->hWnd == NULL) return;	// No window..

	// Calc target area..
    GetClientRect (pLbox->hWnd, &rct);
    if (pLbox->sfont.y == 0) return;	// No font size set..
    if (pLbox->pfnServiceLbox) {
      long cret = (pLbox->pfnServiceLbox) (LBOXSERV_ACCESS_START,(void *) pLbox);
      if (cret == FALSE) {		// Data Access Error..
        if (hIDC == NULL) {
          hDC = GetDC (pLbox->hWnd);
        }
        SelectObject (hDC,pLbox->hBrush[LBOX_COL_MAIN]);
        SelectObject (hDC,pLbox->hPen[LBOX_COL_MAIN]);
        Rectangle (hDC,0,0,rct.right,rct.bottom);
        if (hIDC == NULL) {
          ReleaseDC (pLbox->hWnd,hDC);
        }
        return;
      }
    }
    if (hIDC == NULL) {
      hDC = GetDC (pLbox->hWnd);
    }
    if (pLbox->hPal && *pLbox->hPal) {
      SelectPalette (hDC, *pLbox->hPal, TRUE);	// get palette for window
      RealizePalette (hDC);		// Refresh palette.. 
    }
    if (dmode & LBOX_REDRAWBACK) {	// Refresh backdrop
      SelectObject (hDC,pLbox->hBrush[LBOX_COL_MAIN]);
      SelectObject (hDC,pLbox->hPen[LBOX_COL_MAIN]);
      Rectangle (hDC,0,lbox_TitleHeight (pLbox),rct.right,rct.bottom);
    }
	// Calc viewport pos/size..
    pLbox->rect.tx = (short) rct.left;
    pLbox->rect.ty = (short) rct.top;
    pLbox->rect.lx = (short) (rct.right - rct.left);
    pLbox->rect.ly = (short) (rct.bottom - rct.top);
    pLbox->rect.tx += marg; pLbox->rect.ty += marg; 
    pLbox->rect.lx -= 2 * marg; pLbox->rect.ly -= 2 * marg; 
    if (pLbox->rect.lx < 20 || pLbox->rect.ly < 20) goto draw_ret;	// Too small..
    SelectObject (hDC, *pLbox->phFont);	// Start with default font..
    
	// Keep scroll-bar offset within overall range..
    if (pLbox->lboxtype & LBOX_TYPE_VERTSCROLL) {
      pLbox->StartOffset = max (0,min (pLbox->StartOffset,lbox_MaxStartOffset (pLbox)));
    }

    SetTextColor (hDC, pLbox->color[LBOX_COL_TEXT]);
    SetBkColor (hDC, pLbox->color[LBOX_COL_TITLE]);
    if (dmode & LBOX_REDRAWTITLE) {	// Refresh titleDat bar
      lbox_DrawTitle (pLbox, hDC);	// Redraw titleDat bar (if any)
    }
    if (dmode & LBOX_REDRAWTEXT) {	// Refresh text body
      lbox_DrawText (pLbox, hDC,0);	// Redraw all lines..
    }
    if (dmode & LBOX_REDRAWLINE) {	// Redraw just 1 line..
      lbox_DrawText (pLbox, hDC,dmode & 0xffffff);	// Redraw 1 line..
    }
	// Set Scrollbar position..
    if (pLbox->lboxtype & LBOX_TYPE_VERTSCROLL) {
      SCROLLINFO si;
      long totlines = max (1,pLbox->totLines);
      si.cbSize = sizeof (SCROLLINFO);
      si.fMask = SIF_POS | SIF_PAGE;
      si.nPos = (pLbox->StartOffset * LBOX_SCROLLMAX) / totlines;
      si.nPage = (lbox_DisplayLines (pLbox) * LBOX_SCROLLMAX) / totlines;
      SetScrollInfo (pLbox->hWnd, SB_VERT, &si, TRUE);	// Set scrollbar position..
      //long mline = lbox_MaxStartOffset (pLbox);
      //si.nPos = (pLbox->StartOffset * LBOX_SCROLLMAX) / mline;
    }
draw_ret:
    if (hIDC == NULL) {
      ReleaseDC (pLbox->hWnd,hDC);
    }
    if (pLbox->pfnServiceLbox) {
      (pLbox->pfnServiceLbox) (LBOXSERV_ACCESS_END,(void *) pLbox);
    }
}

  // Scroll ListBox window..
void lbox_ScrollWin (LBOX_WIN *pLbox, WPARAM wParam)
{
      switch (LOWORD (wParam)) {		// Which scroll bar ctrl hit?
        case SB_THUMBTRACK: {	// SB_THUMBTRACK or SB_THUMBPOSITION
          long slacklines = pLbox->totLines;// - lbox_DisplayLines (pLbox);
          pLbox->StartOffset = MUL_DIV (HIWORD (wParam),slacklines, LBOX_SCROLLMAX);	// Pos moved to by user
		// NOTE redraw ensures StartOffset is kept in range..
          break;
	}
        case SB_LINEDOWN:		// down 1 line
          pLbox->StartOffset ++;
          break;
        case SB_LINEUP:		// up 1 line
          pLbox->StartOffset --;
          break;
        case SB_PAGEDOWN:		// down 1 page
          pLbox->StartOffset += lbox_DisplayLines (pLbox);	
          break;
        case SB_PAGEUP:		// up 1 page
          pLbox->StartOffset -= lbox_DisplayLines (pLbox);	
          break;
        default:
          return;	// no action on others..
      }
    lbox_Draw (pLbox, NULL, LBOX_REDRAWALL);   // Redraw all RTF Window items..
}

  // Find line of given y position.. (-1= out of range..0=titleDat,1-n=line)
long lbox_FindLine (LBOX_WIN *pLbox, long ypos)
{
    int theight = lbox_TitleHeight (pLbox);
    //xpos -= pLbox->rect.tx;
    ypos -= pLbox->rect.ty;
    if (ypos < 0) return -1;
    if (ypos < theight) {
      ypos = 0;
    } else {
      ypos = 1 + (ypos - theight) / pLbox->sfont.y;
      if (ypos > pLbox->totLines) return -1;
    }
    return ypos;
}

  // For given X pos, find field # (0..n-1) or -1 for error..
MYINLINE long lbox_FindField (LBOX_WIN *pLbox, long xpos, short fmode)
{
    short cfield;
    short cpos;
    const UINT marg = 10;
    xpos -= pLbox->rect.tx;
    cpos = 0;
    if (xpos < 0) return -1;
    for (cfield = 0; cfield < pLbox->nFields; cfield ++) {
      cpos += pLbox->headx [cfield] + lbox_ADDFIELD;
      if (fmode) {	// detect hit on field-boundary
	if ((UINT) (cpos - xpos + marg) < marg*2) {
          if (cfield < pLbox->nFields -1
		&& (UINT) cpos+pLbox->headx[cfield+1]-xpos+marg < marg) {
	    return (cfield + 1);
	  }
	  return cfield;
	}
      } else {		// detect hit in field..
        if (xpos < cpos) return cfield;
      }
    }
    return -1;		// none found..
}

  // Process LBOX mouse hit..
void lbox_MouseCmd (LBOX_WIN *pLbox, UINT wMsg, long xpos, long ypos)
{
    LBOX_FIELD oField;		// Field-item object

    ypos = lbox_FindLine (pLbox, ypos);
    if (ypos < 0) return;
    oField.rfield = (short) lbox_FindField (pLbox, xpos, 0);
    if (ypos == 0) {
      oField.rline = 0;
    } else {
      oField.rline = lbox_CallerLine(pLbox, pLbox->StartOffset + ypos);
    }
    oField.mouseCmd = wMsg;
    if (ypos && (pLbox->lboxtype & LBOX_TYPE_SELECTABLE)) {
      pLbox->SelectedLine = pLbox->StartOffset + ypos;
      lbox_Draw (pLbox, NULL, LBOX_REDRAWTEXT);	 
    }
    if (pLbox->pfnServiceLbox) {  // Send selection message back to front-end..
      pLbox->pField = &oField;
      (pLbox->pfnServiceLbox) (LBOXSERV_ITEM_SELECTED,(void *) pLbox);
    }
}

  // Service "elastic" header fields..
void lbox_ElasticServe (LBOX_WIN *pLbox, UINT wMsg, long xpos, long ypos)
{
    ypos = lbox_FindLine (pLbox, ypos);
    if (ypos != 0) goto kill_elastic;
    if (wMsg == WM_LBUTTONDOWN) {
      lbox_dat.elastic_xpos = xpos;
      xpos = lbox_FindField (pLbox, xpos, 1);
      if (xpos < 0) goto kill_elastic;
      lbox_dat.pElastic = pLbox;
      lbox_dat.elastic_field = (short) xpos;
      SetCapture (pLbox->hWnd);
      return;
    }
    if (wMsg == WM_LBUTTONUP) {
      if (lbox_dat.pElastic) {
        lbox_Draw (pLbox, NULL, LBOX_REDRAWALL);
      }
      goto kill_elastic;
    }
    if (lbox_dat.pElastic == NULL) return;
    if (lbox_dat.pElastic != pLbox) goto kill_elastic;
    if (wMsg == WM_MOUSEMOVE) {
      long dif = xpos - lbox_dat.elastic_xpos;
      long tpos;
      lbox_dat.elastic_xpos = xpos;
      tpos = pLbox->headx [lbox_dat.elastic_field] + dif;
      if (tpos < 0) goto kill_elastic;
      pLbox->headx [lbox_dat.elastic_field] = (short) tpos;
      lbox_Draw (pLbox, NULL, LBOX_REDRAWTITLE); // Redraw titleDat bar..
    }
    return;

kill_elastic:
    ReleaseCapture ();
    lbox_dat.pElastic = NULL;    
}

  // Service LBOX Window actions..
LRESULT CALLBACK lbox_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    LBOX_WIN *pLbox;
    switch (wMsg) {	// Reject messages we dont handle first
      case WM_CREATE:
        return 0;

      case WM_KEYDOWN:		// These messages simply sent to Parent..
      case WM_CHAR:
      case WM_PALETTECHANGED:	// All the messages we handle..
      case WM_QUERYNEWPALETTE:
      case WM_PAINT:
      case WM_LBUTTONDOWN:	// Click on LBOX Window?
      case WM_LBUTTONDBLCLK:
      case WM_RBUTTONDOWN:	// Click on LBOX Window?
      case WM_RBUTTONDBLCLK:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
      case WM_SIZE:
      case WM_VSCROLL:
        break;

      default:                      // Rest handled by DefWindowProc
	return( DefWindowProc(hWnd, wMsg, wParam, lParam) );
    }
    
      // OK, now scan for (hWnd) to find what LBOX window we are serving..
    pLbox = lbox_GetWndLbox (hWnd);
    if (pLbox == NULL) return 0;	// Cannot find it!

    switch(wMsg) {                      // which message?
      
      case WM_KEYDOWN:		// These messages simply sent to Parent..
      case WM_CHAR:
      case WM_RBUTTONDOWN:
      case WM_RBUTTONDBLCLK:
        PostMessage (pLbox->hParent, wMsg, wParam, lParam);
        break;

      case WM_PALETTECHANGED:
      case WM_QUERYNEWPALETTE:
	{ LRESULT lr;	// serve WM_PALETTECHANGED/WM_QUERYNEWPALETTE msgs
	  if (wio_PaletteServe (&lr,hWnd,wMsg,wParam,*pLbox->hPal)) {
	    return lr;
	  }
	}
        break;

      case WM_PAINT:
        {
	 PAINTSTRUCT ps;
	 HDC hDC;
	 hDC = BeginPaint (hWnd,&ps);
	 lbox_Draw (pLbox, hDC, LBOX_REDRAWALL);	 // Redraw all LBOX Window items..
	 EndPaint (hWnd,&ps);
	}
        break;

      case WM_VSCROLL:
        lbox_ScrollWin (pLbox, wParam);
	return 0L;

      /*case WM_SIZE:	// Asertain parent window size, adjust accordingly..
        if (pLbox->tooltype <= LBOX_WIN_FLOAT) {
	  RECT rparent;
	  GetClientRect (pLbox->hParent, &rparent);
	  pLbox->llen.x = rparent.right;
	  SetWindowPos (hWnd,NULL,pLbox->ltop.x,pLbox->ltop.y,pLbox->llen.x,pLBOX->leny,SWP_NOZORDER | SWP_NOCOPYBITS);
	}
	break;*/

      case WM_LBUTTONUP:
      case WM_MOUSEMOVE:	// Move the mouse..
	if (pLbox->lboxtype & LBOX_TYPE_ELASTIC) {	// "Elastic" fields?
	  lbox_ElasticServe (pLbox,wMsg,LOWORD(lParam),HIWORD(lParam));
	}
        return 0L;

      case WM_LBUTTONDOWN:	// Click on LBOX Window?
      case WM_LBUTTONDBLCLK:
      //case WM_RBUTTONDOWN:	// Click on LBOX Window?
      //case WM_RBUTTONDBLCLK:
      {
	if (pLbox->lboxtype & LBOX_TYPE_ELASTIC) {	// "Elastic" fields?
	  lbox_ElasticServe (pLbox,wMsg,LOWORD(lParam),HIWORD(lParam));
	}
	lbox_MouseCmd (pLbox,wMsg,LOWORD(lParam),HIWORD(lParam));
        return 0;
      }

    }   
    return 0L;                       // return if we handled wMsg
} 

#endif 	// _WIN32

//---------------------------------------------------------------
// MODULE: thread_ Controls Thread functions..
//---------------------------------------------------------------

  // Give cur thread a high priority
void thread_Faster ()
{
    HANDLE hThd = GetCurrentThread ();
    SetThreadPriority (hThd,THREAD_PRIORITY_HIGHEST);
}

  // Give cur thread normal priority
void thread_Normal ()
{
    HANDLE hThd = GetCurrentThread ();
    SetThreadPriority (hThd,THREAD_PRIORITY_NORMAL);
}

//---------------------------------------------------------------
// MODULE: task_ Run an intensive task, show Cancel/% window..
//---------------------------------------------------------------


LRESULT CALLBACK task_WndProc (HWND,UINT,WPARAM,LPARAM);

TASK_DATA task_dat;	// NOTE- only one task, ie, like searching, etc..

#define TASK_KILLWIN (WM_USER + 111)

#define TASK_STR_TITLE   task_dat.szText	
#define TASK_STR_TEXT1   (str_GetNth(task_dat.szText,1))
#define TASK_STR_TEXT2   (str_GetNth(task_dat.szText,2))
#define TASK_STR_CANCEL  (str_GetNth(task_dat.szText,3))
#define TASK_STR_TIME    (str_GetNth(task_dat.szText,4))

#define TASK_BUT_CANCEL 1000

  // Vertical position of items in Cancel window..
#define TASK_VPOS_TEXT1    (4)
#define TASK_VPOS_TEXT2    (task_dat.fontsize.y + 6)
#define TASK_VPOS_PROGRESS (task_dat.fontsize.y * 2 + 8)
#define TASK_VPOS_TIME     (task_dat.fontsize.y * 3 + 10)
#define TASK_VPOS_PERCENT  (task_dat.fontsize.y * 6)
#define TASK_VPOS_CANCEL   (task_dat.fontsize.y * 8)
#define TASK_VPOS_WNDSIZE  (task_dat.fontsize.y * 14)

void task_Reset (HINSTANCE hInstance)
{
    WNDCLASS wClass;           // window class structure
    
    memset (&task_dat,0,sizeof (TASK_DATA));
    task_dat.hInstance = hInstance;
    task_dat.szClass = "TASK_8";	// Unique ID for window class..
    task_dat.hFont = (HFONT) GetStockObject (ANSI_VAR_FONT);

    font_CalcSize (task_dat.hFont, &task_dat.fontsize.x, &task_dat.fontsize.y);

    wClass.style         = CS_HREDRAW | CS_VREDRAW;  // style
    wClass.lpfnWndProc   = (WNDPROC) task_WndProc; // WndProc address
    wClass.cbClsExtra    = 0;            // no extra class data
    wClass.cbWndExtra    = 0;            // no extra window data
    wClass.hInstance     = hInstance;    // which program?
					     // stock arrow cursor
    wClass.hCursor       = LoadCursor (NULL, IDC_ARROW);
			     // stock blank icon
    wClass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wClass.lpszMenuName  = NULL;   // menu name
					     // white background
    wClass.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    wClass.lpszClassName = task_dat.szClass;   // window class name

    RegisterClass(&wClass); // register the class
}

BOOL task_Init ()
{
    int tx,ty,lx,ly;
    int clen;

    if (task_dat.isRunning) return FALSE;	// Task already running..
    clen = strlen (task_dat.szText);
    while (clen > 0) {		// Replace all 01 chars with 00..
      clen --;
      if (task_dat.szText[clen] == 1) task_dat.szText[clen] = 0;
    }
    task_dat.szProgress [0] = 0;
    task_dat.starttime = clock ();

    task_dat.percent = 0;
    task_dat.isRunning = TRUE;
    task_dat.isStopped = FALSE;
    lx = task_dat.fontsize.x * 80; 
    ly = TASK_VPOS_WNDSIZE;
    tx = (wio_DesktopInfo (HORZRES) - lx) / 2;
    ty = (wio_DesktopInfo (VERTRES) - ly) / 2;
    task_dat.hTaskWnd = CreateWindow (task_dat.szClass,           // window class name
		TASK_STR_TITLE,           // caption
		WS_CAPTION | WS_SYSMENU | WS_BORDER | WS_VISIBLE | WS_POPUP, /* | WS_CHILD */ 
		tx,ty,lx,ly,
		task_dat.hParentWnd,		// parent's handle
		NULL,                 // menu handle
		task_dat.hInstance,       // which program?
		NULL);                // Ptr to thread data..
    if (task_dat.hTaskWnd == NULL) return FALSE;
    ShowWindow (task_dat.hTaskWnd, SW_SHOWNORMAL);      // make window visible
    SetFocus (task_dat.hTaskWnd);
    task_dat.threadID = _beginthread (task_dat.pfnTask,0,task_dat.pParams);
    if (task_dat.threadID == -1) {
      return FALSE;
    }
    return TRUE;
}

int task_RedrawInProgress = FALSE;

void task_Redraw (HDC hIDC)
{
    char szPer [20];
    int nchr;
    int tx,ty,lx,ly;
    HDC hDC = hIDC;
    HPEN hPenWht,hPenBlk;
    hPenWht = (HPEN) GetStockObject (WHITE_PEN);
    hPenBlk = (HPEN) GetStockObject (BLACK_PEN);

    if (task_RedrawInProgress) return;	// Another thread already redrawing it..
    task_RedrawInProgress = TRUE;
    if (hIDC == NULL) {
      if (task_dat.hTaskWnd == NULL) return;
      hDC = GetDC (task_dat.hTaskWnd);
    }
    SelectObject (hDC,(HFONT) task_dat.hFont);
    SetTextColor (hDC, RGB(0,0,0));
    SetBkColor (hDC, RGB(192,192,192));
    tx = 10;
    ty = TASK_VPOS_PERCENT;
    lx = task_dat.wrect.right - tx * 2 - task_dat.fontsize.x * 5;
    ly = task_dat.fontsize.y ;

    TextOut (hDC,tx,TASK_VPOS_TEXT1,TASK_STR_TEXT1,strlen (TASK_STR_TEXT1));
    TextOut (hDC,tx,TASK_VPOS_TEXT2,TASK_STR_TEXT2,strlen (TASK_STR_TEXT2));
    if (task_dat.szProgress) {
      TextOut (hDC,tx,TASK_VPOS_PROGRESS,task_dat.szProgress,strlen (task_dat.szProgress));
    }
    if (task_dat.percent) {	// Display estimated time left..
      char szTxt [80],szTime[32];
      int clen;
      long ctime = (clock() - task_dat.starttime) / CLOCKS_PER_SEC;
      ctime = ((ctime * 1000) / task_dat.percent) - ctime;
      ctime = ctime * 2;  // Make guess pessimistic, twice as long..
      str_time2asc (szTime,ctime,TIME_HOURS | TIME_NULLTERM);
      clen = sprintf (szTxt,TASK_STR_TIME,szTime);
      TextOut (hDC,tx,TASK_VPOS_TIME,szTxt,clen);
    }

    wio_Box3d (hDC, hPenWht, hPenBlk, tx,ty,lx,ly,2,0);

    nchr = sprintf (szPer, "%d %% ",task_dat.percent / 10);
    TextOut (hDC,tx + lx + 8,ty,szPer,nchr);
     
    // Calc % rectangle bar..
    SelectObject (hDC,(HPEN) GetStockObject (NULL_PEN));
    SelectObject (hDC,(HBRUSH) GetStockObject (DKGRAY_BRUSH));
    lx = lx * task_dat.percent / 1000;
    Rectangle (hDC, tx,ty,tx + lx,ty + ly);

    if (hIDC == NULL) {
      ReleaseDC (task_dat.hTaskWnd,hDC);
    }
    task_RedrawInProgress = FALSE;
}

  // Return TRUE if a task is running..
BOOL task_IsRunning ()
{
     return (task_dat.isRunning);
}

  // Called by thread upon natural task termination..
void task_ThreadEnd ()
{
    HWND hWnd = task_dat.hTaskWnd;
    if (hWnd) {
      PostMessage (hWnd,TASK_KILLWIN,TASK_KILLWIN,0);
      Sleep (0);
    }
    task_dat.isRunning = FALSE;
    _endthread ();
}

  // Called by front-end on aborting, signal thread to end....
void task_Close ()
{
    if (task_dat.hTaskWnd) {
      DestroyWindow (task_dat.hTaskWnd);
    }
    task_dat.isStopped = TRUE;		// Tell thread to stop..
}

LRESULT CALLBACK task_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    switch(wMsg) {                      // which message?
      case WM_CREATE: {
          int tx,ty,lx,ly;
	  char *szCancel = TASK_STR_CANCEL;
		// Create CANCEL button..
	  GetClientRect (hWnd, &task_dat.wrect);	// Get drawing area size
	  lx = (task_dat.fontsize.x + 1) * strlen (szCancel) + 14; 
	  ly = task_dat.fontsize.y + 12;
	  tx = (task_dat.wrect.right - lx) / 2;
	  ty = TASK_VPOS_CANCEL;
          task_dat.hButWnd = CreateWindow ("BUTTON",
		szCancel,
        	WS_CHILD | WS_TABSTOP | WS_VISIBLE | BS_PUSHBUTTON,
		tx,ty,lx,ly,
		hWnd, (HMENU) TASK_BUT_CANCEL, task_dat.hInstance,NULL);
        }
        return 0;

      case WM_DESTROY:          
        task_dat.hTaskWnd = NULL;
        task_Close ();
        break;
      
      case TASK_KILLWIN:	// Post-msg win kill (sep thread cannot directly DestroyWindow)
        if (wParam == TASK_KILLWIN) {
          DestroyWindow (hWnd);
	}
        return 0;

      case WM_PAINT : {
        PAINTSTRUCT ps;
	HDC hDC;
	hDC = BeginPaint (hWnd,&ps);
	task_Redraw (hDC);
	EndPaint (hWnd,&ps);
        return 0;
      }

      case WM_COMMAND:
        if (wParam == TASK_BUT_CANCEL) {
	  DestroyWindow (hWnd);
	}
        break;

      case WM_KEYDOWN:
        break;
      
      case WM_CHAR:
        break;
        
      default:
        break;
    }   

    return DefWindowProc (hWnd, wMsg, wParam, lParam);
} 

//---------------------------------------------------------------
// MODULE: msg_ Post "delayed" messages..
//---------------------------------------------------------------

typedef struct {
  int released;
  int sleeptime;
  HWND hWnd;
  UINT Msg;
  WPARAM wParam;
  LPARAM lParam;
} MSG_DATA;

  // Call DLL engine start & run..
void msg_RunThread (void *pDat)
{
    MSG_DATA md;
    MSG_DATA *pMDin = (MSG_DATA *) pDat;

    md = *pMDin;
    pMDin->released = TRUE;		// release main thread.
    Sleep (md.sleeptime);	// Allow main thread to do some work..
    PostMessage (md.hWnd, md.Msg, md.wParam, md.lParam);
    _endthread ();
    return;	// Thread terminates here..
}

  // Replacement for PostMessage, but does it by
  //   starting another thread, & delaying before posting.
BOOL msg_PostDelayed (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, int sleeptime)
{
    MSG_DATA md;
    int cret;

    md.hWnd = hWnd; 
    md.Msg = Msg;
    md.wParam = wParam;
    md.lParam = lParam;
    md.released = FALSE;
    md.sleeptime = sleeptime;
    cret = _beginthread (msg_RunThread,0,&md);
    if (cret == -1) return FALSE;
    while (md.released == FALSE) {
      Sleep (0);
    }
    return TRUE;
}

//---------------------------------------------------------------
// MODULE: accel_ Accelerator fns..
//---------------------------------------------------------------

  // Load an accelerator table from param file..
  //  ret handle, or NULL if error..
HACCEL accel_Load (char *szParFile, char *szBlock)
{
    HACCEL hAccel;
    static ACCEL pAC [512];
    const int maxaccel = 512;
    long naccel;
    int cret;
    void *pret;
    
    pret = par_Open (szParFile);
    if (pret == NULL) return FALSE;	// error opening file..
    cret = par_GotoBlock (szBlock,0);	// Go to menu block..
    if (cret == FALSE) goto acc_err;

    cret = par_ReadStr ((char *) pAC, maxaccel * sizeof (ACCEL) - 20, &naccel);
    if (cret == FALSE) goto acc_err;
    naccel = naccel / sizeof (ACCEL);

    hAccel = CreateAcceleratorTable (pAC, naccel);
    par_Close ();
    //naccel = CopyAcceleratorTable (hAccel,NULL,0);
    //CopyAcceleratorTable (hAccel,pAC,naccel);
    return hAccel;

acc_err:
    par_Close ();
    return NULL;
}

//---------------------------------------------------------------
// MODULE: ini_ .INI Profile file read/writes..
//---------------------------------------------------------------

char ini_Prof [256];		// temp workspace
char *ini_szFile = NULL;
char *ini_szHead = NULL;

  // Set INI filename & Heading..
void ini_Init (char *szIniFile, char *szHead)
{
    ini_szFile = szIniFile;    
    ini_szHead = szHead;    
}

	// Write a private profile string (->WGENIUS.INI)
void ini_WrtStr (char *szEntry, char *szString)
{
        WritePrivateProfileString (ini_szHead, szEntry, szString, ini_szFile);
}

	// Write a private profile number (->WGENIUS.INI)
void ini_WrtInt (char *szEntry, int *iVal, short nwrite)
{
	char *istr = ini_Prof;
	while (nwrite > 0) {
	  istr += wsprintf (istr,"%d ",iVal [0]);
          nwrite --; iVal ++;
	}
	ini_WrtStr (szEntry, ini_Prof);
}

  // Get a string "szEntry=.." from "PARAMS" section of PROG.INI
  // Default passed in szString, unaltered if no entry..
void ini_ReadStr (char *szEntry, char *szString)
{
        GetPrivateProfileString (ini_szHead, szEntry, szString, szString, 70, ini_szFile);
}

  // Read in NREAD integers from entry in profile string into INT array..
void ini_ReadInt (char *szEntry, int *iVal, short nread)
{
	char *istr = ini_Prof;
	istr [0] = 0;		// wipe string..
	ini_ReadStr (szEntry, istr);
	while (nread > 0) {			// Until no more integers..
	  if (isdigit (istr [0]) == 0) break;   // not digit, end of str..
	  iVal [0] = atoi (istr);
	  while (isdigit (istr [0])) istr ++;
	  if (istr [0] == ' ' || istr [0] == ',') istr ++;// Space seperator
	  nread --; iVal ++;
	}
}

  // Read in ASC char letter (a-z) (1..26) from entry in profile string into INT array..
void ini_ReadChar (char *szEntry, int *iVal)
{
	char *istr = ini_Prof;
	istr [0] = 0;		// wipe string..
	ini_ReadStr (szEntry, istr);
	*iVal = 0;
	if (istr[0] < 65) return;
	*iVal = (int) (istr[0] & 31);
}


//---------------------------------------------------------------
// MODULE: bmp_ for loading/handling 256 colour bmps/palettes..
//---------------------------------------------------------------

#define bmpUSE_INDEX 1		// RGB conversion method - if by INDEX, extra index table kept.
#define bmpMAX_PAL 1024		// Max colours in palette.

#if bmpUSE_INDEX
    // Colour tables - tot size per entry
  #define bmpCOLOR_SIZE (sizeof(RGBQUAD) + sizeof (short))
  // Get offset to start of palette index data for given ptr to Bitmap data..
  #define bmpPALINDEX(ptr) \
	(WORD far *) ((char far *) (ptr) + sizeof (BITMAPINFOHEADER))
  // Get offset to start of palette RGB data for given ptr to Bitmap data..
  #define bmpRGBINDEX(ptr) \
	(RGBQUAD far *) ((char far *) (ptr) + sizeof (BITMAPINFOHEADER) \
	+ (ptr)->biClrUsed * sizeof (short))
#else
    // Colour tables - tot size per entry
  #define bmpCOLOR_SIZE sizeof(RGBQUAD)
  // Get offset to start of palette RGB data for given ptr to Bitmap data..
  #define bmpRGBINDEX(ptr) \
	(RGBQUAD far *) ((char far *) (ptr) + sizeof (BITMAPINFOHEADER))
#endif

  // Get offset to start of raw bitmap data for given ptr to Bitmap data..
#define bmpSTARTPIX(ptr) \
	((WORD) (ptr)->biSize + (WORD) (ptr)->biClrUsed * bmpCOLOR_SIZE)
  // Total size of all bitmap data, inc color/header/pixel data
#define bmpSIZEOF(ptr) \
   ((ptr)->biSize + (ptr)->biClrUsed * bmpCOLOR_SIZE + (ptr)->biSizeImage)
  // Round bit-size to next 32 bit len (BMPs must have width on long word)
#define bmpROUND32(x) (((x) + 31) & ~31)
#define bmpROUND4(x) (((x) + 3) & ~3)


  // Load one BMP item from disk..
  // Ret 0=ok, or 1..n error #..
short bmp_Read (BMPITEM *bmpi)
{
	LPBITMAPINFOHEADER lpBmp = NULL;	// Pointer to bitmap data
	BITMAPFILEHEADER   bf;
	HFILE hfile = HFILE_ERROR;
	short cerr;		// Error return code..
	short cret;
	DWORD clong;
	WORD nColors;
	hfile = _lopen (bmpi->fname, OF_READ);
	if (hfile == HFILE_ERROR) {
	  cerr = 1; goto LoadErr;
	}
	lpBmp = (LPBITMAPINFOHEADER) my_malloc (sizeof(BITMAPINFOHEADER) );
	if (lpBmp == NULL) {
	  cerr = 2; goto LoadErr;
	}
	  // read the BITMAPFILEHEADER 
	cret = _lread (hfile, (LPSTR) &bf, sizeof (bf));
	if (sizeof (bf) != cret) {
	  cerr = 3; goto LoadErr;
	}
		// Read 1st real part of bitmap - info header
	cret = _lread (hfile, (LPSTR) lpBmp, sizeof(BITMAPINFOHEADER));
	if (sizeof (BITMAPINFOHEADER) != cret) {
	  cerr = 4; goto LoadErr;
	}
	
	  // Don't even deal with CORE headers 
	if (lpBmp->biSize == sizeof (BITMAPCOREHEADER)) {
	  cerr = 4; goto LoadErr;
	}
		// Set correct # colours used.
	nColors = (WORD) lpBmp->biClrUsed;
	if (nColors == 0) {
	  // no color table for 24-bit, default size otherwise 
	  if (lpBmp->biBitCount != 24) {
	    nColors = 1 << lpBmp->biBitCount;	// standard size table
	  }
	}

	  // fill in some default values if they are zero 
	if (lpBmp->biClrUsed == 0) {
          lpBmp->biClrUsed = (DWORD) nColors;
        }

	if (lpBmp->biSizeImage == 0) {
	  lpBmp->biSizeImage = (bmpROUND32 (lpBmp->biWidth * (DWORD) lpBmp->biBitCount) >> 3)
			 * lpBmp->biHeight;
	}

	  // get a proper-sized buffer for header, color table and bits 
	//lpBmp = (LPBITMAPINFOHEADER) my_realloc ((void far *) lpBmp, lpBmp->biSize +
    	//	nColors * sizeof(RGBQUAD) + lpBmp->biSizeImage + 100);
	lpBmp = (LPBITMAPINFOHEADER) my_realloc ((void far *) lpBmp, bmpSIZEOF (lpBmp) + 64);
	if (lpBmp == NULL) {	// Cannot re-size buffer to load full bmp..
	  cerr = 5; goto LoadErr;
	}
	  // read the color table 
	_lread (hfile, (LPSTR) bmpRGBINDEX (lpBmp), nColors * sizeof(RGBQUAD));
	  
	  // Use offset index to position right pos in file
	if (bf.bfOffBits != 0L) {
          _llseek (hfile, bf.bfOffBits, SEEK_SET);
	}
	    // offset to the bits from start of DIB header 
	clong = _hread (hfile, ((LPSTR) lpBmp) + bmpSTARTPIX (lpBmp), lpBmp->biSizeImage);
	if (lpBmp->biSizeImage != clong) {
	  cerr = 6; goto LoadErr;
	}
	_lclose (hfile);
	bmpi->head = lpBmp;
	return 0;	// No error! Loaded ok..

LoadErr:
	if (hfile != HFILE_ERROR) _lclose (hfile);
	if (lpBmp != NULL) my_free (lpBmp);
	return cerr;
}

  // Return palette handle in (pbmp->hPal)
void bmp_MakePalette (BMPHEAD *pbmp)
{
      LOGPALETTE far *lpPal = pbmp->lpPal;
      WORD wpal,cpal;
      WORD cbmp;
      WORD lowcolor,ctemp;	// Darkest colour..

	// since biClrUsed field was filled during the loading of the DIB,
	// we know it contains the number of colors in the color table.
      if (pbmp->hPal) {	// Delete existing palette object
        SelectPalette (pbmp->hOrigDC, (HPALETTE) GetStockObject (DEFAULT_PALETTE), FALSE);
        DeleteObject (pbmp->hPal);
        pbmp->hPal = NULL;
      }
      		// Copy "Extra" fixed palette entries.
      for (cpal = 0; cpal < pbmp->nExtraPal; cpal ++) {
        COLORREF ccol;
	if (cpal >= bmpMAX_PAL) break;	// Exceeded max allowed
	ccol = pbmp->pExtraPal [cpal];
	lpPal->palPalEntry [cpal].peRed = GetRValue (ccol);
	lpPal->palPalEntry [cpal].peGreen = GetGValue (ccol);
	lpPal->palPalEntry [cpal].peBlue = GetBValue (ccol);
	lpPal->palPalEntry [cpal].peFlags = GetFValue (ccol);
      }
		// Now Build palette from all individual entries..
      for (cbmp = 0; cbmp < bmpNITEMS; cbmp ++) {
	RGBQUAD far *lpRGB;
	#if bmpUSE_INDEX	// Generate palette index table..
	  short far *lpPindex;
	#endif
	LPBITMAPINFOHEADER lpBmp;	// Pointer to bitmap data
	DWORD nPal;
	COLORREF RGBtint = pbmp->i[cbmp].RGBtint;
	pbmp->i[cbmp].nPal = 0;		// Count for individual BMP..
	pbmp->i[cbmp].sPal = cpal;	// Start index of entries
        lpBmp = pbmp->i[cbmp].head;
        if (lpBmp) {			// Yes this BMP exists..
	  nPal = (WORD) lpBmp->biClrUsed;

	  // get pointer to the color table 
	  lpRGB = bmpRGBINDEX (lpBmp);
	  #if bmpUSE_INDEX	// Generate palette index table..
	    lpPindex = (short far *) bmpPALINDEX (lpBmp);
	  #endif
	  // Find highest used "unique" entry..
	  if ((pbmp->i[cbmp].mode & BMPI_NO_HI_PACK) == 0) {	//  Compression  allowed..
	    while (nPal > 2 && _fmemcmp (&(lpRGB [nPal - 1]),
	    	&(lpRGB [nPal - 2]), sizeof (RGBQUAD)) == 0) {
	      nPal --;		// Reduce count..
	    }
	  }
	  // copy colors from the color table to the LogPalette structure 
	  lowcolor = 256 * 3; pbmp->i[cbmp].darkest = 0;
	  for (wpal = 0; wpal < nPal; wpal ++) {
	    if (pbmp->i[cbmp].mode & BMPI_USE_RGB_TINT) {	//  Use RGBtint to adjust colours..
	      lpPal->palPalEntry [cpal].peRed = (BYTE) ((short) ((short) GetRValue (RGBtint) * (short) lpRGB [wpal].rgbRed) / 100);
	      lpPal->palPalEntry [cpal].peGreen = (BYTE) ((short) ((short) GetGValue (RGBtint) * (short) lpRGB [wpal].rgbGreen) / 100);
	      lpPal->palPalEntry [cpal].peBlue = (BYTE) ((short) ((short) GetBValue (RGBtint) * (short) lpRGB [wpal].rgbBlue) / 100);
	    } else {
	      lpPal->palPalEntry [cpal].peRed = lpRGB [wpal].rgbRed;
	      lpPal->palPalEntry [cpal].peGreen = lpRGB [wpal].rgbGreen;
	      lpPal->palPalEntry [cpal].peBlue = lpRGB [wpal].rgbBlue;
	    }
	    lpPal->palPalEntry [cpal].peFlags = 0;
	    	// Find darkest palette entry..
	    ctemp = lpPal->palPalEntry [cpal].peRed 
	    	+ lpPal->palPalEntry [cpal].peGreen 
	    	+ lpPal->palPalEntry [cpal].peBlue;
	    if (ctemp < lowcolor) {
	      lowcolor = ctemp; pbmp->i[cbmp].darkest = wpal;
	    }
	    #if bmpUSE_INDEX	// Generate palette index table..
	      lpPindex [wpal] = cpal;// Save ptr to index entry..
	    #endif
	    //if (wpal == 0 || cpal == 0 || compress == 0 || _fmemcmp (&(lpPal->palPalEntry [cpal]),
	    //	&(lpPal->palPalEntry [cpal - 1]), sizeof (RGBQUAD)) != 0) {
	    if (cpal >= bmpMAX_PAL) break;	// Exceeded max allowed
	    cpal ++;		// Not duplicate entry, Dont skip..
	    pbmp->i[cbmp].nPal ++;
	    //}
	  }
	}
      }
      lpPal->palNumEntries = (WORD) cpal; //bmpMAX_PAL;
      pbmp->hPal = CreatePalette (lpPal);
}

  // De-allocate just 1 bitmap 
void bmp_ResetItem (BMPITEM *bmpi, short mode)
{
	if (bmpi->hDC) {	// Not NULL, DCxists..
	  DeleteDC (bmpi->hDC);
	  bmpi->hDC = NULL;
	}
	if (bmpi->hBmp) {	// Not NULL, bmp exists..
	  DeleteObject (bmpi->hBmp);
	  bmpi->hBmp = NULL;
	}
	if (bmpi->hMaskDC) {	// Not NULL, DCxists..
	  DeleteDC (bmpi->hMaskDC);
	  bmpi->hMaskDC = NULL;
	}
	if (bmpi->hMaskBmp) {	// Not NULL, bmp exists..
	  DeleteObject (bmpi->hMaskBmp);
	  bmpi->hMaskBmp = NULL;
	}
	if ((mode & BMP_RST_RAW) && bmpi->head && (bmpi->mode & BMPI_KEEPRAW)) {
	  my_free (bmpi->head);	// Wipe 'raw' bmp data
	  bmpi->head = NULL;
	}
}

  // Release all allocated items..
  // Set bit 0 BMP_RST_DEL_OLD to Delete old objs/DCs/Bmp handles etc
  // Set bit 1 BMP_RST_INIT    to Init first palette alloc
  // Set bit 2 BMP_RST_WIPE    for absolute wipe..
  // Set bit 3 BMP_RST_RAW     to wipe kept 'raw' bitmaps..
BOOL bmp_Reset (BMPHEAD *pbmp, short mode)
{
	short cbmp;
	if (pbmp == NULL) return FALSE;
	if (BMP_RST_DEL_OLD & mode) {
	  for (cbmp = 0; cbmp < bmpNITEMS; cbmp ++) {
	    BMPITEM *bmpi = &pbmp->i[cbmp];
	    bmp_ResetItem (bmpi, mode);
	  }
	  if (pbmp->hPal) {	// Release palette object
	    SelectPalette (pbmp->hOrigDC, (HPALETTE) GetStockObject (DEFAULT_PALETTE), FALSE);
	    DeleteObject (pbmp->hPal);
	  }
	  if (pbmp->lpPal) {	// De-alloc raw palette data
	    my_free (pbmp->lpPal);
	  }
	}
	if (mode & BMP_RST_WIPE) {
	  memset (pbmp, 0, sizeof (BMPHEAD));	// Clr all vars..
	}
	if (mode & BMP_RST_INIT) {				// Alloc raw palette mem
	  WORD palSize;
		// Grab some mem for our palette 
	  palSize = (WORD) ( sizeof(LOGPALETTE) + bmpMAX_PAL * sizeof(PALETTEENTRY));
	  pbmp->lpPal = (LOGPALETTE far *) my_malloc (palSize);
	  if (pbmp->lpPal == NULL) return FALSE;	// Failed..
	  _fmemset (pbmp->lpPal, 0, palSize);		// Clr palette data
	  pbmp->lpPal->palVersion = 0x300;	// Must be done, but why?
	}
	return TRUE;
}

  // Make a mono mask of a bitmap..
  // Set bit 2 of mmode to use top left pixel as background colour
HBITMAP bmp_MakeMask (LPBITMAPINFOHEADER lpBmp, short mmode)
{
	UINT lenx = (UINT) lpBmp->biWidth;
	UINT leny = (UINT) lpBmp->biHeight;
	UINT monox;
	long monosize,lpos;
	UINT xpos,ypos;
	BYTE HUGE_ *lpRaw;	// ptr to orig raw data
	BYTE HUGE_ *lpMask;	// ptr to start mono bitmap data bits
	BYTE HUGE_ *lpSrc;	// temp src ptr
	BYTE far *lpDest;	// tem dest ptr
	HBITMAP hMaskBmp;
	BYTE backcol;		// Background colour
	BYTE cbit;		// bit shift flag..
		// All bmp data rounded to 32bit boundarys
	lenx = bmpROUND4 (lenx);	// byte=pixel= 4 pixel boundary
	monox = bmpROUND32 (lenx) >> 3;	// byte=8pixel, 32 pixel boundary
	monosize = (long) monox * (long) leny;
	lpMask = (BYTE far *) my_malloc (monosize + 16);
	for (lpos = 0; lpos < monosize; lpos ++) lpMask [lpos] = 0;
			// move ptr to bmp data start
	lpRaw = ((BYTE far *) lpBmp) + bmpSTARTPIX (lpBmp);
	backcol = 0;		// Default black
	if (mmode & BMPI_TOPLEFT_BACK) backcol = lpRaw [0];	// or top left pixel
	for (ypos = 0; ypos < leny; ypos ++) {
		// set ptr to start source 256 col bmp line (upside-down!)
	  lpSrc = lpRaw + ((long) (leny - ypos - 1) * (long) lenx); 
	  	// set ptr to dest mono bmp line
	  lpDest = lpMask + ((long) ypos * (long) monox);
	  for (xpos = 0; xpos < monox; xpos ++) {
	    cbit = 0x80;	// Start with hi bit..
	    do {		// process bit by bit..
	      if (*lpSrc == backcol) {
		*lpDest ^= cbit;
		if (mmode & BMPI_TOPLEFT_BACK) *lpSrc = 0;	// mask back colour to black..
	      }
	      lpSrc ++;
	      cbit = cbit >> 1;		// Next bit..
	    } while (cbit);		// no more.
	    lpDest ++;		// ok, next byte..
	  }
	}
	hMaskBmp = CreateBitmap (monox << 3, leny, 1,1, lpMask);
	my_free (lpMask);
	return hMaskBmp;
}

  // Create a final bmp/hdc item from raw data..
void bmp_Create (BMPHEAD *pbmp, short cbmp)
{
	BMPITEM *bmpi = &pbmp->i[cbmp];
	LPBITMAPINFOHEADER lpBmp = bmpi->head; 
	if (lpBmp == NULL) return;		// Yes data exists for this BMP..
	if (bmpi->mode & BMPI_MAKEMASK) {	// Create a mono mask bitmap
	  LPBITMAPINFOHEADER lpNewBmp;	// Clone a temp bmp
	  long newsize = bmpSIZEOF (lpBmp);
	  lpNewBmp = (LPBITMAPINFOHEADER) my_malloc (newsize + 64);
	  my_memcpy (lpNewBmp, lpBmp, newsize + 16);
	  lpBmp = lpNewBmp;		// Use clone bmp, leave orig alone
	  bmpi->hMaskBmp = bmp_MakeMask (lpBmp, bmpi->mode);
	  bmpi->hMaskDC = CreateCompatibleDC (pbmp->hOrigDC);
	  SelectPalette (bmpi->hMaskDC, pbmp->hPal, FALSE);
	  RealizePalette (bmpi->hMaskDC);
	  SelectObject (bmpi->hMaskDC, bmpi->hMaskBmp);
	}
		// OK, create memory DC & put bitmap into it
	bmpi->hDC = CreateCompatibleDC (pbmp->hOrigDC);
	SelectPalette (bmpi->hDC, pbmp->hPal, FALSE);
	RealizePalette (bmpi->hDC);
	bmpi->hBmp = CreateCompatibleBitmap (pbmp->hOrigDC, 
		(short) lpBmp->biWidth, (short) lpBmp->biHeight);
		
	#if bmpUSE_INDEX	// Generate palette index table..
	    SetDIBits (pbmp->hOrigDC, bmpi->hBmp, 0, (short) lpBmp->biHeight, 
		(LPSTR) lpBmp + bmpSTARTPIX (lpBmp), 
		(LPBITMAPINFO) lpBmp, DIB_PAL_COLORS);
	#else
	  SetDIBits (pbmp->hOrigDC, bmpi->hBmp, 0, (short) lpBmp->biHeight, 
		(LPSTR) lpBmp + bmpSTARTPIX (lpBmp), 
		(LPBITMAPINFO) lpBmp, DIB_RGB_COLORS);
	#endif
	SelectObject (bmpi->hDC, bmpi->hBmp);
	if (bmpi->mode & BMPI_MAKEMASK) {	// Remove temp bmp clone
	  my_free (lpBmp);
	}
	if ((bmpi->mode & BMPI_KEEPRAW) == 0) {	// Dont keep data..
	  my_free (bmpi->head);		// Relese raw bmp data
	  bmpi->head = NULL;
	}
}


  // Generate a rescaled copy of a bitmap.. Changing Raw data only..
  //  scales in %..
BOOL bmp_Rescale (BMPITEM *pBmpi, short xscale, short yscale)
{
	BITMAPINFOHEADER HUGE_ *lpDestBmp;	// Pointer to new bitmap data
	BITMAPINFOHEADER HUGE_ *lpSrcBmp;	// Pointer to source bitmap data
	WORD srcx,srcy;			// Size of source bmp data
	WORD destx, desty;		// Size of Dest bmp data
	WORD xpos,ypos;
	static BYTE HUGE_ *hpSrc;
	static BYTE HUGE_ *hpDest;
	WORD DestSize;
	WORD nColors;
	lpSrcBmp = pBmpi->head;
	if (lpSrcBmp == NULL) return FALSE;
	if (yscale == 0 || xscale == 0) return FALSE;
	nColors = (WORD) lpSrcBmp->biClrUsed;
	srcx = bmpROUND4 ((WORD) lpSrcBmp->biWidth);	// 32 bit boundary
	srcy = (WORD) lpSrcBmp->biHeight;
	DestSize = (WORD) sizeof(BITMAPINFOHEADER) + nColors * bmpCOLOR_SIZE; 
	lpDestBmp = (LPBITMAPINFOHEADER) my_malloc (DestSize + 32);
	if (lpDestBmp == NULL) return FALSE;
	_fmemcpy (lpDestBmp, lpSrcBmp, DestSize);
	destx = (WORD) MUL_DIV (lpDestBmp->biWidth, xscale,100);
	lpDestBmp->biWidth = destx;
	desty = (WORD) MUL_DIV (lpDestBmp->biHeight, yscale,100);
	lpDestBmp->biHeight = desty;
	destx = bmpROUND4 (destx);	// push to 32 bit boundary
	lpDestBmp->biSizeImage = (long) destx * (long) desty;
		// Calc dest size..
	lpDestBmp = (LPBITMAPINFOHEADER) my_realloc (lpDestBmp, bmpSIZEOF (lpDestBmp) + 512);
		// Copy & rescale data bits..
	hpDest = ((BYTE HUGE_ *) lpDestBmp) + bmpSTARTPIX (lpDestBmp);
	for (ypos = 0; ypos < desty; ypos ++) {
	  long tl;
	  tl = bmpSTARTPIX (lpSrcBmp) + MUL_DIV (ypos, 100, yscale) * (long) srcx;
	  hpSrc = ((BYTE HUGE_ *) lpSrcBmp) + tl;
	  for (xpos = 0; xpos < destx /*(WORD) lpDestBmp->biWidth*/; xpos ++) {
	    static BYTE HUGE_ *ptr;
	    ptr = hpSrc;
	    ptr += (long) MUL_DIV (xpos, 100, xscale);
	    *hpDest = *ptr;
	    //*hpDest = hpSrc [MUL_DIV (xpos, 100, xscale)] ;
	    hpDest ++;
	  }
	}
	my_free (pBmpi->head);	// Wipe old bmp data
	pBmpi->head = lpDestBmp;
	pBmpi->lenx = (short) lpDestBmp->biWidth;
	pBmpi->leny = (short) lpDestBmp->biHeight;
	return TRUE;
} 

  // Load all bitmaps defined in (BMPHEAD) list, 
  // generate a common palette.
  // Set bit 0 BMP_LOAD_CLR    to wipe old first
  // Set bit 1 BMP_LOAD_MAKEDC to create a temp DC for bmp-loading..
  // RETURN 0=ok, nz=error code..
short bmp_LoadAll (BMPHEAD *pbmp, short lmode)
{
	short cret;
	LPBITMAPINFOHEADER lpBmp;	// Pointer to bitmap data
	short cbmp;
	if (lmode & BMP_LOAD_CLR) {		// Clr any old..
	  bmp_Reset (pbmp, BMP_RST_DEL_OLD | BMP_RST_INIT);
	}
	if (lmode & BMP_LOAD_MAKEDC) {		// Create & use a "compatible" temp desktop DC for bmp-load..
          pbmp->hOrigDC = GetDC (NULL);		// Make a temp DC for drawing bmps..
        }
	for (cbmp = 0; cbmp < bmpNITEMS; cbmp ++) {
	  BMPITEM *bmpi = &pbmp->i[cbmp];
	  if ((bmpi->mode & BMPI_KEEPRAW) && (bmpi->mode & BMPI_FORCE) == 0 && bmpi->head) {	// Keep old data
	  } else if (bmpi->fname) {		// Yes filename exists for this item..
	    if (bmpi->fname [0]) {
	      cret = bmp_Read (bmpi);
	      if (cret) goto bmp_exit;	// return error code (cret)
	      lpBmp = bmpi->head; 
		// save total size of bitmap..
	      bmpi->lenx = (short) lpBmp->biWidth;	// Width of loaded bitmap..
	      bmpi->leny = (short) lpBmp->biHeight; 	// Height..
	      if (bmpi->yscale) {		// Re-scale to new size..
	        bmp_Rescale (bmpi,bmpi->xscale,bmpi->yscale);
	        lpBmp = bmpi->head; 
	      }
	    } else {
	      bmpi->fname = NULL;
	    }
	    bmpi->mode &= ~(BMPI_FORCE);	// Mask out bit 15 - force load bit
	  }
	}
	bmp_MakePalette (pbmp);
	if (pbmp->hPal == NULL) {cret = 10; goto bmp_exit;} // Cannot make palette
	SelectPalette (pbmp->hOrigDC, pbmp->hPal, FALSE);
	RealizePalette (pbmp->hOrigDC);
	
	for (cbmp = 0; cbmp < bmpNITEMS; cbmp ++) {
	  bmp_Create (pbmp, cbmp);
	}
	cret = 0;	// All worked ok!
bmp_exit:
	if (lmode & BMP_LOAD_MAKEDC) {  // Create & use a "compatible" temp desktop DC for bmp-load..
          ReleaseDC (NULL,pbmp->hOrigDC);
          pbmp->hOrigDC = NULL;
        }
	return cret;

}

  // Add bitmap to list
BOOL bmp_Add (BMPHEAD *pbmp, short cbmp, char *fname, COLORREF RGBtint, short iscalex, short iscaley, short amode)
{
	if ((UINT) cbmp >= bmpNITEMS) return FALSE;
	pbmp->i[cbmp].fname = fname;
	pbmp->i[cbmp].RGBtint = RGBtint;
	pbmp->i[cbmp].mode = amode | BMPI_FORCE;
	pbmp->i[cbmp].xscale = iscalex;	// Scaling factor%:0=off
	pbmp->i[cbmp].yscale = iscaley;	// Scaling factor%:0=off
	return TRUE;
}
	  //my_free (bmpi->head);	// Wipe 'raw' bmp data


//---------------------------------------------------------------
// MODULE: d2d_ 2D board graphics library - for sprites, etc..
//---------------------------------------------------------------

// Local variables for d2d_ only..

typedef struct {	// Contains related DC/Bitmap object
  HDC DC;
  HBITMAP BMP;
} HDB;

HDB hScratch = {NULL,NULL};	// Temp scratchpad 
HDB hLast = {NULL,NULL};	// Old "saved" bitmap under current bmp.

void d2d_DelHDB (HDB *hDB)
{
	if (hDB->DC) {
	  DeleteDC (hDB->DC);
	  hDB->DC = NULL;
	}
	if (hDB->BMP) {
	  DeleteObject (hDB->BMP);
	  hDB->BMP = NULL;
	}
}

  // Create a DC/BITMAP object compatible with (hOrigDC), with palette/size..
void d2d_MakeHDB (HDB *hDB, HDC hOrigDC, HPALETTE hPal, WORD lenx, WORD leny) 
{
		// Create BMP/DC temp scratch area for performing overlays..
	hDB->DC = CreateCompatibleDC (hOrigDC);
	SelectPalette (hDB->DC, hPal, FALSE);
	RealizePalette (hDB->DC);
	hDB->BMP = CreateCompatibleBitmap (hOrigDC, lenx, leny);
	SelectObject (hDB->DC, hDB->BMP);
	
}

void d2d_EndMove ()
{
	d2d_DelHDB (&hScratch);
	d2d_DelHDB (&hLast);
}

  // Initialiase use of a sprite, from a given bitmap/loc/size
void d2d_InitMove (spr_SPRITE *pSpr)
{
	BMPHEAD *pbmp = pSpr->bm;
	HDC hOrigDC = pbmp->hOrigDC;	// DC used to create compatible..
	d2d_EndMove ();		// Wipe any old ones..
		// Create BMP/DC temp scratch area for performing overlays..
	d2d_MakeHDB (&hScratch,pbmp->hOrigDC,pbmp->hPal,(WORD) pSpr->lx + pSpr->lx + 4, (WORD) pSpr->ly + pSpr->ly + 4);
		// Last piece kept overlay..
	d2d_MakeHDB (&hLast,pbmp->hOrigDC,pbmp->hPal, (WORD) pSpr->lx + 4, (WORD) pSpr->ly + 4);
}

  // "Fine" put-at - overlay a sprite at a location
void d2d_PutAt (HDC hDC, spr_SPRITE *pSpr, short xpos, short ypos)
{
	BMPHEAD *pbmp = pSpr->bm;
	BMPITEM *bmpi = &pbmp->i[pSpr->cbmp];
	WORD xpix,ypix;
	WORD cspr = spr_PIECE2OFF(pSpr,pSpr->cspr);
	xpix = pSpr->ppos[cspr].x;	// Pos of sprites..
	ypix = pSpr->ppos[cspr].y;
		// Save area of screen to be used..
	BitBlt (hLast.DC,0,0,pSpr->lx,pSpr->ly,hDC, xpos,ypos,SRCCOPY);
		// Copy White/black outline mask to scratch
	BitBlt (hScratch.DC,0,0,pSpr->lx,pSpr->ly,bmpi->hMaskDC, xpix,ypix,SRCCOPY);
		// Take area of screen to use, AND with mask, put in scratch
	BitBlt (hScratch.DC,0,0,pSpr->lx,pSpr->ly,hDC, xpos,ypos,SRCAND);
    		// Merge in piece with background with OR..
	BitBlt (hScratch.DC,0,0,pSpr->lx,pSpr->ly,bmpi->hDC, xpix,ypix,SRCPAINT);
    		// Copy result back to screen.
	BitBlt (hDC,xpos,ypos,pSpr->lx,pSpr->ly,hScratch.DC, 0,0,SRCCOPY);
}

  // Reget orig background
void d2d_Restore (HDC hDC, spr_SPRITE *pSpr, short xpos, short ypos)
{
		// Get orig screen back....
    BitBlt (hDC,xpos,ypos,pSpr->lx,pSpr->ly,hLast.DC, 0,0,SRCCOPY);
}

  // Overlay cur piece on background
  // Moves from (fx,fy) to (tx,ty)
  // if (mode) set, then calls flySync for sw/hw delay
  // Supply address of Flyback-sync delay routine if used..
void d2d_Move (HDC hDC, spr_SPRITE *pSpr, short fx, short fy, short tx, short ty, void (*fnDelay)() )
{
    BMPHEAD *pbmp = pSpr->bm;
    BMPITEM *bmpi = &pbmp->i[pSpr->cbmp];
    short sfx,sfy;	// From pos in scratch area
    short stx,sty;	// To pos in scratch area
    short bigx,bigy;	// Total size of scratch area
    short xpos,ypos;	// Top-left of screen area to blit
    short difx,dify;	// ABS diff between positions src/dest
    WORD xpix,ypix;
    WORD cspr = spr_PIECE2OFF(pSpr,pSpr->cspr);
    xpix = pSpr->ppos[cspr].x;	// Pos of sprites in bmp..
    ypix = pSpr->ppos[cspr].y;
    xpos = fx; ypos = fy;
    difx = abs (fx - tx); 		// Calc dif in positions..
    dify = abs (fy - ty);
    bigx = pSpr->lx + difx;	// calc total work area size
    bigy = pSpr->ly + dify;
    	// From/to areas dont overlap, just draw sprites..
    if (difx > (short) pSpr->lx || dify > (short) pSpr->ly) {
      if (fnDelay) (*fnDelay) ();	// Sync to screen refresh?
	// Restore orig background at from...
      BitBlt (hDC,fx,fy,pSpr->lx,pSpr->ly, hLast.DC,0,0,SRCCOPY);
	// Save background at dest position
      BitBlt (hLast.DC,0,0,pSpr->lx,pSpr->ly,hDC, tx,ty,SRCCOPY);
	// Make copy in scratch..
      BitBlt (hScratch.DC,0,0,pSpr->lx,pSpr->ly,hLast.DC, 0,0,SRCCOPY);
	// AND background with mask, put in scratch
      BitBlt (hScratch.DC,0,0,pSpr->lx,pSpr->ly, bmpi->hMaskDC,xpix,ypix,SRCAND);
	// Merge in piece with background with OR..
      BitBlt (hScratch.DC,0,0,pSpr->lx,pSpr->ly, bmpi->hDC,xpix,ypix,SRCPAINT);
      	// Write result to screen..
      BitBlt (hDC,tx,ty,pSpr->lx,pSpr->ly, hScratch.DC,0,0,SRCCOPY);
      return;
    }
	// Now calc from/to positions in work area..    
    sfx = stx = 0;	// Scratch-3 is the big area..
    sfy = sty = 0;
    if (fx > tx) {
      sfx += difx;
      xpos = tx;
    } else {
      stx += difx;
    }
    if (fy > ty) {
      sfy += dify;
      ypos = ty;
    } else {
      sty += dify;
    }
		// Get area of screen to be used..
    BitBlt (hScratch.DC,0,0,bigx,bigy,hDC, xpos,ypos,SRCCOPY);
    		// Get old background, wiping old piece
    BitBlt (hScratch.DC,sfx,sfy,pSpr->lx,pSpr->ly, hLast.DC, 0,0,SRCCOPY);
		// Save new background, for next time..    
    BitBlt (hLast.DC,0,0,pSpr->lx,pSpr->ly,hScratch.DC, stx,sty,SRCCOPY);
		// Take area of screen to use, AND with mask, put in scratch
    BitBlt (hScratch.DC,stx,sty,pSpr->lx,pSpr->ly, bmpi->hMaskDC,xpix,ypix,SRCAND);
		// Merge in piece with background with OR..
    BitBlt (hScratch.DC,stx,sty,pSpr->lx,pSpr->ly, bmpi->hDC,xpix,ypix,SRCPAINT);
    if (fnDelay) (*fnDelay) ();	// Sync to screen refresh?
    		// Copy result back to screen.
    BitBlt (hDC,xpos,ypos,bigx,bigy, hScratch.DC,0,0,SRCCOPY);
}

  // Slide a piece across the screen..
void d2d_Slide (HDC hDC, spr_SPRITE *pSpr, short fxpos, short fypos, short txpos, short typos, short cpiece, short cspeed, void (*fnDelay)() )
{
	short temp;
	short fx,fy;
	pSpr->cspr = cpiece;
	
	d2d_InitMove (pSpr);
	d2d_PutAt (hDC, pSpr, fxpos,fypos);
	while (txpos != fxpos || typos != fypos) {
	  fx = fxpos; fy = fypos;
	  	// Calc next pos..
	  if (txpos != fxpos) {
	    temp = txpos - fxpos;
	    if (temp > cspeed) temp = cspeed;
	    if (temp < -cspeed) temp = -cspeed;
	    fxpos += temp;
	  }
	  if (typos != fypos) {
	    temp = typos - fypos;
	    if (temp > cspeed) temp = cspeed;
	    if (temp < -cspeed) temp = -cspeed;
	    fypos += temp;
	  }
	  d2d_Move (hDC, pSpr, fx,fy,fxpos,fypos,fnDelay);
	}
	d2d_Restore (hDC, pSpr, fxpos,fypos);	// clr old..
	d2d_EndMove ();
}

static short lastxpos,lastypos;		// Keeps last pos for Piece pickup..

  // Pickup a piece with the mouse..
void d2d_PiecePickUp (HDC hDC, spr_SPRITE *pSpr, short mousex, short mousey)
{
	mousex -= (pSpr->lx >> 1); mousey -= (pSpr->ly >> 1);
	d2d_InitMove (pSpr);
	d2d_PutAt (hDC, pSpr, mousex,mousey);
	lastxpos = mousex; lastypos = mousey;
}

void d2d_PieceMove (HDC hDC, spr_SPRITE *pSpr, short mousex, short mousey)
{
	mousex -= (pSpr->lx >> 1); mousey -= (pSpr->ly >> 1);
	d2d_Move (hDC, pSpr, lastxpos,lastypos,mousex,mousey,NULL);
	lastxpos = mousex; lastypos = mousey;
}

void d2d_PieceDrop (HDC hDC, spr_SPRITE *pSpr, short mousex, short mousey)
{
	mousex -= (pSpr->lx >> 1); mousey -= (pSpr->ly >> 1);
	d2d_Restore (hDC, pSpr, lastxpos,lastypos);	// clr old..
	d2d_EndMove ();
}

void d2d_PieceKill ()
{
	d2d_EndMove ();		// Wipe any old HDC/BMPs..
}

  // Rescale components within a sprite object to %..
void d2d_SpriteRescale (spr_SPRITE *pSpr, WORD xscale, WORD yscale)
{
	WORD cspr;
	pSpr->lx = (WORD) MUL_DIV (pSpr->lx,xscale,100);
	pSpr->ly = (WORD) MUL_DIV (pSpr->ly,yscale,100);
	for (cspr = 0; cspr < spr_MAXPIECES; cspr++) {
	  pSpr->ppos[cspr].x = (WORD) MUL_DIV (pSpr->ppos[cspr].x,xscale,100);
	  pSpr->ppos[cspr].y = (WORD) MUL_DIV (pSpr->ppos[cspr].y,yscale,100);
	}
}

//--------------------------------------------------------------
// MODULE: title_  Generic titleDat screen routines..
//--------------------------------------------------------------

TITLE_DATA titleDat;

#define title_BMP_INDEX 0	// Index of bitmap..
LRESULT CALLBACK title_WndProc (HWND,UINT,WPARAM,LPARAM);

void title_Checker2D (HDC hDC,HINSTANCE hInstance, RECT rct)
{
	int cxpos,cypos;
	const int SqSize=16;
        HBITMAP hBmp = NULL;	// Handle for logo bmp
        HBITMAP hOldBmp;
        HDC hPatDC;		// DC for logo bmp
        BYTE crnd = 0;
        hBmp = LoadBitmap (hInstance, "ChkPat");	// Load logo bitmap
        if (hBmp) {
	  hPatDC = CreateCompatibleDC (hDC);
          hOldBmp = (HBITMAP) SelectObject (hPatDC,hBmp);
	  for (cypos = rct.top; cypos <= rct.bottom; cypos += SqSize) {
	    for (cxpos = rct.left; cxpos <= rct.right; cxpos += SqSize) {
	      BitBlt (hDC, cxpos, cypos, SqSize, SqSize, hPatDC,
	      	(((cxpos ^ 0x58a5) * cypos - (cxpos >> 3)) & (1 << (crnd & 15))) ? SqSize:0,0,SRCCOPY);
	      crnd ++;
	    }
	  }
	  SelectObject (hPatDC,hOldBmp);
	  DeleteDC (hPatDC);
	  DeleteObject (hBmp);
	}
}

static LOGFONT lfBig = {	// Define special big font
  -60,0,0,0,FW_BOLD,1,0,0, 
  ANSI_CHARSET, OUT_STROKE_PRECIS, CLIP_STROKE_PRECIS, PROOF_QUALITY, 
  FF_ROMAN | VARIABLE_PITCH,"Courier New"}; 
  
	// Draw a big header..
MYINLINE void title_BigHeader (HDC hDC, char *hstr, int hxpos, int hypos, int size)
{
	HFONT hBigFont = NULL;		// Font for big lettering
	SIZE ExtTxt;
        int tlen,xpos;
        const int mode = 1;
	HFONT hOldFont = NULL;
	SetTextColor (hDC, RGB (255,255,255));
	SetBkColor (hDC, RGB (0,0,0));
	lfBig.lfHeight = size;
	lfBig.lfWidth = size / 2 - size/8;
		// Create a big font
	hBigFont = CreateFontIndirect (&lfBig);   // create new logical font
	if (hBigFont == NULL) {		// Could not do it, select system..
	  hBigFont = (HFONT) GetStockObject (SYSTEM_FIXED_FONT);
	}
	SelectObject (hDC,(HPEN) GetStockObject (BLACK_PEN));
	SelectObject (hDC,(HBRUSH) GetStockObject (LTGRAY_BRUSH));
	hOldFont = (HFONT) SelectObject (hDC,hBigFont);
	tlen = strlen (hstr);
	GetTextExtentPoint (hDC,hstr,tlen,&ExtTxt);
		// Write black shadow
	SetBkColor (hDC, RGB (0,0,0));
	SetBkMode (hDC,TRANSPARENT);
	SetTextColor (hDC, RGB (0,0,0));
	TextOut (hDC, hxpos - (ExtTxt.cx >> 1) + 21,
	      hypos + 40, hstr,tlen);
	for (xpos = 1; xpos < 40; xpos ++) {
	  if (xpos == 39) {
	    SetTextColor (hDC, RGB (255,255,255));
	  } else {
	    //SetTextColor (hDC, RGB (rand (),rand(),rand()));
	    SetTextColor (hDC, RGB (20 + xpos*5,20 + xpos*5,20 + xpos*5));
	  }
		// Write text..
	  TextOut (hDC, hxpos - (ExtTxt.cx >> 1) + xpos - 20,hypos + xpos,hstr,tlen);
	}
		// Select old font back
	SelectObject (hDC,hOldFont);
	if (hBigFont) DeleteObject (hBigFont);
}


void title_ShowBitmap (HDC hOutDC, HDC hBmpDC, int hxpos, int hypos, int sizex, int sizey, int mode)
{
	if (mode & 1) {		// Auto-center x..
	  hxpos -= (sizex >> 1);
	}
	if (mode & 2) {		// Auto-center x..
	  hypos -= (sizey >> 1);
	}
	SelectObject (hOutDC,(HBRUSH) GetStockObject (NULL_BRUSH));
	SelectObject (hOutDC,(HPEN) GetStockObject (BLACK_PEN));
	Rectangle (hOutDC,hxpos - 1,hypos - 1,hxpos + sizex + 1, hypos + sizey + 1);
	BitBlt (hOutDC, hxpos, hypos, sizex, sizey, hBmpDC,0,0, SRCCOPY);
}


LRESULT CALLBACK title_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    RECT mrct;
    HDC hDC;
    HINSTANCE hInstance = GetInstance (hWnd);
    switch (wMsg) {  
      case WM_PALETTECHANGED:
      case WM_QUERYNEWPALETTE:
	  { LRESULT lr;	// serve WM_PALETTECHANGED/WM_QUERYNEWPALETTE msgs
	    if (wio_PaletteServe (&lr,hWnd,wMsg,wParam,titleDat.phBmp->hPal)) {
 	      return lr;
	    }
	  }
	  break;
      case WM_PAINT: {		// Main Screen redraw 
	hDC = BeginPaint(hWnd, &ps);    // get device context
        if (titleDat.UseBmp) {
	  SelectPalette (hDC, titleDat.phBmp->hPal, TRUE);	// get palette for window
	  RealizePalette (hDC);
	}
	GetClientRect (hWnd, &mrct);	// Get window size
        title_Checker2D (hDC, hInstance, mrct);
        if (titleDat.UseBmp) {
          BMPITEM *pItem = &titleDat.phBmp->i[title_BMP_INDEX];
	  title_ShowBitmap (hDC, pItem->hDC, mrct.right >> 1, 
	    	(mrct.bottom / 2), pItem->lenx, pItem->leny, 3);
        } else {
          title_BigHeader (hDC, titleDat.szProgName, mrct.right >> 1,8,-68);
        }
	EndPaint(hWnd, &ps);            // painting complete
	return 0;
      }
    }
    return ( DefWindowProc (hWnd, wMsg, wParam, lParam) );
}


  // Title screen routine..
int title_Screen (TITLE_DATA *pTitle)
{
    WNDCLASS wndclass;
    //MSG wMsg;                     // message from GetMessage
    HWND title_hWnd ;
    int StartMode = 0;
    static BMPHEAD bhBmp;	// Local Bitmap data..
    short cret;
    
    titleDat = *pTitle;		// Copy data over..
    titleDat.phBmp = &bhBmp;
    memset (titleDat.phBmp, 0, sizeof (BMPHEAD));
    bmp_Reset (&bhBmp, BMP_RST_INIT | BMP_RST_WIPE); // Init Bmp store obj, ready to use..
    if (file_Exists (titleDat.szBmpFile)) {
      bmp_Add (&bhBmp,title_BMP_INDEX,titleDat.szBmpFile,0,0,0,0);
    } else {
      titleDat.UseBmp = FALSE;
    }
    cret = bmp_LoadAll (&bhBmp,BMP_LOAD_MAKEDC);
    if (cret) titleDat.UseBmp = FALSE;	// Error during loading..
    
    if (titleDat.szClass == NULL) {
      titleDat.szClass = "TitleClass";
      wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
      wndclass.lpfnWndProc   = (WNDPROC) title_WndProc;
      wndclass.cbClsExtra    = 0;		// no extra class data
      wndclass.cbWndExtra    = 0;		// no extra window data
      wndclass.hInstance     = titleDat.hInst;	// which program?
      wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);    // stock arrow cursor
      wndclass.hIcon         = LoadIcon(titleDat.hInst,"OurIcon");
      wndclass.lpszMenuName  = NULL;	// No resource menu (szMainWinClass)
					     // no background (use own rect)
      wndclass.hbrBackground = (HBRUSH) GetStockObject(GRAY_BRUSH);
      wndclass.lpszClassName = titleDat.szClass; // window class name
      RegisterClass(&wndclass); // register the class
    }
    
    title_hWnd  = CreateWindow (titleDat.szClass, "",
    	WS_POPUPWINDOW | WS_BORDER,  // style
	0,        // default x position
	0,        // default y position
	100,
	100,
	NULL,                 // parent's handle
	NULL,                 // menu handle
	titleDat.hInst,            // which program?
	NULL);                // no init data
    ShowWindow (title_hWnd , SW_SHOWMAXIMIZED );
    // message loop
    //while ( GetMessage(&wMsg,0,0,0) ) {  // get message from Windows
    //  TranslateMessage(&wMsg);       // convert keystrokes
    //  DispatchMessage(&wMsg);        // call windows procedure
    //}
   if (titleDat.pfnDialog) (titleDat.pfnDialog) ();

   DestroyWindow (title_hWnd);
   bmp_Reset (&bhBmp, BMP_RST_DEL_OLD | BMP_RST_WIPE | BMP_RST_RAW); // Clr old bmp data..
   return StartMode;
}


