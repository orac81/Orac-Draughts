// DBEND.H - header for endgame database..

int DBInit(char *, short, short);
long DBLookup (long far *, int);
void DBFinish ();


#define	DB_WIN		   1600
#define	DB_TIE		      0
#define	DB_LOSS		  -1600
#define	DB_UNKNOWN	  -9999
