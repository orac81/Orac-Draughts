// Header file for GENIO.C - general purpos IO routines..

#define READ 0
#define WRITE 1
#define READ_WRITE 2

#if _DEBUG
 #define FASTCALL 
#else
 #define FASTCALL 
#endif

short bfFileOpen (char far *, short , USHORT, short);
BYTE far * bfFileRead (short, long, USHORT);
short bfFileWrite (short, BYTE far *, long, USHORT);
void bfFileClose (short);
short bfLineRead (short, char *, short);
void BufReset ();
short LineInput (HFILE, char *, short, short);
short LineOutput (HFILE, char *);
short LoadHugeFile (char *, char HUGE_ *,long, long);
short SaveHugeFile (char *,char HUGE_ *,long);
short CopyAFile (char *, char *);
long GetDiskSize (short);
BOOL FileExists (char far *);
short EndStrIs (char far *, char *);
void ChangeExt (char far *, char);
short ModifyFile (char far *, long, long);
long GetFileLen (char *);
void mySrand (USHORT);
short myRand (void);
void time2asc (char *, long , short );
void int2asc (char *, short , short );
long str2val (char *, short , short );
short StrConvCpy (char far *, char far *, short );
short genParseToken (BYTE *, BYTE far *);
char * GetNthStr (char *, short);
short inchr (char *, short );
void StructMv (char far *, char far *, short);
short StructEq (char far *, char far *, short);
void SoundIt (void);
void BeepSnd (void);
void Dink (void);
void gotoxy (short , short ); 
short wherex (void);
short wherey (void);
void printc (short);
void lprintc (short);
void printatime (long, short);
void bufferon (void); 
void bufferoff (void);
void printl (long);
void prints (char *);
void printsi (char *,short);
void printsl (char *,long);
void printi (short);
void printi2 (short);
void printi3 (short);
void printnc (short, short);
short msgprintf (HDC, short, short, char *,...);
short xprintf (char *,...);
short IsKeyHit (USHORT);
void GetMyPDC (HWND, HDC *,short);
void ReleaseMyPDC (HWND, HDC *);
void GetMyDC (short, short);
void ReleaseMyDC (short);
void draw3dbox (void);
void drawlines (void);
char * IDM2String (short);
BOOL SaveDialog (char *, char *, short, BYTE);
BOOL OpenDialog (char *, char *, short);

// -----------------------------------------------------------------------
//  Gen purpose macros..

	// Size of an array in elements, not bytes..
#define aSizeOf(Array) (sizeof (Array) / sizeof (Array [0]))
	// Quick Int to 2 digits of ascii conversion macro
#define INT2ASC2(Cstr,Cint) \
	*(Cstr) = ((Cint) / 10) | 48; Cstr ++; \
	*(Cstr) = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick Int to 3 digits of ascii conversion macro
#define INT2ASC3(Cstr,Cint) \
	if ((Cint) > 99) {*Cstr = ((Cint) / 100) | 48;} else {*Cstr = ' ';}\
	 Cstr ++;\
	if ((Cint) > 9) {*Cstr = (((Cint) / 10) % 10) | 48;} else {*Cstr = ' ';}\
	 Cstr ++;\
	*Cstr = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick Int to 2 digits of ascii conversion macro
#define INT2ASC2NOLEAD(Cstr,Cint) \
	if ((Cint) > 9) {*(Cstr) = ((Cint) / 10) | 48; Cstr ++;} \
	*(Cstr) = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick Int to 3 digits of ascii conversion macro
#define INT2ASC3NOLEAD(Cstr,Cint) \
	if ((Cint) > 99) {*(Cstr) = ((Cint) / 100) | 48; Cstr ++;} \
	if ((Cint) > 9) {*(Cstr) = (((Cint) / 10) % 10) | 48; Cstr ++;} \
	*(Cstr) = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick add-string and advance macro..
#define ADDSTR(Cstr,Istr) \
	{ char *xstr = Istr; \
	  while (*xstr) { *Cstr = *xstr; Cstr ++; xstr ++; } \
	}
	
	// Quick add-char and advance macro..
#define ADDCHAR(Cstr,Cchr) \
	*(Cstr) = Cchr; Cstr ++;
	
	// Swap var macro..
#define SWAPVAR(Var1,Var2,Type) \
	{Type xxtmp; xxtmp = Var1; Var1 = Var2; Var2 = xxtmp;}
	
	// Keep var in a range..
//#define KEEPRANGE(Var,Lo,Hi) min (max (Lo,Var),Hi)

/*typedef struct {
  BYTE lo,hi;
} SPLITWORD;
	
typedef struct {
  short lo,hi;
} SPLITLONG;
	
typedef struct {	// Crack into long word
  BYTE b1,b2,b3,b4;
} LONG2BYTE;
*/

extern short curx,cury;	// Cursor pos for PRINTC.. subs
extern short tprintflag;	// ==1 for printer, ==2 for Spool->OutFile
extern short nprint;	// char count for printing..
extern short VertOff;	// Vertical offset pixels for printing (norm=0)
extern short HorizOff;
extern short PrtCount;	// When set, PrtBuffer recieves printed output
			// if (tprintflag == 3) Dec until zero, then no more
extern char *PrtBuffer; // Ptr to print-mem-buffer..

extern char MenuStr [];		// String for IDM_ to str routine..

#define ABORT_PROG 9999		// MsgPrintf options..
#define USEOPTIONS 9998

typedef struct {	// Data Struct for Button routine..
  char *str;		// string of button txts, null term.
  short tx, ty; 		// top left to start buttons
  short lx,ly;		// x/y size, +x=*nchrs..
  short xend; 		// Wrap about point..
  short num;		// no of buttons..
  short bx;		// Bottom -right edge..
  HWND hOwner;		// Window with buttons. NULL=just repos..
  HWND hButton [20];
} BUTTONINFO;

#define Button 10000		// Code for user buttons..
extern USHORT nLastRead;		// Global - # bytes in last read..

		// Struct for custom edit control..
typedef struct {
  short x,y;	// Top x/y position of field.
  short len;	// Max len of edit field
  short totlen;   // len inc prompt
  short type;	// flags - bit 0 set for right justify..
  long val;	// current value, if numeric..
  		// bit 1 set for numeric. bit 0 for right justify
  char *prompt; // left prompt (INCLUDES PRINTF FORMATTING)
  char str[15];	// edit string
  HDC *hdc;	// Ptr to Device context for field..
  HWND *hWnd;	// Ptr to window handle for field
} EDITINFO;

extern HWND hAWnd [12];	// Array of windows..
extern HDC hADC [12];	// Array of device contexts..
extern HDC hWDC;	// The current Handle Device Context (HDC) can be..
extern HDC hHotDC;	// HDC for hot key bmps
extern HANDLE hInstance; // Instance of application

typedef struct {	// Info on a TOOLBAR - row of hotkeys..
  short lenx,leny;	// size of each key
  short bmpx,bmpy;	// position in BMP file (HOT.BMP)
  short num;		// No of hotkeys in this 
  short nhoriz;		// point to wrap & start new line
  //short index;		// val to add to hotket for unique ret value
  short *idm;		// Pointer to array of IDM_ codes to post..
  			// add (num) for right-button codes..
  short keyx,keyy;	// top left of key bitmaps on window..
  short wnd;		// Window-index into hAWnd/hADC arrays
  char far *txt;	// Ptr to Text for info-string, if any.
  HFONT bFont;		// Font for text-buttons..
  short hmode;		// bit 0 - set to send MenuStr to Main Window title-bar
  			// Bit 1- send txt info to title bar
  			// Bit 2- auto-center xpos..
  			// Bit 3- use txt to create buttons..
  			// Bit 4- allow use of right-button for extra cmds..
} HOTKEYINFO;

extern HOTKEYINFO *HotLastInfo;	// Ptr to info on last pressed
//extern short HotKeyCmds [];

extern OPENFILENAME ofn;           // for GetOpenFileName()
	// Quick-access globals..
extern short ltx,lty,lex,ley;	// top/bott ptrs
extern HDC hTDC;		// Temp DC
extern HPEN hPen1,hPen2;	// temp pens

#define SIZEszTemp 2048
extern char szTemp [SIZEszTemp + 10];	// Temp general buffer

	// Compare 2 structures..
#define StructEQ(Ptr1,Ptr2) \
  StructEq ((char far *) Ptr1, (char far *) Ptr2, sizeof ((Ptr1) [0]))
	// Copy a structure..
#define StructMV(Ptr1,Ptr2) \
  StructMv ((char far *) Ptr1, (char far *) Ptr2, sizeof ((Ptr1) [0]))

	// Info on each buffered file open..
typedef struct {
  HGLOBAL hGlobal;	// Memory handles
  HFILE hFile;		// Handle of files..
  BYTE far *Ptr;	// Memory pointers..
  long fPos;		// Cur pos in file
  long BufPos;		// Cur pos in file of buffer start
  USHORT Size;		// Size of buffer
  USHORT LastRead;	// # bytes in last disk-read
  long WrtPos;		// Current write pos in buffer..
} bfFILE;

#define bfMAX_FILES 7		// Max # buffered files open..

extern bfFILE bfFiles [bfMAX_FILES + 2];
	// Is a file open Macro..
#define bfIsFileClosed(Ind) (bfFiles[Ind].hGlobal == NULL)

//--------------------------------------------------------------------
// More funct declares, dependand on above struct declarations
//

void ProcessEditField (EDITINFO *, short , short );
void DrawHotKeys (HOTKEYINFO *);	// Function declare
short ProcessHotKey (HOTKEYINFO *, short );
void ButtonsOn (BUTTONINFO *, short);
void ButtonsOff (BUTTONINFO *);

//----------------------------------------------------------------------
// PC SOLUTIONS Comment routines
//   .H Declarations for these..
//----------------------------------------------------------------------

#define comTYPE far	// For Comments <64K=far,>64K=huge..
#define comSIZE short	// Size of index vars: <64=short, >64K=long
#define comAUTOLEN 0xffff	// Automatic len find flag

BOOL comInitialise ();
void comFinish ();
BYTE comTYPE *comAddBlock (USHORT, BYTE comTYPE *, USHORT);
BYTE comTYPE *comGetWholeBlock (USHORT *);
short comReadBlock (USHORT , BYTE far *, USHORT, BYTE );
BYTE comTYPE *comGetPtr (USHORT, USHORT *);
BYTE comTYPE *comAllocNew (USHORT);

//----------------------------------------------------------------------
// PC SOLUTIONS GENERAL PURPOSE DYNAMIC DIALOG ROUTINES
//   .H Declarations for these..
//----------------------------------------------------------------------

#define IDD_EDIT 1010		// IDD_s start for edit fields
#define IDD_SPIN 1400		// IDD_s start for spin fields
#define IDD_SLIDERS 1500	// IDD_s start for sliders..
#define IDD_SLIDETEXT 1550	// IDD_s start for slider text
#define IDD_BUTTONS 1600	
#define IDD_FLAGBUTTONS 1680	// Used to control (GroupFlags) sub groups
#define IDD_COMBO 1700
#define IDD_CHECK 1750		// IDD for check boxes
#define IDD_AUTOIDD 1800	// Tells DialogDef to auto gen one..
#define IDD_MIXED 1801		// IDDs for auto gen IDD ctrls..
#define IDD_RADIO 2048		// IDD for radio buttons..(..2400)
		// Misc dialog flags defines..
#define DD_HIDE ((char) 0x8000)
#define D_SECS 1		
#define D_TITLE 2
#define DD_SPECIAL ((short) 0x8000) // Bit means special group-select combo
#define D_LISTBOX 2	 // Bit means permanant (non drop-down)
#define D_OFF 0
#define D_GROUPBOX 0x4000	// Means buttons have group box about them..

#define SetGroup(cGr) CurGroup = cGr;

	// Some preset dialog control types..
	// Used by (dcontrol) array.
#define dBUTTON 0
#define dEDIT 1
#define dTEXT 2
#define dLISTBOX 3
#define dSCROLLBAR 4
#define dCOMBOBOX 5
#define dEDITBOX 6
#define dICON 7
#define dFRAME 8
#define dCHECK 9
#define dRADIO 10
#define dGROUPBOX 11

typedef struct {	// DATA for flags (check-boxes)..
  char far *flag;	// ptr to char flag
  BYTE mask;		// Bit to use..
  char inv;		// nz if inverted flag (set if on by default..)
  char **str;		// ptr to a ptr to associated text
} FLAG_DATA;

extern short DlgButton;		// IDD_ Val of button pushed
extern BOOL DoingDialog;	// Window to get capture..
extern short DlgTopx,DlgTopy;	// Size of current dialog box in DBU's
extern short DlgLenx,DlgLeny;
extern short DlgPixx,DlgPixy;	// Size dialog in pixels..
extern short IddFocus;		// IDD_ no for Focus field
extern short PalRGBx,PalRGBy;	// X/Y loc of RGB colour display box, x=0:none used
extern short PalRGBwide;		// Width of box to be displayed
extern short PalRGBslider;	// Width of box to be displayed
extern short CurGroup;		// Current control group.. 0=none.
extern short GroupFlags;		// Used to control groups within groups
extern short DBUx;		// Pixels per char width (/4 for dlg unit)
extern short DBUy;		// Pixels per char hieght(/8 for dlg unit)
extern BYTE saveclock;		// temp used to save clock status
extern OFSTRUCT ofBuf;		// Struct for open file..

	// PCS DIALOG API Function declarations..
short DialogBeg (char *,short,short,short,short, short);
void DialogEnd ();
void DialogDef (BYTE,char *,short,short,short,short ,short ,long );
void TextDef (short , short , char *);
void TextCentDef (short, short, char *);
void EditDef (short,short,char *,char far *,short,short,short);
void SliderDef (long,short,short,short,short,short,short,short,short,short,short,short);
void SliderTDef (char *,short,short,short,short,short,short,short,short,short);
short ReadSlider ();
void SpinDef (short,short,short,long,long,long,BYTE,short);
void SpinTDef (short,short,short,long,long,long,BYTE,short,char *,short);
long ReadSpin ();
void ComboDef (char *,short,short,short,short,short,short);
void ComboTDef (char *,short,short,short,short,short,short,char *);
short ReadCombo ();
void CheckDef (short,short,short,char *,short);
short ReadCheck ();
void DefTicks (FLAG_DATA *,short,short,short,short,short,short,char *);
void ReadTicks (FLAG_DATA *);
void FlagToDefault (FLAG_DATA *);
void RadioDef (short,short,short,short,char *,short);
short ReadRadio ();
void TimeSpinDef (short,short,long,short);
void TimeSpinTDef (short,short,long,short,char *,short);
long ReadTimeSpin (short);
void DialogDo (HWND);
BOOL CALLBACK GenDlgProc(HWND, USHORT, WPARAM, LPARAM);
void LockFocus ();
void ReleaseFocus ();
void DialogInit (void);
void TextIn (char *, char *, short , HWND );
