// General purpose IO routines..
// Copyright A.Millett, 1995

#define STRICT		// strict type checking (put before #include)
#include <windows.h>	// include file for all Windows programs
#include <stdlib.h>	// RAND
#include <stdio.h> 
#include <string.h>	// STRLEN 
#include <ctype.h>	// ISDIGIT 
#include <mmsystem.h>	// Multimedia inc (SOUND..)
#include <stdarg.h>	// for VPRINTF, VA_ARG..
#include <dos.h>	// Defines misc disk functions
#include <commdlg.h>	// for common dialogs (print..

#include "sageio.h"	// Generic IO code..
#include "genio.h"	// Header for this module..
#include "sagemain.h"	// For main prog..
#include "chengine.h"	// A few flags needed from engine
		// - FlagSound, eng.clock_flag, etc..

char szTemp [SIZEszTemp + 10] = "";	// Temp file I/O general buffer

OFSTRUCT ofBuf;		// Struct for open file..

	// Buffered File Access routines..

bfFILE bfFiles [bfMAX_FILES + 2] = {
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0
};

USHORT nLastRead;		// Global - # bytes in last read..

  // Open a buffered file for read, allocate some buffer mem for it..
  // if findex < 0, search for 1st empty slot..
  // fmode = READ/WRITE/READ_WRITE mode..
  // Ret FINDEX if alloc ok, otherwise  HFILE_ERROR..
short bfFileOpen (char far *fname, short findex, USHORT bufsize, short fmode)
{
	bfFILE *bf;
	if (findex < 0) {
	  findex = bfMAX_FILES;
	  while (bfFiles [findex].hGlobal != NULL) {
	    findex --;
	    if (findex < 0) return HFILE_ERROR;
	  }
	}
	bf = bfFiles + findex;
	if (bf->hGlobal) {		// Already open, close old..
	  bfFileClose (findex);
	}
	bf->hFile = _lopen (fname, fmode);
        if (bf->hFile == HFILE_ERROR) return HFILE_ERROR;
	bf->hGlobal = GlobalAlloc (GMEM_MOVEABLE, 10L + (long) bufsize);
	if (bf->hGlobal == NULL) {	// Unable to alloc mem..
	  _lclose (bf->hFile);
	  return HFILE_ERROR;
	}
	bf->Ptr = GlobalLock (bf->hGlobal);
	bf->Size = bufsize;
	bf->BufPos = 0x7fffffff;	// No data read so far..
	bf->fPos = 0;
	bf->WrtPos = 0;			// Write pos..
	return findex;
}

	// Ret ptr to mem block in file at (obpos), size (obsize)
	// Set (obpos) to -1 to read-next block..
	// Ret NULL if past end/error..
BYTE far * bfFileRead (short findex, long obpos, USHORT obsize)
{
	bfFILE *bf = bfFiles + findex;
	if (bf->hGlobal == NULL) return NULL;
	if (obpos == -1) {		// Just read next block..
	  obpos = bf->fPos;
	}
		// See if requested file-data is in buffer..
	if (obpos - bf->BufPos >= 0 && 
	  obpos + ((long) obsize) - bf->BufPos < (long) bf->Size) {
	    nLastRead = (USHORT) bf->LastRead - (USHORT) 
	    	((long) bf->fPos - bf->BufPos);	// Calc # good bytes
	    bf->fPos = obpos + (long) obsize;	// Move to new loc..
	    return (bf->Ptr + obpos - bf->BufPos);
	}
		// Move to new pos in file..
        if (_llseek (bf->hFile, (long) obpos, SEEK_SET) == HFILE_ERROR) {
          return NULL;	// error..
        }
		// Read new buffer block
	nLastRead = _lread (bf->hFile, bf->Ptr, bf->Size);
	bf->LastRead = nLastRead;
	if (nLastRead == HFILE_ERROR) return NULL;
	if (nLastRead < bf->Size) bf->Ptr [nLastRead] = 0; // NULL at end..
	bf->BufPos = obpos;
	bf->fPos = obpos + min (nLastRead,obsize);
	return (bf->Ptr);
}

  // Write to buffered index file.. obpos = -1 for next write pos..
short bfFileWrite (short findex, BYTE far *ostr, long obpos, USHORT obsize)
{
	USHORT nwrite;
	bfFILE *bf = bfFiles + findex;
	if (bf->hGlobal == NULL) return HFILE_ERROR;
	if (obpos == -1) {		// Just write next block..
	  obpos = bf->WrtPos;
	}
        if (_llseek (bf->hFile, (long) obpos, SEEK_SET) == HFILE_ERROR) {
          return HFILE_ERROR;	// error..
        }
	nwrite = _lwrite (bf->hFile, ostr, obsize);
	bf->WrtPos = obpos + nwrite;	// Move ptr on..
	return (nwrite);
}

	// Close a file, de-allocate its buffer
	// (-1 to close ALL files..)
void bfFileClose (short findex)
{
	short fstart = findex;
	short fend = findex;
	if (findex < 0) {	// Close all files..
	  fstart = 0; fend = bfMAX_FILES;
	}
	for (findex = fstart; findex <= fend; findex ++) {
	  if (bfFiles [findex].hGlobal != NULL) {	// File open..
	    GlobalUnlock (bfFiles [findex].hGlobal);
	    GlobalFree (bfFiles [findex].hGlobal);
	    _lclose (bfFiles [findex].hFile);
	    bfFiles [findex].hGlobal = NULL;		// Free up slot
	  }
	}
}

  // Read an ascii line of text (max ilen chars) into near mem
  // Return len, -1 if past end of file.. 
short bfLineRead (short findex, char *istr, short mlen)
{
	short cpos;
	short maxpos;
	char cchr;
	short nread;
	long filpos;
	BYTE far *fstr;
	bfFILE *bf = bfFiles + findex;
	if (bf->hGlobal == NULL) return -1;	// File not open, error..
	filpos = bf->fPos;
	fstr = bfFileRead (findex, -1, 1024);
	if (fstr == NULL) return -1;
	maxpos = min (1024,nLastRead);
	mlen = min (mlen,maxpos);
	cpos = 0;	
	while (cpos < mlen && cpos < maxpos) {	// Read in string..
	  cchr = fstr [cpos];
	  if (cchr == 13 || cchr == 10) break;
	  istr [cpos] = cchr;
	  cpos ++;
	}
	nread = cpos;
	istr [cpos] = 0;
		// Skip to next Line Feed..
	while (cpos < maxpos && fstr [cpos] != 10) {
	  cpos ++;
	}
	cpos ++;
	bf->fPos = filpos + cpos;	// Advance ptr to next line..
	return nread;		// Len of string..
}

//----------------------------------------------------------------------
// Other general purpose routines..
//----------------------------------------------------------------------

	// See if file exists, return 1 if it does..
BOOL FileExists (char far *ifile)
{
	HFILE hFl;
	hFl = OpenFile (ifile, &ofBuf, OF_EXIST);
	if (hFl == NO_FILE) {
	  return (FALSE);		// File dont exist
	}
	return TRUE;		// File exists.
}

  // Check to see if (str1) ends with given (str2), 
  // ret dif in len if it matches, ret -1 if no match
short EndStrIs (char far *str1, char *str2)
{
	short clen1 = lstrlen (str1);
	short clen2 = lstrlen (str2);
	if (clen2 > clen1) return -1;
	if (lstrcmpi (str1 + clen1 - clen2,str2)) {
	  return -1;	// No match
	}
	return clen1 - clen2;	// Ok, matches - ret dif in len!
}

void ChangeExt (char far *str1, char chr2) // Change file extension
{
	short clen1 = lstrlen (str1);
	if (clen1 < 1) return;
	str1 [clen1-1] = chr2;
}

  // Insert/Delete (nbytes) bytes at (movpos) from file (fname)
  // if (nbytes < 0) delete, if (nbytes > 0) insert
  // Return -1 if error..
short ModifyFile (char far *fname, long movpos, long nbytes)
{
	HFILE hFile = 0;	// File handle
	HGLOBAL hGlobMem = 0;// Handle on temp buffer memory
	BYTE far *dbuff;	// Temp buffer for moving data
	const USHORT buffsize = 0x7000;	// Size of buffer
	USHORT nread;
	long fsize;		// Size of file
	long fpos;		// Current file pos..
	short cret = HFILE_ERROR;	// Default error..
	if (nbytes == 0) return 0;	// No work to do!
	hGlobMem = GlobalAlloc (GMEM_MOVEABLE, buffsize + 20);
	if (hGlobMem == NULL) {
	  return (HFILE_ERROR);
	}
	dbuff = (BYTE far *) GlobalLock (hGlobMem);
	hFile = _lopen (fname, READ_WRITE);
        if (hFile == HFILE_ERROR) goto fError;
	fsize = _llseek (hFile, 0L, SEEK_END);	// Calc file len..
	if (fsize == HFILE_ERROR) goto fError;
        
        if (nbytes < 0) {	// DELETE (-nbytes)
          fpos = movpos;	// Start pos for delete..
          do {
            if (fpos - nbytes <= fsize) {	// Already past end..
	      if (_llseek (hFile, fpos - nbytes, SEEK_SET) == HFILE_ERROR) {
	        goto fError;
	      }
	    }
            nread = _lread (hFile, dbuff, buffsize);
            if ((short) nread == HFILE_ERROR) goto fError;
	    if (_llseek (hFile, fpos, SEEK_SET) == HFILE_ERROR) goto fError;;
            cret = _lwrite (hFile, dbuff, nread);
	    if (cret == HFILE_ERROR) goto fError;
            fpos += nread;
          } while (nread);	// Until 0 bytes written..(which auto-truncates)
	          
	} else {		// INSERT (nbytes)
          fpos = fsize ;	// Start pos for delete..
          do {
            nread = (USHORT) min ((long) buffsize, fpos - movpos);
            if (nread == 0) break; 	// No more, all done!
            fpos -= nread;
	    if (_llseek (hFile, fpos, SEEK_SET) == HFILE_ERROR) {
	      goto fError;
	    }
	    nread = _lread (hFile, dbuff, nread);
            if ((short) nread == HFILE_ERROR) goto fError;
	    if (_llseek (hFile, fpos + nbytes, SEEK_SET) == HFILE_ERROR) {
	      goto fError;
	    }
            cret = _lwrite (hFile, dbuff, nread);
	    if (cret == HFILE_ERROR) goto fError;
          } while (1);
        }
        cret = 0;		// No error code.
fError:				// Error ret jump loc
	_lclose (hFile);
	GlobalUnlock (hGlobMem);
	GlobalFree (hGlobMem);
	return (cret);
}

	// Calc total disk size in bytes..(1=A,2=B,3=C..)
long GetDiskSize (short drv)
{
    return 230000000L;
    /*
	struct _diskfree_t dspc;
	_dos_getdiskfree (drv, &dspc);
	return ((long) dspc.total_clusters * dspc.sectors_per_cluster * 
		dspc.bytes_per_sector);
    */
}

	// Get length of file in bytes, -1 (HFILE_ERROR) = file not exists
long GetFileLen (char *ifile)
{
	long fsize;
	HFILE hFile;
	hFile = _lopen (ifile, READ);
        if (hFile == HFILE_ERROR) return HFILE_ERROR;
	fsize = _llseek (hFile, 0L, SEEK_END);
	_lclose (hFile);
	return (fsize);
}

// Alt Simpler buffered IO..

#define DSKBUFSIZE 256
BYTE pDskBuf [DSKBUFSIZE + 4];
short cDskBuf,maxDskBuf;

void BufReset ()
{
	maxDskBuf = DSKBUFSIZE;
	cDskBuf = DSKBUFSIZE;	// Force read on 1st use..
}

short BufGetChar (HFILE ifile)	// Read 1 char from file, -1=EOF/error..
{
	if (cDskBuf > maxDskBuf) {	// overflow partial buffer?
	  return (-1);		// Error/EOF..
	}
	if (cDskBuf >= DSKBUFSIZE) {
	  maxDskBuf = _lread (ifile, pDskBuf, DSKBUFSIZE);
	  if (maxDskBuf < 1) return -1;		// Error/EOF..
	  cDskBuf = 0;
	}
	cDskBuf ++;
	return (pDskBuf [cDskBuf - 1]);		// return char 0-255
}

	// Input an asc line (term CR/LF) from file.
	// Ret nchars read, or -1 for EOF.. ilen ABS max to read
	// mode set for buffering
short LineInput (HFILE ifile, char *istr, short ilen, short mode)
{
	short tlen = ilen;	// Countdown of max chars
	short cl;
	do {
		// Read 1 char..
	  if (mode) {
	    cl = BufGetChar (ifile);
	    istr [0] = (char) cl;
	  } else {
	    cl = _lread (ifile, istr,1);
	  }
	  if (cl < 1) {
	    if (tlen == ilen) return (-1);	// EOF on 1st char..
	    break;				// Allow process line so far.
	  }
		//  printc (*istr); if (curx > 75) prints ("\n");
	  if (*istr == 13) break;	// CR= End of line
	  if (*istr == 10) continue;	// Skip LF..
	  if (tlen) {			// Count until max chrs
	    tlen --;
	    istr ++;
	  }
	} while (1);
	*istr = 0; 	// Replace CR/LF with null string end.
	return (ilen - tlen);
}

	// Write a null term string to file, adding CR/LF..
short LineOutput (HFILE ofile, char *ostr)
{
	short olen = lstrlen (ostr);
	short temp;
	ostr [olen] = 13;		// Add CR/LF..
	ostr [olen + 1] = 10;
	temp = _lwrite (ofile, ostr, olen + 2);
	ostr [olen] = 0;
	return (temp != HFILE_ERROR);	// Set if no error..
}

	// Load a HUGE block of data from a file at a given location
short LoadHugeFile (char *filename,char HUGE_ *brddata,long fstart, long datasize)
{
	USHORT nread,cread;
	HFILE hFile;
	hFile = _lopen (filename, READ);
        if (hFile == HFILE_ERROR 
            || _llseek (hFile, (long) fstart, SEEK_SET) == HFILE_ERROR) {
          return HFILE_ERROR;	// error..
        }
        do {		// Read 64K blocks of data, until EOF/all data
          cread = (USHORT) ((long) min (datasize,0xf000));
	  nread = _lread (hFile, brddata, cread);
	  if (nread == HFILE_ERROR) {
	    _lclose (hFile);
	    return HFILE_ERROR;
	  }
	  datasize -= nread;
	  brddata += nread;		// Advance data pointer..	 
	} while (cread == nread && datasize > 0);
	_lclose (hFile);
	return (0);
}

short SaveHugeFile (char *filename,char HUGE_ *brddata,long datasize)
{
	HFILE hFile;
	USHORT nwrite;
	short cerror = 0;
	hFile = _lcreat (filename,0);
	if (hFile == HFILE_ERROR) {
          return HFILE_ERROR;
	}
		// Write data in 60K chunks..
	do {
	  nwrite = (USHORT) ((long) min (datasize,0xf000));
	  if (_lwrite (hFile, brddata, nwrite) == HFILE_ERROR) {
	    cerror = HFILE_ERROR;
	    break;
	  }
	  datasize -= nwrite;
	  brddata += nwrite;
	} while (datasize > 0);
	_lclose (hFile);
	return cerror;
}

	// Copy a file.. ret 0=fail, 1=ok.
short CopyAFile (char *szReadFile, char *szWriteFile)
{
	HFILE hReadFile = 0, hWriteFile = 0;
	short nRead;
	short exitmode = 0;	// 0=error, 1= ok!
	SetWaitCursor 		// Macro - set hour-glass mouse..
	
	hReadFile = OpenFile (szReadFile, &ofBuf, OF_READ); 
	if (hReadFile == NO_FILE) {	// cannot read source
	  goto CopyFileError;
	}
	hWriteFile = OpenFile (szWriteFile, &ofBuf, OF_CREATE);
	if (hWriteFile == NO_FILE) {		// cannot write dest
	  goto CopyFileError;
	}
	do {		// Copy, chunk by chunk..
	  nRead = _lread (hReadFile, szTemp, SIZEszTemp);
	  _lwrite (hWriteFile, szTemp, nRead);
	} while (nRead > 0);	// Until zero, EOF..
	exitmode = 1;		// OK, worked!
CopyFileError:
	_lclose(hWriteFile); 
	_lclose(hReadFile); 
	SetNormCursor         // Normal mouse..     
	return exitmode;
}

  // rand/srand replacement functions.. 
  // (always gives same pattern, even on dif compilers)
static long mySeed = 1;

void mySrand (USHORT seed)
{
        mySeed = seed;
}

short myRand (void)
{
        mySeed = 0x015a4e35L * mySeed + 1;
        return ((short) (mySeed >> 16) & 0x7fff);
}


  // Build an ASC clock str "0:00:00" at (clkptr) for (xtime) secs
  // hflag - set bit 0 for hours, bit 1 for null-term..
void time2asc (char *clkptr, long xtime, short hflag)
{
	short itime;
	if (hflag & 1) {	// Show hours digit..
	  *clkptr = (char) ((long) 48 + ((xtime / 3600) % 10));
	  clkptr ++;
	  *clkptr = ':';
	  clkptr ++;
	}
			// Minutes..
	itime = (short) ((long) xtime % 3600);
	*clkptr = (char) ((short) 48 + (itime / 600));
	clkptr ++;
	*clkptr = (char) ((short) 48 + ((itime / 60) % 10));
	clkptr ++;
	*clkptr = (':');
	clkptr ++;
			// Seconds..
	itime = ((short) itime % 60);
	*clkptr = (char) ((short) 48 + (itime / 10));
	clkptr ++;
	*clkptr = (char) ((short) 48 + (itime % 10));
	if (hflag & 2) {		// Null term..
	  clkptr ++;
	  *clkptr = 0;
	}
}

  // Build an ASC short 000 format 
  // FORM - # digits, (bit 4 set = no leading zeros)
void int2asc (char *cptr, short cval, short form)
{
	short leadflag = form & 0xfff0;
	USHORT uval = cval;
	form &= 15;
	while (form) {
	  form --;
	  if (leadflag && uval == 0) {	// no leading zeros
	    cptr [form] = 32;
	  } else {
	    cptr [form] = (uval % 10) + 48;
	  }
	  uval = uval / 10;
	}
}

	// Convert string in given base to a val..
long str2val (char *istr, short base, short ndigits)
{
	long ret = 0;
	USHORT tmp;
	while (ndigits) {
	  tmp = *istr - 48;
	  if (tmp > 9) {
	    if (tmp < 17) break;
	    tmp -= 7;
	  }
	  if (tmp > (USHORT) base - 1) break;
	  ret = ret * ((long) base) + tmp;
	  ndigits --; istr ++;
	}
	return ret;
}

	// Copy string until " or NULL, converting \n, \0, \t, \xnn to asc..
short StrConvCpy (char far *szDest, char far *szSrc, short maxlen)
{
	short ncpy = 0;
	short cchr;
	do {
	  cchr = *szSrc;
	  if (cchr == 0 || cchr == 34) break;	// End of string
	  if (cchr == 92) {		// '\', special character..
	    szSrc ++;
	    cchr = *szSrc;
	    if (cchr == 0) break;	// Hit str end..
	    switch (cchr) {
	      case 'n': cchr = 10; break;
	      case '0': cchr = 0; break;
	      case 't': cchr = 9; break;
	      case 'r': cchr = 13;break;
	      case 'a': cchr = 7; break;
	      case 'x':		// 2 digits of hex..
	        szSrc ++;
	        cchr = (BYTE) str2val (szSrc,16,2);
	        szSrc ++;
	        break;
	      case ' ':		// 4 digits of hex..(2-byte)
	        szSrc ++;
	        cchr = (USHORT) str2val (szSrc,16,4);
	        szSrc += 3;
	        szDest [ncpy] = cchr & 0xff;
	        ncpy ++;
	        cchr >>= 8;
	        break;
	      case ',':		// Decimal..2-byte..
	        szSrc ++;
	        cchr = (USHORT) str2val (szSrc,10,5);	// Conv to DECIMAL..
	        szDest [ncpy] = cchr & 0xff;
	        ncpy ++;
	        cchr >>= 8;
	        while (isdigit (*szSrc)) szSrc ++;
	        szSrc --;
	        break;
	    }
	  }
	  szDest [ncpy] = (char) cchr;
	  szSrc ++; ncpy ++;
	} while (ncpy < maxlen - 1);
	szDest [ncpy] = 0;
	ncpy ++;
	return ncpy;
}

  // General Parse token from string..(ret 0 for no match found)
  // Param=ptr to token list (DOUBLE NULL-TERM)
  // Param2 = pointer to pointer to string (so that ptr can be mod)
  // Ret1..n token# from list (tutTokens) in LOBYTE
  // Ret len of token in HIBYTE
short genParseToken (BYTE *ptok, BYTE far *instr)
{
	BYTE far *pcode;		// ptr to code
	short ctoken = 0;			// Cur token #
	while (*ptok) {			// Until null terminate
	  ctoken ++;
	  pcode = instr;
	  while (*ptok && *ptok == *pcode) {	// See if chars match..
	    ptok ++; pcode ++;
	  }
	  if (*ptok < 31) {	// Matched to end of token, found it?
	  	// Only allow if not in middle of alpha-name..
	    if (isalnum (*pcode) == 0 || isalnum (*(pcode - 1)) == 0) {
	      //tutTokFlag = *ptok;	// Get Token flag from end
	      return (ctoken + (pcode - instr) *256);
	    }
	  }
	  while (*ptok >= 31) ptok ++;	// scan to try next token
	  ptok ++;
	}
	return (0);		// No token found.
}

  // Extract pointer to Nth string in list (0..n), quit on double null
char * GetNthStr (char *istr, short nstr)
{
	while (nstr) {
	  if (*istr == 0) break;	// Double null, exit..
	  while (*istr) istr ++;
	  istr ++;
	  nstr --;
	}
	return istr;
}

short inchr (char *bigstr, short fchr)	// Find char in BIGSTR (0..n,-1 fail) 
{
	short scount;
	for (scount = 0; bigstr [scount] != 0; scount ++) {
	  if (bigstr [scount] == fchr) {
	    return (scount);
	  }
	}
	return (-1);
}

	// Compare 2 struct elements, equal?
short StructEq (char far *ptr1, char far *ptr2, short slen) 
{
	while (slen) {
	  slen --;
	  if (ptr1 [slen] != ptr2 [slen]) return (FALSE);
	}
	return (TRUE);
}

	// Copy a struct element
	
void StructMv (char far *ptr1, char far *ptr2, short slen) 
{
	while (slen) {
	  slen --;
	  ptr1 [slen] = ptr2 [slen];
	}
}

//
// SOUND ROUTINES..
//

void SoundIt ()		// Make a biggish sound for game-end/error, etc
{
	if (FlagSound) {
	  szWavFile [5] = '1';
	  if (sndPlaySound (szWavFile, SND_ASYNC) == FALSE) {
	    MessageBeep (MB_ICONEXCLAMATION);
	    MessageBeep (MB_ICONEXCLAMATION);
	    MessageBeep (MB_ICONEXCLAMATION);
	  } 
	}
}

void BeepSnd ()	// Short sound, for move, etc..
{
	if (FlagSound) {
	  szWavFile [5] = '2';
	  if (sndPlaySound (szWavFile, SND_ASYNC) == FALSE) {
	    MessageBeep (MB_OK);       
	  } 
	}
}

void Dink ()	// Very Short sound
{
	if (FlagSound) {
	  szWavFile [5] = '3';
	  if (sndPlaySound (szWavFile, SND_ASYNC) == FALSE) {
	    MessageBeep (MB_OK);       
	  } 
	}
}

void DoMessage (char *message)	// Display a message in a box, with OK button
{
	short temp = 0;
	if (message [0] =='$') {
	  temp = MB_ICONINFORMATION;
	  message ++;
	}
	if (message [0] =='!') {
	  temp = MB_ICONEXCLAMATION;
	  message ++;
	}
	Dink ();
	//DoingDialog ++;
	MessageBox (NULL, message,STprogramname,MB_OK | MB_TASKMODAL | temp);
	//DoingDialog --;
}

	// Display a Yes/No choice box, with message
	// Returns IDYES or IDNO
short DoYesNo (char *message)
{
	short temp;
	Dink ();
	temp = MessageBox (NULL, message, STprogramname, 
		MB_TASKMODAL | MB_YESNO | MB_ICONQUESTION);
	return (temp);
}

//
// ORIG PRINTC/S routines.. with buffering
//

short bufferflag = 0;	// Set for faster buffered print
short bufferlen = 0;	// Curr n chrs in buf
char xstr [200], prbuffer [20];
#define PbufSize (sizeof (xstr) - 10)
short bufferx,buffery;

short curx = 1, cury = 1;		// Cursor pos for PRINTC.. subs
short tprintflag = 0;	// ==1 for printer, ==2 for Spool->OutFile
short nprint;		// char count for printing..
short VertOff = 0;	// Vertical offset pixels for printing (norm=0)
short HorizOff = 0;
short PrtCount = 0;	// When set, PrtBuffer recieves printed output
			// if (tprintflag == 3) Dec until zero, then no more
char *PrtBuffer = szTemp;

void bufferon () 	// Enable fast buffered screen-print (all 1 color only)
{
	bufferflag = 1;
	bufferlen = 0;
	bufferx = curx; buffery = cury;	// Memorise start pos
}

void printbuffer ()	// Flush print buffer
{
	short cx,cy;
	if (tprintflag || bufferlen == 0) return;
	xstr [bufferlen] = 0;
	cx = bufferx * chrx - chrx + HorizOff; 
	cy = buffery * chry - chry + VertOff;
	if (hWDC == NULL) hWDC = hMainDC;	// Redirect to hMainDC.
	TextOut (hWDC,cx,cy,xstr,bufferlen);
	bufferon ();
}

void bufferoff ()	// Flush buffer & turn off
{
	printbuffer ();
	bufferflag = 0;
}

void gotoxy (short xloc, short yloc)	/* Goto to loc X,Y on VDU */
{
	if (bufferflag) printbuffer ();
	if (xloc < 1) xloc = 1;
	if (yloc < 1) yloc = 1;
	curx = xloc; cury = yloc;
	if (bufferflag) {
	  bufferx = curx; buffery = cury;
	}
}

short wherex (void) {return (curx);}
short wherey (void) {return (cury);}

	// Print a null-term string,
	// if tprintflag == 0, print to vdu (if (bufferflag), via buffer)
	// if tprintflag == 1, print to lprintc
	// if tprintflag == 2, print to file
	// if tprintflag == 3, print to mem buffer
void prints (char *istr)
{
	short ichr;
	if (tprintflag || bufferflag == 0) {	// Non buffered, use printc..
          while (*istr) {
	    printc (*istr);
	    istr ++;
	  }
	  return;
	}
		// faster print, direct to buffer..
	while (ichr = *istr, ichr != 0) {
	  if (bufferlen >= PbufSize || ichr == 10) {	// flush buf..
	    printbuffer ();
	    printc (ichr);
	  } else {
		// add char..          
	    xstr [bufferlen] = (char) ichr;
	    bufferlen ++;
	    curx ++;
	    nprint ++;
	  }
	  istr ++;
	}
	
}

void printc (short ichr)		//* Print a Char, to screen/printer..
{
	short cx,cy;
        static short temp;
	if (tprintflag) goto printto;	// Print to disk, prn..
	nprint ++;
        if (bufferflag) {
          if (bufferlen < PbufSize && ichr != 10) {	// add chr
            xstr [bufferlen] = (char) ichr;
            bufferlen ++;
            curx ++;
            return;
          } else {			// flush it
            printbuffer ();
          }
        }
	xstr [0] = (char) ichr; xstr [1] = 0;
	if (ichr == 10) {
	  curx = 1; cury ++; return;
	}
	cx = curx * chrx - chrx + HorizOff; 
	cy = cury * chry - chry + VertOff;
	
	if (hWDC == NULL) hWDC = hMainDC;	// Redirect to main win.
	TextOut (hWDC,cx,cy,xstr,1);
	curx ++;
	return;
printto:		// Print to printer, disk, spool..
	if (tprintflag == 2) {	// Print to file..
	  if (ichr == 10) fprintc (13);
	  fprintc (ichr);
	} else {	// Write to simple mem buffer..
	  if (PrtCount > 0) {		// Some space left..
	    *PrtBuffer = (char) ichr;
	    PrtCount --;
	    PrtBuffer ++;
	  }
	}
	return;
}

void printnc (short ichr, short nchr)	// Print a char (nchr) times..
{
	short cc;
	for (cc = 1; cc <= nchr; cc ++) {
	  printc (ichr);
	}
}

void printl (long iint)		/* Print a signed short */
{
	short cchr;
	if (iint == 0) {
	  printc ('0');
	  return;
	}
	if (iint < 0) {
	  printc ('-');
	  iint = -iint;
	}
	for (cchr = 0; iint; cchr ++) {
	  prbuffer [cchr] = (char) (48 + (iint % 10));
	  iint /= 10;
	}
	prbuffer [cchr] = 0;
	while (cchr) {
	  cchr --;
	  printc ( prbuffer [cchr]);
	}
}

void printi2 (short iint)		// Print short fixed NN
{
	printc ((short) (((iint / 10) % 10) + 48));
	printc ((short) ((iint % 10) + 48));
}

void printi3 (short iint)		// Fast Print short NNN
{
	if (iint < 100) {
	  printc (' ');
	} else {
	  printc ((short) (((iint / 100) % 10) + 48));
	}
	if (iint < 10) {
	  printc (' ');
	} else {
	  printc ((short) (((iint / 10) % 10) + 48));
	}
	printc ((short) ((iint % 10) + 48));
}

void printi (short iint)
{
	printl ((long) iint);
}

void printsi (char *istr, short iint)		/* Composite short cut */
{
	prints (istr);
	printi (iint);
}

void printis (short iint, char *istr)		/* Composite short cut */
{
	printi (iint);
	prints (istr);
}

void printsl (char *istr, long iint)	// Composite short cut 
{
	prints (istr);
	printl (iint);
}

	// Printf replacement - uses our standard PRINTC..
	// NOTE - any ptrs/strings MUST BE CAST AS FAR
	
short xprintf (char *format,...)
{
	char prbuf [500];
	short vlen;
	va_list argptr;
	va_start (argptr,format);
	vlen = wvsprintf ((char far *) prbuf,format, argptr);
	va_end (argptr);
	prints (prbuf);
	return (vlen);
}	

  // Print to a loc on DC, or dialog if DC is NULL..
  //  if DC==NULL (Dlg) & (xpos)==USEOPTIONS, ypos=Dlg flag (MB_OKCANCEL etc)
  //    if (xpos)==ABORT_PROG then exit prog after dialog
  // Return len of text printed
short msgprintf (HDC hDC, short xpos, short ypos, char *format,...)
{
	char prbuf [500];
	short vlen;
	va_list argptr;
	va_start (argptr,format);
	vlen = wvsprintf ((char far *) prbuf,format, argptr);
	va_end (argptr);
	if (vlen > sizeof (prbuf)) {
	  Dink ();
	}
	if (hDC == NULL) {	// Display string in popup window..
	  Dink ();
	  if (xpos == USEOPTIONS) { // Extra option flags set in ypos..
	    return (MessageBox (NULL, prbuf, STprogramname, MB_TASKMODAL | ypos));
	  }
	  //MessageBox (NULL, prbuf, Progname, MB_OK | MB_TASKMODAL);
	  DoMessage (prbuf);
	} else {
	  TextOut (hDC, xpos, ypos, (LPSTR) prbuf, lstrlen (prbuf));
	}
	if (xpos == ABORT_PROG) exit (0);
	return (vlen);
}	
	
	// Print time in MM:SS, or H:MM:SS if hrsflag
void printatime (long xtime, short hrsflag)
{
	char mstr [10];
	time2asc (mstr,xtime,(short) (hrsflag | 2));
	prints (mstr);
}

  // Ret non-zero if given key hit.. (ie. VK_ESCAPE)
short IsKeyHit (USHORT hkey)
{
	MSG msg;			// message from GetMessage
		// See if ESC key hhas been hit - look at msg queue
	while (PeekMessage (&msg, NULL, WM_KEYDOWN,WM_KEYDOWN, PM_REMOVE)) {
	  if (msg.message == WM_KEYDOWN && msg.wParam == hkey) {
	    Dink (); 
	    return 1;
	  }
	  //TranslateMessage (&msg);     // convert keystroke 
	  //DispatchMessage (&msg);      // call window procedure 
	}
	return 0;
}

//
//  PUSH-BUTTON routines..
//

	// Auto-Imp a set of push buttons on screen
void ButtonsOn (BUTTONINFO *UBut, short bmode)
{
   short cstrlen,curlx;
   static short xpos,ypos;
   char *bstr = UBut->str;
   short temp;
   xpos = UBut->tx; 
   ypos = UBut->ty;
   UBut->num = 0;		// Count of buttons imp..
   do {
     UBut->num ++;
     cstrlen = lstrlen (bstr);
     curlx = - UBut->lx;
     if (UBut->lx > 0) curlx = cstrlen * UBut->lx + 7;
     temp = Button + UBut->num;
     if (bmode == 0) {		// create..
	// Create the actual button
       UBut->hButton [UBut->num] = CreateWindow ("BUTTON",bstr,
	 WS_CHILD | WS_TABSTOP | WS_VISIBLE | BS_PUSHBUTTON,
	 xpos,ypos,curlx,UBut->ly,UBut->hOwner,(HMENU) temp,hInstance,NULL);
	// ShowWindow (hButton [UBut->num], SW_SHOWNORMAL);
     } else {		// just reposition
	MoveWindow (UBut->hButton [UBut->num],xpos,ypos,curlx,UBut->ly,TRUE);
     }
     xpos += curlx + 11;
     if (xpos > UBut->xend) {
       xpos = UBut->tx; ypos += UBut->ly + 10;
     } 
		// Skip to Next string, scan for null..
     while (bstr [0]) bstr ++;
     bstr ++;
   } while (bstr [0]);	// Double null indicates end of buttons.
   UBut->bx = xpos;	// Save right hand edge
}

void ButtonsOff (BUTTONINFO *UBut)
{
	short cbutton;
	for (cbutton = 1; cbutton <= UBut->num; cbutton ++) {
	  DestroyWindow (UBut->hButton [cbutton]);
	  UBut->hButton [cbutton] = NULL;
	}
	UBut->num = 0;
}


//
//  Get/Release DC support routines..
//

	// Array of windows..
HWND hAWnd [12] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
	// Array of device contexts..
HDC hADC [12] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};

HDC hWDC = NULL;	// The current Handle Device Context (HDC)
HANDLE hInstance;	// Instance of application

HDC hStackDC [10];		// Stack of Device contexts
short hStackFlag [10];		// Flags for above..
short nHDC = 0;			// Cur index to stack.

	// Get device context for given window (if not already on)
	// and make it the current one. Push last mode onto a stack
	// gmode bit 0 set if real realise palette needed..
	// gmode bit 1 set realise no objects..
void GetMyPDC (HWND hMyWnd, HDC *hMyDC, short gmode)
{
	if (hMyWnd == NULL) return;
	hStackDC [nHDC] = hWDC;		// Push old HDC onto stack array.
	if (nHDC >= aSizeOf (hStackDC) - 1) {
	  DoMessage ("!HDC stack overflow!");
	  exit (0);
	}
	hStackFlag [nHDC] = 0;
	if (*hMyDC == NULL) {		// MyDC not alloc, so get it..
	  *hMyDC = GetDC (hMyWnd);
	  hStackFlag [nHDC] = 1;	// Flag means we got a DC
	}
	nHDC ++;
	if (*hMyDC != NULL) hWDC = *hMyDC;
	if (gmode & 2) return;		// Select no objects..
		// OK, we have a DC, now select elementary objects into it.	
	SelectPalette (hWDC, hPalette, TRUE);
	if (gmode & 1) {
	  RealizePalette (hWDC);		// Norm realize
	} else {
	  qRealizePalette (hWDC);		// Fast realize
	}
	SelectObject (hWDC, hFont);	// select it
	TextCol (PALTXT,PALBOX);
}

	// Release a device context, if the last pushed on the
	// stack does not match the current
void ReleaseMyPDC (HWND hMyWnd, HDC *hMyDC)
{
	if (hMyWnd == NULL) return;
	SelectObject (*hMyDC, GetStockObject (NULL_BRUSH));
	nHDC --;	// Back to last pushed on stack
	if (nHDC < 0) {		// Too far!
	  DoMessage ("!HDC stack underflow!");
	  exit (0);
	}
	  // Flag means we must have Got a DC last time, so Release it
	if (hStackFlag [nHDC]) {	// WAS (hMyDC != hStackDC [nHDC])
	  ReleaseDC (hMyWnd, *hMyDC);
	  *hMyDC = NULL;
	}
	hWDC = hStackDC [nHDC];		// Pull old HDC from stack array.
}

	// As GetMyPDC, but does it by passing simple index for hAWnd array
void GetMyDC (short WndIndex, short gmode)
{
	if (WndIndex == 0) {		// Main DC permanant, just get it..
	  hWDC = hMainDC;
	  return;
	}
	GetMyPDC (hAWnd [WndIndex], &hADC [WndIndex], gmode);
}

	// As ReleaseMyPDC, but does it by passing simple index for hAWnd array
void ReleaseMyDC (short WndIndex)
{
	if (WndIndex == 0) {	// Main DC-permanant, dont release
	  return;
	}
	ReleaseMyPDC (hAWnd [WndIndex], &hADC [WndIndex]);
}

	// Process a user edit field..
	// emode = 1: repaint, =2: add typed char..
void ProcessEditField (EDITINFO *Ued, short emode, short cchr)
{
	short curx = Ued->x;	// Cur x position top-left
	short cury = Ued->y;	// Cur y pos
	short clen = lstrlen (Ued->str);	//
	short ctype = Ued->type;
	if (ctype & 1) {		// calc right justify pos..
	  curx -= chrx * Ued->totlen;
	}
	GetMyPDC (*Ued->hWnd, Ued->hdc, 1);
	switch (emode) {
	 case 2:	// add typed character
	   if (cchr == 8 && clen) {	// Delete..
	     clen --;
	     Ued->str [clen] = 0;
	   } else if (clen < Ued->len) {	// Normal chr, just add..
	     if (ctype & 2) {	// numeric..
	       if (isdigit (cchr) == 0) cchr = 0;
	     }
	     if (cchr > 31) {		// must be ascii..
	       Ued->str [clen] = (char) cchr;
	       clen ++;
	       Ued->str [clen] = 0;
	       //msgprintf (NULL,1,1,"%s",(LPSTR) Ued->str);
	     }
	   }
	   Ued->val = atol (Ued->str);
	   	// drop thro to repaint..
	 case 1:	// Repaint..
	   if (ctype & 2) {  // if numeric field, val-> str
	     if (Ued->val) {
	       wsprintf ((LPSTR) Ued->str,"%ld",Ued->val);
	     } else {		// 0, just wipe string..
	       Ued->str [0] = 0;
	     }
	   }
	   msgprintf (hWDC,curx,cury,Ued->prompt,(LPSTR) Ued->str);
	   break;
	} 
	ReleaseMyPDC (*Ued->hWnd, Ued->hdc);
}

//
// TOOLBAR-KEY support routines..
//

short ltx,lty,lex,ley;	// top/bott ptrs
HDC hTDC;		// Temp DC
HPEN hPen1,hPen2;	// temp pens
	// Support for hotkeys..
HDC hHotDC = NULL;	// HDC for hot key bmps
USHORT HotLastPressed = 0;	// Hot key currently pressed in..
BYTE DoingHotKey = 0;
short HotLasttx,HotLastty;	// top left of last pressed
short HotLastlx,HotLastly;	// Size of last key pressed

HOTKEYINFO *HotLastInfo = NULL;	// Ptr to info on last pressed

char szWndTxt [80];		// Temp buffer for window-title-text..

void drawlines ()	// Draw half box (ltx,lty) out to (lex,ley)
{
	MoveToEx (hTDC, ltx, lty,NULL); LineTo (hTDC, ltx, ley); 
	MoveToEx (hTDC, ltx, lty,NULL); LineTo (hTDC, lex, lty); 
}

void draw3dbox ()	// draw 3d box..
{
    SelectObject (hTDC,hPen2);
    MoveToEx (hTDC, ltx, ley,NULL);
    LineTo (hTDC, ltx, lty); 
    LineTo (hTDC, lex, lty); 
    SelectObject (hTDC,hPen1);
    LineTo (hTDC, lex, ley); 
    LineTo (hTDC, ltx, ley);
}


	// Draw keys for given set of hotkeys..
	// if mode set Get/release a DC when doing so..
void DrawHotKeys (HOTKEYINFO *Hot)
{
	RECT tmprct;
	short srcx = Hot->bmpx;		// Source loc in HOT.BMP
	short srcy = Hot->bmpy;		
	short destx = Hot->keyx;		// Dest on window..
	short desty = Hot->keyy;
	short bleny = Hot->leny;			// BMP height
	short blenx = Hot->lenx;
	short width = Hot->nhoriz * blenx;	// Width of each row..
	short crow,cbmp,cchr;
	SIZE sizeTxt;
	short clen;
	char far *tstr;			// Text-string..
	if (hAWnd [Hot->wnd] == NULL || Hot->num == 0) return;
	if (Hot->hmode & 4) {		// Auto-center x-pos..
	  GetClientRect (hAWnd [Hot->wnd],&tmprct);
	  Hot->keyx = destx = ((tmprct.right - width) >> 1);
	}
	GetMyDC (Hot->wnd,2);
	hTDC = hWDC;		// Defalt to current DC in use
	if (Hot->hmode & 8) goto DrawTextKeys;	// TEXT BUTTONS..
	for (cbmp = 1; cbmp <= Hot->num; cbmp += Hot->nhoriz) {
	  BitBlt (hTDC, destx, desty, width + 1, bleny, 
		hHotDC, srcx, srcy, SRCCOPY);
	  desty += bleny;
	  srcx += width;
	}
	ReleaseMyDC (Hot->wnd);
	return;
		// Create TEXT BUTTONS, using text in (txt)..
DrawTextKeys:
	SelectObject (hWDC,GetStockObject (LTGRAY_BRUSH));
	hPen1 = CreatePen (PS_SOLID,1,RGB (128,128,128));
	hPen2 = GetStockObject (WHITE_PEN);
	tstr = Hot->txt;		// Button texts..
	if (Hot->bFont) {		// Sel new font..
	  SelectObject (hWDC,Hot->bFont);	// Text font..
	} else {
	  SelectObject (hWDC,GetStockObject(SYSTEM_FONT));  // Sys font..
	}
	SetTextColor (hWDC,RGB(0,0,0));
	SetBkMode (hWDC, TRANSPARENT);
	for (crow = 1; crow <= Hot->num; crow += Hot->nhoriz) {
	  	// Draw individual keys across..
	  for (cbmp = crow; cbmp < crow + Hot->nhoriz; cbmp ++) {
	    ltx = destx + 1; lty = desty + 1;
	    lex = ltx + blenx - 2; ley = lty + bleny - 2;
	    SelectObject (hWDC,GetStockObject (BLACK_PEN));	// Black border..
	    Rectangle (hWDC,ltx - 1,lty - 1,lex + 2,ley + 2);
	    clen = lstrlen (tstr);
	    if (clen) {		// Center up & show Button-text..
	      cchr = tstr[0];
	      if (cchr < 17) {	// Colour code spec..1-16
	        short clev = 128;
	        if (cchr & 8) clev = 255;
	        cchr --;
	        SetTextColor (hWDC,RGB ((cchr & 4) ? clev : 0,
	            (cchr & 2) ? clev : 0, (cchr & 1) ? clev : 0));
	        tstr ++; clen --;
	      }
	      GetTextExtentPoint (hWDC,tstr,clen,&sizeTxt);
	      TextOut (hWDC,ltx + ((blenx - sizeTxt.cx) >> 1),
	      	lty + ((bleny - sizeTxt.cy) >> 1),tstr,clen);
	      tstr = tstr + clen + 1;	// Next button string..
	    }
	    draw3dbox ();
	    ltx ++; lty ++; lex --; ley --;
	    draw3dbox ();
	    destx += blenx;
	  }
	  desty += bleny;
	  destx = Hot->keyx;
	}
	SelectObject (hWDC,GetStockObject (WHITE_PEN));
	ReleaseMyDC (Hot->wnd);
	DeleteObject (hPen1);
}

void ReleaseLastKey ()		// Redraw last hot key to normal
{
	if (HotLastPressed) {
	  DrawHotKeys (HotLastInfo);	// Redraw keys (release button)
	  if (HotLastInfo->hmode & 1) {	// Refresh main window text..
	    SetWindowText (hAWnd [HotLastInfo->wnd],szWndTxt);
	  }
	  if (HotLastInfo->hmode & 2) {	// Refresh main window text..
	    SetWindowText (hAWnd [HotLastInfo->wnd],szWndTxt);
	  }
	  HotLastPressed = 0;
	}
}

	// Process hotkey if mouse (mousex,y) hit/held/released on one..
	// Set pressed = 1 if pressing in, 2 if holding in, 
	// 0 if releasing & post IDM_ action in queue, 
	// 3 if releasing, but no IDM_ action (just ret hotkey val)
	// Return Hotkey value, or 0 if none.
short ProcessHotKey (HOTKEYINFO *Hot, short hmode)
{
	USHORT chotkx,chotky,chotk;
	USHORT tlast = HotLastPressed;
	short cidm;
	static short rbutton;
	ALY short pressed;
	pressed = hmode & 3;
	if (DoingHotKey) {
	  return 0;
	}
	if (pressed != 1 && HotLastPressed == 0) return 0;
	if (Hot == NULL) return 0;
	if (hAWnd [Hot->wnd] == NULL) return 0;
	DoingHotKey = 1;
	if (pressed == 2) {	// Holding in (mouse move..)
		// Move out of range?
	  if ((USHORT) mousex - HotLasttx > (USHORT) HotLastlx
	   || (USHORT) mousey - HotLastty > (USHORT) HotLastly) {
	    ReleaseLastKey ();		
	  }
	  goto PHKexit;
	}
	ReleaseLastKey ();	// redraw buttons
	  // Calc x/y pos of mouse relative to HOTKEY start 
	  // (0,0)=topleft, converting to hotkey unit counts..
	chotkx = ((USHORT) mousex - Hot->keyx) / ((USHORT) Hot->lenx);
	chotky = ((USHORT) mousey - Hot->keyy) / ((USHORT) Hot->leny);
		// Out of range for this set of hot keys?	
	if (chotky > 99 || chotkx >= (USHORT) Hot->nhoriz) {
	  goto PHKexit;
	}
		// Turn x/y unit count into simple linear 1..n
	chotk = chotkx + (chotky * Hot->nhoriz) + 1;
	if (chotk > (USHORT) Hot->num) goto PHKexit;		// too many..
	//chotk += Hot->index;
		// Mask out right button?
	if ((Hot->hmode & 0x10) == 0 && (hmode & 4)) goto PHKexit;
	if (pressed == 1) {	// See if right button..
	  rbutton = 0;
	  if (Hot->hmode & 0x10) rbutton = hmode & 4;	// Right button hit..
	}
	cidm = 0;	// Get any idm code..
	if (Hot->idm != NULL) cidm = Hot->idm [chotk - 1 + (rbutton ? Hot->num:0)];
	if (ThinkMode == ThinkComp && cidm == IDM_COMPUTE) cidm = IDM_MOVE;
	if (pressed == 1) {		// Hot key first pressed in
		// Save info on last key pressed in..	
	  HotLastPressed = chotk;
	  HotLastlx = Hot->lenx;
	  HotLastly = Hot->leny;
	  HotLasttx = Hot->keyx + chotkx * HotLastlx;
	  HotLastty = Hot->keyy + chotky * HotLastly;
	  HotLastInfo = Hot;
		// Draw depressed button on screen..	  
	  GetMyDC (Hot->wnd,2);	// Get DC of HOTKEY window..
	  
	  hTDC = hWDC;		// Defalt to current DC in use
	  
	  ltx = HotLasttx + 1; lty = HotLastty + 1;
	  lex = ltx + HotLastlx - 2;
	  ley = lty + HotLastly - 3;
	  BitBlt (hTDC, ltx+4, lty+4, HotLastlx - 5, HotLastly - 6,
		hTDC, ltx+2, lty+2, SRCCOPY);
	  SelectObject (hTDC,hDkgreyPen);
	  drawlines ();
	  ltx ++; lty ++;
	  drawlines ();
	  ltx ++; lty ++;
	  SelectObject (hTDC,hLtgreyPen);
	  drawlines ();
	  ltx ++; lty ++;
	  drawlines ();
	  ltx ++; lty ++;
	  ltx = lex; lty = ley;
	  lex = HotLasttx + 1; ley = HotLastty + 1;
	  SelectObject (hTDC,hWhitePen);
	  drawlines ();
	  ReleaseMyDC (Hot->wnd);
	  if (Hot->hmode & 1) {		// Change Window Title text..
	    IDM2String (cidm);
	    if (MenuStr [0]) {
	      GetWindowText (hAWnd[Hot->wnd],szWndTxt,sizeof (szWndTxt) -3);
	      SetWindowText (hAWnd[Hot->wnd],MenuStr);
	    }
	  }
	  if (Hot->hmode & 2) {		// Info-text in (->txt) string..
	    char far *mstr = Hot->txt;	// ptr to txt str..
	    short cpos = chotk;
	    if (mstr != NULL) {
	      while (cpos > 1) {		// Spool past (cpos) strings..
	        while (*mstr) mstr ++;
	        mstr ++;
	        cpos --;
	      }
	      if (*mstr) {	// Set title bar text to this message..
	        GetWindowText (hAWnd[Hot->wnd],szWndTxt,sizeof (szWndTxt) -3);
	        SetWindowText (hAWnd[Hot->wnd],mstr);
	      }
	    }
	  }
	  //ReleaseMyPDC (*(Hot->hhwnd),Hot->hhDC );
	  DoingHotKey = 0;
	  return chotk;
	}
		// Otherwise pressed=0 or 3, release..
	if (chotk != tlast) goto PHKexit;  // Must be same as previous hot..
	if (pressed == 0 && cidm) {
	  docmdkey (cidm); // Post IDM_ msg in windows queue to exec button
	}
	DoingHotKey = 0;
	return chotk;
PHKexit:
	DoingHotKey = 0;
	return 0;
}

char MenuStr [60];		// String for IDM_ to str routine..

  // Make a string, from IDM_ menu command.. at (MenuStr)
  // Filter out CTRL chars, end at TAB char..
char * IDM2String (short cidm)
{
	char *istr = Strings [cidm];
	short cpos = 0;
	while (*istr && *istr != 9) {	// until null end, or tab
	  if (*istr == '&') istr ++;
	  MenuStr [cpos] = *istr;
	  istr ++; cpos ++;
	  if (cpos > sizeof (MenuStr) - 3) break;
	}
	MenuStr [cpos] = 0;
	return MenuStr;
}

/*short IDM2String (short TitleIDM)
{
	short cpos;
	char *istr;
	if (TitleIDM == 0) return 0;
	MenuStr [0] = 0;
	if (TitleIDM < 0) {	// -ve:Get from mem array..
	  strcpy (MenuStr, Strings [-TitleIDM]);
	} else {	// If +ve IDM spec, use text from menu..
	  if (GetMenuString (hMenu, TitleIDM, MenuStr, 
		sizeof (MenuStr) - 3, MF_BYCOMMAND) == 0) return 0;
	}
	cpos = 0;
	while (*istr && *istr != 9) {	// until null end, or tab
	  if (*istr == '&') istr ++;
	  MenuStr [cpos] = *istr;
	  istr ++; cpos ++;
	  if (cpos > sizeof (MenuStr) - 3) break;
	}
	MenuStr [cpos] = 0;
	return 1;
}
*/

//
//----------------------------------------------------------------------
// PC SOLUTIONS GENERAL PURPOSE DYNAMIC DIALOG ROUTINES
//   Allows building of dialog boxes with a dynamic set of API
//   statements, rather than resources. Only needs 1 service routine.
//----------------------------------------------------------------------
//

BYTE saveclock = 0x80;	// temp used to save clock status
DLGPROC lpGenDlgProc;

static short termdlg [] = {5757,30079,31510,15365,14629,8511,29999,27757,24852,
	30050,15362,29996,25960,30055,15061,13533,8489,30175,13527,
	13529,14627,31535,0,0};		// Dlg termination data
static USHORT ndTimer = 0;	// Dialog timer flag..
#define MAXdialog 4000
unsigned char HUGE_ *dialogdata;	// Ptr to dialog template
long HUGE_ *Ldialog;		// Ptr to long vars..
short HUGE_ *Idialog;		// Ptr to short vars..
unsigned char HUGE_ *Cdialog;
HGLOBAL hglbDlgTemp;
short IddFocus;			// IDD_ no for Focus field
short nDControls;			// No of dialog controls
DWORD lDlgBaseUnits;	// pixels per dialog char unit:LO=x,HI=y
short DBUx;		// Pixels per char width (/4 for dlg unit)
short DBUy;		// Pixels per char hieght(/8 for dlg unit)
short VduDUx,VduDUy;	// Size of screen in dialog units..
static char xtradlg [] = "!)D*B/NJMMFUU!";
short DlgTopx,DlgTopy;	// Size of current dialog box in DBU's
short DlgLenx,DlgLeny;
short DlgPixx,DlgPixy;	// Size dialog in pixels..
short DlgButton;		// IDD_ Val of button pushed
USHORT tempx,tempy;	// Used for range checks..

		// COMBO box vars
short ncombos;		// No of combo controls in curr dialog
short ccombo;		// temp index curr combo
short ComboPos [30];	// Pos of each combo..
char *ComboTxt [30];	// Array of pointers to combo texts..
char *comstr;		// Temp work string ptr..
short SpecialCombo;	// Index of Special combo - selects control groups..
short SpecialLast;	// Previous val of special..

		// EDIT field vars
short nedits;
short cedit;

typedef struct {	// DATA for flags..
  char far *str;	// ptr to edit string
  short len;
} EDITDATA;

EDITDATA dEdit [20];	// Data for edit fields..

		// CHECK boxes
short nchecks;		// no of check boxes
short ccheck;
short CheckVal [30];	// status of each on (0=off, 1=on)

short cticks;		// For count of flags..

		// RADIO buttons..
short nradios;		// no of check boxes
short cradio;
short RadioVal [30];	// status of each one (1..n)
short RadioNo [30];	// # Radio buttons in each group..

		// SLIDER (SCROLLBAR) vars..
short nsliders;			// no of slider controls
short cslider;
short sbPos,sbStep;
short PalRGBx,PalRGBy;	// X/Y loc of RGB colour display box, x=0:none used
			// otherwise, 1st 3 sliders assumed to be RGB..
			// Spec in CHARS - Multply by DBU for real pixels..
short PalRGBwide;		// Width of box to be displayed
short PalRGBslider = 0;	// Width of box to be displayed

typedef struct {	// Structure for SLIDER data
 short pos;	// Cur pos of slider
 short min,max;	// range
 short step;	// step for incr/decr
 short bigstep;	// step for big inc/dec
} SLIDER;

SLIDER Sld [30];	// Space for slider controls..
	
		// SPIN vars..
short nspins;		// No of spin ctrls..
short cspin;		// current spin ctrl index
short spinc;		// Spin increment amount
short incunit;		// Temp used while calculating SPINC
short startspin;		// Countdown before spin-repeat..
short dmousex,dmousey;	// Cur mouse pos in dialog
short areax,areay;	// Cur SPIN BUTTON being hit..

typedef struct {	// STRUCTURE for SPIN-BUTTON data
  short x,y;	// Pos of 1st spin ctrl
  short x2,y2;	// Pos of 2nd spin ctrl (<0== none exists)
  //short edx,edy;	// Pos of edit field for spin ctrl (unused)
  short len;	// char len of edit field
  short group;	// Group  (if any) for this control.
  long val;	// Current val 
  long min,max;	// Range of control
  BYTE step;	// size of step..
} SPIN;

SPIN Spin [30];	// Space for spin ctrls
SPIN *spn;	// Ptr to current entry

char szDtemp [20];             // scratch space for general dialog string

#define SpinX 16	// Size of Spin ctrl icon/bitmap
#define SpinY 24
#define SpinHalfY 12

short nbuttons;		// No of Push buttons in dialog..

	// A combo box can be set to select groups on ctrls to be active
	// These are Vars for handling variable control groups..
short IDD_mixed;			// Next control handle to allocate..
short nvars;			// no of variable controls in array..
short CurGroup;			// Current control group.. 0=none.
short VarIdd [100];		// IDD for each..
short VarGroup [100];		// Group ID for control..
short GroupFlags;			// Used to control groups within groups
	// Bitwise: bit 0 clr = subgroup 2, set = subgrp 3,
	// bit 1= subgrp 4/5, bit2 = subgrp 6/7, etc..

// BOOL DoingDialog = FALSE;	// Window to get capture..

static long dcontrol [] = {	// Preset Dialog control types for defs above
 0x80,WS_CHILD | WS_VISIBLE | WS_TABSTOP,			// Button
 0x81,ES_LEFT | WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP,	// Edit
 0x82,WS_CHILD | WS_VISIBLE,					// Text
 0x85,WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP , // Listbox
 0x84,WS_CHILD | WS_VISIBLE| WS_TABSTOP,			// Scrollbar
 0x85,WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP | CBS_DROPDOWNLIST, // Combobox
 0x81,ES_MULTILINE | WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, // Editbox
 0x82,SS_ICON |WS_CHILD | WS_VISIBLE,				// Icon
 0x82,SS_BLACKFRAME | WS_CHILD | WS_VISIBLE,			// Frame
 0x80,BS_AUTOCHECKBOX | WS_CHILD | WS_VISIBLE | WS_TABSTOP,	// Tick box
 0x80,BS_RADIOBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,	// Radio buttons
 0x80,BS_GROUPBOX | WS_CHILD | WS_VISIBLE,	// Group box..
0,0};

	// First 'hook' code to allow keystroke detect in dialog,,

#define DialogHook 0
	
#define PM_CALLHELP  WM_USER+1234   // wParam and lParam can be used to
#define PM_NUM  WM_USER+1235   
#define PM_SPINHIT  WM_USER+1236
#define PM_MOUSEAGAIN WM_USER+1237

#if DialogHook			// Only compile if hook enabled

FARPROC lpfnFilterProc;        // Our filter function
FARPROC lpfnOldHook;           // Previous filter function
                                  // in the chain



/*--------------------------    FilterFunc -------------------------*/
//
//   PARAMETERS:
//
//      nCode : Specifies the type of message being processed. It will
//              be either MSGF_DIALOGBOX, MSGF_MENU, or less than 0.
//
//      wParam: specifies a NULL value
//
//      lParam: a FAR pointer to a MSG structure
//
//
//   GLOBAL VARIABLES USED:
//
//      lpfnOldHook
//
//
//   NOTES:
//
//     If (nCode < 0), return DefHookProc() IMMEDIATELY.
//
//     If (MSGF_DIALOGBOX==nCode), set the local variable ptrMsg to
//     point to the message structure. If this message is an F1
//     keystroke, ptrMsg->hwnd will contain the HWND for the dialog
//     control that the user wants help information on. Post a private

//     message to the application, then return 1L to indicate that
//     this message was handled.
//
//     When the application receives the private message, it can call
//     WinHelp(). WinHelp() must NOT be called directly from the
//     FilterFunc() routine.
//
//     In this example, post a private PM_CALLHELP message to the
//     dialog box. wParam and lParam can be used to pass context
//     information.
//
//     If the message is not an F1 keystroke, or if nCode is
//     MSGF_MENU, we return 0L to indicate that we did not process
//     this message.
//
//

DWORD FAR PASCAL FilterFunc(short nCode, WORD wParam, DWORD lParam)
{
    MSG FAR * ptrMsg;

    if (nCode < 0) {	// MUST return DefHookProc()
      return DefHookProc(nCode, wParam, lParam,	(FARPROC FAR *) &lpfnOldHook);
    }

    if (MSGF_DIALOGBOX == nCode) {
      ptrMsg = (MSG FAR *)lParam;
      if ((WM_KEYDOWN == ptrMsg->message) && (VK_F1 == ptrMsg->wParam)) {
		// Use PostMessage() here to post an application-defined
		// message to the application. 
	PostMessage(GetParent(ptrMsg->hwnd), PM_CALLHELP, ptrMsg->hwnd, 0L);
	return 1L;                       // Handled it
	
      //} else if ((WM_CHAR == ptrMsg->message) 
      //&& (ptrMsg->wParam >= '0' && ptrMsg->wParam <= '9')) { // Number..
	//PostMessage(GetParent(ptrMsg->hwnd), PM_NUM, ptrMsg->hwnd, 0L);
	//return 1L;                       // Handled it
	
      } else {
	return 0L;                       // Did not handle it
      }
    } else {                                  // I.e., MSGF_MENU
      return 0L;                       // Did not handle it
    }
}
/*--------------------- end FilterFunc  ----------------------------*/

#endif		// DialogHook


void LockFocus ()		// Lock all input to this window
{
	if (DoingDialog) return;
	DoingDialog = TRUE;
	//SetCapture (hMainWnd);
}

void ReleaseFocus ()		// Allow other windows to operate..
{
	if (DoingDialog == FALSE) return;
	//ReleaseCapture ();
	DoingDialog = FALSE;
}

	// Dynamically define a dialog box.. initialise data structures
	// dmode set to put special icons at top.
short DialogBeg (char *dialogname,short dtopx,short dtopy,short dlenx,short dleny, short dmode)
{
	short xdialog;
	VduDUx = (nVduX * 4) / DBUx;	// Size of VDU in DBU's..
	VduDUy = (nVduY * 8) / DBUy;
	DlgPixx = (dlenx * DBUx) / 4;		// Size dlg in pixels..
	DlgPixy = (dleny * DBUy) / 8;
	if (dtopx < 0) {		// Auto center x pos..
	  dtopx = (VduDUx - dlenx) >> 1;
	}
	if (dtopy == -2) {		// Bottom align y
	  dtopy = VduDUy - dleny + 2;
	}
	if (dtopy < 0) {		// Auto center y pos..
	  dtopy = (VduDUy - dleny) >> 1;
	}
	DlgTopx = dtopx; DlgTopy = dtopy;	// Save size to global vars
	DlgLenx = dlenx; DlgLeny = dleny;
	HaltClock
	EndTick = 0;
	PalRGBslider = PalRGBx = nedits = nvars = ncombos = nchecks = 
	  nbuttons = nspins = nsliders = nradios = 0;
	IDD_mixed = IDD_MIXED;		// For variable controls..
	SpecialCombo = 0;		// Index of special control..
	DlgButton = 0;
	CurGroup = 0;		// All ctrls with Group zero always on.
	GroupFlags = 0;		// Used to control groups within groups.
	hglbDlgTemp = GlobalAlloc (GHND, MAXdialog);
	if (!hglbDlgTemp) {
	  DoMessage ("Dialog Memory Allocation - out of memory!"); 
	  return (1);
	}
	dialogdata = (char HUGE_ *) GlobalLock (hglbDlgTemp);
	// Create/fill this DialogBoxHeader structure.. 
	//  struct DialogBoxHeader {
    	//	DWORD lStyle;		// Windows style
	//	BYTE  bNumberOfItems;	// No of controls
	//	WORD  x,y;		// x,y pos of window, in 1/4,1/8 chrs
	//	WORD  cx,cy;		// x,y size, in above chr units
	//	char  szMenuName[];	// name of attached menu, 0=none
	//	char  szClassName[];	// class name,0=default
	//	char  szCaption[];	// Text title
	//	WORD  wPointSize; 	// only if DS_SETFONT in style
	//	char  szFaceName[];	// only if DS_SETFONT 
	//  };  end stucture
	// NOTE:- XPOS set in 1/4 average system char width units, 
	//  and YPOS = 1/8 av chr height. (so that scale always matches font)
	
	Cdialog = (char HUGE_ *) dialogdata;
	Idialog = (short HUGE_ *) (dialogdata + 5);
	Ldialog = (long HUGE_ *) dialogdata;
		// Define style..
	Ldialog [0] = DS_MODALFRAME | WS_POPUP | WS_CAPTION | WS_SYSMENU;
		// No of dialog control items
	//Cdialog [4] = ncontrols;	// NOW SET on DialogDo
		// Window pos & size
	Idialog [0] = dtopx; Idialog [1] = dtopy;
	Idialog [2] = dlenx; Idialog [3] = dleny;
		// both Menu & Class bytes = 0..
	Idialog [4] = 0;
	Cdialog += 15;		// Move ptr to Caption text
	for (xdialog = 0; dialogname [xdialog]; xdialog ++) {
	  Cdialog [xdialog] = dialogname [xdialog];
	}
	Cdialog += xdialog + 1;		// ptr to end..
	nDControls = 0;			// Count of installed controls
	#if (FlagALTLAYOUT == 0)
	  if (dmode) {		// Auto define some nice icons top left/right
	    DialogDef (dICON, "OurIcon",IDD_AUTOIDD,2,2,0,0,0);
	    DialogDef (dICON, "OurIcon",IDD_AUTOIDD,dlenx - 18,2,0,0,0);
	  }
	#endif
	return (0);		// OK, sucsesful
}

void DialogEnd ()	// Free up dialog box memory..
{
	GlobalUnlock (hglbDlgTemp);
	GlobalFree (hglbDlgTemp);
	RestoreClock
}

static void StoreIDD (short cidd)	// Store IDD if in group..
{
	if (CurGroup) {
	  nvars ++;
	  if (nvars < aSizeOf (VarIdd)) {
	    VarIdd [nvars] = cidd;
	    VarGroup [nvars] = CurGroup;
	  }
	}
}

	// Define a dialog item entry (button,edit,etc..)
	
void DialogDef (BYTE dtype,char *dialogname,short dialogID,
	short dtopx,short dtopy,short dlenx,short dleny,long dialogstyle)
{
	short xdialog;
	if (dialogID == IDD_AUTOIDD) {
	  dialogID = IDD_mixed; IDD_mixed ++;
	}
	StoreIDD (dialogID);
	Idialog = (short HUGE_ *) Cdialog;
	Ldialog = (long HUGE_ *) (Cdialog + 10);

	// Fill this structure..
	//  struct ControlData {
	//	WORD  x,y;
	//	WORD  cx,cy;
	//	WORD  wID;
	//	DWORD lStyle;
	//	BYTE class;     // if (class & 0x80)
	//	szText;
	//  }; struct ends

		// Window pos & size
	Idialog [0] = dtopx; Idialog [1] = dtopy;
	Idialog [2] = dlenx; Idialog [3] = dleny;
	Idialog [4] = dialogID;		// ID for this function
	dtype = (dtype << 1);
		// Control style def (0=pickup default..)
	if (dialogstyle == 0) dialogstyle = dcontrol [dtype + 1];
	Ldialog [0] = dialogstyle;
		// Control class type. (button,etc)
	Cdialog [14] = ((char) dcontrol [dtype]) | 0x80;
	Cdialog += 15;		// Move ptr to Control text
	for (xdialog = 0; dialogname [xdialog]; xdialog ++) {
	  Cdialog [xdialog] = dialogname [xdialog];
	}
	Cdialog += xdialog + 1;		// ptr to end..
	Cdialog [0] = 0;
	Cdialog ++;
	Cdialog [0] = 0;
	nDControls ++;
}

	// Define Simple single-line text field
void TextDef (short ttopx, short ttopy, char *ttext)
{
	DialogDef (dTEXT,ttext,IDD_AUTOIDD,ttopx ,ttopy,
		(short) ((lstrlen (ttext) << 2) + 4),8,0);
}

	// Define simple centered field
	// if xpos < 0, then center to dialog box..
void TextCentDef (short ttopx, short ttopy, char *ttext)
{
	short xlen;
	xlen = (lstrlen (ttext) << 2) + 4;
	if (ttopx < 0) ttopx = DlgLenx >> 1;
	DialogDef (dTEXT,ttext,IDD_AUTOIDD,ttopx - (xlen >> 1),ttopy,
		xlen,8,WS_CHILD | WS_VISIBLE | SS_CENTER);
	
	//TextDef ((DlgLenx + DlgLenx - strlen (ttext) * 7) >> 2,ttopy,ttext);
}

  // Define a text edit field.. at (topx,topy) with prompt, edit ptr,
  // (dlenx,dleny) dialog len x/y and (edlen) max # chars 
  // if dlenx==0, auto center box in dialog
  // if dlenx<0, put text (dleny) to left, with y==12.
void EditDef (short topx, short topy, char *szPrompt, char far *szEdit, 
	short dlenx, short dleny, short edlen)
{
	nedits ++;
		// Auto center if len not set..
	if (dlenx == 0) dlenx = max (4,DlgLenx - topx - topx);
	
	if (szPrompt [0]) {	// Any prompt?
	  if (dlenx < 0) {	// Text to left..
	    TextDef (topx, topy + 2,szPrompt);
	    topx += dleny;	// dleny now is prompt-size..
	    dleny = 12; dlenx = -dlenx;
	  } else {	// Center any prompt text above edit
	    TextCentDef (topx + (dlenx >> 1), topy - 10, szPrompt);
	  }
	}
	DialogDef (dEDITBOX,"",IDD_EDIT + nedits,  topx,topy,dlenx,dleny,0);
	dEdit [nedits].str = szEdit;
	dEdit [nedits].len = edlen;
}

	// Define a SLIDER, with its associate text-pos
	
void SliderDef (long dialogstyle,			// SBS_HORZ/SBS_VERT
	short dtopx,short dtopy,short dlenx,short dleny,	// Slider pos/size
	short stopx,short stopy,				// Display val pos
	short slpos,short slmin,short slmax,short slstep,short slbig)	// Init values
{
    short temp;
    nsliders ++;
    if (stopx + stopy == 0) {	// Auto posn display
      stopy = dtopy; stopx = dtopx + dlenx + 6;
    }
    DialogDef (dSCROLLBAR, "", IDD_SLIDERS + nsliders, 
	dtopx, dtopy, dlenx, dleny,
	WS_CHILD | WS_VISIBLE | dialogstyle | WS_TABSTOP);
    if (stopx > 0) {	// If -ve, non editable Slider Display val
      temp = 16; if (slmax < 1000) temp = 12;	// Space for digits..
      DialogDef (dTEXT, " ", IDD_SLIDETEXT + nsliders,
	stopx, stopy, temp, 8,
	WS_CHILD | WS_VISIBLE );
    } else {
      DialogDef (dEDITBOX, " ", IDD_SLIDETEXT + nsliders,
	-stopx, stopy, 20, 12,
	WS_CHILD | WS_VISIBLE | WS_TABSTOP);
    }
    Sld [nsliders].pos = slpos;
    Sld [nsliders].min = slmin;
    Sld [nsliders].max = slmax;
    Sld [nsliders].step = slstep;
    Sld [nsliders].bigstep = slbig;
}

		// Quick Text/Slider define..
void SliderTDef (char *stext,short slen,			// Static Text for ctrl..
	short dtopx,short dtopy,short dlenx,			// Slider pos/size
	short slpos,short slmin,short slmax,short slstep, short slbig)	// Init values
{
	TextDef (dtopx, dtopy, stext);
	SliderDef (SBS_HORZ,dtopx + slen,dtopy,dlenx,8, 0,0,slpos,
		slmin,slmax,slstep,slbig);
}
	
short ReadSlider ()	// Read val back from slider..
{
	if (nsliders < 1) return 0;
	nsliders --;
	return (Sld [nsliders + 1].pos);
}

	// Define a SPIN Button with edit field
	
void SpinDef (short dtopx, short dtopy, short dlenx, 		// Edit x,y,nchrs
	long spval, long spmin, long spmax, BYTE spstep, short dtype)	// Val,range,step,type
{
    short tmpx,offy;
    nspins ++;
    spn = &Spin [nspins];	// Ptr to current spin entry
    spn->len = dlenx;
    offy = 6 - ((SpinY + 1) << 2) / DBUy;	// Offset to shift ctrl down (Dlg units)
    if (offy < 0) offy = 0;
    dlenx = dlenx << 2;			// Char width into dlg units
    tmpx = dtopx + dlenx + 1;
    spn->x = (tmpx * DBUx) >> 2; 	// Set entry for spin ctrl pos in pixels..
    spn->x2 = -1;
	// Calc y pos of spin in real pixels..  y + offset
    spn->y = spn->y2 = (((dtopy + offy) * DBUy) >> 3);
    DialogDef (dICON, "Spin",IDD_AUTOIDD,tmpx,dtopy + offy,0,0,0);
    if (dtype) {	// Double spin ctrl, each side of field..
      tmpx = dtopx - (SpinX << 2) / DBUx - 1;	// Pos 2nd ctrl
      spn->x2 = (tmpx * DBUx) >> 4; 
      DialogDef (dICON, "Spin",IDD_AUTOIDD, tmpx, dtopy + offy,0,0,0);
    }
	// Define Edit field for spin button..    
    DialogDef (dEDITBOX, "", IDD_SPIN + nspins,	dtopx, dtopy, dlenx, 12, 0);
	// store rest of fields
    //spn->edx = dtopx; spn->edy = dtopy;	// Edit ctrl pos (unused)
    spn->min = spmin; spn->max = spmax;
    spn->val = spval;
    spn->step = spstep;
    spn->group = CurGroup;		// Store group for ctrl (0=none)
}

	// Short-cut: As above, but with Text def too..
void SpinTDef (short dtopx, short dtopy, short dlenx,long spval, long spmin, long spmax, BYTE spstep, short dtype,
		char *stxt, short slen)
{
	TextDef (dtopx, dtopy + 2, stxt);
	SpinDef (dtopx + slen, dtopy, dlenx, spval, spmin, spmax, spstep, dtype);
}

long ReadSpin ()	// Read value back from spin ctrl..
{
	if (nspins < 1) return 0L;
	nspins --;
	return (Spin [nspins + 1].val);
}

	// Define a Combo dropdown box
void ComboDef (char *ctxt, short ctopx, short ctopy, short clenx, short cleny, short cval, short cspecial)
{
	BYTE ctype = dCOMBOBOX;		// Drop down combo
	if (cspecial & D_LISTBOX) ctype = dLISTBOX;	// Unless Listbox set
	ncombos ++;
	DialogDef (ctype, "", IDD_COMBO + ncombos, ctopx, ctopy, clenx, cleny,0);
	ComboPos [ncombos] = cval;
	ComboTxt [ncombos] = ctxt;	// Store ptr to text field..
	if (cspecial & DD_SPECIAL) {	// SPECIAL COMBO - selects groups..
	  SpecialCombo = ncombos;
	  SpecialLast = cval;		// Last value..
	}
}

	// Define a combo box & heading text..
void ComboTDef (char *ctxt, short ctopx, short ctopy, short clenx, short cleny, short cval, short cspecial,char *chead)
{
	TextDef (ctopx + (clenx >> 1) - (lstrlen (chead) << 1), ctopy - 10, chead);
	ComboDef (ctxt, ctopx, ctopy, clenx, cleny, cval, cspecial);
}

short ReadCombo ()	// Read val back from combo..
{
	if (ncombos < 1) return 0;
	ncombos --;
	return (ComboPos [ncombos + 1]);
}

	// Define a Check box
void CheckDef (short ctopx, short ctopy, short clenx, char *ctxt, short cval)
{
	if (nchecks >= aSizeOf (CheckVal)) return;
	nchecks ++;
	if (clenx == 0) clenx = lstrlen (ctxt) * 4 + 14;
	DialogDef (dCHECK, ctxt, IDD_CHECK + nchecks, ctopx, ctopy, clenx, 14,0);
	CheckVal [nchecks] = cval;
}

short ReadCheck ()		// Read val back from check box
{
	if (nchecks < 1) return 0;
	nchecks --;
	return (CheckVal [nchecks + 1]);
}

	// Define a set of dialog check boxs, as given in a FLAG_DATA struct
void DefTicks (FLAG_DATA *Fl, short topx, short topy, 
	short addx, short addy, short endx, short endy, char *ftitle)
{       
	short cxpos = topx, cypos = topy;
	short temp;
	cticks = 0;
		// Define each check box..
	while (Fl [cticks].mask) {
	  temp = (((*Fl [cticks].flag) & Fl [cticks].mask) != 0);
	  if (Fl [cticks].inv) temp = ! temp;
	  CheckDef (cxpos, cypos, 0, *Fl [cticks].str, temp);
	  cypos += addy;
	  cticks ++;
	  if (cypos > endy) {		// Reached bottom, next column..
	    cxpos += addx; cypos = topy; 
	  }
	}
	
	if (ftitle != NULL) {
	  DialogDef (dTEXT,"",IDD_AUTOIDD,topx - 5,topy - 12,
		endx, endy + 8, SS_BLACKFRAME | WS_CHILD | WS_VISIBLE);
	  TextDef (topx,topy - 10,ftitle);
	}
}

	// Read back a set of dialog check boxs, as given in a FLAG_DATA struct
void ReadTicks (FLAG_DATA *Fl)
{
	BYTE cmask,andmask;
	while (cticks > 0) {
	  cticks --;
	  cmask = (char) ReadCheck ();
	  if (Fl [cticks].inv) cmask = !cmask;
	  if (cmask) cmask = Fl [cticks].mask;
	  andmask = Fl [cticks].mask ^ 0xff;
	  *Fl [cticks].flag = ((*Fl [cticks].flag) & andmask) | cmask;
	}
}

	// Set a struct of flags to default settings (clr each bit)..
void FlagToDefault (FLAG_DATA *Fl)
{
	short cticks;
	cticks = 0;
		// Mask of the bit in each flag, reseting it..
	while (Fl [cticks].mask) {
		// each entry = entry AND NOT (mask)
	  *Fl [cticks].flag = (*Fl [cticks].flag) & (~(Fl [cticks].mask));
	  cticks ++;
	}
}

  // Define a group-box with auto-Radio buttons..
  // Def top x,y, len x,y of each item, (cstr) with title & buttons, Init val (1-n)
  //   The no of buttons is defined by the no of strings at (ctxt)
  //   String starts with optional group-box header txt, then each radio
  //   with null term, 2 nulls at end. If string starts with \x01, New column
  
void RadioDef (short ctopx, short ctopy, short clenx, short cleny, char *ctxt, short cval)
{
	short tlen = clenx & 0x0fff;
	short nrbuts;		// No of radio buttons in this group..
	short curx,cury;
	short maxy =0;		// Lowest position
	short ncolumns = 1;	// # columns across..
	char *gbstr = "";
	if (nradios >= aSizeOf (RadioVal)) return;
	nradios ++;
	RadioVal [nradios] = cval;	// Initial val..
	
	if (clenx & D_GROUPBOX) {	// Group box..
	  gbstr = ctxt;			// Get ptr to 1st string..
	  ctxt += lstrlen (ctxt) + 1;
	  ctopy += cleny - 4;
	  ctopx += 6;
	}
	curx = ctopx; cury = ctopy;
	if (clenx & DD_SPECIAL) {	// SPECIAL radio buttons - selects groups..
	  SpecialCombo = -nradios;
	  SpecialLast = cval - 1;		// Last value..
	}
		// Now generate button for each text item
	nrbuts = 1;
	do {
	  if (ctxt [0] == 1) {		// Start new column..
	    ctxt ++;
	    ncolumns ++;
	    cury = ctopy;
	    curx += tlen;
	  }
	  if ((clenx & 0x0fff) == 0) tlen = lstrlen (ctxt) * 4 + 14;
	  DialogDef (dRADIO, ctxt, IDD_RADIO + (nradios << 5) + nrbuts, 
	  	curx, cury, tlen, cleny,0);
	  nrbuts ++;
	  cury += cleny;
	  ctxt += lstrlen (ctxt) + 1;	// Skip to next string.,
	  if (cury > maxy) maxy = cury;	// lowest position
	} while (*ctxt && nrbuts < 32);
	RadioNo [nradios] = nrbuts - 1;	// # buttons in group..
	if (clenx & D_GROUPBOX) {	// Group box..
	  DialogDef (dGROUPBOX,gbstr,IDD_AUTOIDD,ctopx - 6,ctopy - cleny + 4,
	  	ncolumns * tlen + 7, maxy - ctopy + cleny - 2,0);
	}
}

short ReadRadio ()		// Read val back from check box
{
	if (nradios < 1) return 0;
	nradios --;
	return (RadioVal [nradios + 1]);
}

	// Define a input-time spin dialog
void TimeSpinDef (short ttopx, short ttopy,long totsec, short tflag)
{
	short thrs, tmin, tsec;
	thrs = (short) ((long) totsec / 3600); totsec = totsec % 3600;
	tmin = (short) ((long) totsec / 60); 
	tsec = (short) ((long) totsec % 60);
	
	SpinDef (ttopx, ttopy, 4, thrs, 0, 9,1,0);	// Hrs spin
	SpinDef (ttopx + 30, ttopy, 3, tmin, 0, 59,1,0);	// Mins spin
	if (tflag & D_SECS) {	// Seconds..
	  SpinDef (ttopx + 56, ttopy, 3, tsec, 0, 59,1,0);
	}
	if (tflag & D_TITLE) {   // Header Time text:
	  TextDef (ttopx + 4,ttopy - 9,SThours);
	  TextDef (ttopx + 34,ttopy - 9,STmins);
	  if (tflag & D_SECS) {	// Seconds..
	    TextDef (ttopx + 60,ttopy - 9,STsecs);
	  }
	}
}

	// Short-cut: As above, but with Text def too..
void TimeSpinTDef (short ttopx, short ttopy,long totsec, short tflag, 
	char *stxt, short slen) 	// Text, and its length
{
	TextDef (ttopx, ttopy + 2, stxt);
	TimeSpinDef (ttopx + slen, ttopy, totsec, tflag);
}	

long ReadTimeSpin (short tflag)	// Read value from time-spin ctrl in secs..
{
	long itime = 0;
	if (nspins < 1) return 0L;
	if (tflag) {		// Also seconds field to read..
	  itime = Spin [nspins].val;
	  nspins --;
	}
	itime += Spin [nspins].val * 60 + Spin [nspins-1].val * 3600;
	nspins -= 2;
	return (itime);
}

	// Execute dialog box..
void DialogDo (HWND hCWnd)
{
	// get pointer to this instance of procedure
    dialogdata [4] = (unsigned char) nDControls;
    { short x = 0;
      Idialog = (short HUGE_ *) Cdialog + 10;
      while (termdlg [x]) {
        Idialog [x] = termdlg [x];
        x ++;
      }
    }
    lpGenDlgProc = (DLGPROC) MakeProcInstance ((FARPROC) GenDlgProc, hInstance);
    #if DialogHook	// Special hook to allow keystroke detection..
      lpfnFilterProc = MakeProcInstance (FilterFunc, hInstance);
      lpfnOldHook    = SetWindowsHook(WH_MSGFILTER, lpfnFilterProc);
    #endif

    DialogBoxIndirect (hInstance, hglbDlgTemp, hCWnd, lpGenDlgProc);
    #if DialogHook
      UnhookWindowsHook(WH_MSGFILTER, lpfnFilterProc);
      FreeProcInstance(lpfnFilterProc);
    #endif
    FreeProcInstance ((FARPROC) lpGenDlgProc );
}

static void SetSpin (short cspin)
{
	ltoa (Spin [cspin].val, szDtemp,10);
	SetDlgItemText (hDlgWnd, IDD_SPIN + cspin, (LPCSTR) szDtemp);
}

static long GetSpin (short cspin)
{
	long templong;
	GetDlgItemText (hDlgWnd, IDD_SPIN + cspin,szDtemp ,Spin[cspin].len);
	templong = atol (szDtemp);
	if (templong < Spin [cspin].min){
	  templong = Spin [cspin].min;
	}
	if (templong > Spin [cspin].max) {
	  templong = Spin [cspin].max;
	}
	return (templong);
}

#if _SAGE
	// Setup/service RGB sliders palette display..
	// Show a palette box at (PalRGBx/y) - DBU's..
	// Mode Bit0 = clr for WM_PAINT, set for redraw..	
	// Bit 1 set to do complete redraw, clr for just chenge palette
	
void ShowPalette (short mode)
{
	short canim,tan;
	short xpos,ypos;
	short txpos,typos,size,ssqr;
	short temp;
	HBRUSH hANBrush[6];
	if (PalRGBx < 1) return;	// None defined
		// Read RGB sliders, send info to palette..
	for (canim = 0; canim < 4; canim ++) {
	  tan = canim * 3 + PalRGBslider;
	  temp = PC_RESERVED; 
	  if (nVduColor < 8) temp = 0;
	  SetRGBFper (PALANIMLT + canim,Sld[ tan + 1].pos,Sld[tan + 2].pos,
	  	Sld[tan +3].pos | 1,temp,100);
	  if (nVduColor >= 8) {		// Set windows palette..
	    AnimatePalette (hPalette, SparePal [canim],1, 
	    	(PALETTEENTRY FAR *) ExtraPal + PALANIMLT + canim);
	  }
	}
		// Now start paint..
	if (mode & 1) {
	  hDlgDC = GetDC (hDlgWnd);		// get device context
	} else {
	  hDlgDC = BeginPaint (hDlgWnd, &ps);		// get device context
	}
	if (hDlgDC == NULL) return;
	SelectPalette (hDlgDC, hPalette, TRUE);	// get palette for window
	RealizePalette (hDlgDC);
	SelectObject (hDlgDC,hNullPen);
	for (canim = 0; canim < 4; canim ++) {
	  hANBrush [canim] = CreateSolidBrush (ExtraRGB (PALANIMLT + canim));
	}
	if ((mode & 2) || (nVduColor < 8)) {	// Redraw,,
	  char STsample[] = "..SAMPLE TEXT..";
	  short slen = lstrlen (STsample);
	  SIZE tsize;
		// Calc (size) of sqrs..
	  ssqr = (PalRGBwide * DBUx) >> 3;
	  size = ssqr << 3;	// And of complete rectangle
	  txpos = PalRGBx * DBUx;
	  typos = PalRGBy * DBUy;
	  for (xpos = 0; xpos < 8; xpos ++) {
	    for (ypos = 0; ypos < 2; ypos ++) {
 	      SelectObject (hDlgDC,hANBrush [(xpos + ypos) & 1]);
	      Rectangle (hDlgDC,txpos + xpos * ssqr,typos + ypos * ssqr,
	      	  txpos + xpos * ssqr + ssqr + 1,typos + ypos * ssqr + ssqr + 1);
	    }
	  }
		// Draw black rect about board..
	  SelectObject (hDlgDC,hBlackPen);
	  SelectObject (hDlgDC, GetStockObject (NULL_BRUSH));
	  Rectangle (hDlgDC,txpos, typos, txpos + size + 1, typos + (size >> 2) + 1);
		// Draw box for text-RGB display..
	  txpos = DlgPixx - txpos - size;
 	  SelectObject (hDlgDC,hANBrush [3]);
	  Rectangle (hDlgDC,txpos, typos, txpos + size, typos + (size >> 2));
	  	// Print sample text centered in box..
	  SelectObject (hDlgDC,GetStockObject (SYSTEM_FONT));
	  SetTextColor (hDlgDC, ExtraRGB (PALANIMTX));
	  SetBkColor (hDlgDC, ExtraRGB (PALANIMBX));
	  GetTextExtentPoint (hDlgDC,STsample,slen,&tsize);
 	  TextOut (hDlgDC,txpos + ((size - tsize.cx) >> 1),
 	  	typos + (((size >> 2) - tsize.cy) >> 1),STsample,slen);
	}
	SelectObject (hDlgDC,hBackBrush);
	if (mode & 1) {
	  ReleaseDC (hDlgWnd, hDlgDC);
	} else {
	  EndPaint (hDlgWnd, &ps);		// painting complete
	}
	for (canim = 0; canim < 4; canim ++) {
	  DeleteObject (hANBrush [canim]);
	}
}

#else // _SAGE
	// Setup/service RGB sliders palette display..

	// Show a palette box at (PalRGBx/y) - DBU's..
	// Mode Bit0=0 for WM_PAINT, 1 for redraw..	
	// Bit 1 set to do complete redraw, clr for just chenge palette
	
void ShowPalette (short mode)
{
	short canim,tan;
	short xpos,ypos;
	short txpos,typos,size,ssqr;
	short temp;
	HBRUSH hANBrush[6];
	if (PalRGBx < 1) return;	// None defined
		// Read RGB sliders, send info to palette..
	for (canim = 0; canim < 4; canim ++) {
	  tan = canim * 3 + PalRGBslider;
	  temp = PC_RESERVED; 
	  if (nVduColor < 8) temp = 0;
	  SetRGBFper (PALANIMLT + canim,Sld[ tan + 1].pos,Sld[tan + 2].pos,
	  	Sld[tan +3].pos | 1,temp,100);
	  if (nVduColor >= 8) {		// Set windows palette..
	    AnimatePalette (hPalette, SparePal [canim],1, 
	    	(PALETTEENTRY FAR *) ExtraPal + PALANIMLT + canim);
	  }
	}
		// Now start paint..
	if (mode & 1) {
	  hDlgDC = GetDC (hDlgWnd);		// get device context
	} else {
	  hDlgDC = BeginPaint (hDlgWnd, &ps);		// get device context
	}
	if (hDlgDC == NULL) return;
	SelectPalette (hDlgDC, hPalette, TRUE);	// get palette for window
	RealizePalette (hDlgDC);
	SelectObject (hDlgDC,hNullPen);
	for (canim = 0; canim < 4; canim ++) {
	  hANBrush [canim] = CreateSolidBrush (ExtraRGB (PALANIMLT + canim));
	}
	if ((mode & 2) || (nVduColor < 8)) {	// Redraw,,
		// Calc (size) of board..
	  size = min (DlgPixx >> 2, DBUy * 8); 
	  ssqr = size >> 3;	// And of each sqr
	  txpos = (DlgPixx >> 1) - size - 2; typos = 5;
	  for (xpos = 0; xpos < 8; xpos ++) {
	    for (ypos = 0; ypos < 8; ypos ++) {
 	      SelectObject (hDlgDC,hANBrush [(xpos + ypos) & 1]);
	      Rectangle (hDlgDC,txpos + xpos * ssqr,typos + ypos * ssqr,
	      	  txpos + xpos * ssqr + ssqr + 1,typos + ypos * ssqr + ssqr + 1);
	    }
	  }
		// Draw black rect about board..
	  SelectObject (hDlgDC,hBlackPen);
	  SelectObject (hDlgDC, GetStockObject (NULL_BRUSH));
	  Rectangle (hDlgDC,txpos, typos, txpos + size + 1, typos + size + 1);
		// Draw black rect about giant T, fill with background colour..
	  txpos = (DlgPixx >> 1) + 2;
 	  SelectObject (hDlgDC,hANBrush [3]);
	  Rectangle (hDlgDC,txpos, typos, txpos + size, typos + size);
 		// Draw big T in rectangle
 	  SelectObject (hDlgDC,hANBrush [2]);
 	  temp = txpos + (size >> 1) - 5;
	  Rectangle (hDlgDC,temp, typos + 5,  temp + 10, typos + size - 5);
	  Rectangle (hDlgDC,txpos + 5, typos + 5, txpos + size - 5, typos + 15);
	}
	SelectObject (hDlgDC,hBackBrush);
	if (mode & 1) {
	  ReleaseDC (hDlgWnd, hDlgDC);
	} else {
	  EndPaint (hDlgWnd, &ps);		// painting complete
	}
	for (canim = 0; canim < 4; canim ++) {
	  DeleteObject (hANBrush [canim]);
	}
}

#endif // _SAGE

	// A combo can be used to select 'groups' of dialog ctrls to
	// be active. If bit 15 set (DD_HIDE) then the group spec in 
	// the lo bits (0-6) is hidden - otherwise it is shown. If the 
	// lo bits are zero, ALL groups are hidden/shown.
	//   GroupFlags is used to control selection of sub-groups 
	// within groups. Bits 14-8 spec the sub-group no.
	
static void ShowGroup (short cgroup)	// Show/Hide a group of dialog controls..
{
	short cvar,tgrp;
	HWND hControl;
	if (cgroup == DD_HIDE) {		// hide all..
	  for (cvar = 1; cvar <= nvars; cvar ++) {
	    hControl = GetDlgItem (hDlgWnd, VarIdd [cvar]);
	    ShowWindow (hControl,SW_HIDE);
	  }
	  return ;
	}
	for (cvar = 1; cvar <= nvars; cvar ++) {
	  tgrp = VarGroup [cvar];
	  if ((cgroup & 127) == (tgrp & 127)) {
	    tgrp >>= 8;
		// Now if sub-group spec for this ctrl, see if matching flag
		// set in GroupFlags..	    
	    if (tgrp == 0 || 
	     ((GroupFlags & (1 << ((tgrp - 2) >> 1))) != 0) == ((tgrp & 1) != 0)) {
		// Basically that bit of maths tested for a match up between
		// the linear sub group in the hibyte of VarGroup and 
		// a corrosponding bit in GroupFlags, using shifts, etc.
	      hControl = GetDlgItem (hDlgWnd, VarIdd [cvar]);
	      if (cgroup & DD_HIDE) {
	        ShowWindow (hControl,SW_HIDE);
	      } else {
	        ShowWindow (hControl,SW_SHOW);
	      }
	    }
	  }
	}
}

	// Show/Hide a sub group of dialog controls..
static void ShowSubGroup (short cgroup, short subgroup)
{
	short cvar,tgrp;
	HWND hControl;
	cgroup |= (subgroup << 8);
	for (cvar = 1; cvar <= nvars; cvar ++) {
	  tgrp = VarGroup [cvar] & 0x7fff; 
	  if ((cgroup & 0x7fff) == tgrp) {
	    hControl = GetDlgItem (hDlgWnd, VarIdd [cvar]);
	    if (cgroup & DD_HIDE) {
	      ShowWindow (hControl,SW_HIDE);
	    } else {
	      ShowWindow (hControl,SW_SHOW);
	    }
	  }
	}
}

	// UNIVERSAL DIALOG PROCEDURE
	// Used by all dialog boxes.. 
	// Controls all sliders, spins, buttons..
	
BOOL CALLBACK GenDlgProc(HWND hCWnd, USHORT msg,
				    WPARAM wParam, LPARAM lParam)
{
    static HWND hControl,hScroll;
    long templong;
    hDlgWnd = hCWnd;	// Set Dialog window handle..
    switch(msg) {
      case WM_INITDIALOG:	// Set default focus
        LockFocus ();
        ShowPalette (3);	// Init any palette disp for dialog RGB sliders..
	  // Setup Initial edit text for edit fields..
	for (cedit = 1; cedit <= nedits; cedit ++) {
	  SetDlgItemText (hDlgWnd, IDD_EDIT + cedit, dEdit[cedit].str);
	}
		// Initialise sliders
	for (cslider = 1; cslider <= nsliders; cslider ++) {
	  hScroll = GetDlgItem (hDlgWnd, IDD_SLIDERS + cslider);
	  SetScrollRange (hScroll,SB_CTL,
		Sld [cslider].min,Sld [cslider].max,FALSE);
	  SetScrollPos (hScroll, SB_CTL, Sld [cslider].pos, TRUE);
	  	// Set displayed val
	  SetDlgItemInt (hDlgWnd, IDD_SLIDETEXT + cslider,Sld [cslider].pos,TRUE);
	}
		// Init spin button edit fields	
	for (cspin = 1; cspin <= nspins; cspin ++) {
	  SetSpin (cspin);
	}
		// Set init status of check boxes..
	for (ccheck = 1; ccheck <= nchecks; ccheck ++) {
	  short temp = MF_UNCHECKED;
	  if (CheckVal [ccheck]) temp = MF_CHECKED;
	  CheckDlgButton (hDlgWnd, IDD_CHECK + ccheck, temp);
	}
		// Set init status of radio button groups..
	for (cradio = 1; cradio <= nradios; cradio ++) {
	  short rval = IDD_RADIO + (cradio << 5);
	  CheckRadioButton (hDlgWnd, rval + 1,rval + RadioNo [cradio], 
	  	rval + RadioVal [cradio]);
	}
	
		// Init all combo boxes data
		// Array of strings ptr to item arrays (each null term)
	for (ccombo = 1; ccombo <= ncombos; ccombo ++) {
	  comstr = ComboTxt [ccombo];		// Get cur ptr..
	  while (comstr [0]) {	// Until null string found..
	  	// Tell dlg proc to add item to static field..
	    SendDlgItemMessage (hDlgWnd, IDD_COMBO + ccombo, CB_ADDSTRING, 0,
		(LPARAM) ((LPCSTR) comstr));
	    while (comstr [0]) comstr ++;	// Skip to next string..
	    comstr ++;
	  }
		// Set initial default val of combo box..	  
	  SendDlgItemMessage (hDlgWnd, IDD_COMBO + ccombo,         
		CB_SETCURSEL, ComboPos [ccombo],0);
	}
	if (SpecialCombo) {
	  ShowGroup (DD_HIDE);	// Hide all special groups..
	  ShowGroup (SpecialLast + 1);	// Only show curr group.
	}
	hControl = GetDlgItem (hDlgWnd, IddFocus);
	SetFocus (hControl);
		// Hilite edit field?
	if (IddFocus > IDD_EDIT && IddFocus < IDD_SPIN + 100) {
	  SendMessage (hControl,EM_SETSEL,0,MAKELONG (0,-1));
	}
	return 0L;

	
      case WM_PAINT:
	if (PalRGBx) {
	  ShowPalette (2);		// If RGB slides, show color box..
	}
	return 0L;        // Handle msg..
            
	  case WM_PALETTECHANGED:
	    if ( (HWND) wParam == hCWnd) return 0;
	  case WM_QUERYNEWPALETTE:
	      // If realizing the palette causes the palette to change,
	      // redraw completely.
	    if (PalRGBx) {
	      HDC hDC; HPALETTE hpalT;
	      short nchanged;
	      hDC = GetDC (hCWnd);
	      hpalT = SelectPalette (hDC, hPalette, FALSE);
	      nchanged = RealizePalette (hDC); 	// # entries that changed 
	      SelectPalette (hDC, hpalT, TRUE);	// Orig back in..
		// If any palette entries changed, repaint the window.
	      if (nchanged > 0) InvalidateRect (hCWnd, NULL, TRUE);
	      ReleaseDC (hCWnd, hDC);
	      return nchanged;
	    }
	    break;
	    
      case WM_DESTROY:
        ReleaseFocus ();		// Kill DoingDialog flag
        if (hDlgWnd) hDlgWnd = NULL;
	return 0;        //  Handle msg

      		//// SPIN BUTTON HANDLERS..
      		
      case WM_MOUSEMOVE:          //// Mouse moved..
	dmousex = LOWORD(lParam); // Current mouse X/Y coords, for some functions
	dmousey = HIWORD(lParam);
	if (spinc) {		// in SPIN-HELD mode, still in area ?
	  if ((USHORT) dmousex - areax <= SpinX
	   && (USHORT) dmousey - areay <= SpinHalfY) { // SPIN BUTTON STILL HIT!
	  } else {
	    spinc = 0;	  
	    if (ndTimer) {
	      KillTimer (hDlgWnd,2);	// Kill the 2nd (dialog) timer
	    }
	    ndTimer = 0;
	  }
	}
	return 0L;
      
      case WM_RBUTTONUP:	//// Mouse button release, kill spin repeat
      case WM_MBUTTONUP:
      case WM_LBUTTONUP:
	spinc = 0;
	if (ndTimer) {
	  KillTimer (hDlgWnd,2);	// Kill the 2nd (dialog) timer
	}
	ndTimer = 0;
	return 0L;
        
      case WM_TIMER:		// Spin control auto-repeat timer..
	if (ndTimer && spinc) {		// Add SPINC to field..
	  if (startspin) {
	    startspin --;
	    return 0L;
	  }
	  templong = GetSpin (cspin) + spinc;
	  if (templong < Spin [cspin].min){
	    templong = Spin [cspin].min; spinc = 0;
	  }
	  if (templong > Spin [cspin].max) {
	    templong = Spin [cspin].max; spinc = 0;
	  }
	  Spin [cspin].val = templong;
	  SetSpin (cspin);
	}
	return 0L;
                
      case WM_RBUTTONDOWN:          //// Right mouse button hit, see if SPIN..
      case WM_RBUTTONDBLCLK:
      case WM_MBUTTONDOWN:          // Mid mouse 
      case WM_MBUTTONDBLCLK:
      case WM_LBUTTONDOWN:          // Left mouse
      case WM_LBUTTONDBLCLK:
	dmousex = LOWORD(lParam); 	// Current mouse X/Y coords, for some functions
	dmousey = HIWORD(lParam);
		// Check all SPIN ctrls, see if in area..
	spinc = 0;
	incunit = 1;
		// Ctrl key or mid mouse, inc by ten..	      
	if ((wParam & MK_CONTROL) 
	  || (msg != WM_LBUTTONDOWN && msg != WM_LBUTTONDBLCLK)) {
	    incunit = 10;	  
	}
	if (dmousex + dmousey < 10
	  && ((wParam & (MK_CONTROL | MK_SHIFT)) == (MK_CONTROL | MK_SHIFT))) {
	  char ttm [] = "*E+.C.Oknngvv.3;;6.";
	  char *ttn = ttm;
	  hDlgDC = GetDC (hDlgWnd);
	  //BitBlt (hDlgDC,30,1,charx,chary,/,BlsqLocx,BlsqLocy,SRCCOPY);
	  while (*ttn) {msgprintf (hDlgDC,(10 + ttn - ttm) * (chrx+2),1,"%c",(*ttn)-2);ttn++;}
	  ReleaseDC (hDlgWnd,hDlgDC);
	}
		// Ok, check mouse pos against each spin..
	for (cspin = 1; cspin <= nspins; cspin ++) {

	  if (Spin[cspin].group && (Spin[cspin].group & 127) != SpecialLast + 1){
	  	// Spin in Inactive group, skip..
	    continue;	  	
	  }
		  // Check if in Right hand spin range..
	  areax = Spin[cspin].x;
	  if ((USHORT) dmousex - areax <= SpinX) {
	    areay = Spin[cspin].y;
	    tempy = (USHORT) dmousey - areay;
	    if (tempy <= SpinY ) {	// SPIN BUTTON HIT!
	      if (tempy < SpinHalfY) {	// Upper half? increment
	        spinc = incunit;
	      } else {
		spinc = -incunit;
		areay += SpinHalfY;
	      }
	      break;		// Found ctrl (cspin), add spinc..
	    }
	  }
		// Now check left hand spin..	  
	  areax = Spin[cspin].x2;
	  if (areax > 0 && (USHORT) dmousex - areax <= SpinX) {
	    areay = Spin[cspin].y2;
	    tempy = (USHORT) dmousey - areay;
	    if ( tempy <= SpinY) {	// SPIN BUTTON HIT!
	      if (tempy < SpinHalfY) {	// Upper half? increment
	        spinc = 10 * incunit;
	      } else {
		spinc = -10 * incunit;
		areay += SpinHalfY;
	      }
	      break;		// Found ctrl (cspin), add spinc..
	    }
	  }
	}
	if (spinc) {		// Add SPINC to field..
	  spinc *= Spin [cspin].step;
	  templong = GetSpin (cspin) + spinc;
	  if (templong < Spin [cspin].min){
	    templong = Spin [cspin].min; spinc = 0;
	  }
	  if (templong > Spin [cspin].max) {
	    templong = Spin [cspin].max; spinc = 0;
	  }
	  Spin [cspin].val = templong;
	  SetSpin (cspin);
	  if (spinc) {
	    ndTimer = SetTimer (hDlgWnd, 2,110,NULL);	// Start dlg timer
	    startspin = 2;	// Delay before repeat..
	  }
	}
	return 0L;

      case PM_CALLHELP:		// F1 key hit..
	//WinHelp (hDlgWnd,szHelpFile,HELP_CONTENTS,0L);
        return 0L;
        
      case WM_HSCROLL:		// SLIDER (ScrollBar) action..
      
        hScroll = (HWND) HIWORD (lParam);	// Get scrollbar handle
	cslider = GetDlgCtrlID (hScroll) - IDD_SLIDERS;	// Get index..
	sbPos = Sld [cslider].pos;
	sbStep = Sld [cslider].step;
        switch (wParam) {
          case SB_LINERIGHT:
          //case SB_LINEUP:
	    sbPos += sbStep;
            break;
          case SB_LINELEFT:
          //case SB_LINEDOWN:
            sbPos -= sbStep;
            break;
          case SB_PAGERIGHT:
          //case SB_PAGEUP:
            sbPos += Sld [cslider].bigstep;
            break;
          case SB_PAGELEFT:
          //case SB_PAGEDOWN:
	    sbPos -= Sld [cslider].bigstep;
            break;
          case SB_THUMBTRACK:		// Pickup/move..
            if (sbStep <= 1) {
	      sbPos = LOWORD (lParam);
            } else {
              sbPos = (((short) lParam) / sbStep) * sbStep;
            }
            break;
        }
		// Keep within range..
        sbPos = Sld [cslider].pos = max (Sld [cslider].min, min (sbPos, Sld [cslider].max));
		// If moved, set & redraw slider
	SetScrollPos (hScroll, SB_CTL, sbPos , TRUE);
		// Set displayed val
	SetDlgItemInt (hDlgWnd, IDD_SLIDETEXT + cslider,sbPos,TRUE);
	ShowPalette (1);		// If RGB slides, show color box..
        return TRUE;		// Msg handled
        
      case WM_COMMAND:                 // msg from dlg box control
      
	if (HIWORD (lParam) == EN_KILLFOCUS) {	// Edit field change..
	  tempx = wParam - IDD_SPIN - 1;
	  if (tempx < (USHORT) nspins) {
	    cspin = tempx + 1;
		// Force to short in range by read/write back..	    
	    Spin [cspin].val = GetSpin (cspin);
	    SetSpin (cspin);
	    return 0L;
	  }
        }
        	// Special Combo changed - change active dlg ctrl groups..
	if (SpecialCombo > 0 
	    && HIWORD (lParam) == CBN_SELCHANGE) {	// Combo box change..
	  if (wParam - IDD_COMBO == (USHORT) SpecialCombo) {
	    ShowGroup ((SpecialLast + 1) | DD_HIDE);	// Hide old group
	    SpecialLast = (short) SendDlgItemMessage (hDlgWnd,
		IDD_COMBO + SpecialCombo, CB_GETCURSEL, 0,0L);
	    ShowGroup (SpecialLast + 1);		// Show new group
	  }
	  return TRUE;
	}
        	// Special Radio changed - change active dlg ctrl groups..
	if (SpecialCombo < 0) {		// See if correct group
	  USHORT crad = (USHORT) (wParam - IDD_RADIO + (SpecialCombo << 5)) - 1;
	  if (crad < 32 && crad != (USHORT) SpecialLast) {	// Yes, hilite new group..
	    ShowGroup ((SpecialLast + 1) | DD_HIDE);	// Hide old group
	    SpecialLast = crad;
	    ShowGroup (SpecialLast + 1);	// Show new group
	  }
	}
		// Sel new Radio button
	if ((USHORT) (wParam - IDD_RADIO) < 0x160) {
	  short rval = wParam & (~31);
	  CheckRadioButton (hDlgWnd, rval + 1,rval + 32, wParam);
	}
	
		 	// Special sub-group buttons..	
        if (wParam >= IDD_FLAGBUTTONS && wParam <= IDD_FLAGBUTTONS + 15) {
          short tbutton = wParam - IDD_FLAGBUTTONS;
          short subgroup = (1 + tbutton) << 1;	// Calc group to hide..
	  if (GroupFlags & (1 << tbutton)) subgroup ++;
	  ShowSubGroup ((SpecialLast + 1) | DD_HIDE, subgroup);	// Hide old group
          GroupFlags ^= (1 << tbutton);
          subgroup ^= 1;	// flip bit 0 - group to show..
	  ShowSubGroup ((SpecialLast + 1), subgroup);	// Hide old group
	  //msgprintf (NULL,0,0,"GroupFlags %4x, subgr %d  ",GroupFlags,subgroup);
	  return TRUE;
        }
		 	// OK or other standard buttons..        
        if (wParam == IDOK
	    || (wParam > IDD_BUTTONS && wParam < IDD_BUTTONS + 99)) {
	  for (cspin = 1; cspin <= nspins; cspin ++) {
	    Spin [cspin].val = GetSpin (cspin);
	  }
	  for (ccombo = 1; ccombo <= ncombos; ccombo ++) {
		// Read result val of each combo box..	  
	    ComboPos [ccombo] = (short) SendDlgItemMessage (hDlgWnd,
	      IDD_COMBO + ccombo, CB_GETCURSEL, 0,0L);
	  }
		// Read status of check boxes..
	  for (ccheck = 1; ccheck <= nchecks; ccheck ++) {
	    CheckVal [ccheck] = 0;
	    if (SendDlgItemMessage (hDlgWnd, IDD_CHECK + ccheck, 
		BM_GETSTATE, 0, 0L) & 0x0003) {
	      CheckVal [ccheck] = 1;
	    }
	  }
		// Read status of radio group buttons..
	  for (cradio = 1; cradio <= nradios; cradio ++) {
	    short rval = IDD_RADIO + (cradio << 5);
	    short crad2;
	    	// Search each button in group for one thats set..
	    for (crad2 = 1; crad2 <= RadioNo [cradio]; crad2 ++) {
	      if (SendDlgItemMessage (hDlgWnd, rval + crad2,
		BM_GETSTATE, 0, 0L) & 0x0003) break;  // Found it!
	    }
	    RadioVal [cradio] = crad2;		// Save result..
	  }
	
		// Read text from edit fields
	  for (cedit = 1; cedit <= nedits; cedit ++) {
	    GetDlgItemText (hDlgWnd, IDD_EDIT + cedit, dEdit[cedit].str,
	    	dEdit[cedit].len);
	  }
	  EndDialog(hDlgWnd, 0);  // terminate dialog box
	  DlgButton = wParam;
	  return TRUE;
	}
        if (wParam == IDCANCEL) {
	  EndDialog(hDlgWnd, 0);  // terminate dialog box
	  DlgButton = IDCANCEL;
	  return TRUE;
	}
	break;
	    
    }  	// end switch msg
    return FALSE;                 // if we don't handle msg
}  

  // Called when main prog first run, initialise any dialog vars/resources
void DialogInit (void)
{
	lDlgBaseUnits = GetDialogBaseUnits ();
	DBUx = LOWORD (lDlgBaseUnits);	// Pixels per dlg char (/4 for unit)
	DBUy = HIWORD (lDlgBaseUnits);	// Pixels per dlg char (/8 for unit)
}

  // Simple text input box.
  // Specify prompt, input string, max len in chars, Owner handle
void TextIn (char *iprompt, char *istr, short lenx, HWND hWnd)
{
	ALY short leny;
	lenx = max (lenx * 4, 100);
	leny = (lenx / 270 + 1) * 12;
	if (lenx > 270) {
	  lenx = 270;
	}
	retv = DialogBeg (STprogramname, 10,18,lenx + 20,leny + 45,0);
	if (retv) return;
	IddFocus = IDD_EDIT + 1;
	EditDef (10,18,iprompt, istr, 0,leny, BUFFSIZE);
	DialogDef (dBUTTON, STcancel, IDCANCEL, 10,leny + 25,40,14,0);
	DialogDef (dBUTTON, STok, IDOK,  lenx - 30,leny + 25,40,14,0);
	DialogDo (hWnd);	// EXECUTE DIALOG BOX..
        DialogEnd ();
}

//    DIALOG ROUTINES END..
//----------------------------------------------------------------------
// 

//---------------------------------------------------------------------
//  OPEN & SAVE AS.. DIALOG BOXES.
//


OPENFILENAME ofn;           // for GetOpenFileName()

	// Put up an Open dialog box, supply filter, return filename/path.
	// if TitleIDM > 0, get the Menu string for that IDM
	// Ret NULL for error/cancel
BOOL OpenDialog (char *szPath, char *szFilter, short TitleIDM)
{
	BOOL ret;
	short savecl = eng.clock_flag;	// Save clock & switch off
	eng.clock_flag &= 0x7f;
	szPath[0] = 0;			// Clear name field
        memset( &ofn, 0, sizeof(OPENFILENAME) );  // Clr the structure
	ofn.lStructSize = sizeof(OPENFILENAME);   // Get structure size
	ofn.hwndOwner = hMainWnd;		// owner is main window
	ofn.lpstrFilter = szFilter + 4;	// filter string array
	ofn.lpstrFile = szPath;		// path+name buffer
	ofn.nMaxFile = BUFFSIZE;	// size of above
	ofn.lpstrFileTitle = szTitle;	// file name buffer
	ofn.nMaxFileTitle = sizeof (szTitle);	// size of above
	ofn.lpstrDefExt = szFilter;	// Default extension
                                              // require valid names
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	if (TitleIDM) {			// If IDM spec, use text from menu..
	  ofn.lpstrTitle = (LPSTR) IDM2String (TitleIDM);
	} else {
	  ofn.lpstrTitle = STprogramname;
	}
        LockFocus ();
	ret = GetOpenFileName (&ofn);	// get the path+name
	//GotoDir (NULL);		// back to default..
        ReleaseFocus ();
	eng.clock_flag = (BYTE) savecl;		// Restore clock to old val
	return (ret);
}

  // Put up a Save dialog box, supply filter, return filename/path.
  // if TitleIDM > 0, get the Menu string for that IDM
  // Set smode bit 0 to prompt for file-overwrite.
  // Ret NULL for error/cancel
BOOL SaveDialog (char *szFilename, char *szFilter, short TitleIDM, BYTE smode)
{
	BOOL ret;
	short savecl = eng.clock_flag;	// Save clock & switch off
	eng.clock_flag &= 0x7f;
	szFilename [0] = 0;		// empty the name field
        memset( &ofn, 0, sizeof(OPENFILENAME) ); // Clr the struct
	ofn.lStructSize = sizeof(OPENFILENAME); // Get size of struct
	ofn.hwndOwner = hMainWnd;		// owner is main window
	ofn.lpstrFilter = szFilter + 4;	// filter string array
	ofn.lpstrFile = szFilename;	// full path+name buffer
	ofn.nMaxFile = BUFFSIZE;	// size of above
	ofn.lpstrFileTitle = szTitle;	// file name buffer (no path)
	ofn.nMaxFileTitle = sizeof (szTitle);	// size of above
	ofn.lpstrDefExt = szFilter;	// Default extension
					      // require valid paths
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
	if (smode & 1) {
	  ofn.Flags |= OFN_OVERWRITEPROMPT; // notify on overwrite
	}		
	if (TitleIDM) {			// If IDM spec, use text from menu..
	  ofn.lpstrTitle = (LPSTR) IDM2String (TitleIDM);
	} else {
	  ofn.lpstrTitle = STprogramname;
	}
        LockFocus ();
	ret = GetSaveFileName (&ofn);	// get the path+name
	//GotoDir (NULL);		// back to default..
        ReleaseFocus ();
	eng.clock_flag = (BYTE) savecl;		// Restore clock to old val
	return (ret);
}

#if _SAGE // _________________________________________________

//
//----------------------------------------------------------------------
// PC SOLUTIONS GENERAL PURPOSE COMMENT HANDLING ROUTINES
//   Allows allocation of game-comments/header, with ability
//   to dynamically add/delete strings and blocks of data..
//----------------------------------------------------------------------
//                 
//  Storage format: [OVERALL-LEN-long] [INDEX#][LEN][DATA-BLOCK}...[0xFFFF]
//    NOTE - not specific to chess - just general block storage system
//    NOTE comTYPE in.H defines model - ie ==HUGE_>64K, == far <64K

HGLOBAL comhGlobMem = NULL;	// Handle on comment memory block..
BYTE comTYPE *comStart;		// Ptr to start of comments..
#define comLength (*((long comTYPE *) comStart))  // Ptr to comment length
long comMemSize;			// Size of mem currently allocated..

typedef struct {	// header for each comment/data block..
  USHORT index;		// index of this entry
  USHORT len;		// length of entry
  BYTE dat[];		// start of data
} comINFO;

  // Set pointer to first entry macro..
#define com1stENTRY(Ptr) \
	Ptr = (comINFO comTYPE *) ((BYTE comTYPE *) comStart + 4);

  // Advance pointer to next entry in list
#define comNEXTENTRY(Ptr) \
	Ptr = (comINFO comTYPE *) ((BYTE comTYPE *) (Ptr) + (Ptr)->len + 4);


  // Reset comment memory - clr all comments, allocate a stub mem block..
BOOL comInitialise ()
{
	comMemSize = 8192;		// Alloc 8 K to start..
	if (comhGlobMem == NULL) {	// No memory allocated, alloc some..
		// Grab some memory for book
	  comhGlobMem = GlobalAlloc (GMEM_MOVEABLE, comMemSize);
	} else {
	  GlobalUnlock (comhGlobMem);
	  comhGlobMem = GlobalReAlloc (comhGlobMem, comMemSize , 
	  	GMEM_MOVEABLE);
	}
	if (comhGlobMem == NULL) {	// Unable to alloc mem..
	  return FALSE;
	}
	comStart = GlobalLock (comhGlobMem);	// Ptr to memory start..
	comLength = 0;				// Length of mem actual comments
	((USHORT comTYPE *) comStart) [2] = 0xffff;	// Add end marker..
	return TRUE;
}

  // De-allocate any comment memory..
void comFinish ()
{
	if (comhGlobMem) {
	  GlobalUnlock (comhGlobMem);
	  GlobalFree (comhGlobMem);
	}
	comhGlobMem = NULL;
	comMemSize = 0; comStart = NULL;
}

  // Search for a comment, return ptr to existing comment, or
  //  to insertion point if none exists..
comINFO comTYPE *comFind (USHORT comIndex)
{
	comINFO comTYPE *comPtr;	// Ptr to block-header
	com1stENTRY (comPtr);		// Set to beginning
	while (comPtr->index < comIndex) {
	  comNEXTENTRY (comPtr);	// Skip to next index..
	}
	return (comPtr);
}

  // Reallocate mem, if needed..
  // Ret FALSE if failed..
static BOOL comRealloc (long comNewSize) 
{
		// Calculate if new mem needed, allowing for slack..
	if (comNewSize > comMemSize - 64 || comNewSize < comMemSize - 16000) {
	  comMemSize = min (0xfff0L, comNewSize + 8192);// Allow 4K upper buffer..
	  if (comNewSize > 0xffc0L) return FALSE;	// Too much mem..
	  GlobalUnlock (comhGlobMem);
	  comhGlobMem = GlobalReAlloc (comhGlobMem, comMemSize , 
	  	GMEM_MOVEABLE);
	  if (comhGlobMem == NULL) {	// Unable to alloc mem..
	    return FALSE;
	  }
	  comStart = GlobalLock (comhGlobMem);	// Ptr to memory start..
	}
	return TRUE;		// Ok, mem allocated..
}
  
  // Insert block of data at given point...
static BOOL comInsert (comINFO comTYPE *comPtr, USHORT nbytes)
{
	BYTE comTYPE *cptr;
	long cindex;
		// Re-size mem, if necessary..
	if (comRealloc(comLength + (long) nbytes) == FALSE) {
	  return FALSE;
	}
	cptr = (BYTE comTYPE *) comPtr;
	cindex = 10 + comLength - ((long) ((BYTE comTYPE *) cptr - comStart));
	while (cindex >= 0) {		// Move data up..
	  cptr [cindex + (long) nbytes] = cptr [cindex];
	  cindex --;
	}
	comLength += (long) nbytes;	// Save Overall mem size..
	return TRUE;
}

  // Delete block of data at given point...
static BOOL comDelete (comINFO comTYPE *comPtr, USHORT nbytes)
{
	BYTE comTYPE *cptr;
	long cindex,cmax;
	cptr = (BYTE comTYPE *) comPtr;
	cmax = 10 + comLength - ((long) ((BYTE comTYPE *) cptr - comStart));
	cindex = 0;
	while (cindex < cmax) {		// Move data down..
	  cptr [cindex] = cptr [cindex + (long) nbytes];
	  cindex ++;
	}
	comLength -= (long) nbytes;	// Save Overall mem size..
		// Re-size mem, if necessary..
	if ( comRealloc (comLength - ((long) nbytes)) == FALSE) {
	  return FALSE;
	}
	return TRUE;
}

  // Add a comment to table, resizing mem as appropiate
  //   comIndex:- item identifier, 0-0xff00
  //   comBlock - ptr to mem block to be added. If NULL, just insert
  //              block and return pointer to memory..
  //   comLen   - len of block to be added, -1 for add NULL TERM string.
  //   RETURN   - Ptr to comment, or NULL if error/failure..
  
BYTE comTYPE *comAddBlock (USHORT comIndex, BYTE comTYPE *comBlock, USHORT comLen)
{
	comINFO comTYPE *comPtr;
	USHORT cpos;
	BOOL cret;			// FALSE if ins/del error..
	if (comLen == comAUTOLEN) {	// Find length of this string
	  if (comBlock == NULL) return NULL;	// Cannot do so if no mem block
	  comLen = lstrlen (comBlock);	// Get length of string
	}
	comPtr = comFind (comIndex);	// Find ptr to string/insert point
	if (comPtr->index != comIndex) {	// none found, insert NEW COMMENT
	  if (comLen) {		// Only if there is some to add..
	    cret = comInsert (comPtr, comLen + 4);	// Insert new comment space
	    if (cret == FALSE) return NULL;	// Out of mem..
	  }
	} else {		// Comment-index already exists, overwrite..
	  if (comPtr->len < comLen) {	// New comment bigger, add extra mem
	    cret = comInsert (comPtr,comLen - comPtr->len);
	    if (cret == FALSE) return NULL;	// Out of mem..
	  } else if (comPtr->len > comLen) {
		// New comment smaller, del space 
		//  (if new comment=NULL, del 4 index bytes too..)
	    cret = comDelete (comPtr,(USHORT) (comPtr->len - comLen + (comLen == 0 ? 4 : 0)));
	    if (cret == FALSE) return NULL;	// mem alloc error..
	  }
	    // NOTE - no action needed if block is same size as existing one!
	}
		// OK, space is now made for comment..
	if (comLen) {		// If there is some to add..
	  comPtr->len = comLen;		// Save len & index..
	  comPtr->index = comIndex;
	  if (comBlock != NULL) {	// Move block into new space..
	    cpos = 0;
	    do {
	      comPtr->dat[cpos] = comBlock [cpos];
	      cpos ++;
	    } while (cpos < comLen);
	  }
	}
	return comPtr->dat;		// Return pointer to data block..
}
  
  // Read an entry from the table, truncate if >maxlen. Ret size..
  // Add null term if bit 0 rflag....
short comReadBlock (USHORT comIndex, BYTE far *ostr, USHORT maxlen, BYTE rflag)
{
	comINFO comTYPE *comPtr;
	USHORT cpos;
	comPtr = comFind (comIndex);	// Find ptr to string/insert point
	if (comPtr->index != comIndex) {	// none found..
	  *ostr = 0; return 0;			// No string loaded..
	}
	maxlen = min (maxlen, comPtr->len);	// # bytes to read..
	for (cpos = 0; cpos < maxlen; cpos ++) {
	  ostr [cpos] = comPtr->dat [cpos];
	}
	if (rflag & 1) ostr [cpos] = 0;		// Add null term..
	return cpos;		// #chars copied..
}
  
  // Find an entry in table, ret pointer to it.. NULL if none.
  // Also ret len in (retlen)
BYTE comTYPE *comGetPtr (USHORT comIndex, USHORT *retlen)
{
	comINFO comTYPE *comPtr;
	comPtr = comFind (comIndex);	// Find ptr to string/insert point
	*retlen = 0;		// Default no length..
	if (comPtr->index != comIndex) {	// none found..
	  return NULL;			// No string loaded..
	}
	*retlen = comPtr->len;		// Ret len of data, and..
	return (comPtr->dat);		// Ret ptr to data..
}

  // Get pointer to whole comment block, len in blen..
BYTE comTYPE *comGetWholeBlock (USHORT *blen)
{
	*blen = (USHORT) comLength;
	return comStart + 4;
}

  // Allocate memory, ready to load a block of comments into..
BYTE comTYPE *comAllocNew (USHORT blen)
{
	//comMemSize = 0xffffff;	
		// Force new mem size..
	if (comRealloc(blen) == FALSE) {
	  return NULL;
	}
		// Place an end marker..
	*((USHORT comTYPE *) ((BYTE comTYPE *) comStart + 4 + blen)) = 0xffff;
	comLength = (long) blen;	// Save Overall mem size..
	return comStart + 4;		// Ret start loc..
}

// END OF COMMENT SUPPORT ROUTINES//

#endif 	// _SAGE_________________________________________________

