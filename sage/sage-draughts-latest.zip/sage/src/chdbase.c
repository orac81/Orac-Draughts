// PDN DataBase support routines and functions
// Copyright A.Millett, 1994-2025.


#define STRICT		// strict type checking (put before #include)
#include <windows.h>	// include file for all Windows programs
#include <stdlib.h>	// RAND
#include <stdio.h> 
#include <string.h>	// STRLEN 
#include <ctype.h>	// ISDIGIT 
#include <time.h>	// Mix TIME functions..
#include <mmsystem.h>	// Multimedia inc (SOUND..)
#include <commdlg.h>	// for common dialogs (print..

#include "sageio.h"	// Generic IO code..
#include "sagewio.h"
#include "sagedlg.h"
#include "genio.h"	// Header for General IO routines..
#include "sagemain.h"	// Header with function/var prototype, & #defines..
#include "chengine.h"	// Header with info on CHECKER ENGINE..
#include "chdbase.h"	// Header for Database..


//---------------------------------------------------------------------
//  CONVERT POS from/to ASCII (FEN,EPD etc)
//



  // Turn current SAGE pos into an asc piece list.. 
  // FORMAT side:W#,K#:B#,#. (ie. W:W14,K7:BK31,28.)
void ConvertPos2Asc (char *cstr, char far *cbrd, short cside, BYTE extra)
{
	ext_encode_asc_pos (cstr, cbrd, cside);
}

  // Parse a line of SAGE asc text into a gamINITBRD struct at (setup)
  // Set (.brd) & (.side). Ret 0=error, or set to nchars read..
short ConvertAsc2Pos (char far *Inline, gamINITBRD *setup)
{
	short cret;
	cret = ext_decode_asc_pos (Inline, setup->brd);
	setup->castle = 0;
	setup->side = cret & 1;
	return (cret >> 1);
}


//---------------------------------------------------------------------
//  COMMENT/HEADER EDIT ROUTINES..
//


  // Extract & decode SAGE game-data from comment tables into local mem..
  // If gmode bit 0 set, just extract pointers to comments
  // if gmode bit 1 set, get init board pos (or just ptrs to it)
void gamExtractDetails (gamDETAILS *gamDet, BYTE gmode)
{
    if (gmode & 1) {	// Extract pointers only
      memset (gamDet,0,sizeof (gamPTR2DET));
    } else {		// Full extraction
      memset (gamDet,0,sizeof (gamDETAILS));	// Clr details
    }
    gamDet->h.result = 3;	// Default no result..
    comReadBlock (gamiHEADER,(BYTE far *) &(gamDet->h),sizeof (gamDETHEAD),0);
    if (gamDet->h.year == 0) gamDet->h.year = timeCalender.tm_year + 1900;
    if ((gmode & 2) && (eng.init_moven & 0x8000)) {	// Get ptrs to init board pos
      gamDet->p.brd = eng.init_board;
      gamDet->p.side = (eng.init_moven & 1) + 1;
      gamDet->p.castle = 0;
    }
    if (gmode & 1) {	// Extract pointers only (NULL if none..)
      gamDet->p.play1 = comGetPtr (gamiPLAY1,&(gamDet->p.lplay1));
      gamDet->p.play2 = comGetPtr (gamiPLAY2,&(gamDet->p.lplay2));
      gamDet->p.venue = comGetPtr (gamiVENUE,&(gamDet->p.lvenue));
    } else {
      comReadBlock (gamiPLAY1,gamDet->play1,sizeof (gamDet->play1) - 1,1);
      comReadBlock (gamiPLAY2,gamDet->play2,sizeof (gamDet->play2) - 1,1);
      comReadBlock (gamiVENUE,gamDet->venue,sizeof (gamDet->venue) - 1,1);
    }
    int2asc (gamDet->p.ecostr,gamDet->h.eco,4);	// Opening classification
}

  // Set SAGE game-data into comment tables..
  // Set bit 0 gmode to use pointer-info rather than actual str
void gamSetDetails (gamDETAILS *gamDet, BYTE gmode)
{
	comAddBlock (gamiHEADER,(BYTE far *) &(gamDet->h),sizeof (gamDETHEAD));
	comAddBlock (gamiPLAY1,gamDet->play1,comAUTOLEN);
	comAddBlock (gamiPLAY2,gamDet->play2,comAUTOLEN);
	comAddBlock (gamiVENUE,gamDet->venue,comAUTOLEN);
}

  // Edit SAGE game header details (white player, black player, venue, etc)
  // Emode zero for normal edit, bit 0 set for Save append/replace dialog
long DlgEditGameDetails (BYTE emode)
{
	int cret;
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
        cret = dlg_Init (IDM2String(IDM_EDITGAMEDET), -1,-1,300,200,0);
        if (cret == FALSE) return -1;
	gamExtractDetails (gamDet,0);	// Get game details,,
        dlgs.FocusID = IDD_EDIT + 1;
	//dlg_DefEdit (7,16, (FlagInitCol) ? STwhiteplayer : STblackplayer,
	//	gamDet->play1, -180,50, sizeof (gamDet->play1));
        dlg_DefEdit (7,16,(FlagInitCol) ? STwhiteplayer : STblackplayer,
		gamDet->play1,  180,50, sizeof (gamDet->play1),DLG_EDIT_LEFTTEXT); 
	dlg_DefSpinTxt (245,16,5,gamDet->h.elo1,0,9999,1,0,STwhiteelo,16);
	dlg_DefEdit (7,34, (FlagInitCol) ? STblackplayer : STwhiteplayer,
		gamDet->play2, 180,50, sizeof (gamDet->play2),DLG_EDIT_LEFTTEXT);
	dlg_DefSpinTxt (245,34,5,gamDet->h.elo2,0,9999,1,0,STblackelo,16);
	dlg_DefEdit (7,60,STvenue,gamDet->venue, 0,46, sizeof (gamDet->venue),DLG_EDIT_SCROLL);
	dlg_DefSpinTxt (80,120,5,gamDet->h.year,1200,3000,1,0,STyear,20);
	dlg_DefSpinTxt (20,150,5,gamDet->h.eco,0,9999,1,0,STecocode,80);
	dlg_DefRadio (210,115,D_GROUPBOX | 50,11,SToptresult,1 + gamDet->h.result,0);
        dlg_DefOKCancel (30,10,STok,NULL,50);
        dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
        if (dlgs.ButtonHit != IDOK) return -1;	// Cancel..
        gamDet->h.eco = (UINT) dlg_ReadSpin ();
        gamDet->h.year = (UINT) dlg_ReadSpin ();
        gamDet->h.elo2 = (UINT) dlg_ReadSpin ();
        gamDet->h.elo1 = (UINT) dlg_ReadSpin ();
        gamDet->h.result = (BYTE) dlg_ReadRadio () - 1;
	gamSetDetails (gamDet,1);	// Set game details,,
	return 0;
}

  // Get ptr to comment..
//MYINLINE BYTE far * comtReadPtr (UINT comIndex, UINT *retlen)
//{
//	return (comGetPtr (comIndex, retlen));
//}

  // Edit individual SAGE comment at current move..
void DlgAddComment ()
{
	short ccom = gamCOMMENTS + eng.move_number;	
	short cret;
		// Extract a null-term string..
	comReadBlock (ccom,szTemp,SIZEszTemp - 10,1);
	cret = dlg_TextIn (IDM2String(IDM_ADDCOMMENT), szTemp, 600,STok,NULL);
        if (cret != IDOK) return;	// Cancel..
	comAddBlock (ccom,szTemp,comAUTOLEN);
}
	

 //-------------------------------------------------------------------------
 //
 // PDN import/export routines..
 //

#define pdnMaxRead 8191
long pdnLastGameRead = 1;	// # of last game read from pdn file..
char pdnCurFile [300]="main.pdn"; 	// File/path of current pdn file..
char pdnCurFileOld [300]=""; 	// File/path of current pdn file..

long pdnFilePos;		// Cur pos in cur PDN file
short pdnIndex;			// PDN buffered-input index #.
char pdnSzTags [] = "Event\0Site\0Date\0Round\0White\0Black\0Result\0ECO\0"
	"WhiteElo\0BlackElo\0SetUp\0FEN\0\0\0\0\0\0";
#define pdnLASTTAG 9		// Highest tag #
char pdnSzResult [] = "0-1\0001/2-1/2\0001-0\0*\0\0\0\0";

#define pdnSkipSpace \
	do {\
	  cchr = cstr [cpos];\
	  if (cchr == 0) return 0;\
	  if (cchr != 32 && cchr != 13 && cchr != 10 && cchr !=	'\t') break;\
	  cpos ++;\
	  if (cpos > pdnMaxRead) return 0;\
	} while (1);
	
#define pdnNextBlock \
	pdnFilePos += cpos;\
	cstr = bfFileRead (pdnIndex, pdnFilePos, pdnMaxRead);\
	cpos = 0;
	

#define pdnNextNSBlock \
	pdnSkipSpace \
	pdnFilePos += cpos;\
	cstr = bfFileRead (pdnIndex, pdnFilePos, pdnMaxRead);\
	cpos = 0;

	// Next character
#define pdnNextChar cpos++; cchr = cstr [cpos];
	
	// Next char, but also ensure buffer never exceeded
#define pdnNextInChar \
	cpos++; \
	if (cpos >= pdnMaxRead) {\
	  pdnNextBlock; if (cstr == NULL) return 0;\
	}\
	cchr = cstr [cpos];

  // Scan past a comment.. ret# char read, or 0 for EOF/error
short pdnScanComment (char far *cstr)
{
	short cpos = 0;
	char cchr;
	if (*cstr == '{') {		// Recursive comment..
	  do {
	    pdnNextInChar;
	  } while (cchr != '}');
	} else {			// ;-single line comment..
	  do {
	    pdnNextChar;
	  } while (cchr != 10);	// Until LF..
	}
	return cpos;
}

  // PDN-Skip over game in open file.. (pdnIndex) at (pdnFilePos)
  // Return 1 if ok, 0 if fails..
MYINLINE short pdnSkipGame ()
{
	char far *cstr;		// Start of current block
	char cchr;
	int anydat = FALSE;
	short cpos = 0;		// pos reletive to that block..
        do {	// Skip TAG pairs - header info..
          pdnNextBlock; if (cstr == NULL) return 0;
          pdnSkipSpace;
          if (cchr != '[') break;	// Found 1st none-header info
	  anydat = TRUE;
          do {
            pdnNextInChar;
	    if (cchr == 0) return 0;
          } while (cchr != ']');
          cpos ++;
        } while (1);
        do {	// Now skip main-game tokens..
          pdnNextNSBlock;
    	  if (cstr == NULL) {
	    if (anydat == FALSE) return 0;
            cchr = '*';
	  } else {
            cchr = cstr [0];
	  }

          cchr = cstr [0];
          switch (cchr) {
            case '*':
              pdnFilePos ++;
              return 1;		// OK, found end..
            case '[':
              pdnFilePos --;
              return 1;		// OK, found end..
            case '0':
              if (cstr [1] == '-' && cstr [2] == '1') {
                pdnFilePos += 3;
                return 1;
              }
              break;
            case '1':
              if (cstr [1] == '-' && cstr [2] == '0') {
                pdnFilePos += 3;
                return 1;
              }
              if (cstr [1] == '/' && cstr [2] == '2' && cstr [3] == '-' 
              	   && cstr [4] == '1' && cstr [5] == '/' && cstr [6] == '2') {
              	pdnFilePos += 6;
              	return 1; 
              }
              break;
            case '{':			// Comment..
            case ';':
              cpos = pdnScanComment (cstr);
              if (cpos == 0) return 0;
              cpos ++;
              continue;
          }
          do {		// Scan past other tokens..
	    if (cchr == 0) return 0;
	    pdnNextInChar;
          } while (cchr != 32 && cchr != 10 && cchr != '\t');
        } while (1);
        return 0;		// Error..
}

  // Ret 1=ok, 0=fail
short pdnSkipHeader ()
{
	char far *cstr;		// Start of current block
	char cchr;
	short cpos = 0;		// pos reletive to that block..
        do {	// Read TAG pairs - header info..
          pdnNextBlock; if (cstr == NULL) return 0;
          pdnSkipSpace;
          if (cchr != '[') break;	// Found 1st none-header info
          do {
            pdnNextInChar;
          } while (cchr != ']');
          cpos ++;
        } while (1);
        return 1;		// OK, worked!
}
  
  
MYINLINE void pdnClrHead ()
{
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	memset (gamDet,0,sizeof (gamDETAILS));	// Clr details
	gamDet->h.result = 3;	// Default no result..
}

  // Read item from PDN header into Details..
MYINLINE void pdnAddHeadItem (BYTE citem, char *istr, short ipos)
{
	short rcode;
	char endch;
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	//if (sizeof (szTemp) < sizeof (gamDETAILS)) exit 0;
	citem --;
	  if (FlagInitCol == 0 && ((citem >> 1) == 2 || (citem >> 1) == 4)) {	// Reverse wht/blk..
	    citem ^= 1;
	  }
	endch = istr [ipos];
	istr [ipos] = 0;	// Force a null term..
        switch (citem) {
          case 0:		// Event
            if (istr [0] != '?') {
              lstrcpyn (gamDet->venue, istr, sizeof (gamDet->venue) - 2);
            }
	    break;
          case 1:		// Site
            if (istr [0] != '?') {
	      lstrcat (gamDet->venue, ", ");
	      lstrcat (gamDet->venue, istr);
	    }
            break;
          case 2:		// Date
	    if (strlen (istr) > 4) {
	      char *p = istr + strlen(istr) - 4;
	      int yr = str2val (p,10,4);
	      if (yr > 1500) {gamDet->h.year = (short) yr; break;}
	    }
	    gamDet->h.year = (short) str2val (istr,10,4);
	    break;
          case 3:		// Round
            break;
          case 4:		// White
            lstrcpyn (gamDet->play1, istr, sizeof (gamDet->play1) - 2);
	    break;
          case 5:		// Black
            lstrcpyn (gamDet->play2, istr, sizeof (gamDet->play2) - 2);
	    break;
          case 6:		// Result
	    rcode = genParseToken (pdnSzResult,istr);
	    if (rcode == 0) break;	// Bad result code..
	    gamDet->h.result = LOBYTE (rcode) - 1;
	    break;
	  case 7:		// ECO
	    if (istr [0] != '?') {
	        gamDet->h.eco = (short) str2val (istr,10,4);
	    }
	    break;
	  case 8:		// WHITE ELO
            if (istr [0] != '?') {
	      gamDet->h.elo1 = (short) str2val (istr,10,4);
            }
	    break;
	  case 9:		// BLACK ELO
            if (istr [0] != '?') {
	      gamDet->h.elo2 = (short) str2val (istr,10,4);
            }
	    break;
	  case 10:		// SetUp
	    break;
	  case 11:		// FEN
            if (istr [0]) {
	      gamDet->init.set = 2;	// Flag means bad pos..
              if (ConvertAsc2Pos (istr, &(gamDet->init))) {	// Legal pos found..
                gamDet->init.set = 1;	// Flag means set-up pos..
              }
	    }
	    break;
	}
	istr [ipos] = endch;	// Put old end back
}

  // Read header information into a (gamDETAIL) struct at (szTemp)
  // Ret 1=ok, 0=fail
short pdnReadHeader ()
{
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	short rcode;
	char *cstr;		// Start of current block
	char cchr;
	short cpos = 0;		// pos reletive to that block..
	short ipos;		// pos of input str..
	pdnClrHead ();		// Wipe temp data area..
        do {	// Read TAG pairs - header info..
          pdnNextBlock; if (cstr == NULL) return 0;
          pdnSkipSpace;
          if (cchr != '[') break;	// Found 1st none-header info
          cpos ++;
          	// Tokenise "Event.." tags..
          rcode = genParseToken (pdnSzTags,cstr + cpos);
          if (rcode) {		// Found a tag, read in data
            cpos += HIBYTE (rcode);	// Get len..
            do {		// Find open quotes..
              pdnNextChar;
              if (cpos >= pdnMaxRead) return 0;	// Too long
            } while (cchr != 34);		// Until 1st quote
            ipos = cpos + 1;	// Pos of input..
            do {		// Find close quotes..
              pdnNextChar;
              if (cpos >= pdnMaxRead) return 0;	// Too long
            } while (cchr != 34);		// Until 2nd quote..
            	// Ok found string start & len, decide how to process..
              pdnAddHeadItem (LOBYTE (rcode),&cstr [ipos],cpos - ipos);
	      if (gamDet->init.set == 2) return 0;	// Illegal pos
          }       
          do {		// Scan rest of data, until ']'..
            pdnNextChar;
            if (cpos >= pdnMaxRead) return 0;	// Too long
          } while (cchr != ']');
          cpos ++;
        } while (1);
        return 1;	// OK..
}

  // Read a comment into (istr).. ret# char read, or 0 for EOF/error
MYINLINE short pdnReadComment (char far *cstr, char *istr, short maxlen)
{
	short cpos = 0;
	short lpos = 1;		// # chars read
	short ipos = 0;		// # chars written
	char cchr;
	istr [0] = 0;
	if (*cstr == '{') {		// Recursive comment..
	  do {
	    pdnNextInChar;
	    lpos ++;
	    	// LF=end of str.. Add to istr..
	    if (cchr == '}' || cchr == 0) { 
	      break;
	    } else if (cchr == 13) { 	// ignore CR
	    } else if (cchr == 10) { 	// Spc for LF..
	      istr [ipos] = 32;
	      ipos ++;
	    } else {
	      istr [ipos] = cchr;
	      ipos ++;
	    }
	  } while (ipos < maxlen - 1);
	  istr [ipos] = 0;
	} else {			// ;-single line comment..
	  do {
	    pdnNextInChar;
	    lpos ++;
	  } while (cchr != 10);	// Until LF..
	}
	return lpos;
}

extern short whkingweights [] ;
BYTE *const pdnMatchBrd = (BYTE *) whkingweights;	// Match to search for 
short pdnMatchCol = 0;

  // Compare 2 boards (uses INT size for speed..)
MYINLINE BOOL pdnCompare (char far *mem1, char *mem2, UINT csize)
{
	register UINT cpos = csize >> 1;
	do {
	  cpos --;
	  if (((short far *) mem1) [cpos] != ((short *) mem2) [cpos]) {
	    return FALSE;	// Fail
	  }
	} while (cpos > 0);
	if (csize & 1) {		// Test left-over byte, if odd size..
	  if (mem1 [csize - 1] != mem2 [csize - 1]) {
	    return FALSE;
	  }
	}
	return TRUE;		// Success!
}


  // Save current pos as snapshot..
void pdnMatchSave ()
{
	_fmemcpy (pdnMatchBrd, eng.checker_board,eng.boardx * eng.boardy);
	pdnMatchCol = IsBlacksMoveAbs;
}

  // See if position matches..
BOOL pdnCheckMatch (short isBlk)
{
	if (pdnCompare (eng.checker_board, pdnMatchBrd,eng.boardx * eng.boardy) == FALSE) {
          return FALSE;
	}
        if (isBlk != pdnMatchCol) return FALSE;
	return TRUE;
}

  // Decode ASC move at cstr, ret mvinfo
int pdnDecodeMove (char *cstr, int fastmode, BYTE *pRoute)
{
	short cpos;
	int nroute = 0;
	const int maxroute = 100;

        memset (pRoute,0,maxroute);
        if (isdigit (*cstr) == 0) return -1;
        cpos = (short) str2val (cstr, 10, 5);
        if (cpos < 100) {	// 11-15, 11x18, 11x18x25..
          pRoute [0] = (BYTE) ext_num2pos ((BYTE) cpos);
	  nroute ++;
	  while (1) {
            while (isdigit (*cstr)) cstr ++;
            if (*cstr != '-' && *cstr != 'x') break;
            cstr ++;
	    pRoute [nroute] = (BYTE) ext_num2pos ((BYTE) str2val (cstr, 10, 2));
            if (pRoute [nroute] < 0) return -1;
	    nroute ++;
	    if (nroute > maxroute-5) return -1;   // Too long!
	  }
	  if (nroute < 2) return -1;
        } else {    // Old fashioned 1115 type format..
          pRoute [0] = (BYTE) ext_num2pos ((BYTE) ((short) cpos / 100));
          pRoute [1] = (BYTE) ext_num2pos ((BYTE) ((short) cpos % 100));
	  nroute = 2;
        }
	pRoute [nroute] = 0;	// Terminator..
        Pmove_test->from = (BYTE) pRoute [0];
        Pmove_test->to = (BYTE) pRoute [nroute - 1];
        Pmove_test->flags = 254;	// Allow multi-jump..
	if (Pmove_test->from == Pmove_test->to) return -1;
        //Pmove_test->routehash = 0;	// hash of all inbetween sqrs..
        if (fastmode) {
	  if (eng.checker_board [Pmove_test->from] == 0) return (-3);
	  if (eng.checker_board [Pmove_test->to] != 0) return (-1);
	  return 0;	// Fast conv, no legal check..
	}
        return ext_is_move_legal ();
}

  // PDN-Import SAGE game from open file.. (pdnIndex) at (pdnFilePos)
  // rmode set bit 0 to skip headers, just read game
  // rmode set bit 1 for line-import (get flag info, compare to prev game)
  // rmode set bit 2 for compare diagram to (pdnMatchBrd/pdnMatchCol) 
  // Return 1 i+f ok, 0 if fails.. ret 2 if match sucseeds.
short pdnReadGame (BYTE rmode)
{
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	short cret = 0;		// Return code:0=fails
	char far *cstr;		// Start of current block
	char cchr;
	short cpos = 0;		// pos reletive to that block..
	short matchok = 1;
	BYTE mvRoute [100];

	if ((rmode & 1) == 0) {
	  comInitialise ();	// Clear comment memory..
	  cret = pdnReadHeader ();
	  if (cret == 0) {	// Error in header..
	    goto ImpErr;
	  }
	  gamSetDetails (gamDet,1);	// Save game details,,
	}
	{
          BYTE tmp = VarMainBook;
	  int tmp2 = VarEndgameDB;		// Disable endgame db look during build..
	  Clr_(EndgameDB);
          Clr_(MainBook);	// Disable main book..
	  ext_init_game ();
          VarMainBook = tmp;	// Re-enable?
	  VarEndgameDB = tmp2;
        }
	if ((rmode & 1) == 0 && gamDet->init.set) {	// Set up pos..
	  _fmemcpy (eng.checker_board, gamDet->init.brd, MAX_CHECKER_BOARD);
	  eng.param_ax_pass = gamDet->init.side;
	  ext_set_board_pos ();
          if ((rmode & 4) && pdnCheckMatch (IsBlacksMoveAbs)) {	// Diagram matched..
            matchok ++;
          }
	}
	pdnNextBlock; if (cstr == NULL) return 0;		// Re-get cstr..
        do {	// Now parse main-game tokens..
          pdnNextNSBlock;
    	  if (cstr == NULL) {
	    if (eng.move_number == 0) return 0;
            cchr = '*';
	  } else {
            cchr = cstr [0];
	  }
          	// Result code?
          if (cchr == '*') {
            cpos ++; break;		// OK, found end..
          } else if (cchr == '[') {
            break;		// OK, found end..
          } else if (cchr == '0') {
            if (cstr [1] == '-' && cstr [2] == '1') {
              cpos += 3;
              break;		// OK, found end..
            }
          } else if (cchr == '1') {
            if (cstr [1] == '-' && cstr [2] == '0') {
              cpos += 3;
              break;		// OK, found end..
            }
            if (cstr [1] == '/' && cstr [2] == '2' && cstr [3] == '-' 
            	   && cstr [4] == '1' && cstr [5] == '/' && cstr [6] == '2') {
              cpos += 6;
              break;		// OK, found end..
            }
          }
          		// Move # or move.. 
          if (isdigit (cchr)) {
            short zpos = cpos;
            do {
              zpos++; cchr = cstr [zpos];
            } while (isdigit (cchr));
            if (cchr != '.') goto LoadSAN;	// Load in ##-## move..
            while (cchr == '.') {	// Skip any dots after move #..
              pdnNextChar ;
            }
            continue;			// Next token
          }
          
          if (isalpha (cchr)) {	 // Std.Alg.Not.(SAN) -Move token..
LoadSAN:
	    cret = pdnDecodeMove (cstr+cpos, rmode & 4,mvRoute);
            //eng.lparam_pass = (long) ((char far *) cstr + cpos);
            //eng.param_ax_pass = (rmode & 4) ? 2 : 3;
            //rcode = ext_misc_service ();
            if (cret) {
              goto ImpErr;
            }
            do {		// Skip over SAN characters..
              pdnNextChar;
            } while (isalpha (cchr) || isdigit (cchr) || cchr == '-' 
            	|| cchr == '+' || cchr == '=');
            if (rmode & 2) {	// Import PDN->book opt..
	      BYTE cflag = 0;
	      switch (cchr) {
	        case '<' : cflag = 1; cpos ++; break;
	        case '?' : cflag = 2; cpos ++; break;
	        case '!' : cflag = 6; cpos ++; break;
	        case '>' : cflag = 7; cpos ++; break;
	      }
	      exAddExtraInfo (cflag, *((short far *) Pmove_test));  // Save flag/last game info
	    }
	    if (rmode & 4) {		// Special scan-fast do move
	      short lastcol;
              ext_make_move (2,mvRoute);
	      lastcol = 6 & eng.checker_board [Pmove_test->to];  // Kludge to make col moved available
              if (pdnCheckMatch (lastcol == 2)) {	// Diagram matched..
                matchok ++;
              }
	    } else { 			// Do the move normal load..
              BYTE tmp = VarMainBook;
	      int tmp2 = VarEndgameDB;		// Disable endgame db look during build..
	      Clr_(EndgameDB);
              Clr_(MainBook);	// Disable main book..
              ext_make_move (1,mvRoute);
              VarMainBook = tmp;	// Re-enable?
	      VarEndgameDB = tmp2;
            }
            continue;		// Next token..
          }
          switch (cchr) {		// Other tokens..
            case 123:			// Comment..
            case ';':
              cpos = pdnReadComment (cstr,szTemp,SIZEszTemp);  // Read into szTemp
              if (cpos == 0) goto ImpErr;
              	// Save comment..
              if ((rmode & 4) == 0) {
	        comAddBlock (gamCOMMENTS + eng.move_number,szTemp,comAUTOLEN);
	      }
              cpos ++;
              continue;
            case '(':			// Sub-variation
              do {
                pdnNextInChar;
                if (cchr == 123) {
                  short apos = pdnScanComment (cstr);
                  if (apos == 0) goto ImpErr;
                  cpos += apos;
                }
              } while (cchr != ')');
              cpos ++;
              continue;
            case '.':
              cpos ++;
              continue;
            case ',':
              cpos ++;
              continue;
            case '<':
              cpos ++;
              continue;
            case '>':
              cpos ++;
              continue;
            case '?':
              cpos ++;
              continue;
            case '!':
              cpos ++;
              continue;
          }
          goto ImpErr;		// Unrecognised token, exit as error..
        } while (1);
        pdnFilePos += cpos + 1;
        if ((rmode & 4) == 0) {
          eng.param_ax_pass = 0;
          ext_step_move ();
        }
        return matchok;
ImpErr:
        eng.param_ax_pass = 0;
	ext_step_move ();
	return 0;
}


  // external Reset PDN file
void pdnResetFile (short cindex)
{
	pdnIndex = cindex;
	pdnFilePos = 0;		// index into cur file..
}

  // PDN-Import game..
  // Read Nth game from file.. 
  // (-101 for last,-100 for re-read cur game, -99 for next..)
  // if filename="", then read from last file..
  // Return # chars if game read ok
  // Return 0 if fails..
  // return -1 if EOF..
long pdnImport (char *pfile, long ngame)
{
	long pdnFileLen = GetFileLen (pfile);
	pdnFilePos = 0;		// index into cur file..
	if (ngame < 1) {	// index based on last game #
	  ngame = max (1,pdnLastGameRead + ngame + 100);
	}
	
		// Open a buffered read-file
	pdnIndex = bfFileOpen (pfile,-1,0x7ff0,READ);
	if (pdnIndex == HFILE_ERROR) return 0;
		// Skip over early games..
	for (pdnLastGameRead = 1; pdnLastGameRead < ngame; pdnLastGameRead ++) {
	  if (pdnSkipGame () == 0) {	// Past end/error..
	    if (pdnFilePos + 20 > pdnFileLen) {
	      pdnFilePos = -1; 	// EOF..
	    } else {
	      pdnFilePos = 0; 	// Error..
	    }
	    break;
	  }
	  pdnFilePos ++;
	}
		// Load cur game..
	if (pdnReadGame (0) == 0) {	// Past end/error..
	  if (pdnFilePos + 20 > pdnFileLen) {
	    pdnFilePos = -1; 	// EOF..
	  } else {
	    pdnFilePos = 0; 	// Error..
	  }
	}
	bfFileClose (pdnIndex);
	return pdnFilePos;
}

long pdn_ngames (char *pfile) 
{
    pdnImport (pfile,9999999L);
    return pdnLastGameRead - 1;
}

  // Dialog box for import PDN game..
  // Set mode (1=reload last,2=next..) to import next game
void pdnDlgImport (int mode)
{
	long cgame;
	long cret;
	StopAutoPlay ();	// If comp v comp, back to normal
	StopThinking ();
	if (mode && *pdnCurFile) {	// Load next..
	  cgame = pdnLastGameRead + mode - 1;
	  if (cgame < 1) cgame = 1;
	} else {
	  if (OpenDialog (szPath, STpdnfilter, IDM_PDNIMPORT) == FALSE) goto EndPDN;
		// Dialog box to input 	
          cret = dlg_Init (szTitle, -1,-1,100,100,0);
          if (cret == FALSE) return;
	  cgame = 1;
	  lstrcpyn (pdnCurFile, szPath, sizeof (pdnCurFile) - 2);
	}
	SetWaitCursor 		// Macro - set hour-glass mouse..
	cret = pdnImport (pdnCurFile,cgame);
	if (cret == 0) {	// Read error..
	  DoMessage (STEinvalidfile);
	}
	if (cret == -1) {	// EOF...
	  SoundIt (); 
	  pdnLastGameRead = 1;
	  DoMessage (STend);
	}
	SetNormCursor 
EndPDN:
        open_ClassifyCurGame ();
	InitThink (ThinkOpp);
	return ;
}

  // Turn current PDN move to a string...
  // Ret # chars..
MYINLINE short pdnGetMoveStr (char *istr, short cmove)
{
	char *cstr = istr;
	if ((cmove & 1) == 0 && movenumbering) {	// Add move #..
	  INT2ASC3NOLEAD (cstr,(cmove + 2) >> 1);
	  ADDCHAR (cstr,'.');
	  ADDCHAR (cstr,' ');
	}
	Move2Str (cstr, cmove, 0);	// Get short-not move..
	cstr [9] = 32;
	do {
	  cstr ++;
	} while (*cstr != 32);
	*cstr = 0;		// Add null term..
	return (cstr - istr);	// Ret # chars
}

  // Calculate wrap-point in given string
  // ilen = string len, wraplen = wrap pos, startpos==0 for split long..
  // Ret # chars, or zero when no more..
MYINLINE short pdnWrapStr (char far *cstr, short ilen, short wraplen, short startpos)
{
	char cchr;
	short cpos = 0;
	short lastbreak = 0;
	if (ilen <= 0) return 0;
	if (wraplen <= 0) return 0;
	do {
	  do {
	    cchr = cstr [cpos];
	    cpos ++;
	  } while (cchr != 32 && cpos < ilen);
	  if (cpos >= wraplen) {
	    if (startpos < 3 && lastbreak == 0) {  // Split a long line
	      return (wraplen);
	    }
	    return (lastbreak);		// Break at prev point..
	  } 
	  if (cpos >= ilen) return (cpos);	// No more chars..
	  lastbreak = cpos;		// Save as new break point..
	  //cpos ++;
	} while (1);
}

pdnINFO pdnInfo;	// Struct with info for PDNEXPORT..
char outBuf [400];	// Gen 1 line of output ascii
gamPTR2DET pdnHead;	// Game-header info decoded ready for PDN export

//char pdnSzTags [] = "Event\0Site\0Date\0Round\0White\0Black\0Result\0ECO\0"
//	"WhiteElo\0BlackElo\0\0";

  // Extract SHORT 3 line header info..
MYINLINE short pdnExportShortHead (char *ostr, pdnINFO *pin)
{
      char *tstr;		// Temp ptr to output string
      char far *itstr;	// Ptr to cur item to add
      short itlen;			// Length of that item (0=none defined, -1 autolen)
      *ostr = 0;
      tstr = ostr;
      if ((pin->headitem) > 0x7f) {		// No more header data..
	ostr [0] = 0;
	return 0;
      }
      switch (pin->headitem) {
        case 0:		// Players
	  if (pdnHead.p.play1 != NULL) {
	    itstr = pdnHead.p.play1;
	    itlen = pdnHead.p.lplay1;
            _fmemcpy (tstr, itstr, itlen);	// Add WHITE name
            tstr += itlen;
	  }
	  ADDCHAR (tstr,'-');
	  if (pdnHead.p.play2 != NULL) {
	    itstr = pdnHead.p.play2;
	    itlen = pdnHead.p.lplay2;
            _fmemcpy (tstr, itstr, itlen);	// Add BLACK player name
            tstr += itlen;
	  }
	  if (tstr - ostr == 1 && pdnHead.p.venue == NULL) {  // No header!
	    *ostr = 0;
	    (pin->headitem) = 0xe0;
	    return 0;
	  }
	  *tstr = 0;
	  break;
          
	case 1:		// Event
	  if (pdnHead.p.venue != NULL) {
	    itstr = pdnHead.p.venue;
	    itlen = min (pdnHead.p.lvenue,pin->maxwide);
            _fmemcpy (tstr, itstr, itlen);	// Add VENUE..
            tstr += itlen;
	  }
	  *tstr = 0;
	  break;
	case 2:		// Date
	  wsprintf (tstr,"%4d  %s  %s  %4d-%4d",pdnHead.h.year,
	  	(LPSTR) GetNthStr (pdnSzResult, ((short) pdnHead.h.result) & 3),
	  	(LPSTR) pdnHead.p.ecostr, pdnHead.h.elo1, pdnHead.h.elo2);
	  tstr += lstrlen (tstr);
	  break;
	case 3:		// END - Force exit..
	  (pin->headitem) = 0xe0;
	  return 0;
      }
      if (pin->centwide && ostr [0]) {	// Center up text..
	short cpos = tstr - ostr;		// len..
        short addpos = (pin->centwide - cpos) >> 1;
        tstr += addpos;
        if (addpos > 0) {
          do {			// move string up..
            ostr [cpos + addpos] = ostr [cpos];
            cpos --;
          } while (cpos >= 0);
          do {			// pad out left to justify..
            addpos --;
            ostr [addpos] = 32;
          } while (addpos);
        }
      }
      pin->headitem ++;		// Next item..
      return tstr - ostr;	// Item added sucessfully, ret length..
}


  // Extract PDN header info..
MYINLINE short pdnExportHead (char *ostr, pdnINFO *pin)
{
    char *tstr;		// Temp ptr to output string
    char citem;
    static char far *itstr;	// Ptr to cur item to add
    short itlen;			// Length of that item (0=none defined, -1 autolen)
    char tmpstr [160];
    ///(*headitem) = 0xf0; return 0;
    do {
      *ostr = 0;
      tstr = ostr;
      if ((pin->headitem) > 0x7f) {		// No more header data..
	ostr [0] = 0;
	return 0;
      }
      itlen = 0;
      itstr = (char far *) tmpstr;	// Default to work-space..
      switch (pin->headitem) {
	case 0:		// Event
	  if (pdnHead.p.venue != NULL) {
	    itstr = pdnHead.p.venue;
	    itlen = pdnHead.p.lvenue;
	  }
	  break;
	case 1:		// Site
	  break;
	case 2:		// Date
	  if (pdnHead.h.year) {
	    int2asc (tmpstr, pdnHead.h.year,4);
	    itlen = 4;
	  }
	  break;
	case 3:		// Round
	  break;
	case 4:		// White
	  if (pdnHead.p.play1 != NULL) {
	    itstr = pdnHead.p.play1;
	    itlen = pdnHead.p.lplay1;
	  }
	  break;
	case 5:		// Black
	  if (pdnHead.p.play2 != NULL) {
	    itstr = pdnHead.p.play2;
	    itlen = pdnHead.p.lplay2;
	  }
	  break;
	case 6:		// Result
          itstr = GetNthStr (pdnSzResult, ((short) pdnHead.h.result) & 3);
          itlen = -1;	// Calc length
	  break;
	case 7:		// ECO
	  if (pdnHead.h.eco) {		// Classification code..
	    itstr = pdnHead.p.ecostr;
	    itlen = -1;		// Calc length
	  }
	  break;
	case 8:		// Wht ELO
	  if (pdnHead.h.elo1) {	
	    int2asc (tmpstr, pdnHead.h.elo1,4);
	    itlen = 4;
	  }
	  break;
	case 9:		// Blk ELO
	  if (pdnHead.h.elo2) {	
	    int2asc (tmpstr, pdnHead.h.elo2,4);
	    itlen = 4;
	  }
	  break;
	case 10:	// SETUP
	  if (pdnHead.p.side) {		// Just specify "1"..
	    tmpstr [0] = '1'; tmpstr [1] = 0; itlen = 1;
	  }
	  break;
	case 11:	// FEN
	  if (pdnHead.p.side) {		// Convert pos to string..
	    ConvertPos2Asc (tmpstr, pdnHead.p.brd, 
	    	pdnHead.p.side-1, pdnHead.p.castle);
	    itlen = -1;
	  }
	  break;
	case 12:		// END - Force exit..
	  (pin->headitem) = 0xe0;
	  break;
      }
      pin->headitem ++;		// Next item..
      if (itlen) {	// OK, item found, add it to dest string..
        short clen;	// Calc len (up to max)
	char *tagstr;	// Pointer to current tag string
        if (itlen == -1) itlen = lstrlen (itstr);
        	// Calc max allowable size of string
        clen = min (itlen, pin->maxwide - (tstr - ostr) - 3);
	citem = (pin->headitem) - 1;
	  if (FlagInitCol == 0 && ((citem >> 1) == 2 || (citem >> 1) == 4)) {
	    citem ^= 1;
          }
        tagstr = GetNthStr (pdnSzTags, citem);
        ADDCHAR (tstr,'[');
        ADDSTR  (tstr,tagstr);	// Add tag-pair id string..
        ADDCHAR (tstr,' ');
        ADDCHAR (tstr,34);
        _fmemcpy (tstr, itstr, clen);	// Add tag data
        tstr += clen;
        ADDCHAR (tstr,34);
        ADDCHAR (tstr,']');
        *tstr = 0;	// Null term
        return tstr - ostr;	// Item added sucessfully, ret length..
      }
    } while (1);	// Reloop if it is a null item..
}


  // Export a pdn file, line by line
  // if (pi) not NULL, Initialise export for that line-width..
  // return # chars if more lines. set pi->mode bit 0 when done..
  // if pi->flags bit 0 set, Tabbed output, else PDN.
  // if pi->flags bit 1 set, Print condensed header info
  // if pi->flags bit 2 set, Print FULL PDN header info
  // if pi->flags bit 3 set, Current move comment only.
  // if pi->flags bit 4 set, show using chess-base char set..
short pdnExportLine (pdnINFO *pi)
{
	static pdnINFO *pin;		// Ptr to info-struct
	static char *ostr;		// Ptr to Output string
	short movenum;			// End game move #
	static short xmax;		// Line width, in chrs..
	short xpos;
	static short cmove;		// cur move #
	static short comlen;		// Len of comment
	static short compos;		// Cur pos, if in middle of comment
	static BYTE comgot;		// Indicates comment for this move got
	static BYTE anngot;		// Indicates annote for this move got
	static BYTE EndResult;		// Indicates final end-result added..
	static char far *cstr;		// Comment string
	static char twork [20];		// Temp-current move-string..
	  const short mvsize = 7;		// Size of fixed move field
	short cpos;
	xpos = 0;		// # characters wide so far..
			// START NEW OUTPUT?
	if (pi != NULL) {		// Initialise new spool..
	  pin = pi;			// Save ptr to info struct..
	  movenum = eng.move_number;	// Save current game move # as end
	  cmove = eng.init_moven & 0x3fe;	// First move..
	  compos = 0;
	  comgot = 0;			// Comment not yet got..
	  anngot = 0;
	  cstr = NULL;
	  ostr = pi->outstr;		// Output string
	  xmax = pi->wide;		// Line width..wrap point..
	  pi->mode = 0;			// set mode to zero..
	  if (xmax < 5) goto pdnEnd;	// Too narrow, abort..
	  pi->headitem = 0xf0;		// Default no header
	  EndResult = 1;
	  if (pi->flags & 6) {		// Print Header info
	    if (pi->flags & 4) EndResult = 0;	// Enable end-result print?
	    // Get pointers to game details, initial board..
	    gamExtractDetails ((gamDETAILS *) &pdnHead,3); 
	    pi->headitem = 0;		// Start from beginning
	  }
	}
	*ostr = 0;
	if (pin->mode & 1) goto pdnEnd;	// Already finished..
	#if _CHAMP		// No header text..
	 pin->headitem = 0xf0;
	#else
	if (pin->headitem < 0x80) {		// Header info to print..
	  if (pin->flags & 2) {		// Condensed header info
	    return (pdnExportShortHead (ostr, pin));
	  } else {
	    return (pdnExportHead (ostr, pin));
	  }
	}
	#endif
	if (pin->flags & 1) goto pdnTabbed;	// Tabbed out mode..
	do {
pdnAddCom:
	 #if (_CHAMP == 0)
	  if (comgot == 0) {	// Not yet got this moves comment..
	    if (compos == 0) {	// Dont re-get if we alread have comment
		// Ok, see if we have a comment..
	        cstr = comGetPtr (gamCOMMENTS + cmove,&comlen);
	    }
	    if  (cstr) {	// Yes, we have a comment..
	    	
	      short cpos;
	      cpos  = pdnWrapStr (cstr + compos, comlen - compos,
	   		xmax - xpos - 1, xpos);
	      if (cpos == 0) {		// No more comment on this line?
	        return xpos;
	      }
	      if (compos == 0) {	// New comment, add open bracket..
	        ostr [xpos] = '{'; xpos ++;
	      }
	      _fmemcpy (ostr + xpos, cstr + compos, cpos);
	      compos += cpos;
	      xpos += cpos;
	      if (compos >= comlen) {		// No more comment, end..
	        ostr [xpos] = '}'; xpos ++;
	        ostr [xpos] = ' '; xpos ++;
	        ostr [xpos] = 0;
	        compos = 0; cstr = NULL;
	        comgot = 1;	// Dont try to reget this comment!
	      } else {		// Wrapped at spc, No more on this line
	        if (cpos) {	// Strip end-space?
	          if (ostr [xpos - 1] == 32) xpos --;
	        }
	        ostr [xpos] = 0;
	        return xpos;
	      }
	    }
	  }	// Comment end..
	 #endif // _CHAMP
	 
	  if (cmove >= eng.move_number) {  // end of game-line, no more..
	    char *rstr;
	    short rlen;
	    if (EndResult) goto pdnEnd;	// Already printed, done..
            rstr = GetNthStr (pdnSzResult, ((short) pdnHead.h.result) & 3);
            rlen = strlen (rstr);
	    if (xpos + rlen >= xmax && xpos > 1) {	// Over wrap point..
	      return xpos;
	    }
            memcpy (ostr + xpos, rstr, rlen + 1);
            xpos += rlen;
	    EndResult = 1;
	    return xpos;
	  }
	  cpos = pdnGetMoveStr (twork, cmove);
	  twork [cpos] = 32; cpos ++; twork [cpos] = 0;
	  if (xpos + cpos >= xmax && xpos > 0) {	// Over wrap point..
	    return xpos;
	  }
	  
	  memcpy (ostr + xpos, twork, cpos);
	  xpos += cpos;
	  ostr [xpos] = 0;
	  cmove ++;		// Next move..
	  comgot = 0;		// Comment not got for this move..
	} while (1);
pdnEnd:
	pin->mode = 1;		// Set mode, no more output..
	return xpos;
	
pdnTabbed:			// Alt simple tabbed output
	  if ((compos || anngot) && cmove >= eng.move_number) {	// end of game-line, no more..
	    ostr [xpos] = 0;
	    goto pdnAddCom;
	  }
	#define mvFIELD (mvsize + mvsize + 5)	// Move field size
	if (xmax > mvFIELD) {		// Center up output..
	  xpos = (xmax % mvFIELD) >> 1;	// Calc left-over (centering)
	  for (cpos = 0; cpos <= xpos; cpos ++) {
	    ostr [cpos] = 32;	
	  }
	}
	do {
	  char *tstr = ostr + xpos;
	  if ((cmove & 1) == 0 && movenumbering) {	// Add move #..
	    INT2ASC3 (tstr,(cmove + 2) >> 1);
	    ADDCHAR (tstr,'.');
	    ADDCHAR (tstr,' ');
	    xpos += 5;
	  }
	  do {
	    if (cmove >= eng.move_number) {	// end of game-line, no more..
	        ostr [xpos] = 0;
	        goto pdnEnd;
	    }
	    Move2Str (ostr + xpos, cmove, (BYTE) (FlagShortNot == 0));
	    xpos += mvsize;
	    ostr [xpos] = 0;
	    cmove ++;
	  } while (cmove & 1);
	  if (xpos + mvFIELD > xmax) {	// Over wrap point..
	    return xpos;
	  }
	} while (1);
	return xpos;
}

short pdnExport (char *pfile) 
{
	HFILE hFile;
	short nchr;
	short nwr;
	if (pfile == NULL) {	// Null filename, use a dialog first..
	  short stat = SaveDialog (szPath, STpdnfilter,IDM_PDNEXPORT,0);
	  if (stat == FALSE) return 0;
	  pfile = szPath;
	}
	if (FileExists (pfile)) {	// APPEND DATA..
	  hFile = _lopen (pfile, READ_WRITE);
	  if (hFile == HFILE_ERROR) return 0;
	  if (_llseek (hFile, 0L, 2) == HFILE_ERROR) {
	    goto pdnErr;
	  }
	  nwr = _lwrite (hFile,  "\x0d\x0a",2);	// Prn CR/LF
	  if (nwr == HFILE_ERROR) goto pdnErr;
	} else {
	  hFile = _lcreat (pfile, 0);
	  if (hFile == HFILE_ERROR) return 0;
	}
	memset (&pdnInfo, 0,sizeof (pdnInfo));
	pdnInfo.outstr = outBuf;
	pdnInfo.wide = 77;
	pdnInfo.maxwide = sizeof (outBuf) - 20;
	pdnInfo.flags = 4;	// Full PDN header..
	nchr = pdnExportLine (&pdnInfo);	// get 1st line
	do {
	  nwr = _lwrite (hFile,  pdnInfo.outstr, nchr);
	  if (nwr == HFILE_ERROR) break;
	  nwr = _lwrite (hFile,  "\x0d\x0a",2);	// Prn CR/LF
	  if (nwr == HFILE_ERROR) break;
	  if (pdnInfo.mode & 1) break;		// All over..
	  nchr = pdnExportLine (NULL);	// Next line ..
	} while (1);
pdnErr:
	_lclose (hFile);
	return 1;
}

 //-------------------------------------------------------------------------
 //
 // PDN Game-list browsing routines..
 //


 // Database game select edit field..
EDITINFO DBed = {0,0,7,14,2,0L,NULL,"",&hPopDC, &hPopWnd};

USERLISTBOX DBbox = {30,30,300,200,50,20,0L,0L,1L,NULL,NULL,NULL,9999,NULL};
BOOL ULboxflag = FALSE;		// TRUE when database list box active
UINT mhitx,mhity;	// Mouse hit position..
short DoingBuild = 0;	// Set while building DB index..
#define MAXDBGAMES 120		// Max DB games on screen..
long dbindex [MAXDBGAMES+2];	// Ptrs to DB games list displayed
short botspc;		// 
long DBcurgame = 0;
long dbselGameCount = 0;
BOOL dbselGameLoaded = FALSE;
long DBnSearch;		// # games found by search....
char DBSchIndexFile [] = "$temp._";	// Index file name..
BYTE dbOldIndexOk = 0;  // Set if prev built search index still applies..
char szDBSearch [258]=""; // String for database search..
BOOL dbselViewMode = FALSE;

char szTEMPGAMEFILE [] = "$$temp.chk";

#define MAXMVSCROLL 100	// range for mv box scroll bar

typedef struct {	// PDI index header..
  short len;		// Length of header..
  long pdnsize;		// Size of PDN file..
  long pdndate;		// File date stamp
  long spare;		// Spare bytes..		
  short spare2;
} PDIHEAD;

PDIHEAD far *pdiHead;		// Ptr to cur pdi header..
HGLOBAL pdihGlob = NULL;	// handle on pdi mem
long HUGE_ *pdiData;		// Ptr to entry data

  // Create a 1 line game summary text for PDN game-select
BOOL pdnGetGameSummary (char *otxt,long cgame,short maxlen)
{
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	short maxdet = (maxlen - 20) >> 2;
	short cstat;
	short clen;
	#if _DEBUG
	 static long ttgame;
	 ttgame = cgame;
	#endif
	if (dbselViewMode) maxdet = max (2,maxdet - 4);
	memset (otxt,32,maxlen);
	otxt [maxlen] = 0;
	otxt [maxlen + 1] = 0;
	otxt [maxlen + 2] = 0;
	otxt [maxlen + 3] = 0;
        if (bfIsFileClosed (1)) {	// Not open, reopen..
	  pdnIndex = 1;
	  cstat = bfFileOpen (pdnCurFile,pdnIndex,0x7ff0,READ);
	  if (cstat == HFILE_ERROR) return FALSE;
        }                
        #if _DEBUG
          if (ttgame == 148) {
            ttgame = ttgame;
          }
        #endif
        pdnFilePos = pdiData [cgame];
	cstat = pdnReadHeader ();
	if (cstat == 0) return FALSE;	// Error in header..
	clen = wsprintf (otxt,"%c%5lu %3.3s %4d %3d ",
	  gamDet->init.set ? '>' : ' ', cgame,
	  (LPSTR) GetNthStr (SToptresult,gamDet->h.result + 1) + 1,
	  gamDet->h.year, gamDet->h.eco);
	otxt [clen] = 32;
	_fmemcpy (otxt + clen, gamDet->play1, min (maxdet - 1,lstrlen (gamDet->play1)));
	clen += maxdet;
	_fmemcpy (otxt + clen, gamDet->play2, min (maxdet - 1,lstrlen (gamDet->play2)));
	clen += maxdet;
	if (dbselViewMode) {	// Show first few moves?
	  char far *cstr;
	  cstr = bfFileRead (pdnIndex, pdnFilePos, maxdet * 2 + 54);
	  if (cstr) {		// Copy first moves from games
	    short cpos = 0;
	    short spos = 0;
	    char cchr;
	    do {	// Filter out Ctl/xtra chars..
	      cchr = cstr [spos];
	      spos ++;
	      if (spos > maxdet * 2 + 50) break;
	      if (cchr < 32) continue;
	      if (cchr == '-' || cchr == 'x') continue;
	      if (cchr == '.') {	// scan back, del move #..
	        do {
	          if (cpos <= 0) break;
	          cpos --;
	        } while (isdigit (otxt [clen + cpos]));
	        continue;
	      }
	      otxt [clen + cpos] = cchr;
	      cpos ++;
	    } while (cpos + clen < maxlen);
	  }
	} else {		// Show venue..
	  _fmemcpy (otxt + clen, gamDet->venue, min (maxdet << 1,lstrlen (gamDet->venue)));
	}
        return TRUE;
}

// long xxx [200];

  // (re)Alloc mem for (csize) games PDI index..
BOOL pdiResize (long csize)
{
	BYTE HUGE_ *cptr;
	csize = csize * 4 + sizeof (PDIHEAD) + 16;
	if (pdihGlob == NULL) {
	  pdihGlob = GlobalAlloc (GMEM_MOVEABLE,csize);
	} else {
	  GlobalUnlock (pdihGlob);
	  pdihGlob = GlobalReAlloc (pdihGlob,csize,GMEM_MOVEABLE);
	}
	if (pdihGlob == NULL) return FALSE;
	cptr = GlobalLock (pdihGlob);
	pdiHead = (PDIHEAD far *) cptr;
	cptr += sizeof (PDIHEAD);
	pdiData = (long HUGE_ *) cptr;
	//#if _DEBUG
	//  pdiData = xxx;
	//#endif
	return TRUE;
}

  // Build PDI index info..
BOOL pdiBuild (char *pfile)
{
	long maxgames = 1024;
	long cgame = 1;
	long pdnFileLen = GetFileLen (pfile);

	if (pdiResize (maxgames) == FALSE) {
	  return FALSE;
	}
	pdnFilePos = 0;		// index into cur file..
		// Open a buffered read-file
	pdnIndex = bfFileOpen (pfile,-1,0x7ff0,READ);
	if (pdnIndex == HFILE_ERROR) return 0;
		// Skip over early games..
	pdnLastGameRead = 0;
	do {
	  pdnLastGameRead ++;
	  if (pdnLastGameRead >= maxgames) {	// Re-alloc mem..
	    maxgames += 1024;
	    if (pdiResize (maxgames) == FALSE) {
	      return FALSE;
	    }
	  }
	  pdiData [pdnLastGameRead] = pdnFilePos;	// Save index pos of game..
          if (VER_ == SHARE_) {	// Limit shareware ver to first 100
            if (pdnLastGameRead >= 200) {
	      pdnFilePos = -1; 	// Force Early EOF..
	      break;
            }
          }
	  if (pdnSkipGame () == 0) {	// Past end/error..
	    if (pdnFilePos + 20 > pdnFileLen) {
	      pdnFilePos = -1; 	// EOF..
	    } else {
	      pdnFilePos = 0; 	// Error..
	    }
	    break;
	  }
	  pdnFilePos ++;
	} while (pdnFilePos > 0);
	bfFileClose (pdnIndex);	
	return TRUE;
}

BOOL InitDBSelect ()
{
	char *endname;  // ptr to end of filename
	char origend;
	BOOL cstat;
	endname = pdnCurFile + lstrlen (pdnCurFile) - 1;  // ptr to end
		// Open Database files for reading..
	origend = *endname;
	if (FileExists (pdnCurFile) == FALSE) return FALSE;	// No pdn file..
      	*endname = 'I';		// Make .CBI on end.. Database index file
	cstat = FileExists (pdnCurFile);	// No pdn file..
      	*endname = origend;		// Make .CBF on end.. Database main file
	//if (cstat == FALSE) {		// Build new PDI index..
	//}
	if (pdiBuild (pdnCurFile) == FALSE) {	// Build new PDI index..
	  return FALSE;
	}
	dbselGameCount = pdnLastGameRead - 1;
	pdnLastGameRead = 1;
	pdnIndex = 1;
	cstat = bfFileOpen (pdnCurFile,pdnIndex,0x7ff0,READ);
	if (cstat == HFILE_ERROR) return FALSE;
        return TRUE;
}

void CloseDBSelect ()
{
	bfFileClose (1);	// Close main data
	bfFileClose (2);	// Close search index file..
	if (pdihGlob) {		// Free up any index mem..
	  GlobalUnlock (pdihGlob);
	  GlobalFree (pdihGlob);
	  pdihGlob = NULL;
	}
}

  // dbDoesHeadMatchSearch - routine..
  // See if szFind is anywhere in the (dbSHead) game record header txt
  // If supplied SEARCH string matches game, return 1, else 0.
  // Note - szFind should already be in LOWER case..
  // Supports WILDCARDS (?), AND (&), OR (|), NOT (!), operators 
  // in search text. Does Simple left to right parsing only..For example
  // kaspar&karpov        will find games with BOTH Kasparov/Karpov playing
  // kaspar|karpov        will find games with EITHER Kasparov/Karpov playing
  // kaspar|karpov&m?sc?w    finds EITHER Kasparov/Karpov playing in MOSCOW.
  // timm|kaspa&!mosc&!ussr   EITHER timman/kasparov, NOT in moscow or USSR
BOOL FASTCALL dbDoesHeadMatchSearch (gamDETAILS far *dbSHead, char *szFindi)
{
      char far *cptr;		// temp ptrs to game text..
      char far *fptr;
      char *ffind;		// temp ptr to search text
      short fend;			// start/end of txt search..
      short ctxt,ftxt;
      BYTE oper = 0;		// current Operator:0=AND, 1=OR
      BYTE oresult = 1;		// Result so far BOOLEAN - 0 or 1..
      		// (to start make last op "1 & ..."
      BYTE cresult;		// Result for current param (0,1)
      BYTE invert;		// Invert current op flag (NOT)
      char find1st;
      char *szFind = szFindi;
      char cchr;
      short schval;		// Val in search str
      short headval;		// Val from DB header
      BYTE condition;		// Comaprison operator 0<,1=,2>
      BYTE cstack = 0;		// Ptr to it..
      BYTE opstack [30];	// Stack for saving parenthesis data..
      if (*szFind == 0) return TRUE;	// Always match null..
		// Calc total game text length
      //lplay = (dbSHead->h.playersLength & 63);	// len player names
      //lven = (dbSHead->h.sourceLength & 63);	// len venue txt
      //lgtxt = lplay + lven;		// total game txt len
      				// (ie. all players/venue text)
	      
      		// Loop to evaluate parameters,,
      while (1) {			
        fend = 0;
	invert = 0;		// No invert..
	if (*szFind == '!') {	// NOT flag, invert..
	  invert = 1;
	  szFind ++;
	}
	if (*szFind == 0) break;	// Premature search str end
	
	find1st = *szFind;	// get first char for fast check..
	if (find1st == '(') {	// Open parenthesis..
	  szFind ++;
	  opstack [cstack] = oresult | (oper << 1) | (invert << 2);// Push on stack..
	  cstack ++;
	  if (cstack >= sizeof (opstack)) break;	// Overflow
	  oper = 0; oresult = 1;	// Start with "1 &.."
	  invert = 0;
	  continue;			// Eval code in brackets..
	}
        cptr = dbSHead->venue;	  // Set ptr to game txt start..
	fend = lstrlen (dbSHead->venue);
        
	condition = (BYTE) inchr ("<=>wbvr",find1st);
		// is it ECO/YEAR/GAMELEN parameter?
	if (condition >= 0 && condition < 3) {		// Param starts <=>..
	  szFind ++;
	  if (*szFind == '=' && condition != 1) {  // CONDITION <=  or >= 
	    szFind ++;
	    	// Just invert - ie. >= is same as !<, <= same as !>
	    condition = 2 - condition; 
	    invert = invert ^ 1;
	  }
	  schval = headval = 0;
	  find1st = *szFind;	// get first char for fast check..
	  if (isdigit (find1st)) {
	    schval = atoi (szFind);
	    if (schval > 1600) {	// Search for YEAR..
	      headval = (short) dbSHead->h.year;
	    } else {			// Search for GAME-LENGTH
	      headval = (short) dbSHead->h.eco;
	    }
	  }
	  cresult = invert;	// False by default
	  if (condition == 0) {		// Condition <..
	    if (headval < schval) {	// true, match
	      cresult = invert ^ 1;
	    }
	  } else if (condition == 1) {	// Condition =
	    if (schval == headval) {	// true, match
	      cresult = invert ^ 1;
	    }
	  } else {			// Condition >..
	    if (headval > schval) {	// true, match
	      cresult = invert ^ 1;
	    }
	  }
	  goto EvalDone;	// END ECO/YEAR/GAMELEN parameter..
	  
	  	// RESULT/WHT/BLK/VENUE command?
	} else if (condition > 2) {
	  if (szFind [1] == '!' && szFind [2] == '=' && szFind [3]) {
	    invert = invert ^ 1;
	    szFind ++;
	  }
	  if (szFind [1] == '=' && szFind [2]) {	// param:x=..
	    szFind += 2;
	    cresult = invert;		// default false..
	    switch (find1st) {
	      case 'r':
	        if ((*szFind & 3) == (dbSHead->h.result & 3)) {
	          cresult = !(invert);	// result match - true..
	        }
	        goto EvalDone;	// END result search..
	      case 'v':		// Venue - already got it..
	        break;
	      case 'b':		// player 1
	        if (FlagInitCol) {
	          cptr = dbSHead->play2;
	          fend = lstrlen (dbSHead->play2);
	        } else {
	          cptr = dbSHead->play1;
	          fend = lstrlen (dbSHead->play1);
	        }
	        break;
	      case 'w':		// player 2
	        if (FlagInitCol) {
	          cptr = dbSHead->play1;
	          fend = lstrlen (dbSHead->play1);
	        } else {
	          cptr = dbSHead->play2;
	          fend = lstrlen (dbSHead->play2);
	        }
	        break;
	    }
	  }
	}
		// Now scan game txt for possible matches..
	find1st = *szFind;
	for (ctxt = 0; ctxt < fend; ctxt ++) {
	  if (find1st == ((*cptr) | 32)) {	// 1st char may match..
	    ffind = szFind;
	    fptr = cptr;
		// Now see if that match holds out for current FIND param..
	    for (ftxt = ctxt; ftxt < fend; ftxt ++) {
	      cchr = *ffind;
	      	// Break out if mismatch..
	      if (cchr != '?' && cchr != tolower (*fptr)) break;
	      ffind ++;
	      fptr ++;
	      cchr = *ffind;
		  // See if it matches to end of this find string param
	      if (cchr == 0 || cchr == '|' || cchr == '&' || cchr == ')') {  // NULL,&,|
	        cresult = !(invert);	// Result = 1, unless inverted..
	        goto EvalDone;
	      }
	    }
	  } 
	  cptr ++;
	}
		// No match found, result 0 unless inverted..
	cresult = invert;
EvalDone:	// Ok, have evaluated 1 parameter, AND/OR with last oresult..
	if (oper) {
	  oresult |= cresult;		// OR with last result
	} else {
	  oresult &= cresult;		// AND with last result..
	}
		// Scan (szFind) ptr to end of current search operand
	while (1) {
	  cchr =*szFind;
	  if (cchr == 0 || cchr == '&' || cchr == '|' || cchr == ')') break;
	  szFind ++;
	}
	  // If NULL end reached, all params evaluated, return result
	if (cchr == 0) return (oresult);	// OK! good result, return..
	
	while (cchr == ')') {	// End of parenthesised expression
	  if (cstack == 0) break;	// No more stack..
	  cstack --;
	  cchr = opstack [cstack];	// Pull main result off stack
	  oper = cchr & 2;
	  cresult = (oresult ^ (cchr >> 2));	// 2nd result, with invert?
	  oresult = cchr & 1;		// Old 1st result off stack
	  szFind ++;
	  goto EvalDone;
	}
	  // Now set (oper) to 0 for AND (&) or 1 for OR (|) for next op
	oper = (cchr == '|');
	szFind++;	// move onto next operator
	//printsi (szFind,oresult);
      }		// and loop for next parameter..
      return FALSE;		// Syntax error in evaluation
}

  // As above, but heads in header for a game from current file first..
MYINLINE BOOL dbMatchSearch (char *szFind, long cgame)
{
	gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	short cstat;
	BOOL matchpos = FALSE;
	if (*szFind == 0) return TRUE;	// Always match null..
	if (cgame < 1) return FALSE;
	if (*szFind == '*') {		// Also find matching positions.
	  matchpos = TRUE; szFind ++;
	}
		// Now read in specified DB game
	pdnFilePos = pdiData [cgame];
	cstat = pdnReadHeader ();
	if (cstat == 0) return FALSE;	// Error in header..
	cstat = dbDoesHeadMatchSearch (gamDet,szFind);
	if (matchpos == FALSE || cstat == FALSE) return cstat;
	pdnFilePos = pdiData [cgame];
	cstat = pdnReadGame (4);
	return (cstat > 1);		// ret TRUE if pos matches..
}

short qkcount = 0;	// iteration count..
	// Ret non-zero if quit key hit..
short QuitKeyHit ()
{
	MSG msg;			// message from GetMessage
	qkcount ++;
	if (qkcount < 200) return 0;
	qkcount = 0;
	DoingBuild = 1;
		// See if ESC key hhas been hit - look at msg queue
	while (PeekMessage (&msg, NULL, WM_KEYDOWN,WM_KEYDOWN, PM_REMOVE)) {
	  if (msg.message == WM_KEYDOWN && msg.wParam == VK_ESCAPE ) {
	    Dink (); 
	    DoingBuild = 0;
	    return 1;
	  }
	  //TranslateMessage (&msg);     // convert keystroke 
	  //DispatchMessage (&msg);      // call window procedure 
	}
	DoingBuild = 0;
	return 0;
	    //return (GetKeyState (VK_F2) & 0x8000);
}

  // Search text dialog, return 0 for error..
BYTE dbDlgSearch ()
{
        int cret;
	dbOldIndexOk = 0;	// Invalidate old search index..
	cret = dlg_TextIn (STsearchfortext,szDBSearch,100,STok,NULL);
	if (cret == IDCANCEL) return 0;
	AnsiLower (szDBSearch);		// force string to LOWER case..
	return 1;
}

	// Get search string, re-build serach index..
	// ret 
BOOL pdnLoadGame (long cgame)
{
	short cstat;
	long pdnFileLen = GetFileLen (pdnCurFile);
        if (bfIsFileClosed (1)) {	// Not open, reopen..
	  pdnIndex = 1;
	  cstat = bfFileOpen (pdnCurFile,pdnIndex,0x7ff0,READ);
	  if (cstat == HFILE_ERROR) return FALSE;
	}
        pdnFilePos = pdiData [cgame];
		// Load cur game..
	if (pdnReadGame (0) == 0) {	// Past end/error..
	  if (pdnFilePos + 20 > pdnFileLen) {
	    pdnFilePos = -1; 	// EOF..
	  } else {
	    pdnFilePos = 0; 	// Error..
	  }
	}
	bfFileClose (pdnIndex);
	return (pdnFilePos > 0);
}


void CreateMyWindow (HWND *hpWnd, LPCSTR lpszClass, LPCSTR lpszTitle, DWORD Style,
	short wx, short wy, short lenx, short leny, HWND hParentWnd, short flags)
{
	if (flags & 1) {	// set by rect, not len..
	  lenx -= wx; leny -= wy;
	}
		// keep within vdu bounds..
	wx = max (min (nVduX - lenx,wx),-WndBorderx);
	wy = max (min (nVduY - leny,wy),-WndBordery);
	
	*hpWnd = CreateWindow (lpszClass,lpszTitle, Style,wx,wy,lenx,leny,
		hParentWnd, NULL,hInstance, NULL);
	ModSysMenu (*hpWnd);	// Delete unwanted sys menu cmds
	ShowWindow (*hpWnd, SW_SHOWNORMAL);	
}

	// Reset all params and start Custom popup dialog mode..
	// Main entry point to start..
	
void ResetPopDlg (short mode)
{
	short wtx,wty;
	long ltmp;
	DBbox.tline = 1L;		// top line..
	ClockOff			// switch Clock off
	MainMode = mode;	// Tells WinProc we are selecting DB..
	StopThinking ();		// Ensure no thinking..
		// Create the Pop-up dialog window..	
	if (hPopWnd == NULL) {
	  GetMainInfo ();		// Get pos info on main window..
	  DoingPopDlg = TRUE;
	  wtx = popdlgwnd.tx ;		// Position rel to main window
	  wty = popdlgwnd.ty ;
	  if (FlagPopUp) { // Add main wnd pos to this window pos
	    wtx += (short) (mainrct.left);
	    wty += (short) (mainrct.top);
	  } else {
	    wtx += (short) (absmain.left);
	    wty += (short) (absmain.top);
	  }
	  //if (FlagPopUp) {
	    ltmp = WS_POPUP;
	  //} else {
	  //  ltmp = WS_CHILD | WS_CLIPSIBLINGS;
	  //}
	  CreateMyWindow (&hPopWnd, "PopDlgClass", "",
		ltmp | WS_VISIBLE | WS_BORDER | WS_CAPTION | WS_SYSMENU
		| WS_MAXIMIZEBOX | WS_THICKFRAME,
		wtx,wty,popdlgwnd.lx,popdlgwnd.ly,
		hMainWnd,0);
	}
}

  // Database Select..
  // dmode=1 to only load if current DB illegal
  // Ret 0 for bad-name/cencel, 1 for OK..

BOOL dbDlgSelect (BYTE dmode)
{
	BOOL isDBok = FileExists (pdnCurFile);
	if (dmode && isDBok) {	// See if current DB filename is legal
	  return TRUE;
	}
	dbOldIndexOk = 0;
	if (SaveDialog (pdnCurFile, STpdnfilter, IDM_SELECTDATABASE,0) == FALSE) {
	  return FALSE;
	}
	szDBSearch [0] = 0;		// Wipe old search string..
	//dbCreateIfNone (szPath);
	return TRUE;
}

  // Edit db game as text file..
void dbEdit ()
{
    char szFil [256];
    if (FileExists (pdnCurFile) == FALSE) {	// Select dialog if no name
      if (OpenDialog (pdnCurFile, STpdnfilter, IDM_PDNIMPORT) == FALSE) {
        return;
      }
    }
    sprintf (szFil,"write %s",pdnCurFile);
    WinExec (szFil,SW_SHOWMAXIMIZED);
}


  // Database load/browse routines..
void dbDlgListGames (char *szName)
 {
	StopAutoPlay ();	// If comp v comp, back to normal
	StopThinking ();
	if (szName) {
	  strcpy (pdnCurFileOld,pdnCurFile);
	  strcpy (pdnCurFile,szName);
	}
	if (FileExists (pdnCurFile) == FALSE) {	// Select dialog if no name
	  if (OpenDialog (pdnCurFile, STpdnfilter, IDM_PDNIMPORT) == FALSE) {
	    return;
	  }
	}
		// Ok, dbase name in (pdnCurFile), open it..
	if (InitDBSelect () == FALSE) {
	  DoMessage (STEdatabasenotopened);
	  return ;
	}
	DBbox.nlist = dbselGameCount;
	dbselGameLoaded = FALSE;
	SaveGame (IDM_SAVEGAMEO,szTEMPGAMEFILE); // Write-back cur game & ALL settings
	pdnMatchSave ();			// Save cur pos for match-search..
	ResetPopDlg (DoingDBGameSelect);	// Start list-db mode
}

#define Col2sch(X) ((9-(X)/10)*10 + ((X)%10))

int col_ReadStr (BYTE *pIn, int ilen, BYTE *pDat)
{
     int cpos = 0;
     while (1) {
       char cchr = pDat [cpos];
       if (cchr == 13) {
         pIn[cpos] = 0;
         cpos += 2; break;
       }
       if (cpos < ilen) pIn[cpos] = cchr;
       cpos ++;
     }
     return cpos;
}


  // Load Collossus 95 format file..
short col_LoadNewFormat (char *szFile)
{
    long flen;
    BYTE *pDat;
    int cpos,clen;
    int ngame;
    int cgame,cflag;
    gamDETAILS gamHead;	// Temp uncompressed store of game header info..
    char szTmp [1000];

    flen = file_Length (szFile);
    if (flen < 0) return FALSE;
    pDat = (BYTE *) malloc (flen + 256);
    file_Load (szFile, pDat,0,flen);
    if (pDat[0] != 'C' || pDat[1] != 'O'|| pDat[2] != 'L') goto err;
    ext_init_game ();		// Start new game..
    comInitialise ();		// Clear old comment/header info..
    memset (&gamHead,0,sizeof (gamHead));
    gamHead.h.result = 3;	// Default no result.. (0:0-1,  1:Draw, 2:1-0, 3=none)
    cpos = 0;
    cpos += col_ReadStr (szTmp,sizeof(szTmp),pDat+cpos);
    if (cpos > flen) goto err;
    cpos += col_ReadStr (gamHead.play1,sizeof(gamHead.play1),pDat+cpos);
    if (cpos > flen) goto err;
    cpos += col_ReadStr (gamHead.play2,sizeof(gamHead.play2),pDat+cpos);
    if (cpos > flen) goto err;
	// Result..
    cpos += col_ReadStr (szTmp,sizeof(szTmp),pDat+cpos);
    if (cpos > flen) goto err;
    if (strcmp (szTmp,"Draw") == 0) {
      gamHead.h.result = 1;
    }
    if (strcmp (szTmp,"White Win") == 0) {
      gamHead.h.result = 0;
    }
    if (strcmp (szTmp,"Black Win") == 0) {
      gamHead.h.result = 2;
    }
	// Date..
    cpos += col_ReadStr (szTmp,sizeof(szTmp),pDat+cpos);
    if (cpos > flen) goto err;
    clen = strlen (szTmp);
    if (clen > 3) {
      gamHead.h.year = (short) str2val (szTmp + clen - 4,10,4);
    }
    cpos += col_ReadStr (gamHead.venue,sizeof(gamHead.venue),pDat+cpos);
    if (cpos > flen) goto err;
    cpos ++;
    // Now add to game..
    comAddBlock (gamiHEADER,(BYTE far *) &(gamHead.h),sizeof (gamDETHEAD));
    comAddBlock (gamiPLAY1,gamHead.play1,comAUTOLEN);
    comAddBlock (gamiPLAY2,gamHead.play2,comAUTOLEN);
    comAddBlock (gamiVENUE,gamHead.venue,comAUTOLEN);
      // cpos now at src sq list
      // Find # moves (dest sq list at cpos+ngame+1)
    ngame = 0;
    while (pDat[cpos + ngame] != 255) {
      if (cpos + ngame > flen) goto err;
      ngame ++;
    }
    for (cgame = 1; cgame <= ngame; cgame ++) {
      int msrc,mdest;
      GAMESTORE pmov [2];
      msrc = Col2sch (pDat[cpos+cgame-1]);
      mdest= Col2sch (pDat[cpos + ngame + cgame]);
	  	// Ok, now make move on board..
      Pmove_test->from = pmov[0].src = (BYTE) sch2cg ((short) msrc);
      Pmove_test->to = pmov [0].dest = (BYTE) sch2cg ((short) mdest);
      Pmove_test->flags = pmov[0].flag = 0;
      pmov [1].src = pmov [1].dest = 0;
      cflag = ext_is_move_legal ();		// nz=illegal mv..
      if (cflag && cgame == 1) goto err;
	  	// Temp Store move-flag..
      ext_checker_move (pmov,0,NULL);	// Exec move..
    }

    free (pDat);
    return TRUE;
err:
    free (pDat);
    return FALSE;
}

//---------------------------------------------
//  New db edit window routine..
//---------------------------------------------

typedef struct {
  int game;
} DB_INDEX;

LBOX_WIN lbDB;		// Book view-box..
extern HFONT hSysVarFont;
HWND db_hWnd = NULL;
DB_INDEX *db_pIndex = NULL;		// Ptr to index of games to display from search.. (malloc object, needs freeing..)
int db_nIndex = 0;
int db_LastScrollPos = 0;

void db_KillIndex ()
{
  if (db_pIndex) {
    free (db_pIndex);
    db_pIndex = NULL;
    db_LastScrollPos = 0;
  }
  db_nIndex = 0;
  dbOldIndexOk = 0;
}

int db_GetIndex (int cgame) 
{
    if (db_pIndex == NULL) return cgame;
    return db_pIndex [cgame].game;
}

  // Build an index file that conforms to specified search string..
BOOL db_BuildIndex (char *szSearch)
{
	long cgame;		// current game no 1..n

	if (DoingBuild) return TRUE;	// Already doing it!
	db_KillIndex ();
	if (szSearch [0] == 0) return TRUE;
        db_pIndex = malloc (dbselGameCount * sizeof(DB_INDEX));	// Alloc mem for list..
	if (db_pIndex == NULL) return FALSE;
		// SEARCH for matching lines, building (dbindex)
	SetWaitCursor 		// Macro - set hour-glass mouse..
	DoingBuild = 1;
		// Find games, add to search-index file..
	for (cgame = 1; cgame <= dbselGameCount; cgame ++) {
	  		// Scan forwards for a match to add..
	  if (dbMatchSearch (szSearch, cgame)) {	// Until match found
	    gamDETAILS *const gamDet = (gamDETAILS *) szTemp;
	    db_nIndex ++;
	    db_pIndex [db_nIndex].game = cgame;	// 1..n..
	  }
          if (QuitKeyHit ()) {
	    SetNormCursor 		// Macro - set normal mouse..
	    return FALSE;
	  }
	}
	SetNormCursor 		// Macro - set normal mouse..
	DoingBuild = 0;
	dbOldIndexOk = 1;	// New index will apply..
	return TRUE;
}

char dbx_szWhite [100] = "";
char dbx_szBlack [100] = "";
char dbx_szVenue [200] = "";
int dbx_year = 0;
int dbx_code = 0;
int dbx_result = 4;
int dbx_sch4pos = 0;

BOOL db_DlgSearchAdvanced ()
{
    int cret;
    dbOldIndexOk = 0;	// Invalidate old search index..
    cret = dlg_TextIn (STsearchfortext,szDBSearch,100,STok,NULL);
    if (cret == IDCANCEL) return FALSE;
    AnsiLower (szDBSearch);		// force string to LOWER case..
    return TRUE;
}

BOOL db_DlgSearch ()
{
    int cret,hitbut;
    int useand = FALSE;
    char szTmp [100];
again:
    dbOldIndexOk = 0;	// Invalidate old search index..
    IDM2String (IDM_DB_SEARCH);
    cret = dlg_Init (MenuStr,-1,-1,290,200,1);
    if (cret == FALSE) return FALSE;

    dlg_DefEdit (20,10,STblackplayer,dbx_szBlack, 180,60, sizeof(dbx_szBlack),DLG_EDIT_LEFTTEXT); 
    dlg_DefEdit (20,25,STwhiteplayer,dbx_szWhite, 180,60, sizeof(dbx_szWhite),DLG_EDIT_LEFTTEXT); 
    dlg_DefEdit (20,40,STvenue,dbx_szVenue , 180,60, sizeof(dbx_szVenue ),DLG_EDIT_LEFTTEXT); 
    dlg_DefRadio (20,65,D_GROUPBOX | 50,11,SToptresult,dbx_result,0);
    dlg_DefSpinTxt (160,65,5,dbx_year,0,3000,1,0,STyear,20);
    dlg_DefSpinTxt (100,85,5,dbx_code,0,9999,1,0,STecocode,80);
    dlg_DefCheck (100, 110, 200, "Search for current position", dbx_sch4pos);
    dlg_Define (dBUTTON, "Advanced Search..", IDD_BUTTONS + 1,  20,140,110,14,0);  
    dlg_Define (dBUTTON, "Clear", IDD_BUTTONS + 2,  150,140,70,14,0);  

    dlg_DefOKCancel (40,20,STok,NULL,40);
    hitbut = dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
    if (hitbut  == IDCANCEL) {
      return FALSE;
    }
    if (hitbut == IDD_BUTTONS+1) return db_DlgSearchAdvanced ();
    if (hitbut == IDD_BUTTONS+2) {
      szDBSearch [0] = 0;
      dbx_szWhite [0] = 0;
      dbx_szBlack [0] = 0;
      dbx_szVenue [0] = 0;
      dbx_year = 0;
      dbx_code = 0;
      dbx_result = 4;
      dbx_sch4pos = 0;
      goto again;
    }
    dbx_result = (BYTE) dlg_ReadRadio ();
    dbx_code = (UINT) dlg_ReadSpin ();
    dbx_year = (UINT) dlg_ReadSpin ();
    dbx_sch4pos = dlg_ReadCheck ();
      // Build search string...
    szDBSearch[0] = 0;
    if (dbx_sch4pos) strcat (szDBSearch,"*");
    if (*dbx_szBlack) {    //  black polayer data..
      strcat (szDBSearch,"b=");
      strcat (szDBSearch,dbx_szBlack);
      useand = TRUE;
    }
    if (*dbx_szWhite) {    //  black polayer data..
      if (useand) {
        if (strcmp (dbx_szBlack,dbx_szWhite) == 0) {
          strcat (szDBSearch,"|");
        } else {
          strcat (szDBSearch,"&");
	}
      }
      strcat (szDBSearch,"w=");
      strcat (szDBSearch,dbx_szWhite);
      useand = TRUE;
    }
    if (*dbx_szVenue) {    //  black polayer data..
      if (useand) strcat (szDBSearch,"&");
      strcat (szDBSearch,"v=");
      strcat (szDBSearch,dbx_szVenue);
      useand = TRUE;
    }
    if (dbx_year > 1000) {
      if (*szDBSearch) strcat (szDBSearch,"&");
      sprintf (szTmp,"=%d",dbx_year);
      strcat (szDBSearch,szTmp);
      useand = TRUE;
    }
    if (dbx_code) {
      if (*szDBSearch) strcat (szDBSearch,"&");
      sprintf (szTmp,"=%d",dbx_code);
      strcat (szDBSearch,szTmp);
      useand = TRUE;
    }
    if (dbx_result && dbx_result < 4) {
      if (*szDBSearch) strcat (szDBSearch,"&");
      sprintf (szTmp,"r=%d",dbx_result-1);
      strcat (szDBSearch,szTmp);
    }
    AnsiLower (szDBSearch);		// force string to LOWER case..
    return TRUE;
}

//BOOL pdnGetGameSummary (char *otxt,long cgame,short maxlen)

void db_DecodeMoves (char *pOut, char *pSrc, int max)
{
    char *pEnd = pSrc + max;
    int mfrom,mto;
    int com = 0;
    while (pSrc < pEnd) {
      if (*pSrc == '{') com = 1;
      if (*pSrc == '}') com = 0;
      if (*pSrc == '*') break;
      if (*pSrc == '0') {  // 0-1 result?
        if (strcmp (pSrc,"0-1") == 0) break;
      }
      if (*pSrc == '1') {  // 1/2-1/2 1-0  result?
        if (strcmp (pSrc,"1-0") == 0) break;
        if (strcmp (pSrc,"1/2-1/2") == 0) break;
      }
      if (isdigit (*pSrc) && com == 0) {
        while (1) {
	  char act;
          mfrom = str2val (pSrc, 10, 5);
          if (mfrom > 99 ) break;
          while (isdigit (*pSrc)) pSrc ++;
	  act = *pSrc;
          if (act != '-' && act != 'x') break;
          pSrc ++;
          mto =  str2val (pSrc, 10, 3);
          while (isdigit (*pSrc)) pSrc ++;
          if (mto > 99 ) break;
          pOut += sprintf (pOut,"%d%c%d ",mfrom,act,mto);
        }
      } 
      pSrc ++;
    }
}

  // pdnGetGameSummary (pStr,cline+1, 200);
void db_GetField (char *pStr, int cfield, int cgame)
{
    long cval = 0;
    gamDETAILS *const pGamDet = (gamDETAILS *) szTemp;   // struct at szTemp read by pdnReadHeader()

    *pStr = 0;
    switch (cfield) { 
      case 1:		// Index
        cval = cgame; 
	break;

      case 2: 		// Result
        strcpy (pStr, GetNthStr (SToptresult,pGamDet->h.result + 1) + 1);
	return;

      case 3: 		// Date
        cval = pGamDet->h.year;
	if (cval) break;
	strcpy (pStr,"  -");
	return;
       
      case 4: 		// Open
	cval = pGamDet->h.eco;
	if (cval) break;
	strcpy (pStr," -");
	return;
      
      case 5: 		// Set
        pStr [0] = (pGamDet->init.set ? '*' : ' ');
	pStr [1] = 0;
	return;
      
      case 6: 		// Black
        strcpy (pStr,pGamDet->play1);
	return;
      
      case 7: 		// White
        strcpy (pStr,pGamDet->play2);
	return;
      
      case 8: 		// Comments
        strcpy (pStr,pGamDet->venue);
	return;
      
      case 9: {		// Moves
	char *cstr;
	int nread = 100;
	cstr = bfFileRead (pdnIndex, pdnFilePos, nread+10);
	pStr[0] = 32;
	db_DecodeMoves (pStr+1, cstr, nread);
	return;
      } 
      
      default: return;   // No string..
    }
      // Val is in (cval), add as field..
    ltoa (cval,pStr,10);
    return;
}

long db_GetInfo (int msg, void *pDat)
{
    LBOX_WIN *pLbox = (LBOX_WIN *) pDat;
    LBOX_FIELD *pField = pLbox->pField;
    static int cline;
    static int cgame;
    int cret;

    switch (msg) {
      case LBOXSERV_ACCESS_START: {
	lbDB.totLines = dbselGameCount;
	if (db_pIndex) lbDB.totLines = db_nIndex;	// use search result array 
        if (bfIsFileClosed (1)) {	// Not open, reopen..
	  pdnIndex = 1;
	  cret = bfFileOpen (pdnCurFile,pdnIndex,0x7ff0,READ);
	  if (cret == HFILE_ERROR) return FALSE;
        }                
        return TRUE;
      }
      case LBOXSERV_ACCESS_END: {
        return TRUE;
      }
      case LBOXSERV_STARTLINE: {	// Start display of new line, get header data from db..
        cline = pField->rline;
	cgame = db_GetIndex (cline);
        pdnFilePos = pdiData [cgame];
	cret = pdnReadHeader ();
	if (cret == 0) return FALSE;	// Error in header..
        return TRUE;	// Line is ok!
      }
      case LBOXSERV_NEEDFIELD: {
	pField->lineColour = LBOX_COL_TEXT;

	//if (eng.disp_mvlist[cline].flag) {   // Book move, hilite in blue
	//  pField->lineColour = LBOX_COL_TEXT_RED;
	//}
	db_GetField (pField->pTxt,pField->rfield,cgame);
	return TRUE;	// Data is ok..
      }
      case LBOXSERV_ITEM_SELECTED: {	// Mouse selects a move?
        if (pField->mouseCmd != WM_LBUTTONDBLCLK) return 0;   // Must be lmouse dbl click
        if (pField->rline > 0) {
	  int cgame = db_GetIndex  (pField->rline);
	  if (cgame < 1 || cgame > dbselGameCount) return 0;
	  if (pdnLoadGame (cgame) == FALSE) {
	    short t;
	    t = DoYesNo (STpdnerror);
	    if (t == IDNO) break;
	  }
	  open_ClassifyCurGame ();
	  if(pdnCurFileOld[0]) {
	    strcpy (pdnCurFile,pdnCurFileOld);
	    pdnCurFileOld[0] = 0;
	  }

	  dbselGameLoaded = TRUE;
	  pdnLastGameRead = cgame;
          DestroyWindow (db_hWnd);
          return 0;
	}
	return 0L;
      }
    }
    return TRUE;
}


  // Exit Database pop-up dialog - kill window, back to normal
void db_EndPopDlg (void)
{
	CloseDBSelect ();
	if (dbselGameLoaded == FALSE) {		// Reload old game..
	  LoadGame (szTEMPGAMEFILE);
	}
	if(pdnCurFileOld[0]) {
	  strcpy (pdnCurFile,pdnCurFileOld);
	  pdnCurFileOld[0] = 0;
	}
		// back to normal game play mode..
	ClockOn			// switch Clock on
	MainMode = DoingGame;
	eng2brd ();
	DoingPopDlg = FALSE;
	InitThink (ThinkOpp);	// Restart think in opp..
	RedrawAllWindows ();	// Force repaint..
	hPopWnd = NULL;		// Disable future writes to this window
	DBbox.hUWnd = NULL;	// Disable future writes to this window
	ULboxflag = FALSE;		// Clear this pointer..
}


LRESULT db_DlgProc (HWND hWnd,  // our window's handle
				UINT wMsg,	   // message number
				WPARAM wParam,	   // word parameter
				LPARAM lParam)	   // long parameter
{
    LBOX_WIN *pLbox = &lbDB;
    RECT wrct;
    int ngames;
    db_hWnd = hWnd;
    #if _DEBUG 
      //if ((GetKeyState (VK_CONTROL) & 0x8000)) return DBDlgProc (hWnd,wMsg,wParam,lParam);
    #endif
    if (DoingBuild) goto ExitBoxProc;	// Building DB, abort other cmds..
    switch (wMsg) {
	    
      case WM_GETMINMAXINFO:	// Set minimize window size..
        lpmmi = (MINMAXINFO FAR *) lParam;
        lpmmi->ptMinTrackSize.x = 330;// Never smaller than this..
        lpmmi->ptMinTrackSize.y = 270;
        return 0L;
	    
      case WM_DESTROY:
        db_LastScrollPos = pLbox->StartOffset ;
	lbox_Close (pLbox);
        db_EndPopDlg ();	// Tidy up at end of Popup -dialog mode
        return 0L;
	    
      case WM_MOUSEMOVE:		// Keep kybd focus in this window..
        SetFocus (hWnd);
        break;
	    
      case WM_CREATE:
	    	// Rebuild search index if old string left behind..
        if (szDBSearch [0]) {	// Any search?
          if (dbOldIndexOk == 0) {	// No old index, so..
	    db_BuildIndex (szDBSearch);
          }
        } else {
	  db_KillIndex ();
	}
        ngames = dbselGameCount;
        if (db_pIndex) ngames = db_nIndex;	// use search result array 
	wsprintf (szTemp, "%s \x22%s\x22 %d games. ",
	    	(LPSTR) IDM2String (IDM_LISTGAMES),(LPSTR) pdnCurFile,ngames);
	if (*szDBSearch) {
	  strcat (szTemp,STsearchfortext);
	  strcat (szTemp,szDBSearch);
	}
	SetWindowText (hWnd,szTemp);
        memset (pLbox,0,sizeof (LBOX_WIN));
	pLbox->pHeadTxt = STdbfields;
	pLbox->nFields = 9;
	pLbox->pfnServiceLbox = db_GetInfo;	// Service routine..
	{ short t[] = {-14,-12,-12,-12,-4,-35,-35,-100,-300,-300};  // Width each field (in 1/2 ave chars)
	  memcpy (pLbox->headx,t,pLbox->nFields * sizeof(short));
	}
	pLbox->szTitle = "";
	pLbox->llen.x = 10;	// Set up an initial window size (set properly by WM_SIZE)
	pLbox->llen.y = 10;
	pLbox->hParent = hWnd;
	pLbox->phFont = &hSysVarFont;
	pLbox->lboxtype = LBOX_TYPE_VERTSCROLL | LBOX_TYPE_SELECTABLE | LBOX_TYPE_ELASTIC;
	pLbox->StartOffset = db_LastScrollPos ;
        lbox_WinCreate (pLbox);	// Create "list-view-box" with analysis..
        return 0;

      case WM_SIZE: {
	GetClientRect (hWnd, &wrct);
        lbox_Resize (pLbox,0,0,wrct.right+1, wrct.bottom+1);
      case WM_MOVE:
        SaveWin (&popdlgwnd, hWnd,1);	// Save window size..
        return 0L;
      }

      default:
        goto ExitBoxProc;
    }
    return 0L;

ExitBoxProc:	
    return DefWindowProc (hWnd, wMsg, wParam, lParam);
}

//---------------------------------------------
//  PDN Transfer..
//---------------------------------------------

char tran_szDest [300] = "transfer.pdn";

  // Open (pdnCurFile) for read, build search index for (szDBSearch)
  // Ret # games found,  -1 for error
long db_Start ()
{
    int ngames,cret;
    if (InitDBSelect () == FALSE) return -1;
    if (szDBSearch [0]) {	// Any search?
      cret = db_BuildIndex (szDBSearch);
      if (cret == FALSE) return -1;
    } else {
      db_KillIndex ();
    }
    ngames = dbselGameCount;
    if (db_pIndex) ngames = db_nIndex;	// use search result array 
    return ngames;
}

void db_End ()
{
    bfFileClose (-1);	// Close any buffered input files..
}

int db_GetGame (int cgame)
{
    int cpdn;
    cpdn = db_GetIndex  (cgame);
    return pdnLoadGame (cpdn);
}

typedef struct {
  int index;
  int sort;
} SORT_INDEX;

void eng_playoutmoves ();

  // Transfer games from one file to another..
void pdnTransfer()
{
    int cret;
    int cgame;
    int ngames;
    int ecoflag = 1;
    int hitbut;
    int sortmode = 1;
    int appendflag = 0;
    int warnflag = 1;
    int killdupe = 0;
    int modes = 0;
    char szTxt[300]; 
    SORT_INDEX *pSort = NULL;
    gamDETAILS gamDet;

    StopAutoPlay ();	// If comp v comp, back to normal
    StopThinking ();
    szDBSearch [0] = 0;

    while (1) {
      IDM2String (IDM_PDNTRANSFER);
      cret = dlg_Init (MenuStr,-1,-1,320,200,1);
      if (cret == FALSE) return ;

      dlg_DefEdit (5,20,STtransfer,pdnCurFile,185,55,sizeof (pdnCurFile)-4,DLG_EDIT_LEFTTEXT);
      dlg_Define (dBUTTON, STbrowse,IDD_BUTTONS + 1,260,20,40,14,0);
      dlg_DefEdit (5,45,str_GetNth(STtransfer,1),tran_szDest,185,55,sizeof (tran_szDest)-4,DLG_EDIT_LEFTTEXT);
      dlg_Define (dBUTTON, STbrowse,IDD_BUTTONS + 2,260,45,40,14,0);
      dlg_Define (dBUTTON, str_GetNth(STtransfer,2),IDD_BUTTONS + 3,10,70,80,14,0);
      dlg_DefText (110,70,szDBSearch);	// Current DB search..
      dlg_DefRadio (20,95,D_GROUPBOX | 90,12,str_GetNth(STtransfer,8),1,0);
      dlg_DefCheck (140, 100, 200, str_GetNth(STtransfer,3), ecoflag);
      dlg_DefCheck (140, 115, 200, str_GetNth(STtransfer,4), appendflag);
      dlg_DefCheck (140, 130, 200, str_GetNth(STtransfer,5), warnflag);
      // dlg_DefCheck (140, 145, 200, str_GetNth(STtransfer,12), killdupe);
      dlg_DefOKCancel (40,20,STok,NULL,40);

      hitbut = dlg_Execute ();	// EXECUTE DIALOG BOX..
      dlg_End ();
      if (hitbut  == IDCANCEL) {
        return ;
      }
      //killdupe = dlg_ReadCheck ();
      warnflag = dlg_ReadCheck ();
      appendflag = dlg_ReadCheck ();
      ecoflag = dlg_ReadCheck ();
      sortmode = dlg_ReadRadio ();
      if (hitbut  == IDOK) break;
      if (hitbut == IDD_BUTTONS + 1) {
        cret = dlg_Open (pdnCurFile, STpdnfilter, STtransfer,0);
	continue;
      }
      if (hitbut == IDD_BUTTONS + 2) {
        cret = dlg_Save (tran_szDest, STpdnfilter, str_GetNth(STtransfer,1),0);
	continue;
      }
      if (hitbut == IDD_BUTTONS + 3) {
        db_DlgSearch ();
	continue;
      }
    }
    SetWaitCursor 		// Macro - set hour-glass mouse..
    ngames = db_Start ();
    if (ngames < 0) return;
    if (sortmode > 1) {   // Sort by date/eco..
      int cins,xins;
      pSort = malloc (ngames * sizeof(SORT_INDEX) + 32);
      for (cgame = 1; cgame <= ngames; cgame ++) {
        int cdat;
        if ((cgame % 10) == 0) {
          sprintf (szTxt,str_GetNth(STtransfer,6),cgame,ngames,STescabort); 
          SetWindowText (hMainWnd, szTxt); 
        }
        if (QuitKeyHit ()) goto exittran;
        cret = db_GetGame (cgame);
        gamExtractDetails (&gamDet, 0);
	if (sortmode == 2) {
	  cdat = gamDet.h.year;
	} else {
	  cdat = gamDet.h.eco;
	}
	  // Insert..
        for (cins = 1; cins < cgame; cins ++) {
	  if (cdat < pSort [cins].sort) break;
	}
	for (xins = cgame; xins >= cins; xins --) {
	  pSort [xins] = pSort [xins - 1];
	}
	pSort [cins].sort = cdat;
	pSort [cins].index = cgame;
      }
    }
    if (appendflag == 0) DeleteFile (tran_szDest);
      // Ok open access to read (pdnCurFile), matching search (szDBSearch)
    for (cgame = 1; cgame <= ngames; cgame ++) {
      int xgame;
      if ((cgame % 10) == 0) {
        sprintf (szTxt,str_GetNth(STtransfer,7),cgame,ngames,STescabort); 
        SetWindowText (hMainWnd, szTxt); 
      }
      if (QuitKeyHit ()) break;
      xgame = cgame;
      if (pSort) xgame = pSort[cgame].index;
      cret = db_GetGame (xgame);
      if (pdnFilePos < 0) break;	// EOF..
      if (cret == TRUE) {
        if (1) { eng_playoutmoves (); modes ++;}
        if (ecoflag) open_ClassifyCurGame ();
        pdnExport (tran_szDest);
      } else {
	short t;
	sprintf  (szTxt,"%s\n (%s,Game %d) ",STpdnerror,pdnCurFile,xgame);
	t = DoYesNo (szTxt);
	if (t == IDNO) break;
      }
    }    
exittran:
    free (pSort);
    db_End ();
    SetNormCursor 
    InitThink (ThinkOpp);
}


//---------------------------------------------
//  opening classification routines..
//---------------------------------------------

#define OPEN_MAX 512
#define OPEN_MAX_MOVES 32
#define OPEN_MAX_DESC 4000

typedef struct {
  short code;
  BYTE loss;
  BYTE ballot;
  GAMESTORE gam[OPEN_MAX_MOVES];
  short nmoves;
  char *szDescript;
} OPENING_CLASSIFY;

OPENING_CLASSIFY opens[OPEN_MAX];
int nopens = 0;
char open_szDescription[OPEN_MAX_DESC];
char open_szCur [256];
int open_cur = -1;   // Current opening.
long open_chk = 0;   // Checksum
char open_szOpen[128] = "opening1.pdn";

  // Load opeing classification files
void open_Init ()
{
    char *pDesc = open_szDescription;
    int cgame = 1;
    int cret;
    nopens = 0;
    memset (&opens,0,sizeof(opens));
    memset (open_szDescription,0,sizeof(open_szDescription));
    if (eng.gamtype > 1) return; 
    open_szOpen[7] = 49 + eng.gamtype;  // eng/ital?
    while (1) {
      OPENING_CLASSIFY *pOpen = opens+nopens;
      char *pTxt;
      gamDETAILS gamDet;
      cret = pdnImport (open_szOpen,cgame);
      if (cret < 1) break;  // EOF/error..
        // Ok, take game info, put into OPENING_CLASSIFY entry..
      gamExtractDetails (&gamDet,0);	// Get game details,,
      pOpen->code = (short) gamDet.h.eco;
      if (gamDet.venue[0] == '<') pOpen->loss = TRUE;
      if (gamDet.venue[0] == '=') pOpen->ballot = TRUE;
      pTxt = strchr (gamDet.venue,39);
      pOpen->szDescript = "";
      if (pTxt) {
	pDesc += strlen (pDesc)+1;
        strcpy (pDesc,pTxt+1);
        pOpen->szDescript = pDesc;
      /*} else {   // No specific description, search earlier openings for description string..
        int desopen = open_Find ();
	if (desopen > -1) {
	  pOpen->szDescript = opens[desopen].szDescript;
	} */
      }
      memcpy (pOpen->gam,eng.game_store+1,sizeof(pOpen->gam));
      pOpen->nmoves = min (OPEN_MAX_MOVES,eng.move_number);
      nopens ++;
      if (nopens >= OPEN_MAX) break;
      if (pDesc - open_szDescription > OPEN_MAX_DESC - 128) break;   // Descriptions too long..
      cgame ++;
    }
}

int open_Find (BOOL findfirst)
{
    int copen,cmove;
    int matchop = -1;
    int matchlen = 0;
    int himove;
    GAMESTORE *pGam = eng.game_store+ 1;
    for (copen = 0; copen < nopens; copen ++) {
      OPENING_CLASSIFY *pOpen = opens+copen;
      himove = pOpen->nmoves; //,eng.move_number);
      if (eng.move_number < himove) continue;  // Not enough moves played yet to match this opening
      for (cmove = 0; cmove < himove; cmove ++) {
        if (pGam[cmove].src != pOpen->gam[cmove].src) break;
        if (pGam[cmove].dest != pOpen->gam[cmove].dest) break;
      }
      if (cmove >= himove && cmove > matchlen) {
        matchop = copen; matchlen = cmove;
	if (findfirst) return matchop;
      }
      if (pOpen->nmoves == 3) {  // Cheap 3mv transpos check..
        if (pGam[1].src != pOpen->gam[1].src) continue;
        if (pGam[1].dest != pOpen->gam[1].dest) continue;
	  // Test Trans 1st/3rd moves ie. 9-13,21-17,10-15 == 10-15,21-17,9-13
        if (pGam[0].src == pOpen->gam[2].src 
          && pGam[0].dest == pOpen->gam[2].dest) {
          if (pGam[2].src == pOpen->gam[0].src 
            && pGam[2].dest == pOpen->gam[0].dest) {
            if (matchlen < 3) {
              matchop = copen; matchlen = 3;
            }
	  }
	}
	  // Test Trans path ie. 11-15,22-17,15-19 == 11-16,22-17,16-19
        if (pGam[0].src == pOpen->gam[0].src 
          && pGam[2].dest == pOpen->gam[2].dest) {
          if (pGam[0].dest == pGam[2].src 
            && pOpen->gam[0].dest == pOpen->gam[2].src) {
            if (matchlen < 3) {
              matchop = copen; matchlen = 3;
            }
	  }
	}
	  // Test Trans path2 ie. 11-15,22-17,7-11 == 10-15,22-17,7-10
        if (pGam[2].src == pOpen->gam[2].src 
          && pGam[0].dest == pOpen->gam[0].dest) {
          if (pGam[2].dest == pGam[0].src 
            && pOpen->gam[2].dest == pOpen->gam[0].src) {
            if (matchlen < 3) {
              matchop = copen; matchlen = 3;
            }
	  }
	}
      }
    }
    return matchop;
}

  // Quick checksum of game data..
long open_checksum ()
{
    long chk = eng.init_moven + eng.move_number;
    BYTE *pDat = (BYTE *) & eng.game_store[1];
    int cpos;
    for (cpos = 0; cpos < sizeof (opens[0].gam); cpos ++) {
      chk += pDat[cpos] * cpos;
    }
    return chk;    
}

  //Classify the current opening.
char *open_Classify ()
{
    int copen,firstopen;
    OPENING_CLASSIFY *pOpen;
    char *szDesc;
    if (eng.gamtype > 1) return NULL; 
    if (open_chk == open_checksum ()) return open_szCur;
    if (eng.init_moven & 0x8000) goto err; // Setup pos..
    firstopen = open_Find (1);
    if (firstopen == -1) goto err;
    copen = open_Find (0);
    if (copen == -1) goto err;
    pOpen = opens+copen;
    szDesc = pOpen->szDescript;
    if (szDesc[0] == 0) szDesc = opens [firstopen].szDescript;
    if (pOpen->code) {
      sprintf (open_szCur,"%d:%s",pOpen->code,szDesc);
    } else {
      sprintf (open_szCur,"%s",szDesc);
    }
    open_chk = open_checksum ();
    return open_szCur;
err:
    open_szCur[0] = 0;
    open_chk = open_checksum ();
    return open_szCur;
}

  // Classify current game, fill eco field..
void open_ClassifyCurGame ()
{
    int copen;
    gamDETAILS gamDet;
    if (eng.gamtype > 1) return ; 
    copen = open_Find (0);
    if (copen == -1) return;
    gamExtractDetails (&gamDet, 0);
    if (gamDet.h.eco == 0) {
      gamDet.h.eco = opens[copen].code;
    }
    gamSetDetails (&gamDet,1);	// Set game details,,
}

  // Classify current game, fill eco field..
void open_Random ()
{
    int copen,cm;
    OPENING_CLASSIFY *pOpen;
    if (eng.gamtype > 1) return ; 
    if (nopens < 5) return;
    srand ((unsigned int) clock ());
    while (1) { 
      copen = rand () % nopens;
      pOpen = opens+copen;
      if (pOpen->ballot == TRUE) break;
    }
    NewGame (1);
    StopAutoPlay ();	// Make (eng.play_mode) either norm or 2play.
    RedrawAllWindows ();
    DlgNAG (5);     // Shareware NAG screen..
    for (cm = 0; cm < pOpen->nmoves; cm ++) {
      ExecMove (pOpen->gam+cm,9);
    }
}

