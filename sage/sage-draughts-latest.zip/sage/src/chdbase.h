// CHDBASE.H Header for PDN DataBase support routines and functions.


			// Define a struct for a custom list box..
typedef struct {
  short tx,ty;		// Top left of box in pixels
  short bx,by;		// bottom in pixels
  short nchx,nchy;	// max size of box in characters
  long nlist;		// Current total no of items in box..
  long hlist;		// Current hilited item 1..n (0=none)
  long tline;		// Current top line of box..
  char *txt;		// ptr to data for list box, (null terminated)
  HWND hUWnd;		// Handle for User box window, if any..
  HWND hOwner;		// Handle for Owner window..
  short ScrollPos;	// Pos of scroll bar..
  HDC *hUDC;		// ptr to DC
} USERLISTBOX;

extern USERLISTBOX EdBook;
extern USERLISTBOX DBbox;
#define ULBOXOFF 3	// Pixel size Non print area about edge..

extern WRECT popdlgwnd;	// Popup custom dialog window
extern BYTE cb2win [];
extern long DBcurgame;

void dbDlgSaveGame ();
BOOL dbDlgSelect (BYTE);
void dbEdit ();
void dbDlgListGames (char *);
void DlgDelDatabase ();
void DBReadHeader (long);
void GetDBstr (long , short );
BOOL InitDBSelect (void);
void CloseDBSelect (void);
void DrawUserListBox (short,short );
void DBGameViewInit (long, short);
short ULBseekDB (short);
short ULBreadDB (short, short, short);
void ULBcloseDB (void);
short GetDBplayinfo (void);
short ULBkeycode (short);
void RedrawDBgameview (void);
void TestDB (void);

LRESULT db_DlgProc (HWND,UINT,WPARAM,LPARAM);
 
 //-------------------------------------------------------------------------
 //
 // COMMENT/PDN support..
 //
 
#define gamiHEADER 0x0100	// Start comment-index for header info
#define gamiPLAY1 0x0101	// Index for player 1 (white)
#define gamiPLAY2 0x0102	// Index for player 2 (black)
#define gamiVENUE 0x0103	// Index for venue string
#define gamCOMMENTS 0x4000	// Start for game-move comments

typedef struct {	// Struct for game details header vars..
  short year;		// Current year
  short elo1,elo2;	// ELO for white/black
  short eco;		// ECO code 1-500 (0=undefined) subtract 1..
  BYTE result;		// Game result code.. (0:0-1,  1:Draw, 2:1-0, 3=none)
} gamDETHEAD;	

typedef struct {	// Struct for game details header pointers
  char far *play1;	// PTR Player names (white,black)
  char far *play2;
  char far *venue;	// PTR Venue..
  short lplay1,lplay2;	// Length of player names
  short lvenue;		// Length on venue
  char far *brd;	// Ptr to Set-up board pos
  BYTE side;		// Side to move (1=w,2=b, 0=none)
  BYTE castle;		// Initial castling status
  char ecostr[10];	// Decoded ECO string
} gamDETPTRS;

typedef struct {	// Struct for set-up board positions
  char brd [MAX_CHECKER_BOARD];	// Initial board-position..
  BYTE side;		// Initial side to move (0=wht,1=blk)
  BYTE castle;		// Initial castling status (as ep_castle_status)
  BYTE set;		// Zero if no set up pos, 1 if set up pos..
} gamINITBRD;

typedef struct {	// Struct for accessing game-details..
  gamDETHEAD h;		// Other header info (see above)
  gamDETPTRS p;		// Pointers to names, if not fully extracted
  			// If fully extracted, this is also filled..
  char play1 [140];	// Player names (white,black)
  char play2 [140];
  char venue [500];	// Venue..
  gamINITBRD init;	// Initial set-up board pos..
} gamDETAILS;	

typedef struct {	// Small Struct for fast access game-detail pointers..
  gamDETHEAD h;		// Other header info (see above)
  gamDETPTRS p;		// Pointers to names, if not fully extracted
} gamPTR2DET;	

typedef struct {	// Info for PDN-Export function..
  char *outstr;		// Output string
  short wide;		// Output width for wrapping game
  short maxwide;		// Absolute max width - for header/pdn tags etc.
  short centwide;		// Width for header centering (0 for none)
  BYTE mode;		// Output mode..(set bit 0 when done)
  BYTE flags;		// Input flags (set bit 0 for tabbed, bit 1 for header)
  BYTE headitem;	// Current header item being printed, >0x80 not in header
} pdnINFO;

extern pdnINFO pdnInfo;	// Struct with info for PRG-EXPORT..
extern char outBuf [400];	// Gen output buffer..

void pdnResetFile (short);
short pdnReadGame (BYTE);
void pdnDlgImport (int);
long pdnImport (char *, long);
long pdn_ngames (char *pfile); 
short pdnExportLine (pdnINFO *);
short pdnExport (char *) ;
long DlgEditGameDetails (BYTE);
void DlgAddComment ();

// GAME mem alloc routines..

extern BYTE far *cbgStart;	// Ptr to start of memory (same as cb_datablock_pointer)

UINT cbgAllocMem (UINT, BYTE);
void cbgFinish ();
void cbgCheckSize ();
UINT cbgCalcSize ();
void ConvertPos2Asc (char *, char far *, short, BYTE);
short ConvertAsc2Pos (char far *, gamINITBRD *);

short col_LoadNewFormat (char *szFile);
BOOL db_DlgSearch ();
short QuitKeyHit ();
void pdnTransfer();
void open_Init ();
char *open_Classify ();
void open_ClassifyCurGame ();
void open_Random ();
extern char open_szOpen[128];


