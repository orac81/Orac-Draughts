// Header for SAGIO.C - Universal non-genius specific defines/prototypes..
//  Copyright A.Millett 1996-97, All Rights Reserved.

#define READ 0
#define WRITE 1
#define READ_WRITE 2

typedef struct  {	// General RECT position descriptor, by top/len
 short tx,ty;		// pos of top left
 short lx,ly;		// x/y size of box
} WRECT;

typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   ULONG;
typedef int             BOOL;
typedef unsigned int    UINT;
typedef signed short int SINT;
typedef __int64     LONGLONG;
  // For passing pointers to functions to routines..
typedef int (*PROC_VOID) (void); 
typedef int (*PROC_PVOID) (void *); 
typedef int (*PROC_INT_PVOID) (int, void *); 

#ifndef FALSE
 #define FALSE 0
#endif

#ifndef TRUE
 #define TRUE  1
#endif

  // Some generic character codes..
#define CHR_NULL    0
#define CHR_TAB	    9
#define CHR_LF     10
#define CHR_CR     13
#define CHR_MARK   14	// Used as marker..
#define CHR_SPC    32
#define CHR_QUOTE  34
#define CHR_BSLASH 92


typedef long (*FNSERV_PROC) (int, void *);  // For generic front end service function..
typedef void (*FNVOID_PROC) (void);        // Generic void fn ptr..

// -----------------------------------------------------------------------
//  Gen purpose macros..

//#define min(a,b) ((a) < (b) ? (a) : (b))
//#define max(a,b) ((a) > (b) ? (a) : (b))

	// Size of an array in elements, not bytes..
#define SizeOfArray(Array) (sizeof (Array) / sizeof (Array [0]))
	// Quick Int to 2 digits of ascii conversion macro
#define INT2ASC2(Cstr,Cint) \
	*(Cstr) = ((Cint) / 10) | 48; Cstr ++; \
	*(Cstr) = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick Int to 3 digits of ascii conversion macro
#define INT2ASC3(Cstr,Cint) \
	if ((Cint) > 99) {*Cstr = ((Cint) / 100) | 48;} else {*Cstr = ' ';}\
	 Cstr ++;\
	if ((Cint) > 9) {*Cstr = (((Cint) / 10) % 10) | 48;} else {*Cstr = ' ';}\
	 Cstr ++;\
	*Cstr = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick Int to 2 digits of ascii conversion macro
#define INT2ASC2NOLEAD(Cstr,Cint) \
	if ((Cint) > 9) {*(Cstr) = ((Cint) / 10) | 48; Cstr ++;} \
	*(Cstr) = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick Int to 3 digits of ascii conversion macro
#define INT2ASC3NOLEAD(Cstr,Cint) \
	if ((Cint) > 99) {*(Cstr) = ((Cint) / 100) | 48; Cstr ++;} \
	if ((Cint) > 9) {*(Cstr) = (((Cint) / 10) % 10) | 48; Cstr ++;} \
	*(Cstr) = ((Cint) % 10) | 48; Cstr ++;
	
	// Quick add-string and advance macro..
#define ADDSTR(Cstr,Istr) \
	{ char *xstr = Istr; \
	  while (*xstr) { *Cstr = *xstr; Cstr ++; xstr ++; } \
	}
	
	// Quick add-char and advance macro..
#define ADDCHAR(Cstr,Cchr) \
	*(Cstr) = Cchr; Cstr ++;
	
	// Swap var macro..
#define SWAPVAR(Var1,Var2,Type) \
	{Type xxtmp; xxtmp = Var1; Var1 = Var2; Var2 = xxtmp;}

	// Keep var in a range..
#define KEEPRANGE(Var,Lo,Hi) __min (__max (Lo,Var),Hi)
#define EQKEEPRANGE(Var,Lo,Hi) Var = min (max (Lo,Var),Hi);

#define MUL_DIV(a,b,c) ((long) (((long) (a)) * ((long) (b))) / ((long) (c)))

typedef struct {
  BYTE lo,hi;
} SPLITWORD;
	
typedef struct {
  short lo,hi;
} SPLITLONG;
	
typedef struct {	// Crack into long word
  BYTE b1,b2,b3,b4;
} LONG2BYTE;

typedef struct {	// Graphic point struct
  short x,y;
} MYPOINT ;

typedef struct {	// Graphic point struct
  long x,y;
} LONGPOINT ;

typedef struct {	// Accurate Graphic point struct
  float x,y;
} FLOATPOINT ;

#define SWAPSHORT(w1,w2) {short tmp = w1; w1=w2; w2 = tmp;}

#ifndef MYINLINE
  #if _DEBUG
    #define MYINLINE 		// Dummy-do nothing..
    #define FASTCALL 
  #else
    #define MYINLINE // _inline		// inline function..
    #define FASTCALL // _fastcall		// Hi speen function calls.
  #endif
#endif

/*	// Macros to access flags
#define Flag_(x) ((x & Bit##x) ^ Xor##x)
#define BFlag_(x) (((x & Bit##x) ^ Xor##x) != 0)	// Boolean flag..
#define Tog_(x) x ^= Bit##x;
#define Set_(x) x = (x | Bit##x) ^ Xor##x;
#define Clr_(x) x = (x & (~Bit##x)) | Xor##x;
#define FlagData_(x) &x,Bit##x,(Xor##x != 0)
#define NotFlagData_(x) &x,Bit##x,(Xor##x == 0)
*/


#ifdef _WIN32		// 32 bit (Win95) code..
  #define HUGE_ 
  #define FAR_
  #define my_malloc malloc
  #define my_free free
  #define my_realloc realloc
  #define my_memcpy memcpy
  #define my_memset memset
  #define _fmemcpy memcpy
  #define _fmemcmp memcmp
  #define _fmemset memset
  #define _fmemmove memmove
  
  #define GetInstance(wnd) (HINSTANCE) GetWindowLong (wnd, GWL_HINSTANCE)
  #define my_malloc malloc
  
#else			// 16 bit (Large mem model) code..

  #define HUGE_ huge
  #define FAR_ far
  #define GetInstance(wnd) (HINSTANCE) GetWindowWord (wnd, GWW_HINSTANCE)
  void my_memcpy (void far *, void far *, long );
  void my_memset (void far *, int, long );
  #include <windows.h>
  
	// Simple malloc/free replacements using win16 GlobalAlloc..
  _inline void huge *my_malloc (long memsize) 
  {
    HANDLE hMem;
    void far *pMem;
    hMem = GlobalAlloc (GMEM_MOVEABLE, memsize);
    if (hMem == NULL) return NULL;	// Out of mem..
    pMem = GlobalLock (hMem);
    //GlobalUnlock (hMem);
    return (pMem);
  }
  
  
  _inline void huge *my_realloc (void far *pMem, long memsize) 
  {
    HANDLE hMem;
    hMem = GlobalReAlloc ((HGLOBAL) SELECTOROF (pMem), memsize, GMEM_MOVEABLE);
    if (hMem == NULL) return NULL;	// Out of mem..
    pMem = GlobalLock (hMem);
    //GlobalUnlock (hMem);
    return (pMem);
  }
  
  _inline void my_free (void far *pMem)
  {
    // GlobalHandle()..
    if (pMem == NULL) return;
    if (GlobalUnlock ((HGLOBAL) SELECTOROF (pMem)) != 0) {
      exit (0);
    }
    GlobalFree ((HGLOBAL) SELECTOROF (pMem));
  }
  
#endif




      //This routine removes/inserts data from a block in memory.
int  mem_AddRemove (BYTE *ppos,BYTE *pend,BYTE *pnew,int remcnt,int inscnt);

//---------------------------------------------------------------
// MODULE: file_ General file handling routines
//---------------------------------------------------------------


#define FILE_METHOD_WIN95 1  // Do this for Win95 specific file handling
//#define FILE_METHOD_FOPEN 1  // Do this to enable alt file method..


#ifdef FILE_METHOD_FOPEN   // Use fopen libraries..

  #define FILE_HANDLE FILE *
  FILE_HANDLE file_Open (char *, int);
  #define file_Close(hFile) fclose(hFile)
  #define file_HandleIsBad(hFile) ((hFile) == NULL)   // True if bad file-handle..
  #define file_Read(hFile,pbuf,size) fread(pbuf,sizeof (BYTE),size,hFile)
  #define file_Write(hFile,pbuf,size) fwrite(pbuf,sizeof (BYTE),size,hFile)
  #define file_Seek(hFile,offset,origin) fseek(hFile,offset,origin)
  #define file_Tell(hFile) ftell(hFile)
  #define file_Error(hFile) ferror(hFile)
  #define file_Truncate(hFile) (TRUE)

#endif

#ifdef FILE_METHOD_WIN95   // Use win95 libraries..

  #define STRICT                
  #include <windows.h>          // Ensure windows lib is used..
  #define FILE_HANDLE HANDLE

  FILE_HANDLE file_Open (char *, int);
  void file_Close (FILE_HANDLE);
  #define file_HandleIsBad(hFile) ((hFile) == INVALID_HANDLE_VALUE)   // True if bad file-handle..
  ULONG file_Read (FILE_HANDLE,void *,long); 
  ULONG file_Write (FILE_HANDLE,void *,long);
  BOOL file_Seek (FILE_HANDLE,long,int);
  long file_Tell(FILE_HANDLE);
  BOOL file_Truncate (FILE_HANDLE);

#endif

#define FILE_READ   1   // Open modes..
#define FILE_WRITE  2   // for both read/write
#define FILE_CREATE 3   // Create (del old) then read/write


int  file_Exists (char *);
long file_Length (char *);
long file_ChecksumID (char *);
short file_ModifyOpen (FILE_HANDLE hFile, long movpos, long nbytes);
short file_Modify (BYTE *filename, long movpos, long nbytes);
#define FILE_SAVE_CREATE (-1)
long file_Save (char *, void *, long, long);
long file_Load (char *, void *, long, long);
void file_SplitFileAndPath (char *, char *);

//---------------------------------------------------------------
// MODULE: filbuf_ Buffered file I/O..
//---------------------------------------------------------------

typedef struct {	// Object for buffered file handling..
  BYTE *pData;		// Ptr to current data block req by client.
  long ngood;		// #bytes of above block that are "good"..
			// Rest normally not accessed by user..
  BYTE *pBuf;		// Ptr to memory used as buffer.. (at end of this obj)
  long nread;		// Size of block actually read into buffer last time..
  long bufsize;		// Size of mem buffer
  FILE_HANDLE hFile;		// Handle of file..
  long bufPos;		// File-Pos of start of buffer..
  long filePos;		// Current read/write (seek) pos in file..
  void *pParent;	// Ptr to another FILE_DATA struct with file-handle
			//  (for 2nd buf on same file)
} FILE_DATA;		// Buffer mem follows..

#define FILE_BUF_READ 1		// Open to read
#define FILE_BUF_RW 2		// Open for read/write..
#define FILE_BUF_CREATE 3	// Create file for read/write..

FILE_DATA * filbuf_Open (char *, long, int, FILE_DATA *);
BOOL filbuf_ReadPtr (FILE_DATA *, long, long, WORD);
 #define FILE_BUF_NOMOVE 1	// keep pos ptr in file the same..
 #define FILE_BUF_PARTREADOK 2 	// ret TRUE even if only partial read..
BOOL filbuf_Read (FILE_DATA *, long, long, WORD, void *);
short filbuf_ReadChar (FILE_DATA *);
short filbuf_ReadCharFast (FILE_DATA *);
short filbuf_ReadNonSpaceChar (FILE_DATA *);
void * filbuf_ReadNonSpaceChunk (FILE_DATA *,long);
BOOL filbuf_ReadAscLong (FILE_DATA *, long *);
BOOL filbuf_Seek (FILE_DATA *, long);
BOOL filbuf_Write (FILE_DATA *, long, long, void *);
BOOL filbuf_Modify (FILE_DATA *, long, long);
void filbuf_Close (FILE_DATA *);

//---------------------------------------------------------------
// MODULE: str_ General string handling routines
//---------------------------------------------------------------
int  str_EndIs (char *, char *);
int str_fromval (char *, long , short);
 #define STR_LEAD_SPC   0x10
 #define STR_NOLEAD_CHR 0x20
 #define STR_ADD_NULL   0x40
long str_2val (char *, short, short, short *);
long str_convC (char *, char *, long);
char * str_GetNth (char *istr, short nstr);
short str_inchr (char *bigstr, short fchr);
void str_SwapChar (char *, char, char);
long str_ParseToken (char *, char *);
void str_time2asc (char *, long , short );
 #define TIME_HOURS         1    // Show hour digit H:MM:SS
 #define TIME_NULLTERM      2
 #define TIME_ALLOWOVERFLOW 4    // Show HH;MM on a big time val..
long str_add (char *, char *);

//---------------------------------------------------------------
// MODULE: mem_ Misc mem block-manipulation fns..
//---------------------------------------------------------------
typedef struct {	// For (mem_WrapLines) function..
  BYTE *pLastWrap;	// Pos of start of unwrapped part (after last CR)
  BYTE *pWrt;		// Current "write" pos (end+1)
  int linelen;		// max len of line
  BYTE addcr;		// nz if add CR for wrap..
} WRAP_INFO;

long mem_Checksum (BYTE *pMem, long msize);
long mem_ReverseLong (long);
BOOL mem_WrapLines (WRAP_INFO *);
BOOL mem_swap (void *, void *, long);

//---------------------------------------------------------------
// MODULE: mobj_ Mem object handler.. 
//---------------------------------------------------------------

typedef struct {
  BYTE *pMem;
  long cpos;
  long msize;
  long chunksize;
} MOBJ_DATA;

  // Return codes..
#define MOBJ_OK      1
#define MOBJ_REALLOC 2

BOOL mobj_Alloc (MOBJ_DATA *, long);
void mobj_Free (MOBJ_DATA *);
int mobj_Request (MOBJ_DATA *, long);
int mobj_Add (MOBJ_DATA *, void *, long);
BOOL mobj_FileSave (MOBJ_DATA *, char *);

//---------------------------------------------------------------
// MODULE: par_ Parameter-type file (ie. DEF files) reading functions..
//---------------------------------------------------------------

#define PAR_EOB 2	// END OF BLOCK ret code..
void par_Close ();
void * par_Open (char *);
char * par_GetCurrentPtr ();
int par_ReadLong (long *cvar);
int par_ReadShort (short *cvar);
int par_ReadByte (BYTE *cvar);
int par_ReadShorts (short *cvar, short nshort);
int par_ReadStr (char *szStr, long, long *);
BOOL par_GotoBlock (char *szBlock, short blockID);
BOOL par_ReadStrings (char *szFile, char *szBlock, short blockID, char *szOptions, short *nopts, short *olen, short maxsize);

