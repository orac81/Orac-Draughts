  // Checkers engine Header file, external integer/bytes/Funtions/Macros.

#define EXT_ENG 1	// Allow use of external engines..

BOOL dll_initialize  ();
void dll_finish ();
short dll_calcmove_start ();
short dll_calcmove_continue ();
short dll_calcmove_stop ();

typedef struct {	// Colour data structure..
  BYTE r,g,b;		// RGB colour, as % 0-100
  BYTE preset;		// preset used, or 0 for user RGB.
} PRERGB;

typedef struct {	// Game-move internal engine storage
  BYTE src;
  BYTE dest;
  BYTE flag;
} GAMESTORE;
 
#define MAX_GAME_STORE 700

typedef struct {
  BYTE src;
  BYTE dest;
  BYTE score;
  BYTE flag;
} DISPMOVE;

	// ENG_VAR structure, for passing params to/from engine.
	//   note - a fair bit of this is old/redundant/unused!
	
typedef struct {
  long debug_ncount;		// used for debugging.
  BYTE book_flag;		// checker engine sets this to nz if
  BYTE hash_type;		// =0 if not yet defined, =1 list of segments
  WORD hash_sizemax;		// size of hash table. in segments or mb
  WORD hash_sizeused;		// size actually being used.
  WORD hash_seg_list;		// list of segments. Max at present is 16 = 1mb of hash.
  BYTE hash_sl_end[1];		// end of hash segment table
  BYTE ioram_start[4];		//  to reset computer clear ram from ioram_start to ioram_end
  char checker_board[256];	// board for set up pos
  BYTE ep_castle_status;   	// Specifies whether e/p and castling are
  BYTE check_squares[9];	//
  BYTE game_status;		// read only flag 0 normal, 1 to f illegal position.
  BYTE Spare;	
  WORD endsave_address; 	// final address to save. the checker engine sets this value
  BYTE hint_move[3];		// from, to, flags of hint move.
  BYTE ant_move[3];		// from, too, flags of anticipate move
  BYTE move_test[3];		// from, to. Client must put move here before calling srvc_test_legal or srvc_make_move.
  BYTE move_info[6];		// _srvc_misc_service(0) uses these 6 bytes to return information about the
  BYTE step_flag;		// this byte tells the checker program whether take_back/replay, step_forward, next_best are legal. 
  long lparam_pass;		// Long word for passing long parameter
  long lparam1_pass;		// Extra long word for parameters
  short param_pass;		// used to pass parameters from i/o to checker engine. eg _srvc_misc_service
  short param1_pass;	
  short param_ax_pass;		// uses this to pass the ax register to _srvc_functions now new database memory
  BYTE dbase_pname[128];	// path name and name of database file null terminated. Set by client. 
  BYTE dbase_flag;	 	//  bit 0 set if database is open. if set then _dbase_gamecount gives total no. of games
  long dbase_lastloaded;  	// last loaded. so can load next/again or del/replace
  long dbase_gamecount;   	// count of number of games in database
  BYTE db_header_start[4];	
  BYTE db_head_year;		
  BYTE db_head_result; 		
  WORD db_head_gsize;		
  BYTE db_head_pntext; 	
  BYTE db_head_vtext;		// length of venue text
  WORD db_head_csize;		// byte 7,8.Lenght of comment text. if>0 show 'c'
  BYTE db_head_welo;		// byte 9. White elo. add 140h then multiply by 5
  BYTE db_head_belo;		// byte a. Black "
  BYTE db_head_flag0;		// byte b.
  BYTE db_head_flag1;		// byte c
  BYTE db_head_glength; 	// byte d. Lenght of game. this byte is displayed
  BYTE db_head_random;  	// byte e
  BYTE db_player_name[4];	//  label byte		;names are seperated by a '-' character
  BYTE  Spare2[80]; 
  BYTE clock_flag;		// set -ve if clock to run.
  BYTE search_mode;		// bit 7 set if computing in computers time. (normal search) bit 6 set if search is active. 
	//bit 5 set if hint search. (bit 0 also set if 2player mode)
	//bit 4 set if anticipate search.
	//bit 3 set if anticipate search and srvc_make_move has made
  BYTE timer_tick;		// 17 to -ve to count seconds
  BYTE timer_tick1;		// 4 to -ve to adjust above as 18.2 t/sec
  BYTE timer_flag;
  BYTE anal_flag;		// checker program sets this nz whenever root move or main line changes. 
  short analy_moveno;		// move number of move being searched
  BYTE analy_cmove[3];		// from,to,flags. current move being
	//searched.
  BYTE analy_wflag;		// zero. or +ve if fail high, -ve fail low
  BYTE analy_depth[2];		// Numbers related to current depth of
	//search. min/max
  BYTE analy_mvcnt;		// number of legal moves for computer
  BYTE analy_number;		// number of move being calculated

  WORD analy_score;		// analysis score
  BYTE analy_moves[50];		// up to 12 moves. 3 bytes/move. from,to,flags. Term with a zero word.
  long analy_time;		// search time in seconds FOR analysis
  long analy_nodes;		// Node count.

	//These variables are defined here so that frontend can copy the _analy_??  to _sanaly_???. 
  WORD sanaly_moveno;	
  BYTE sanaly_cmove[3];	
  BYTE sanaly_wflag;	
  BYTE sanaly_depth[2];	
  BYTE sanaly_mvcnt;	
  BYTE sanaly_number;	
  WORD sanaly_score;	
  BYTE sanaly_moves[50];
  long sanaly_time;	
  long sanaly_nodes;	

  DISPMOVE disp_mvlist[100];		// List of possible moves with db evals & flags..
  long disp_nmoves;
  long disp_jumpflag;
  WORD book_moves[51];		// space for 20 book moves at root pos. from,to. bit 7,6 set if user book

	//game save area. To save a game the data starting here should be saved to a
	//a file. The length to save is given in Bytes_to_save
  BYTE current_game_start[4];	// save current game from here
  BYTE language;		// byte specifies language,0,1 eng/germ
  BYTE screen_col;		// colour set chosen by user. 0-4
  BYTE exb_flag;		// -ve if an external board is connected
  BYTE exb_info;		// defines extra info about type of board
  WORD Spare2b;	    		// spare. extra data saved only in lastgame.gam
  PRERGB back;			//  Background colour preset - 0 for RGB, or 1-n..
  PRERGB box;			//  Move/search boxes colour preset - 0 for RGB..
  PRERGB txt;			//  Text colour preset - 0 for RGB..
  PRERGB lsqr;			//  Light square preset/RGB value..
  PRERGB dsqr;			//  Dark sqr preset/RGB val (if preset==0)

  BYTE pieceset;     	// Current piece set selected (1-5)
  BYTE scontrast;    	// Light/Dark contrast level
  BYTE pcontrast;    	// Pattern contrast level
  BYTE sqpattern;    	// Pattern style in sqr (0-4)
  BYTE charx;		//  Width of each sqr
  BYTE chary;		//  Width of each sqr
  BYTE flags;		//  Misc flags
  BYTE flags2;		//  Misc flags
  BYTE anyfont;		//  Indicates a font is in use..
  BYTE mainlogf[58];	// Current FONT data.. NOTE - this MUST be big enough for LOGFONT structure (50 bytes)
  BYTE flags3;		//  Misc flags
  BYTE flags4;		//  Misc flags
  BYTE clkmode;      	//  Current clock mode (color/font)
  WRECT clkwnd;		//  Pos/size of clock window
  WRECT schwnd;		//  Pos/size of search window
  WRECT movwnd;		//  Pos/size of move box window
  WRECT bokwnd;		//  Pos/size of book window
  WRECT brdwnd;		//  Pos/size of board window
  WORD histanal;	//  Historical analysis lines

  BYTE gamesett_start[4];  // save game+settings from here
  WORD play_level;		//dw  1 dup(?)		;defines level
	//first byte defines the level type.	Second byte defines level
	//0	mate search level		0-15 mate in 1 to 16
	//1	not used	reserved for fixed time for each move level ??
	//2	itterative fixed depth		0-30 depth
	//2					31  is infinite level
	//3	loosing 			0-9
	//4	handicap			0-9
	//5	blitz				0-9
	//6	normal				0-9
	//7	user adjustable 		0   sublevels defined only by time
	//8	tourn				0-9
  BYTE play_levex;		// extra level info . eg anticipate ?
	//bit 7,6	= set if easy mode,hint search not allowed
  BYTE Spare4;	 
  
	// These 3 long words specify white time control.
  long levw1;		// word: move number of first time control (0 if all moves)
  long levw2;		// as above but second control. this control repeats
  long levw3;	
	// These 3 long words specify Black time control. as above
  long levb1,levb2,levb3;		
		// Start of time used info (WHITE)
  long white_time;	  	// time used by white
  long white_move_time;  	// incremented each second while white is thinking
  short white_cdown_movs; 	// moves till next white time control. if 0 then whole game before next time control
  WORD Spare5;	  
  long white_cdown_time; 	// white time till next control. decremented each second whilst white is thinking.
		// Start of time used info (BLACK) as above
  long black_time;	  	
  long black_move_time;  	
  short black_cdown_movs; 	
  WORD Spare6;	
  long black_cdown_time; 

  BYTE play_mode;		// 0,$ff,$7f,$7e normal,2play,auto,continous auto $43,$42,$41=anotate both,black,white.$20=epd
  BYTE human_col;		// 0/ff human white/blk. must follow pmode on odd not set or used by checker engine. 
  BYTE champ_flag;		// byte. top bit set if cheated, bits 6,5,4,3,2,1 give the reason. bit0 set if comp has resigned
  BYTE Spare7;
	// Unused space for more options
  WORD cdispm; 
  WORD hdispm; 
  long Spare8;	

  BYTE option_bits;		// byte of bit flags
	//bits 7,6,5,4,3,2,1,0=invert,sound off,learner,random,resign off,tadj request book, tourn/random book. all used.
  BYTE option2_bits;		// bits 7,6,1,0= hash, p plans, set if P.book on bits 5,4,3 set if main analysis is on. 
	// set if extra analysis is off,set if list of book moves is off bit 2 set if fast slide piece
  BYTE oper_time;		// byte gives operator secs/move. added on
  BYTE contempt;		// byte contempt factor. -.30h,-20h,-10h
	// ,0,10h,20h,30h = -.75pawn, -.5pawn, -.25pawn, 0, .25pawn .. .75 pawn
  BYTE play_style;		// playing style byte  0,1,-1=norm,risky,solid
  BYTE option3_bits;	
  BYTE short_depth;		// short-depth cutoff.. 1-100 (36 norm)
  BYTE hash_mode;		// Hash table mode. 1-50 (22 norm)
  BYTE endgame_db;		// Endgame DB depth control 
  BYTE autolearn;       	// #K entries in autolearn table (0=off)
  BYTE sparebyte[3];	

  BYTE book_style;		// which book. 0-5.
  BYTE piece_value[5];		// each byte 5,4,3,2,1,0,-1,-2,-3,-4,-5 for 125,120,115,110,105,100,95,...75%

  BYTE gameonly_start[4];  	//save game only.
	// from here now the game itself.
  short init_moven;		// word for initial move number. bit 15 setup.
	// if _init_moven is zero then the checker engine does not require _init_board
	// to be saved/restored when games are saved/loaded. If want to minimize data storage space then use this feature
  char init_board[256];		// initial board pos.
  short move_number;		
	// SAGE/POLY HEADER DATA..
  WORD boardx;			// Width of board
  WORD boardy;			// Height of board
  BYTE menperside;		// #men per side on new game
  BYTE gammisc0;		// Spare
  BYTE gamtype;		// Type of game 0=eng,1=ital..ff=user
  BYTE gamrules;		// Type of game rules:0=eng,1=ital,2=int10x10 3=spanish,4=pool,5=russian,6=port
  WORD gamflags;		// Inv num, init col,Chess not,cornmode
  WORD gammisc1;		// Spare
  WORD gammisc2;		// Spare
  WORD gammisc3;		// Spare
  GAMESTORE game_store [MAX_GAME_STORE+128];
  BYTE ioram_end[4];  //	label  byte	;to reset computer clear ram from ioram_start

} ENG_VAR;

extern ENG_VAR eng;

extern short bmult;

//#define ELONG long extern 		// External long word
//#define EINT short extern 		// Ext signed short
//#define EBYTE unsigned char extern 	// Ext unsigned short
//#define ECHAR signed char extern 
//#define PINT short *
//#define PBYTE unsigned char *
#define EFUNC short 		// External function

#if _DEBUG
 #define FASTCALL 
#else
 #define FASTCALL 
#endif

		// Declare FUNCTIONS to use..
EFUNC ext_initialize (void);
EFUNC ext_reset (void);
EFUNC ext_init_game (void);
EFUNC ext_next_best (void);
EFUNC ext_calcmove_start (void);
EFUNC ext_calcmove_continue (void);
EFUNC ext_calcmove_stop (void);
EFUNC ext_make_move (BYTE,BYTE *);
EFUNC ext_second (void);
EFUNC ext_set_level (void);
EFUNC ext_step_move (void);
EFUNC ext_is_move_legal (void);
EFUNC ext_misc_service (void);	// ax=0: move in (param_pass)->move_info
EFUNC ext_set_board_pos (void); //
EFUNC ext_userbook (void);
EFUNC ext_database (void);
EFUNC ext_hash (void);
EFUNC ext_db_decode (void);
EFUNC ext_db_stepmove (void);
EFUNC ext_finish (void);

#if _SAGE

 EFUNC ext_checker_move (GAMESTORE *,short,BYTE *);
 EFUNC ext_pos2num (BYTE);
 EFUNC ext_num2pos (BYTE);
 EFUNC ext_new_board (short *,short);
 EFUNC ext_load_old_format (char *, short);
 EFUNC ext_decode_asc_pos (char *, char *);
 EFUNC ext_encode_asc_pos (char *, char *, short);
 EFUNC ext_book_import (char *, long);
 EFUNC ext_hash_init (long);
  
 #define MAX_CHECKER_BOARD 256
 #define MAX_BOOK_MOVES 50	// Absolute max # book moves
 #define MAX_SHOWN_BOOK 20	// Max actualy shown..
 extern char bokName [];	// Current book name (SBOOK#.BOK)
 #define BOOKTYPE long HUGE_
 extern BOOKTYPE *bokPtr [MAX_BOOK_MOVES + 4];	// Array of ptrs to moves in book_moves
 short bokSave ();
 void exAddExtraInfo (BYTE , short);
 void hashClrPreset ();	// Free any hash-book mem.

#else
 #define MAX_CHECKER_BOARD 64
 #define MAX_BOOK_MOVES 20	// Absolute max # book moves
 #define MAX_SHOWN_BOOK 20	// Max actualy shown..
#endif



#define IsDBok (eng.dbase_flag & 1)		// Is DB selected ok?


#define AtNewStart ((eng.move_number | eng.init_moven) == 0)

#define FlagBackOk (eng.step_flag & 0x80)
#define FlagFwdOk (eng.step_flag & 0x40)
#define FlagNextBOk ((eng.step_flag & 3) == 3)
#define FlagNextBReady ((eng.step_flag & 3) == 2)

	// Temporirly halt clock, saving state
#define HaltClock \
	{saveclock = eng.clock_flag; eng.clock_flag &= 0x7f;}
#define RestoreClock  eng.clock_flag = saveclock;	// Restore status.	

#define ClockOn eng.clock_flag |= 0x80;
#define ClockOff eng.clock_flag &= 0x7f;
#define ClockIsOff ((eng.clock_flag & 0x80) == 0)

extern BYTE bokFlags [MAX_BOOK_MOVES + 1];	// Flag - move strength

#define ANALY_NMOVES 12		// # moves in anal line..

typedef struct {	// Analysis data structure..
  short moveno;	//2 move number of move being searched
  BYTE mvfrom;	//  from,to,flags. current move being searched.
  BYTE mvto;	
  BYTE mvflag;
  char wflag;	//1 zero. or +ve if fail high, -ve fail low
  BYTE depthmin;//2 Numbers related to current depth of search. min/max
  BYTE depthmax;
  BYTE mvcnt;	//1 number of legal moves for computer
  BYTE number;	//1 number of move being calculated
  char scorelo;	//1 Score:lo=0..99 in pawns, bit7-ve.
  BYTE scorehi; //HI:=1/100 pawn
  BYTE moves[48]; //36 Best line, 12 moves x 3bytes, 1st 3= fr,to,flag
  short type;	// Type of analy - true if main..
    #define AN_MAIN 1
    #define AN_OPP  2
    #define AN_EXEC 3
  long time;	// Search time for this analysis
  long nodes;	// node count.
} ANALY;

ANALY *Panaly;	// Ptr to either analysis structure
#define Manaly ((ANALY *) &eng.analy_moveno) // Ptr to main analy struct
#define Eanaly ((ANALY *) &eng.sanaly_moveno) // Ptr to extra analy struct

typedef struct {	// Gen move from/to structure
  BYTE from;		// from sqr (0..0x3f)
  BYTE to;		// to sqr (0..0x3f)
  BYTE flags;		// mixed flags
  WORD route[3];	// route taken if multi..
} MOVES;

	// Def some constant ptrs to MOVE-DATA structures..
extern MOVES *const Phint_move;
extern MOVES *const Pmove_test;
extern MOVES *const Pmove_info;

 	// Game-storage - allow 700 moves @ 3 bytes/move
extern GAMESTORE game_store [MAX_GAME_STORE];


#define EdgeSq 16

#if _SAGE
	// Other globals..
 extern GAMESTORE *CheckerMoveInfo; // Pointer to extra checker move info
 extern UINT CheckerNParts;	// And count of # jumps/moves in sequence..
 extern short schNsqrs;		// No of squares..
 extern short schIsMultiJump;	// Set if we are in middle of Multiple-jump..
 extern short schMixedFlagsVar; 
 
 #define Bman 2		// Val of black man  on schBoard..   
 #define Bking 3	
 #define Wman 4	
 #define Wking 5	
	// Initial colour (0=black,nz=white)
 #define VarInitCol eng.gamflags
 #define BitInitCol 1
 #define FlagInitCol (VarInitCol & BitInitCol)
 #define CurColor ((eng.move_number ^ VarInitCol) & 1)
	// Invert numbering   
 #define VarInvNum eng.gamflags
 #define BitInvNum 2
 #define FlagInvNum (VarInvNum & BitInvNum)
	// Chess notation flag
 #define VarChessNot eng.gamflags
 #define BitChessNot 4
 #define FlagChessNot (VarChessNot & BitChessNot)
	// Corn mode- Inverted square play area
 #define VarCornMode eng.gamflags
 #define BitCornMode 8
 #define FlagCornMode (VarCornMode & BitCornMode)
	// Light square at A1
 #define VarLightA1 eng.gamflags
 #define BitLightA1 16
 #define FlagLightA1 (VarLightA1 & BitLightA1)

#else		// Normal Chess...
 #define FlagInitCol 1		// Always white
#endif

 #define VarPgnMoves eng.flags2
 #define BitPgnMoves 8
 #define XorPgnMoves 0		// =8 for inverted

	// Macros to access flags
#define Flag_(x) ((Var##x & Bit##x) ^ Xor##x)
#define Tog_(x) Var##x ^= Bit##x;
#define Set_(x) Var##x = (Var##x | Bit##x) ^ Xor##x;
#define Clr_(x) Var##x = (Var##x & (~Bit##x)) | Xor##x;
;
#define PlayNormal 0
#define PlayTwo 0xff
#define PlayAuto 0x7f
#define PlayCont 0x7e
#define PlayEPD 0x20
#define PlayAnalBoth 0x43
#define PlayAnalBlack 0x42
#define PlayAnalWhite 0x41
#define IsPlayAnalMode ((eng.play_mode & 0xfc) == 0x40)


  
	// Macros to access flags
#define Flag_(x) ((Var##x & Bit##x) ^ Xor##x)
#define Tog_(x) Var##x ^= Bit##x;
#define Set_(x) Var##x = (Var##x | Bit##x) ^ Xor##x;
#define Clr_(x) Var##x = (Var##x & (~Bit##x)) | Xor##x;
;
#define VarInvert eng.option_bits
#define BitInvert 0x80
#define VarSound eng.option_bits
#define BitSound 0x40
	// Main book vars..
#define VarMainBook eng.option_bits
#define BitMainBook 0x02
#define XorMainBook 0x02
	// Endgame database..
#define VarEndgameDB eng.flags3
#define BitEndgameDB 2
#define XorEndgameDB 2

	// Quick access flag macros.. (Inverts have ! preceeding..)
#define FlagInvert	 (VarInvert & BitInvert)
#define FlagSound	!(VarSound & BitSound)
#define FlagRandomPlay 	 (eng.option_bits & 0x10)
#define FlagResign 	!(eng.option_bits & 0x08)
#define FlagTimeAdjust 	 (eng.option_bits & 0x04)
#define FlagMainBook 	!(eng.option_bits & 0x02)
#define FlagRandomBook 	 (eng.option_bits & 0x01)
#define FlagHash 	!(eng.option2_bits & 0x80)
#define FlagPawnStruct 	!(eng.option2_bits & 0x40)
#define FlagMainAnal 	!(eng.option2_bits & 0x20)
#define FlagExtraAnal 	 (eng.option2_bits & 0x10)
#define FlagBookMoves 	!(eng.option2_bits & 0x08)
#define FlagSlide 	!(eng.option2_bits & 0x04)
#define FlagFloat	!(eng.flags & 0x02)	// Old FLoat wnd (always on)
#define FlagClock	!(eng.flags & 0x04)	// Clock window flag
//#define FlagTool 	!(eng.flags & 0x08)	// Toolbar flag
#define FlagTool 	0
#define FlagNumbering 	 (eng.flags & 0x10)	// Show board co-ords
#define FlagMoveBox	!(eng.flags & 0x20)	// Move box window
#define FlagFullAnal	!(eng.flags & 0x40)	// Full 4-line analysis
#define FlagLEDClock	!(eng.flags & 0x80)	// LED colock display
#define FlagBoard	!(eng.flags2 & 0x01)	// Board wnd flag
#define FlagPopUp	 (eng.flags2 & 0x02)	// Popup/child windows
#define FlagSecsMove	!(eng.flags2 & 0x04)	// Time is Seconds per move..
#define FlagShortNot 	 (eng.option3_bits & 0x01)	// Short Notation
#define FlagFigurine 	!(eng.option3_bits & 0x02)	// Graphic notation
#define FlagResigned     (resigned & 1)         
#define FlagTutor     	 (eng.flags3 & 0x01)	// Tutor mode..
        
#define ClrTutor	eng.flags3 &= (~0x01);
#define SetTutor	eng.flags3 |= 0x01;
        
#define SetResigned     resigned |= 1;
#define ClrResigned     resigned &= (~1);

#define FlagAnySearch	((eng.option2_bits & 0x30) != 0x20)
#define KillSearchFlags	eng.option2_bits = (eng.option2_bits & 0xcf) | 0x20;
#define KillClockFlag	eng.flags |= 0x04;
#define KillMoveBoxFlag	eng.flags |= 0x20;
#define SetMoveBoxFlag	eng.flags &= ~0x20;
#define KillBookMovesFlag   eng.option2_bits |= 0x08;
#define KillBoardFlag	eng.flags2 |= 0x01;
#define KillSecsMove    eng.flags2 |= 0x04;
#define SetSecsMove     eng.flags2 &= ~0x04;
#define KillToolFlag	eng.flags |= 0x08;

#define THINK_OPP_DEFAULT 0    // Set if think-opp is on by default..

#if (THINK_OPP_DEFAULT == 1)
  #define FlagPermanent 	!(eng.play_levex & 0x80)   // Invert for per brain..
#else
  #define FlagPermanent 	(eng.play_levex & 0x80)   
#endif

#define HasResigned 	!(eng.champ_flag & 0x01)

#define IsBlacksMove	 (eng.move_number & 0x01)
#define IsWhitesMove	!IsBlacksMove
//#define HumanIsBlack	 (human_col)
#define IsBlacksMoveAbs  (CurColor)

	// Toggle flag commands.. XOR the flag bit..
#define TogInvert 	eng.option_bits ^= 0x80;
#define TogSound 	eng.option_bits ^= 0x40;
#define TogTimeAdjust 	eng.option_bits ^= 0x04;
#define TogRandomPlay 	eng.option_bits ^= 0x10;
#define TogResign 	eng.option_bits ^= 0x08;
#define TogMainBook 	eng.option_bits ^= 0x02;
#define TogRandomBook 	eng.option_bits ^= 0x01;
#define TogHash 	eng.option2_bits ^= 0x80;
#define TogPawnStruct 	eng.option2_bits ^= 0x40;
#define TogMainAnal 	eng.option2_bits ^= 0x20;
#define TogExtraAnal 	eng.option2_bits ^= 0x10;
#define TogBookMoves 	eng.option2_bits ^= 0x08;
#define TogSlide 	eng.option2_bits ^= 0x04;
#define TogPermanent 	eng.play_levex ^= 0x80;
#define TogHasResigned 	eng.champ_flag ^= 0x01;
#define Tog3dBox	eng.flags ^= 0x01;
#define TogFloat	eng.flags ^= 0x02;
#define TogClock	eng.flags ^= 0x04;
#define TogTool		eng.flags ^= 0x08;
#define TogNumbering	eng.flags ^= 0x10;
#define TogMoveBox	eng.flags ^= 0x20;
#define TogFullAnal	eng.flags ^= 0x40;
#define TogBoard	eng.flags2 ^= 0x01;
#define TogPopUp	eng.flags2 ^= 0x02;
#define TogShortNot 	eng.option3_bits ^= 0x01;
#define TogFigurine 	eng.option3_bits ^= 0x02;
#define TogTutor	eng.flags3 ^= 0x01;

#if _SAGE
 #define FlagUserBook FlagMainBook
 #define TogUserBook  TogMainBook
#else
 #define FlagUserBook 	 (eng.option2_bits & 0x02)
 #define TogUserBook 	eng.option2_bits ^= 0x02;
#endif

#define HumanIsBlack	 ((IsBlacksMove != 0) ^ (ThinkMode == ThinkComp))
#define AnyBookMoves ((FlagBookMoves) && book_moves [0])

extern short schIniWeights [20];
extern short schDrawByRep;	// # moves before draw by rep..
void DumpWeights (short);


extern char edbFile [100];	// Name of default endgame db file.
extern short edbBuffSize;		// # K mem to alloc for buffers.
extern short edbType;		// Type of db + (gametype * 10)

extern int drawbyrep;

void autol_Quit ();		  // Prog ends, save & free autolearn data..
char *dll_engcmd (char *, int );
extern char dll_szEng1[256];
extern char dll_szEng2[256];
extern char dll_szEngName1[256];
extern char dll_szEngName2[256];
extern int eng_touse;   // Normally 1, set to 2 in autoplay..
extern int dll_usesagebook1 ;
extern int dll_usesagebook2 ;
