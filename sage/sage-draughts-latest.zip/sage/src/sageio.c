//  G32IO.C - Generic C routines - non-genius specific.
//   All code C-standard - no win-specific code..
//  Copyright R.Lang/A.Millett 1996-97, All Rights Reserved.

#define STRICT                // strict type checking

#include <stdio.h>		// Standard C routines..
#include <string.h>		//for memcpy,memmove, memcmp
#include <stdlib.h>		//for atoi
#include <malloc.h>		// for malloc..
#include <ctype.h>		// isdigit
//#include <time.h>		// _stat
#include <sys/types.h>		// _stat
#include <sys/stat.h>		// _stat

#include "sageio.h"			// General non-genius specific code..


//---------------------------------------------------------------
// MODULE: my_ Misc patches for standard C functions (malloc, etc)
//---------------------------------------------------------------



#ifndef _WIN32
    // For copying objects >64K..
  void my_memcpy (void far *vpDest, void far *vpSrc, long csize)
  {
    long tsize;
    WORD cpos;
    WORD HUGE_ *pSrc = (WORD HUGE_ *) vpSrc;
    WORD HUGE_ *pDest = (WORD HUGE_ *) vpDest;
    while (csize >= sizeof (WORD) ) {
      tsize = min (csize, 0x7f00L) >> 1;
      for (cpos = 0; cpos < (WORD) tsize; cpos ++) {
        pDest [cpos] = pSrc [cpos];
      }
      pDest = (WORD HUGE_ *) pDest + tsize;
      pSrc =  (WORD HUGE_ *) pSrc + tsize;
      csize = csize - tsize - tsize;
    }
    if (csize) {		// Copy any odd byte
      *((BYTE far *) pDest) = *((BYTE far *) pSrc);
    }
    /*
    while (csize) {
      tsize = min (csize, 0x7f00L);
      _fmemcpy (hpDest, hpSrc, (WORD) tsize);
      hpDest = (BYTE HUGE_ *) hpDest + tsize;
      hpSrc = (BYTE HUGE_ *) hpSrc + tsize;
      csize -= tsize;
    } */
  }
    // For copying objects >64K.. _fmemset
  void my_memset (void far *vpDest, int chr, long csize)
  {
    long tsize;
    WORD cpos;
    WORD HUGE_ *pDest = (WORD HUGE_ *) vpDest;
    WORD dchr;			// Double-char
    dchr = (LOBYTE (chr) << 8) | LOBYTE (chr);
    while (csize >= sizeof (WORD) ) {
      tsize = min (csize, 0x7f00L) >> 1;
      for (cpos = 0; cpos < (WORD) tsize; cpos ++) {
        pDest [cpos] = dchr;
      }
      pDest = (WORD HUGE_ *) pDest + tsize;
      csize = csize - tsize - tsize;
    }
    if (csize) {		// Set any odd byte
      *((BYTE far *) pDest) = (BYTE) chr;
    }
    /*
    while (csize) {
      tsize = min (csize, 0x7f00L);
      _fmemcpy (hpDest, hpSrc, (WORD) tsize);
      hpDest = (BYTE HUGE_ *) hpDest + tsize;
      hpSrc = (BYTE HUGE_ *) hpSrc + tsize;
      csize -= tsize;
    } */
  }
  
#endif
    
//---------------------------------------------------------------
// MODULE: file_ General file handling routines
//---------------------------------------------------------------
  // First generic replacements for file-open,read/write/close etc.
  // portable across all possibilities (ie open/fopen/Win95-32bit special)

#ifdef FILE_METHOD_FOPEN   // Use fopen libraries..

FILE_HANDLE file_Open (char *szFile, int mode)
{
    char *szMode;
    if (mode == FILE_READ) szMode = "rb";
    if (mode == FILE_WRITE) szMode = "r+b";
    if (mode == FILE_CREATE) szMode = "w+b";
    return fopen (szFile, szMode);
}

#endif   

   // Win95 API calls..
#ifdef FILE_METHOD_WIN95

   // Open/Create a file. 
   // mode = FILE_READ, FILE_WRITE, FILE_CREATE
 FILE_HANDLE file_Open (char *szFile, int mode)
 {
    int oMode = GENERIC_READ;
    int oCreate = OPEN_EXISTING;
    // if (mode == FILE_READ) // Implicit mode..
    if (mode == FILE_WRITE) oMode = GENERIC_READ | GENERIC_WRITE;
    if (mode == FILE_CREATE) {
      oMode = GENERIC_READ | GENERIC_WRITE;
      oCreate = CREATE_ALWAYS;
    }
    return CreateFile (szFile, oMode,0,NULL,oCreate,FILE_ATTRIBUTE_NORMAL,NULL);
 }

   // Close a file
 void file_Close (FILE_HANDLE hFile) 
 {
    CloseHandle (hFile);
 }

   // Read block of data at (pBuf) of (size) from file..
   //  ret # bytes read, or 0=none/error (use file_Error to check)
 ULONG file_Read (FILE_HANDLE hFile,void *pBuf,long size) 
 {
    ULONG rlen;
    BOOL cret;
    cret = ReadFile (hFile, pBuf, size,&rlen,NULL);
    if (cret == FALSE) return 0;
    return rlen;
 }

   // Write block of data at (pBuf) of (size) to file..
   //  ret # bytes written, or 0=none/error (use file_Error to check)
 ULONG file_Write (FILE_HANDLE hFile,void *pBuf,long size) 
 {
    ULONG wlen;
    BOOL cret;
    cret = WriteFile (hFile, pBuf, size,&wlen,NULL);
    if (cret == FALSE) return 0;
    return wlen;
 }

   // Move file ptr to position, use SEEK_SET/SEEK_CUR/SEEK_END for origin
 BOOL file_Seek (FILE_HANDLE hFile,long offset,int origin) 
 {
    DWORD fp;
    fp = SetFilePointer (hFile, offset,NULL,origin);
    return (fp == 0xffffffffL);         // 0 if sucsessfull..
 }

   // Get size of file..
 long file_Tell(FILE_HANDLE hFile) 
 {
    return ((long) GetFileSize (hFile,NULL));
 }
    
    // Get error status for file - 0=none, notzero=error code
 int file_Error(FILE_HANDLE hFile) 
 {
    return GetLastError ();
 }

   // Truncate file at current position..
 BOOL file_Truncate (FILE_HANDLE hFile) 
 {
     return SetEndOfFile (hFile);
 }

#endif    // FILE_METHOD_WIN95 


  // Test if file exists. Return 1 if yes. 0 if no.
int file_Exists (char *szFile)
{
  FILE_HANDLE stream;
  stream  = file_Open( szFile, FILE_READ);
  if (file_HandleIsBad(stream)) return FALSE;
  file_Close (stream);
  return TRUE;
}


  // Ret file-length, or -1 if error/doesnt exist..
long file_Length (char *szFile)
{
    struct _stat buf;
    int cret;
    cret = _stat ((char *) szFile, &buf );   // Get data associated with file..
    if (cret != 0 ) return -1;		// Error..
    return (buf.st_size);
}

  // Ret unique ID based on name, len & time/date stamp of file..
  // ret zero if file error..
long file_ChecksumID (char *szFile)
{
    long chk;
    struct _stat buf;
    int cret;
    cret = _stat ((char *) szFile, &buf );   // Get data associated with file..
    if (cret != 0 ) return 0;		// Error..
    chk = (long) mem_Checksum ((BYTE *) szFile,-1);
    chk += (long) buf.st_size;	// Size of file
    chk += (long) buf.st_mtime;	// Time of last modification
    if (chk == 0) chk ++;
    return (chk);
}


  // Insert/Delete (nbytes) bytes at (movpos) to file fname
  // if (nbytes < 0) delete, if (nbytes > 0) insert
  // Return FALSE if error. TRUE if ok
short file_Modify (BYTE *fname, long movpos, long nbytes)
{
  FILE_HANDLE hFile;
  int   retv;
  hFile = file_Open((char *) fname, FILE_WRITE);
  if (file_HandleIsBad (hFile)) return FALSE;
  retv = file_ModifyOpen (hFile, movpos, nbytes);
  file_Close (hFile);
  return (retv);         // TRUE/FALSE
}


  // Insert/Delete (nbytes) bytes at (movpos) from open file (opened with 
  //fopen), handle=hfile
  // if (nbytes < 0) delete, if (nbytes > 0) insert
  // Return FALSE if error..
short file_ModifyOpen (FILE_HANDLE hFile, long movpos, long nbytes)
{
  BYTE *dbuff;	// Temp buffer for moving data
  WORD buffsize = 0x7000;	// Size of buffer
  ULONG nread;
  long fsize;		// Size of file
  long fpos;		// Current file pos..
  short cret = FALSE;	// Default error..
  if (nbytes == 0) return TRUE;	// No work to do!
  
  dbuff = (BYTE *) malloc (buffsize);
  if (dbuff == NULL) return FALSE;
  if (file_Seek (hFile, 0L, SEEK_END)) goto fError;	// Calc file len..
  fsize = file_Tell (hFile);
  if (fsize==-1) goto fError;
  if (movpos > fsize) return TRUE;	// Past end, no work to do..
  if (nbytes < 0) {	// DELETE (-nbytes)
    fpos = movpos;	// Start pos for delete..
    do {
      if (fpos - nbytes <= fsize) {	// Already past end..
        if (file_Seek (hFile, fpos - nbytes, SEEK_SET)) goto fError;
      }
      nread = file_Read (hFile,dbuff,buffsize);
      if (!nread){
        if (file_Error(hFile)) goto fError;		//was an error
      }
      if (file_Seek (hFile, fpos, SEEK_SET)) goto fError;
      if (file_Write (hFile,dbuff, nread) != nread) goto fError;
      fpos += nread;
    } while (nread);	
    file_Truncate (hFile);      // Truncate file at current pos..

  } else {		// INSERT (nbytes)
    fpos = fsize ;	// Start pos for insert
    do {
      nread = (WORD) __min ((long) buffsize, fpos - movpos);
      if (nread == 0) break; 	// No more, all done!
      fpos -= nread;
      if (file_Seek (hFile, fpos, SEEK_SET)) goto fError;
      nread = file_Read (hFile,dbuff, nread);
      if (!nread){
        if (file_Error(hFile)) goto fError;		//was an error
      }
      if (file_Seek (hFile, fpos + nbytes, SEEK_SET)) goto fError;
      if (file_Write (hFile,dbuff, nread) != nread) goto fError;
    } while (1);
  }
  cret = TRUE;		// No error code.
fError:				// Error ret jump loc
  free (dbuff);
  return (cret);
}


  // Create (or truncate existing file and write specified memory to it
  //and then close it.
  // Return TRUE if ok else FALSE=error  
long file_Save (char *filename,void *pData,long datasize, long datapos)
{
  FILE_HANDLE hFile;
  long retv = 0;
  int iMode = FILE_CREATE;	// create new..
  if (datapos == FILE_SAVE_CREATE) {		// Create a new file..
    datapos = 0;
  } else {				// Modify existing?
    if (file_Exists (filename) == TRUE) iMode = FILE_WRITE;
  }
  hFile  = file_Open((char *) filename, iMode);
  if (file_HandleIsBad (hFile)) return (FALSE);
  if (datasize) {	// Any data to write?
    file_Seek (hFile, datapos, SEEK_SET);
    retv = file_Write (hFile,pData, (size_t) datasize);	//write data
  }
  file_Close (hFile);					// Close stream 
  if (retv == datasize) return TRUE;	//ok correct size
  return FALSE;
}



  // Open, Load and close a block of data from a file at a given location
  // Ret 0=error , else number of characters read 
long file_Load (char *filename, void *pData, long fstart, long datasize)
{
  FILE_HANDLE hFile;
  long retv;
  // Open for read (will fail if file "data" does not exist) 
  hFile = file_Open ((char *) filename, FILE_READ);
  if (file_HandleIsBad (hFile)) return (0);
  if (file_Seek (hFile, fstart, SEEK_SET)) return (0);	//seek failed
  retv = file_Read (hFile, pData, (size_t) datasize);	//read data
  file_Close(hFile);					// Close stream 
  return (retv);
}

  // Parse File name from full path, truncate path..
  //  If (szName == NULL), dont sep title..
void file_SplitFileAndPath (char *szFullPath, char *szName)
{
    short slen,clen;
    char cchr;
    clen = slen = strlen (szFullPath);
    if (szName) *szName = 0;
    if (clen < 2) return;
    do {
      clen --;
      cchr = szFullPath [clen];
      if (cchr == CHR_BSLASH || cchr == ':') {
        if (szName) strcpy (szName, szFullPath + clen + 1);
        if (cchr == ':') clen ++;
        szFullPath [clen] = 0;
	return;
      }
   } while (clen > 0);
     // No / char, just assume its a filename..
   if (szName) strcpy (szName, szFullPath);
   szFullPath [0] = 0;
}

//---------------------------------------------------------------
// MODULE: filbuf_ Buffered file I/O..
//---------------------------------------------------------------

  // Open a buffered file for read, allocate some buffer mem for it..
  // fmode = READ/WRITE/READ_WRITE mode..
  // If pParent!=NULL, use supplied file-handle, dont fopen/fclose (for 2ndary buffering..)
  // Ret ptr to FILE_DATA id if alloc ok, otherwise NULL..
FILE_DATA * filbuf_Open (char *szFile, long bufsize, int fmode, FILE_DATA *pParent)
{
    FILE_DATA *pFile;
    pFile = (FILE_DATA *) malloc (bufsize + sizeof (FILE_DATA) + 256);
    if (pFile == NULL) return NULL;	// Cannot alloc mem..
    memset (pFile, 0, sizeof (FILE_DATA));	// Clr data object..
    pFile->pBuf = ((BYTE *) pFile) + sizeof (FILE_DATA);
    pFile->pParent = pParent;
    if (pParent) {	// 2ndary buffer, use "parent" file-handle..
      pFile->hFile = pParent->hFile;
    } else {
      if (fmode == FILE_BUF_CREATE) {
        pFile->hFile = file_Open (szFile,FILE_CREATE);
      } else if (fmode == FILE_BUF_RW) {
        pFile->hFile = file_Open (szFile,FILE_WRITE);
        if (pFile->hFile == NULL) {	// no file, try creating one..
          pFile->hFile = file_Open (szFile,FILE_CREATE);
	}
      } else {		// default FILE_BUF_READ mode..
        pFile->hFile = file_Open (szFile,FILE_READ);
      }
      if (file_HandleIsBad (pFile->hFile)) {		// File error..
        free (pFile);
        return NULL;
      }
    }
    pFile->bufsize = bufsize;
    pFile->bufPos = 0x7fffffffL;	// Flush read buffer (force read on 1st access)
    pFile->pBuf[bufsize] = 0;		// put a NULL past end..
    pFile->pBuf[bufsize+1] = 0;		// put a NULL past end..
    return pFile;
}

  // Flush buffer(s) associated with file..
void filbuf_Flush (FILE_DATA *pFile)
{
    pFile->bufPos = 0x7fffffffL;	// Flush read buffer (force read on next access)
}


  // Read data into FILE_DATA buffer..
  //  Set rPos == -1 for seek from prev read.. 
  //  if FILE_BUF_NOMOVE | iSize, do not advance ptr..
  // Ret Ptr to data in pFile->pData. 
  // Returns TRUE if all bytes are read ok.
  // Return FALSE if fail,(pFile->ngood) indicates how many bytes read ok..
BOOL filbuf_ReadPtr (FILE_DATA *pFile, long rPos, long rSize, WORD flags)
{
    pFile->ngood = 0;	// Default no good bytes read..
    if (rPos == -1) rPos = pFile->filePos;	// Default current file pos..

		// See if requested file-data is in buffer..
    if (rPos >= pFile->bufPos && rPos+rSize <= pFile->bufPos + pFile->nread) {
      pFile->ngood = rSize;	// All read data is good..
      pFile->pData = pFile->pBuf + (rPos - pFile->bufPos);
      if (!(flags & FILE_BUF_NOMOVE)) pFile->filePos = rPos + rSize;
      return TRUE;
    }
	// Move to new pos in file..
    if (file_Seek (pFile->hFile, rPos, SEEK_SET)) {		// Seek error..
      return FALSE;	// error..
    }
		// Read new buffer block
    pFile->nread = file_Read (pFile->hFile,pFile->pBuf,pFile->bufsize);
    pFile->pData = pFile->pBuf;
    pFile->bufPos = rPos;
    pFile->ngood = pFile->nread;	// Ret indicator of how many really read..
    if (pFile->nread == 0) return FALSE;	// EOF/read error..
    if (rPos+rSize > pFile->bufPos + pFile->nread) {  // Failed to read req data..
      pFile->pBuf[pFile->nread] = 0;	// put a NULL past end..
      if (!(flags & FILE_BUF_NOMOVE)) pFile->filePos = rPos + pFile->nread;
      if (flags & FILE_BUF_PARTREADOK) return TRUE;  // Allow "partial" block read..
      return FALSE;	// EOF..
    }
    if (!(flags & FILE_BUF_NOMOVE)) pFile->filePos = rPos + rSize;
    return TRUE;
}

  // Read data from buffered file, copying to buffer..
  // ret TRUE if ok..
BOOL filbuf_Read (FILE_DATA *pFile, long rPos, long rSize, WORD flags, void *pData)
{
    BOOL cret;
    cret = filbuf_ReadPtr (pFile, rPos, rSize,flags);
    if (cret == FALSE) return FALSE;
    memcpy (pData, pFile->pData, __min (pFile->ngood,rSize));
    return TRUE;
}

  // Read current char from file, without advancing file pointer... 
  //  ret -1 for error..
short filbuf_ReadChar (FILE_DATA *pFile)
{
    short cchr = 0;
    BOOL cret;
		// See if requested file-data is in buffer..
    if (pFile->filePos >= pFile->bufPos && pFile->filePos < pFile->bufPos + pFile->nread) {
      cchr = (short) pFile->pBuf [pFile->filePos - pFile->bufPos];
      return cchr;
    }
    cret = filbuf_Read (pFile, -1,1, FILE_BUF_NOMOVE,&cchr);
    if (cret == FALSE) return -1;
    return cchr;
}

  // Read current char from mem without bounds-check..
  //  ret -1 for error..
short filbuf_ReadCharFast (FILE_DATA *pFile)
{
    return (short) pFile->pBuf [pFile->filePos - pFile->bufPos];
}

  // Read next non-space char from file... ret -1 for error..
short filbuf_ReadNonSpaceChar (FILE_DATA *pFile)
{
    short cchr = 0;
    do {
      cchr = filbuf_ReadChar (pFile);
      if (cchr != 32 && cchr != CHR_CR && cchr != CHR_LF && cchr != CHR_TAB) return cchr;
      pFile->filePos ++;
    } while (1);
}

  // Ret ptr to next Non-Space chunk of data, without reading past it..
  //  Ret NULL if error..
void * filbuf_ReadNonSpaceChunk (FILE_DATA *pFile,  long chSize)
{
    short cchr = filbuf_ReadNonSpaceChar (pFile);
    if (cchr < 0) return NULL;
    filbuf_ReadPtr (pFile, -1, chSize, FILE_BUF_NOMOVE);
    if (pFile->ngood == 0) return NULL; // No chars read at all..
    return pFile->pData;	// ret ptr to data..
}

  // Read long-int as ascii, 
  //  Ret TRUE if ok, FALSE on error..
BOOL filbuf_ReadAscLong (FILE_DATA *pFile, long *lval)
{
    char szBuf [32];
    BOOL cret;
    short ccount;
    cret = filbuf_Read (pFile, -1,sizeof(szBuf)-4, FILE_BUF_NOMOVE | FILE_BUF_PARTREADOK,szBuf);
    if (cret == FALSE) return FALSE;
    if (isdigit(szBuf[0]) == 0) return FALSE;
    *lval = str_2val (szBuf,10,sizeof(szBuf)-4,&ccount);
    pFile->filePos += ccount;	// Move file ptr along by char count..
    return TRUE;
}

BOOL filbuf_Seek (FILE_DATA *pFile, long rPos)
{
    pFile->filePos = rPos;
    return TRUE;
}

  // Write data to buffered file..
BOOL filbuf_Write (FILE_DATA *pFile, long wPos, long wSize, void *pData)
{
    int nwrt;
		// If write data shadowed by read buffer, copy to it..
    if (wPos >= pFile->bufPos && wPos+wSize < pFile->bufPos + pFile->nread) {
      memcpy (pFile->pBuf + wPos - pFile->bufPos, pData, wSize);
    } else {
	// If partial overlap, flush..
      if (wPos + wSize >= pFile->bufPos || wPos < pFile->bufPos + pFile->nread) {
        filbuf_Flush (pFile);
      }
    }
    if (file_Seek (pFile->hFile, wPos, SEEK_SET)) {		// Seek error..
      return FALSE;	// error..
    }
    nwrt = file_Write (pFile->hFile,pData,wSize);
    if (nwrt < wSize) return FALSE;
    return TRUE;
}

  // Insert/Delete (nbytes) bytes at (movpos) from buffered file 
  // (opened with filbuf_Open)
  // if (nbytes < 0) delete, if (nbytes > 0) insert
  // Return FALSE if error..
BOOL filbuf_Modify (FILE_DATA *pFile, long movpos, long nbytes)
{
    filbuf_Flush (pFile);
    return file_ModifyOpen (pFile->hFile, movpos,nbytes);
}


  // Close file and free buffer mem..
void filbuf_Close (FILE_DATA *pFile)
{
    if (pFile == NULL) return;
    if (pFile->pParent == NULL) {
      file_Close (pFile->hFile);
    }
    free (pFile);
}

//---------------------------------------------------------------
// MODULE: str_ General string handling routines
//---------------------------------------------------------------

  // Check to see if (str1) ends with given (str2),
  // ret dif in len if it matches, ret -1 if no match
  // NOT CASE SENSITIVE
int str_EndIs (char *str1, char *str2)
{
        int clen1 = strlen ((char *) str1);
        int clen2 = strlen ((char *) str2);
        if (clen2 > clen1) return -1;
        if (strcmpi ((char *) str1 + clen1 - clen2,(char *) str2)) {
          return -1;    // No match
        }
        return clen1 - clen2;   // Ok, matches - ret dif in len!
}

  // Build an ASC short 000 format 
  // (form:bit 0-3) - max # digits 
  // STR_LEAD_SPC   set = leading spaces, not zeros..
  // STR_NOLEAD_CHR set = del leading chars (not fixed format)
  // STR_ADD_NULL   set = add null term
  // return # digits (excl null term)..
int str_fromval (char *cptr, long cval, short form)
{
	short leadflag = form;
	form &= 0x0f;
	if (leadflag & STR_NOLEAD_CHR) {	// Del leading chars..
	  char tstr[20];
	  int ndig = 0;
	  int cpos;
	  do {
	    tstr [ndig] = (char) ((long) (cval % 10) + 48);
	    cval = cval / 10;
	    ndig ++; form --;
	  } while (cval && form);
	  for (cpos = 0; cpos < ndig; cpos ++) {
	    cptr [cpos] = tstr [ndig - cpos - 1];
	  }
	  if (leadflag & STR_ADD_NULL) cptr [ndig] = 0;
	  return ndig;
	}
	while (form) {
	  form --;
	  if ((leadflag & STR_LEAD_SPC) && cval == 0) {	// no leading zeros
	    cptr [form] = 32;
	  } else {
	    cptr [form] = (char) ((long) (cval % 10) + 48);
	  }
	  cval = cval / 10;
	}
        if (leadflag & STR_ADD_NULL) cptr [leadflag & 0x0f] = 0;
	return (leadflag & 0x0f);
}

	// Convert string in given base to a val..
long str_2val (char *istr, short base, short maxdigits, short *ccount)
{
	long ret = 0;
	WORD tmp;
	short sign = 0;
	if (ccount) *ccount = 0;
	if (*istr == '-') {
	  sign = 1; istr ++;
	  if (ccount) (*ccount) ++;
	}
	while (maxdigits) {
	  tmp = *istr - 48;
	  if (tmp > 9) {
	    tmp -= 7;
	    if (tmp < 10) break;
	  }
	  if (tmp >= (WORD) base) break;
	  ret = ret * ((long) base) + tmp;
	  maxdigits --; istr ++;
	  if (ccount) (*ccount) ++;
	}
	return sign ? -ret : ret;
}

  // Copy string until " or NULL, converting \n, \0, \t, \xnn to asc..
long str_convC (char *szDest, char *szSrc, long maxlen)
{
	long ncpy = 0;
	WORD cchr;
	do {
	  cchr = *szSrc;
	  if (cchr == 0 || cchr == CHR_QUOTE) break;	// End of string
	  if (cchr == CHR_BSLASH) {		// '\', special character..
	    szSrc ++;
	    cchr = *szSrc;
	    if (cchr == 0) break;	// Hit str end..
	    switch (cchr) {
	      case 'n': cchr = CHR_LF; break;
	      case '0': cchr = 0; break;
	      case 47: cchr = 0; break;		// Also "\/"==NULL..
	      case CHR_BSLASH: cchr = CHR_BSLASH; break;//  "\\"==BackSlash
	      case 't': cchr = CHR_TAB; break;
	      case 'r': cchr = CHR_CR;break;
	      case 'a': cchr = 7; break;
	      case 'x':		// 2 digits of hex..
	        szSrc ++;
	        cchr = (BYTE) str_2val (szSrc,16,2,NULL);
	        szSrc ++;
	        break;
	      case '$':		// 4 digits of hex..(2-byte)
	        szSrc ++;
	        cchr = (WORD) str_2val (szSrc,16,4,NULL);
	        szSrc += 3;
	        szDest [ncpy] = (char) (cchr & 0xff);
	        ncpy ++;
	        cchr >>= 8;
	        break;
	      case ',':		// Decimal..2-byte..
	        szSrc ++;
	        cchr = (WORD) str_2val (szSrc,10,5,NULL);	// Conv to DECIMAL..
	        szDest [ncpy] = (char) (cchr & 0xff);
	        ncpy ++;
	        cchr >>= 8;
	        while (isdigit (*szSrc)) szSrc ++;
	        szSrc --;
	        break;
	    }
	  }
	  szDest [ncpy] = (char) cchr;
	  szSrc ++; ncpy ++;
	} while (ncpy < maxlen - 1);
	szDest [ncpy] = 0;
	ncpy ++;
	return ncpy;
}

  // Extract pointer to Nth string in list (0..n), quit on double null
char * str_GetNth (char *istr, short nstr)
{
	while (nstr) {
	  if (*istr == 0) break;	// Double null, exit..
	  while (*istr) istr ++;
	  istr ++;
	  nstr --;
	}
	return istr;
}

  // Find char in BIGSTR (0..n,-1 fail) 
short str_inchr (char *bigstr, short fchr)
{
	short scount;
	for (scount = 0; bigstr [scount] != 0; scount ++) {
	  if (bigstr [scount] == fchr) {
	    return (scount);
	  }
	}
	return (-1);
}

  // Swap one char for another in a string..
void str_SwapChar (char *istr, char chr1, char chr2)
{
	short cpos;
	for (cpos = 0; istr [cpos]; cpos ++) {
	  if (istr [cpos] == chr1) istr [cpos] = chr2;
	}
}


  // General Parse token from string.. (ret 0 for no match found)
  // (pTok)=ptr to token list (DOUBLE NULL-TERM)
  // (pFind) = pointer to string
  // Ret1..n token# from list (pTok) in LOWORD
  // Ret len of token in HIWORD
  //  Ret 0=no token
long str_ParseToken (char *pTok, char *pFind)
{
	char *pPos;		// ptr to code
	short ctoken = 0;			// Cur token #
	while (*pTok) {			// Until null terminate
	  ctoken ++;
	  pPos = pFind;
	  while (*pTok && *pTok == *pPos) {	// See if chars match..
	    pTok ++; pPos ++;
	  }
	  if ((BYTE) *pTok < 31) {	// Matched to end of token, found it?
	  	// Only allow if not in middle of alpha-name..
	    if (isalnum (*pPos) == 0 || isalnum (*(pPos - 1)) == 0) {
	      //tutTokFlag = *pTok;	// Get Token flag from end
	      return (ctoken + ((short) (pPos - pFind) << 16));
	    }
	  }
	  while ((BYTE) *pTok >= 31) pTok ++;	// scan to try next token
	  pTok ++;
	}
	return (0);		// No token found.
}

  // Build an ASC clock str "0:00:00" at (clkptr) for (xtime) secs
  // hflag - set bit 0 for hours, bit 1 for null-term..
  //  set bit 2 for "00;00" hours/mins if time >= 60 mins..
void str_time2asc (char *clkptr, long xtime, short hflag)
{
	short itime;
	char sepchar = ':';
	if (hflag & TIME_HOURS) {	// Show hours digit..
	  *clkptr = (char) ((long) 48 + ((xtime / 3600) % 10));
	  clkptr ++;
	  *clkptr = ':';
	  clkptr ++;
	}
	if ((hflag & TIME_ALLOWOVERFLOW) && xtime >= 3600) {	// If >1hour, "hh;mm" mode.
	  xtime = xtime / 60; sepchar = ';';
	}
			// Minutes..
	itime = (short) ((long) xtime % 3600);
	*clkptr = (char) ((short) 48 + (itime / 600));
	clkptr ++;
	*clkptr = (char) ((short) 48 + ((itime / 60) % 10));
	clkptr ++;
	*clkptr = sepchar;
	clkptr ++;
			// Seconds..
	itime = ((short) itime % 60);
	*clkptr = (char) ((short) 48 + (itime / 10));
	clkptr ++;
	*clkptr = (char) ((short) 48 + (itime % 10));
	if (hflag & TIME_NULLTERM) {		// Null term..
	  clkptr ++;
	  *clkptr = 0;
	}
}

  // Copy (szDest) to (szSrc), like (strcpy), only ret # char copied
long str_add (char *szDest, char *szSrc)
{
    long clen = strlen (szSrc);
    memcpy (szDest,szSrc,clen);
    return clen;
}

//---------------------------------------------------------------
// MODULE: mem_ Misc mem block-manipulation fns..
//---------------------------------------------------------------

//  mem_AddRemove
// input	*ppos	Pointer to where to add/remove
//		*pend	Pointer to end of data.
//		*pnew	Pointer to new data to insert into data
//		remcnt	No of bytes to remove
//		inscnt	No of bytes to insert
// This routine removes and/or inserts bytes into a data area. It first shifts
// any data between *ppos and *ppend and then inserts bytes into the space left.
// (This is quicker than first removing and then adding). Note if remcnt/addcnt
//  are zero then no data is removed/inserted.
//It returns inscnt-remcnt. So +ve if more bytes added then removed.


int mem_AddRemove(BYTE *ppos,BYTE *pend,BYTE *pnew,int remcnt,int inscnt) 
{
  int i=inscnt-remcnt;
  if (i>0) memmove(ppos+i,ppos,pend-ppos);	//dest, source, bytes to move
  if (i<0) memmove(ppos, ppos-i, pend+i-ppos);
  if (inscnt) memcpy(ppos,pnew,inscnt);       	//as memmove but no overlap
  return (i);
}  

  // Compute a checksum for a memory block.. 
  //  (msize == -ve) for string-checksum (ie. do strlen)
long mem_Checksum (BYTE *pMem, long msize) 
{
    ULONG checksum = 0;
    ULONG check2 = 0;
    ULONG v1 = 0;
    ULONG cpos;
    if (msize < 0) msize = strlen ((char *) pMem);
    for (cpos = 0; cpos < (ULONG) msize; cpos ++) {
      v1 = v1 * 1024 + pMem [cpos];
      if ((cpos & 3) == 0) v1 = 0;
      checksum += v1;
      check2 += (check2 * 2) + (check2 > 0x80000000L) + v1;
    }
    return (long) checksum + check2;
}


  // Reverse byte order in a 32bit long word..
long mem_ReverseLong (long clong)
{
    BYTE *plong = (BYTE *) &clong;
    return (plong[3]+(plong[2]<<8)+(plong[1]<<16)+(plong[0]<<24));
}

  // Take a chunk of mem, and wrap lines in it..
BOOL mem_WrapLines (WRAP_INFO *pwi)
{
    long wsize;
    BYTE *pBuf;
    BYTE *pSrc;
    BYTE *pDest;
    int slen;
    wsize =  pwi->pWrt - pwi->pLastWrap;
    pBuf = (BYTE *) malloc (wsize + pwi->linelen + 64);
    if (pBuf == NULL) return FALSE;
    memcpy (pBuf,pwi->pLastWrap,wsize);
    pSrc = pBuf;
    pDest = pwi->pLastWrap;
    while (1) {		// Scan multiple lines..
      int cpos;
      slen = wsize - (pSrc - pBuf);	// Amount of mem left..
      if (slen < pwi->linelen) {	// No more lines left to wrap..
        break;
      }
      cpos = pwi->linelen;
      while (1) {	// Scan line, find breakpoint
        if (cpos <= 0) {    // No breakpoint, wrap all..
	  memcpy (pDest,pSrc,pwi->linelen);
	  pDest += pwi->linelen;
	  pSrc += pwi->linelen;
	  if (pwi->addcr) *pDest ++= CHR_CR;
	  *pDest ++= CHR_LF;
	  break;
	}
        if (pSrc[cpos] < 33) {   // Wrap point?
	  memcpy (pDest,pSrc,cpos);
	  pDest += cpos;
	  pSrc += cpos+1;	// also skip breakpoint char..
	  if (pwi->addcr) *pDest ++= CHR_CR;
	  *pDest ++= CHR_LF;
	  break;
	}
        cpos --;
      }
    }
    memcpy (pDest,pSrc,slen);
    pwi->pLastWrap = pDest;
    pwi->pWrt = pDest + slen;
    free (pBuf);
    return TRUE;
}

  // Swap 2 chunks of mem..
BOOL mem_swap (void *p1, void *p2, long bsize)
{
    void *pTmp = malloc (bsize);
    if (pTmp == NULL) return FALSE;
    memcpy (pTmp, p1, bsize);
    memcpy (p1, p2, bsize);
    memcpy (p2, pTmp, bsize);
    free (pTmp);
    return TRUE;
}

//---------------------------------------------------------------
// MODULE: mobj_ Mem object handler.. 
//---------------------------------------------------------------

BOOL mobj_Alloc (MOBJ_DATA *pM, long chunksize)
{
    if (pM->pMem) free (pM->pMem);
    memset (pM,0,sizeof (MOBJ_DATA));
    pM->pMem = (BYTE *) malloc (chunksize);
    if (pM->pMem == NULL) return FALSE;
    pM->chunksize = pM->msize = chunksize;
    return TRUE;
}

void mobj_Free (MOBJ_DATA *pM)
{
    if (pM->pMem) free (pM->pMem);
    memset (pM,0,sizeof (MOBJ_DATA));
}
  
  // Request a chunk of mem of (datsize) to be available
  // Return FALSE on err, or MOBJ_OK/MOBJ_REALLOC
int mobj_Request (MOBJ_DATA *pM, long datsize)
{
    long reqsize;
    BYTE *pDat;
    if (pM->pMem == NULL) return FALSE;
    reqsize = pM->cpos + datsize + pM->chunksize/16;
    if (reqsize < pM->msize) return MOBJ_OK;	// no realloc
    pM->msize = (1 + reqsize / pM->chunksize) * pM->chunksize;
    pDat = (BYTE *) realloc (pM->pMem,pM->msize);
    if (pDat ==NULL) return FALSE;
    pM->pMem = pDat;
    return MOBJ_REALLOC;
}

  // Add chunk of mem to mem object..
  // Return FALSE on err, or MOBJ_OK/MOBJ_REALLOC
int mobj_Add (MOBJ_DATA *pM, void *pDat, long datsize)
{
    BOOL cret = mobj_Request (pM, datsize);
    memcpy (pM->pMem + pM->cpos,pDat,datsize);
    pM->cpos += datsize;
    return cret;
}

  // Save off mem object as file..
BOOL mobj_FileSave (MOBJ_DATA *pM, char *szFile)
{
    return file_Save (szFile,pM->pMem,pM->cpos,FILE_SAVE_CREATE);
}

//---------------------------------------------------------------
// MODULE: par_ Parameter-type file (ie. DEF files) reading functions..
//---------------------------------------------------------------

BYTE FAR_ *par_Ptr = NULL; // Ptr to start pos in mem..
WORD par_Pos;		// Position in file..
size_t par_FileSize;

#define par_FILESIZE 256000L	// Max file size for param-read..

void par_Close ()
{
    if (par_Ptr) my_free (par_Ptr);	// Free any old mem..
    par_Ptr = NULL;
}

  // Open a param file & read into mem, ready for parsing
  //  Return NULL if error, else ptr to mem..
  //  (Also serves as File-grabbing routine..)
void * par_Open (char *szFile)
{
    FILE *par_Index = NULL;	// Handle for file..
    long fsize;
    if (par_Ptr) free (par_Ptr);	// Free any old mem..
    fsize = file_Length (szFile);
    if (fsize == -1) return NULL;	
    if (fsize > par_FILESIZE) fsize = par_FILESIZE;
    par_Index = fopen (szFile, "rb");
    if (par_Index == NULL) return NULL;	// open failed
    par_Ptr = (BYTE FAR_ *) my_malloc (fsize + 32);
    if (par_Ptr == NULL) return NULL;
    par_FileSize = fread (par_Ptr, 1,(size_t) fsize,par_Index);
    if (par_Ptr == NULL) return NULL;
    par_Pos = 0;
    fclose (par_Index);
    return par_Ptr;		// Ret ptr to mem with file-data..
}

char * par_GetCurrentPtr ()
{
    if (par_Ptr == NULL) return "";
    return (char *) par_Ptr + par_Pos;
}

  // Scan until char found in param file..
BOOL par_ScanChar (BYTE scanchr)
{
	BYTE cchr;
	do {
	  if (par_Pos >= par_FileSize) return FALSE;	// EOF error..
	  cchr = par_Ptr [par_Pos];
	  par_Pos ++;
	} while (cchr != scanchr);
	return TRUE;
}

  // Scan white-space in param file..
BOOL par_ScanSpace ()
{
	BYTE cchr;
	do {
	  if (par_Pos >= par_FileSize) return FALSE;	// EOF error..
	  cchr = par_Ptr [par_Pos];
	  if (cchr == '/' && par_Ptr [par_Pos+1] == '/') {  //Skip comment
	    if (par_ScanChar (CHR_LF) == FALSE) return FALSE;	// EOF..
	    continue;
	  }
	  if (cchr != CHR_CR && cchr != CHR_LF && cchr != 32 && cchr != CHR_TAB) return TRUE;
	  par_Pos ++;
	} while (1);
}

  // Read a long variable..
int par_ReadLong (long *cvar)
{
	BYTE cchr;
	if (par_ScanSpace () == FALSE) return FALSE;	// EOF..
	cchr = par_Ptr [par_Pos];
	if (isdigit (cchr) == 0 && cchr != '-') return FALSE;
	*cvar = str_2val ((char *) par_Ptr + par_Pos,10,10,NULL);
	do {
	  par_Pos ++;
	} while (isdigit (par_Ptr [par_Pos]));
	if (par_Ptr [par_Pos] == ',') par_Pos ++;	// Skip if following comma
	if (par_Ptr [par_Pos] == '}') return PAR_EOB;		// End.Of.Block
	return TRUE;
}

int par_ReadShort (short *cvar)
{
	long lvar;
	short cret;
	cret = par_ReadLong (&lvar);
	*cvar = (short) lvar;
	return cret;
}

int par_ReadByte (BYTE *cvar)
{
	long lvar;
	short cret;
	cret = par_ReadLong (&lvar);
	*cvar = (BYTE) lvar;
	return cret;
}

int par_ReadShorts (short *cvar, short nshort)
{
	long lvar;
	short cret;
	while (nshort) {
	  cret = par_ReadLong (&lvar);
	  if (cret == FALSE) return cret;
	  *cvar = (short) lvar;
	  if (cret != TRUE) return cret;
	  cvar ++;
	  nshort --;
	}
	return TRUE;
}

  // Read a string from par file, copy chars to (szStr)..
  // Len stored in (slen) INC null term,
  //  comma delimited, ignore '//' rems.. Quotes optional.
  // ret 0=error, 1=ok,2='}' block ends..

int par_ReadStr (char *szStr, long smax, long *pSlen)
{
      BYTE cchr,lastchr;
      long cpos;
      BOOL quotes = FALSE;
      cpos = 0;
      if (pSlen) *pSlen = 0;
      while (1) {
        if (par_ScanSpace () == FALSE) return FALSE;	// EOF..
        lastchr = par_Ptr [par_Pos];
        if (lastchr == CHR_QUOTE) {
          par_Pos ++;	// Skip quote..
	  while (1) {
	    szStr [cpos] = 0;
	    if (par_Pos >= par_FileSize) return FALSE;	// EOF error..
	    if (cpos >= smax-1) return FALSE;	// String too long
	    cchr = par_Ptr [par_Pos];
	    if (cchr < 32) break;
	    if (cchr == CHR_QUOTE) {	// Closing quote?
	      par_Pos ++;
	      if (par_ScanSpace () == FALSE) return FALSE;	// EOF..
	      cchr = par_Ptr [par_Pos];
	      if (cchr == '+' && par_Ptr [par_Pos + 1] == CHR_QUOTE) {  // +"...
	        par_Pos +=2;
	        continue;
	      }
	      break;
	    }
	    szStr [cpos] = cchr;
	    cpos ++; 
	    par_Pos ++;
	  }
	  if (cpos) cpos = (long) str_convC (szStr,szStr,smax);
	   // Series of dec/hex/bin numbers in form [#w:1234,2134,..]..
	} else if (lastchr == '[') {
	  long cval;
	  short nchar;
	  short cvar;
	  short dbase = 10;	// Default base 10
	  short dsize = 2;	// Default short words..
	  short i[] = {10,16,2};
	  par_Pos ++;	// Skip '['
	  while (1) {
	    if (par_ScanSpace () == FALSE) return FALSE;	// Scan wht spc..
	    cvar = str_inchr ("#$%",par_Ptr [par_Pos]);	// dec,hex,bin..
	    if (cvar >= 0) {	// Change of base size #b: #w: #l: #t:
	      par_Pos ++;
	      dsize = str_inchr ("bwtl",par_Ptr [par_Pos]) +1;	// byte,word,triple,long..
	      if (dsize < 1) return FALSE;
	      par_Pos ++;
	      if (par_Ptr [par_Pos] != ':') return FALSE;
	      par_Pos ++;
	      dbase = i [cvar];	// Convert to real base:10,16,2..
	      if (par_ScanSpace () == FALSE) return FALSE;	// scan wht spc..
	    }
	    if (par_Ptr [par_Pos] == 39) {	// Asc digit in form 'X
	      cval = par_Ptr [par_Pos + 1];
	      nchar = 2;
	    } else {
              cval = str_2val ((char *) par_Ptr + par_Pos,dbase,32,&nchar);	// Conv to DECIMAL..
	    }
	    memcpy (szStr + cpos,&cval,dsize);
	    cpos += dsize;
	    par_Pos += nchar;
	    if (par_ScanSpace () == FALSE) return FALSE;
	    if (par_Ptr [par_Pos] == ']') {	// End of block..
	      par_Pos ++;
	      if (par_ScanSpace () == FALSE) return FALSE;
	      if (par_Ptr [par_Pos] == '+' && par_Ptr [par_Pos + 1] == '[') {  // +[...
	        par_Pos +=2;
		continue;
		//goto newblk;
	      }
	      break;
	    }
	    if (par_Ptr [par_Pos] != ',') return FALSE;		// , must seperate fields..
	    par_Pos ++;
	  }
	} else {	// Unquoted string..
	  while (1) {
	    szStr [cpos] = 0;
	    if (par_Pos >= par_FileSize) return FALSE;	// EOF error..
	    if (cpos >= smax-1) return FALSE;	// String too long
	    cchr = par_Ptr [par_Pos];
	    if (cchr < 32) break;
	    if (cchr == '}' || cchr == ',') break;
	    szStr [cpos] = cchr;
	    cpos ++; 
	    par_Pos ++;
	  }
	}
	if (pSlen) *pSlen += cpos;	// Return len of string..
	szStr += cpos; cpos = 0;
	if (par_ScanSpace () == FALSE) return FALSE;	// EOF..
        cchr = par_Ptr [par_Pos];
	if (cchr == '}') return 2;		// End.Of.Block
	if (cchr == ',') break;
	if (cchr != '+') return FALSE;		// Error..
        par_Pos ++;
      }
      par_Pos ++;
      return TRUE;
}

  // Find a block (szBlock) in param file
BOOL par_GotoBlock (char *szBlock, short blockID)
{
	BYTE cchr;
	short cvar;
	par_Pos = 0;
	while (1) {		// Scan file in mem for matching block..
	  if (par_ScanSpace () == FALSE) return FALSE;	// EOF..
	  cchr = par_Ptr [par_Pos];
	  if (cchr == '/') {	// Remark - til end of line..
	    if (par_ScanChar (CHR_LF) == FALSE) return FALSE;	// EOF..
	    continue;
	  }
	  if (cchr == '!' || cchr == 0) return FALSE;
	  cvar = strlen (szBlock);
	  if (memcmp (par_Ptr + par_Pos, szBlock, cvar) == 0) {	// String match!
	    par_Pos += cvar;
	    if (par_ReadShort (&cvar) == FALSE) {
	      cvar = 0;
	      if (par_Ptr [par_Pos] != '{') return FALSE;
	    }
	    if (cvar == blockID) {	// Found a matching block!
	      if (par_ScanChar ('{') == FALSE) return FALSE;	// EOF..
	      return TRUE;
	    }
	  } 
	  if (par_ScanChar ('}') == FALSE) return FALSE;	// EOF..
	  continue;
	} 
}

  // Read strings from param file..
BOOL par_ReadStrings (char *szFile, char *szBlock, short blockID, char *szOptions, short *nopts, short *olen, short maxsize)
{
	BOOL cret;
        void *pret;
		// Open input set.DEF file	
	*nopts = 0;
	*olen = 0;
	pret = par_Open (szFile);
	if (pret == NULL) return FALSE;
	cret = par_GotoBlock (szBlock,blockID);
	if (cret == FALSE) goto ErrRet;
	  
	do {
	  cret = par_ReadStr (szOptions + *olen,(long) maxsize - *olen - 2,NULL);
	  if (cret == FALSE) goto ErrRet;
	  *olen += strlen (szOptions + *olen) + 1;
	  (*nopts) ++;
	} while (cret == TRUE);
	par_Close ();
	szOptions [*olen] = 0;
	(*olen) ++;
	szOptions [*olen] = 0;
	(*olen) ++;
	return TRUE;
ErrRet:
	par_Close ();
	return FALSE;
}
  
