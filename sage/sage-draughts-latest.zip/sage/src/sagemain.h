// Header for SAGEMAIN.C

//******************************************************** DEFINES *****
//  NOTE One of these PRE_PROCESSOR entries is needed in compiler setup..
// _POLYCHESS defined if using Poly-chess engine..
// _SAGE defined if using Sage-Draughts engine..

#define FINALVER 0	// Set for final version
#if NDEBUG
 #define Debug 0
#else
 #define Debug 1
#endif

#define CLOCKTYPE 1	// Specifies time-keeping method and adjustment
#define UseIntroBMP 1	// Enable Special hi-res intro screen bmp

#if _SAGE
 #define VARBOARDSIZE 1
 #define USEDB 0		// Enables/Disables Database functions
 #define FlagFIXEDBRD 0		// Fixes board window border non-stretchable.
 #define FlagALTLAYOUT 1

 #define DiskProt 0
 #define PROT_ENABLED 0	// 1999 protection scheme..

 #define SHARE_ 0
 #define STD_   1
 #define FULL_  2
 #if PROT_ENABLED
	// Examine data returned from protection routines, set mode accordingly..
  #define VER_   (prodat.isOK == FALSE ?  SHARE_ : ((prodat.Serial & CHK_NOTPRO)? STD_ : FULL_)) 
 #else    // No serial number protection, just set an appropiate version
   #define VER_   FULL_	// Set to appropiate ver
 #endif
 
 #define AUTOTEST 1	// Enable auto-test self play mode..
 #define FullVer 0	// Set for Full version, 0 for limited ver.(no EPD)
 #define USEECO 1	// Use ECO codes in DBase..
 #define ECOSTR 0	// Enable full ECO descriptive string
 #define SERNO 0		// Use serial numbers..
 #define UseResign 0	// Enable comp-resign mode
 #define ENDGAMEDB 1	// Use End game databases
#endif

#define REMOVEONLY 1		// Force protect to use remove-only media..
#define HackTest 0		// Hacks first level protect to check 2nd..

#define FILENAME_SIZE 256

	// CDROM Protection defines..

#define ProtectOn 0		// Enable protection (=1 CDROM)
#define RANDOMBLOCKS 1		// Makes prot choose real RND blocks..

#if FINALVER
 #define Debug 0
 #define HackTest 0
 #define RANDOMBLOCKS 0
 #define UseResign 1
 #define ProtectOn 1
 #define MINPROTSIZE 799999L	// Minimum size of protection file (in256byte blocks)
 #define ABSPROTSIZE 800000L	// Absolute size of protection file (x256byte)
				// (0=no abscheck, 5600=1.4Mb,800000=200mb
#else 
 #if ProtectOn			// 1.44 flop protection..
  #define MINPROTSIZE 5599L	// Minimum size of protection file (in256byte blocks)
  #define ABSPROTSIZE 5600L	// Absolute size of protection file (x256byte)
			// (0=no abscheck, 5600=1.4Mb,800000=200mb
 #else
  #define MINPROTSIZE 0L	// Minimum size of protection file (in256byte blocks)
  #define ABSPROTSIZE 0L	// Absolute size of protection file (x256byte)
 #endif
#endif

#if _DEBUG
  #define MYINLINE 		// Dummy-do nothing..
#else
  #define MYINLINE 		// inline function..
#endif

//--------------------------------------------------------------------
// FUNCTION PROTOTYPE DECLARATIONS..
// 

void TutorRun (long);
void TutorInit (void);
void TutorEnd (void);
void TutorCLR (void);

void ModSysMenu (HWND);
void InitBoxPaint (HWND);
void GetMainInfo (void);
void StopThinking (void);
void SetMousePos (UINT, LPARAM);
void gputat (short, short);
void MoveBox (char);
void InitEngine (void);
void NewGame (short);
void eng2brd (void); void brd2eng (void);
void ResetMenu (void);
void MenuFlags (void);
void ShowSearch (short);
void SearchBox ();
void qDrawBoard (void);
void SelectSet (short);
short my2cg (short);
short cg2my (short);
void MakeMove (short);
void syncfly (void);
void CreateBoardGraphics (void);
void SetSqrCol (void);
void FastMakeMove (void);
void objon (void); 
void ShowUserMove (void);
void ThinkProcess (void);
void InitThink (short);
void DrawBoard (void);
void StepMove (short);
void SoundIt (void);
void BeepSnd (void);
void TimerOn (void);
void TimerOff (void);
short islegalengine (short,short,short);
void StopAutoPlay (void);
void PrintClock (short);
void MenuGraying (void);
short buildstatus (void);
void levSetString (void);
void ImpNewSet (short);
void SetDefault (short);
void ShowBookMoves (void);
void WrtBookMove (short);
void DoMessage (char *);
void fprintc (short);
void PrintSearch (short);
void PrintFlush (short);
void NextAnal (short);
short NextEPD (short);
char * GameStatusText(void);
void PrintEval (BYTE, BYTE);
void EPDPrintEval (short, short);
void PrintBestLine (short,short);
void mlaUpdate (int);
void UpdateSearch (BYTE);
void GetClkDC (void);
void ProcessFloatingWindows (short);
void docmdkey (short);
void MakeBookStr (void);
void RedrawAllWindows (void);
void Fill3d (HDC, short, short, short, short, short);
short ReadPieceOpt (void);
void PickupPiece (short);
short DropPiece (void);
void MoveAPiece (WPARAM);
short DoHumanMove (short, short,short);
void KillPiece (void);
short ReadDIB (char *);
void ResetPopDlg (short);
void EndPopDlg (void);
UINT qRealizePalette (HDC);
void TextCol (BYTE,BYTE);
void SetCountdownStr (void);
void RedrawAWindow (short);
void SetPiecePtrs (void);
void NewBoard (short);
short ExecMove (BYTE far *, short);
short Exec1Move (short , short , short , short);
void ReadECOFile (short);
void SetHash (BYTE);
void ReadProInt (char *, short *, short);
short DoYesNo (char *);
void BufReset (void);
void EndProg (short);
void CheckProtect (void);
BOOL ServeAutoTest (short);
void SetRGBFper (short,short,short,short,short,short);
void CalcMetrics (HDC, short *, short *);
void Move2Str (char *, short , BYTE );
void FASTCALL mlaInit (short nlist);
short LoadGame (char *);
void SaveGame (short, char *);

COLORREF ExtraRGB(short);

LRESULT ServiceEditBook (HWND, UINT, WPARAM, LPARAM );
LRESULT ServiceSetup (HWND, UINT, WPARAM, LPARAM);

LRESULT CALLBACK PopDlgProc (HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK ChildBoxProc (HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK WndProc (HWND,UINT,WPARAM,LPARAM);

LRESULT CALLBACK TutorBoxProc (HWND,UINT,WPARAM,LPARAM);

//--------------------------------------------------------------------
// Various MACROS and STRUCTURE definitions
//
	// Text string defines..
	
#define STabout			Strings[0]
#define STinitdialog 		Strings[1]
#define STin 			Strings[2]
#define STallin 		Strings[3]
#define STexceededtime 		Strings[4]
#define STpiecesa 		Strings[5]
#define SThistoricanal		Strings[6]
#define STanalysis 		Strings[7]
#define STsearching 		Strings[8]
#define STdepth 		Strings[9]
#define STscore			Strings[10]
#define STwait 			Strings[11]
#define STbookstyle		Strings[12]
#define SThashdepth		Strings[13]
#define STshortlook	   	Strings[14]
#define STpawnvalue		Strings[15]
#define STknightvalue		Strings[16]
#define STbishopvalue		Strings[17]
#define STrookvalue		Strings[18]
#define STqueenvalue		Strings[19]
#define STcontempt		Strings[20]
#define SToperatortime		Strings[21]
#define STwhitetime		Strings[22]
#define STblacktime		Strings[23]
#define STall			Strings[24]
#define STmatein		Strings[25]
#define STfixeddepth		Strings[26]
#define STuserlevel		Strings[27]
#define STeasylevel		Strings[28]
#define STmovesin		Strings[29]
#define STwhitefirstcontrol	Strings[30]
#define STwhiteothercontrols	Strings[31]
#define STblackfirstcontrol	Strings[32]
#define STblackothercontrols	Strings[33]
#define STfilename		Strings[34]
#define STillegalposition	Strings[35]
#define STendgamedb		Strings[36]
#define STtoomanypieces		Strings[37]
#define STpawnonillegalsquares	Strings[38]
#define STbookstrength		Strings[39]
#define STanaly2comment		Strings[40]
#define STqueen			Strings[41]
#define STrook			Strings[42]
#define STbishop		Strings[43]
#define STknight		Strings[44]
#define STnomatefound		Strings[45]
#define STcontinue		Strings[46]
#define STnewgame		Strings[47]
#define STreset			Strings[48]
#define STEillegalfilename	Strings[49]
#define STEfilenotfound		Strings[50]
#define STEinvalidfile		Strings[51]
#define STEdiskerror		Strings[52]
#define STEdiskfull		Strings[53]
#define STEprintererror		Strings[54]
#define STEerror		Strings[55]
#define STEdatabaseerror	Strings[56]
#define STEgamenotsaved		Strings[57]
#define STEgamenotloaded	Strings[58]
#define STEnoredirection	Strings[59]
#define STEbooknotsaved		Strings[60]
#define STEbooknotloaded	Strings[61]
#define STEbooknotmerged	Strings[62]
#define STEdatabasenotopened	Strings[63]
#define STEprintingaborted	Strings[64]
#define STEuserbooknotchanged	Strings[65]
#define STEnomainopeningbook	Strings[66]
#define STresign		Strings[67]
#define STserialno		Strings[68]
#define SThash			Strings[69]
#define STsquarecolour		Strings[70]
#define STaddlinetouserbook	Strings[71]
#define STedituserbook		Strings[72]
#define STdelete		Strings[73]
#define STbsym			Strings[74]
#define STorder			Strings[75]
#define STfileexistsoverwrite	Strings[76]
#define STwhitemoves		Strings[77]
#define STblackmoves		Strings[78]
#define STload			Strings[79]
#define STgotomove		Strings[80]
#define STgoto			Strings[81]
#define STpermove		Strings[82]
#define STplayer		Strings[83]
#define STgenius		Strings[84]
#define STend			Strings[85]
#define SThome			Strings[86]
#define STpgup			Strings[87]
#define STpgdn			Strings[88]
#define STbook			Strings[89]
#define STmat			Strings[90]
#define STgameover		Strings[91]
#define STstalemate		Strings[92]
#define STdraw3rep		Strings[93]
#define STdraw50move		Strings[94]
#define STdrawmaterial		Strings[95]
#define STadjustclock		Strings[96]
#define SThours			Strings[97]
#define STmins			Strings[98]
#define STsecs			Strings[99]
#define STselectpieces		Strings[100]
#define STpieceset		Strings[101]
#define STok			Strings[102]
#define STcancel		Strings[103]
#define STdefault		Strings[104]
#define SToptsquarestyles	Strings[105]
#define STsquarestyles		Strings[106]
#define STcontrast		Strings[107]
#define STpatterncontrast	Strings[108]
#define STsquaresize		Strings[109]
#define STred			Strings[110]
#define STgreen			Strings[111]
#define STblue			Strings[112]
#define STdarksquarecontrast	Strings[113]
#define SToptbookstyle		Strings[114]
#define SToptplaystyle		Strings[115]
#define SToptplaylevels		Strings[116]
#define STplayleveltype		Strings[117]
#define STsettimepermove	Strings[118]
#define STsettimepergame	Strings[119]
#define STuse256colors		Strings[120]
#define STeditbrdbuttons	Strings[121]
#define STeditbookbuttons	Strings[122]
#define STinfinite		Strings[123]
#define SToptcolourpresets	Strings[124]
#define STopeningecocode	Strings[125]
#define STtextcolour		Strings[126]
#define STflags			Strings[127]
#define STboxcolour		Strings[128]
#define STsetcolours		Strings[129]
#define STdarksqrcolour		Strings[130]
#define STlightsqrcolour	Strings[131]
#define SToutputto		Strings[132]
#define STprint			Strings[133]
#define STprinterfont		Strings[134]
#define STfile			Strings[135]
#define SToptgraphictypes	Strings[136]
#define STpiecegraphics		Strings[137]
#define STanalysegame		Strings[138]
#define SToptanalsides		Strings[139]
#define STtxtfilter		Strings[140]
#define STepdfilter		Strings[141]
#define STgamfilter		Strings[142]
#define STbokfilter		Strings[143]
#define STcbffilter		Strings[144]
#define STimportepdline		Strings[145]
#define STclock			Strings[146]
#define STmoves			Strings[147]
#define STsavechanges		Strings[148]
#define STselectamovefirst	Strings[149]
#define STsearchinformation	Strings[150]
#define STfloatboard		Strings[151]
#define STextrasearchinformation Strings[152]
#define STfullanalysis		Strings[153]
#define STshowbookmoves		Strings[154]
#define STclockdisplay		Strings[155]
#define STmovebox		Strings[156]
#define STspare2		Strings[157]
#define STfloatingwindows	Strings[158]
#define STfigurinenotation	Strings[159]
#define STlongnotation		Strings[160]
#define STledclock		Strings[161]
#define STspare 		Strings[162]
#define STnumbering		Strings[163]
#define STselectamove		Strings[164]
#define STboard			Strings[165]
#define STrealignwindows	Strings[166]
#define STdbgamebuttons		Strings[167]
#define STdbviewbuttons		Strings[168]
#define STsearchfortext		Strings[169]
#define STslidepieces		Strings[170]
#define STplay			Strings[171]
#define STcannotinitialise	Strings[172]
#define STtimeup		Strings[173]
#define STnewsure		Strings[174]
#define STenterhash		Strings[175]
#define STprogramnamefor	Strings[176]
#define STinsertorig	 	Strings[177]
#define STwhiteplayer	 	Strings[178]
#define STblackplayer	 	Strings[179]
#define STvenue		 	Strings[180]
#define STyear		 	Strings[181]
#define STecocode	 	Strings[182]
#define STwhiteelo	 	Strings[183]
#define STblackelo	 	Strings[184]
#define SToptresult	 	Strings[185]
#define STpdnfilter	 	Strings[186]
#define STimportpdngame	 	Strings[187]
#define STautolearn	 	Strings[188]
#define STwwwsite	 	Strings[189]

#if VARBOARDSIZE
 #define STboardx		Strings[370]
 #define STboardy		Strings[371]
#endif

#if _SAGE
 #define SToptgametype		Strings[372]
 #define SToptgamerules		Strings[373]
 #define STchkwhitestarts	Strings[374]
 #define STchkinvertnum		Strings[375]
 #define STchkchessnot		Strings[376]
 #define STchkinvertplay	Strings[377]
 #define STchklighta1		Strings[378]
 #define STmenperside		Strings[379]
 #define STstrengthmove		Strings[380]
 #define STalterbookstrength	Strings[381]
 #define STstartfrompos		Strings[382]
 #define SThms			Strings[383]
 #define SToptnew		Strings[384]
 #define STopteng		Strings[385]
 #define STcomment		Strings[386]
 #define STdlgeng		Strings[387]
 #define STdlgauto		Strings[388]
 #define STauto			Strings[389]
 #define STbrowse  		Strings[401]
 #define STtransfer		Strings[402]
 #define STdbfields		Strings[403]
 #define STescabort		Strings[404]
 #define STpdnerror		Strings[405]

#endif


// SEE IDM_ codes 209.. in CHESSxx.H for menu-string indexes..

#define STruntutor	 	Strings[IDM_RUNTUTOR]
#define STexittutor	 	Strings[IDM_EXITTUTOR]

extern char STprogramname [];
extern char STprogramname2 [];
extern char szWavFile [];
  
typedef union {
 short w;
 struct {
  char lb; char hb;
 } b;
} Splitword;	// Access to hi/lo bytes via. name.b.hib/lob. WORD=name.w

//#define ELONG long extern far 		// External long word
//#define EINT short extern far 		// Ext signed short
//#define EBYTE unsigned char extern far	// Ext unsigned short
//#define ECHAR signed char extern far 
//#define PINT short far *
//#define PBYTE unsigned char far *
//#define EFUNC short far 		// External function
//typedef unsigned char BYTE;
//typedef unsigned long ULONG;

#define BUFFSIZE    180              // buffer size

typedef struct {	// Split std move word into src/dest..
  BYTE from; BYTE to;
} SPLITMOVE;

#if _WIN32
 #define MYSEG 
 #define MYSEG2
 #define MYSEG3
 #define MYSEG4
#else 
	// Extra segment allocations..
 #define MYSEG __far __based(__segname("MYSEG")) 
	// Extra segment allocations..
 #define MYSEG2 __far __based(__segname("MYSEG2")) 
 #define MYSEG3 __far __based(__segname("MYSEG3")) 
 #define MYSEG4 __far __based(__segname("MYSEG4")) 
#endif

	// Convert Genius board pos-move to long short
_inline long tutMOVE2VAR (short Mfr,short Mto,short Mpr)
{
	return (0x01000000 | (Mfr) | ((long) (Mto) << 8) | ((long) (Mpr) << 16));
}
	// Decode moves/promo from variable
#define tutMOVESRC(Var) ((Var) & 0xff)
#define tutMOVEDEST(Var) (((Var) >> 8) & 0xff)
#define tutMOVEPROM(Var) (((Var) >> 16) & 15)

#define _WM_RUNTUTOR WM_USER + 1244

extern BUTTONINFO iBtn;		// General purpose buttons..


#define NO_FILE HFILE_ERROR	// Flag for no-file opened.

	// Index of RGB vals in ExtraPal..
#define PALBACK 10	// Index for Background color
#define PALBOX 11	// Index for Box window color
#define PALTXT 12	// Index for Text color
#define PALLOTXT 14	// Index for Lo lite txt colour
#define PALUBOX 15	// Index for User list box colour
#define PALHITXT 16	// Index for hi lite txt colour (red)
#define PALVATXT 17	// Index for variation txt colour (blue)
#define PALANIMLT 18	// Index for Animation lite sqr
#define PALANIMDK 19	// Animation - dark sqr
#define PALANIMTX 20	// Animation - txt
#define PALANIMBX 21	// Animation - Box
	// Non-palette SYSTEM pal colours..
#define PALGREY 25	// For system grey colour
#define PALDKGREY 26	// For system colour
#define PALBLACK 27	// For system colour
#define PALWHITE 28	// For system colour
#define PALRED 29	// For system red colour

#define PALLEAVE 0xff	// No colour index - leave alone..

#if _SAGE
#else

 #define Wpawn 1
 #define Wknight 2
 #define Wbishop 3
 #define Wrook 4
 #define Wqueen 5
 #define Wking 6

 #define Bpawn -1
 #define Bknight -2
 #define Bbishop -3
 #define Brook -4
 #define Bqueen -5
 #define Bking -6

#endif

#define Posof(Xpos,Ypos) ((Xpos) - 1 + ((Ypos) - 1) * eng.boardx)

#define Setboard(Xpos,Ypos,Cpiece) \
	frBoard [Posof(Xpos,Ypos)] = Cpiece;

#define Getboard(Xpos,Ypos) \
	frBoard [Posof(Xpos,Ypos)]

#define Xposof(Cpos) (((Cpos) % eng.boardx) + 1)
#define Yposof(Cpos) (((Cpos) / eng.boardx) + 1)
	
	// Set up mouse cursor shapes..
#define SetWaitCursor {hCurCursor = hWaitCursor; SetCursor (hCurCursor);}
#define SetNormCursor {hCurCursor = hNormCursor; SetCursor (hCurCursor);}

#if FlagALTLAYOUT
 #define ALY static
#else
 #define ALY auto
#endif

//--------------------------------------------------------------------
// Various EXTERN variable-declarations
//

extern char *Strings[440];	// Array of pointers to multi-language strings..

extern char *STtutor;
extern long tutPauseTime;		// End time of Input-pause

#define tutNBLOCKS 4		// Max No of tool-bar blocks..
#define tutSTRSIZE 256		// Size of strings..
extern HOTKEYINFO tutButtons [tutNBLOCKS + 1];
extern BYTE MYSEG tutBUTSTR [(tutNBLOCKS + 1) * tutSTRSIZE];

extern RECT rct,urct,winrct;	// Temp rectangle for window-size read
extern RECT absmain;		// main client area pos in abs desktop wnd coords
extern RECT mainrct;		// Current rect for main window..

extern MINMAXINFO FAR *lpmmi;	// ptr to min/max info structure, for minimize..

extern short tutAllowMove ;		// Allows input of move-request
extern short MoveSpeed;			// Sliding move-speed (% of normal..)

extern HMENU hMenu;		// Handle on main menu..
extern HFONT hFont;		// Handle of main window font..

extern short retv;		// General AX param ret from EXT_ functions
extern char EPDboard [];	// Current EPD board
extern BYTE EPDside;		// 0=White to move, 1=black to move,
extern BYTE EPDcastle;		// Castle status, format as (ep_castle_status)
extern char EPDpieces [];	// Lookup table to find piece vals

extern PAINTSTRUCT ps;		// Gen purpose WM_PAINT struct
extern short MoveSpeed;		// Sliding move-speed (% of normal..)
extern short nVduX;
extern short nVduY;		// Screen size in pixels..
extern short nVduColor;		// no of color-planes for screen..
extern short WndBorderx;		// Window border sizes..
extern short WndBordery;

extern short chrx,chry;		// Cur Screen Font sizes 
extern char szPath [BUFFSIZE];	// buffer for file path+name
extern char szTitle [100];	// buffer for file name (no path)
extern short mousex,mousey;
extern short SysChrx,SysChry;	// Default system font size
extern short frBoard [];		// Playing area 
extern short debugflag;

extern short MainMode;		// Cur mode, edit/comp/game..
	// MainMode mode constants..
#define BIT_POPDLG 16		// Mask bit for popdlg..
//#define DoingDBGameView 17		// Pop-up dialog mode..
#define DoingDBGameSelect 16	// Pop-up dialog mode..
#define DoingEditBook 8		// Editing user book..
#define DoingSetup 4		// Setting up board..
#define DoingGame 1		// Normal game mode

#define ThinkHint 2	// 2 player mode
#define ThinkOpp 1
#define ThinkComp -1
#define ThinkNone 0
extern short ThinkMode;	// Cur Comp thinking mode, comp/game/none
extern int movenumbering;   // Flag for move numbering

extern HDC hUsrDC;	// HDC for User list box
extern HDC hTinyDC;	// HDC for Tiny piece set..

#define NAWND 7		// No of Active normal windows.

#define W_MAIN 0		// Window-Index definitions..
#define W_SCH 1
#define W_MOV 2
#define W_CLK 3
#define W_BOK 4
#define W_BRD 5
#define W_TUT 6
#define W_POP 7
#define W_DLG 8

#define hMainWnd hAWnd[W_MAIN]	// Handle on main prog window
#define hSchWnd  hAWnd[W_SCH]	// Handle on search box window (NULL== none)
#define hMovWnd  hAWnd[W_MOV]	// Handle on move box window (NULL== none)
#define hClkWnd  hAWnd[W_CLK]	// Handle on Clock window (NULL== none)
#define hBokWnd  hAWnd[W_BOK]	// Handle on Book window (NULL== none)
#define hBrdWnd  hAWnd[W_BRD]	// Handle on Board window (NULL== none)
#define hTutWnd  hAWnd[W_TUT]	// Handle on tutor window
#define hPopWnd  hAWnd[W_POP]	// Handle on popup custom window
#define hDlgWnd  hAWnd[W_DLG]	// Handle on dialog window

#define hMainDC hADC[W_MAIN]	// The Handle Device Context (HDC) of main window 
#define hSchDC  hADC[W_SCH]	// The HDC of the Search box (NULL== none)
#define hMovDC  hADC[W_MOV]	// The HDC of the move box (NULL== none)
#define hClkDC  hADC[W_CLK]	// The HDC for the clock
#define hBokDC  hADC[W_BOK]	// The HDC for the book
#define hBrdDC  hADC[W_BRD]	// The HDC for the board
#define hTutDC  hADC[W_TUT]	// HDC for tutor window
#define hPopDC  hADC[W_POP]	// HDC for popup custom dialog
#define hDlgDC  hADC[W_DLG]	// HDC of current windows dialog

extern HCURSOR hWaitCursor;	// Handles on mouse cursors..
extern HCURSOR hCurCursor;
extern HCURSOR hNormCursor;
	// Stock pen handles
extern HPEN hNullPen;
extern HPEN hLtgreyPen;
extern HPEN hDkgreyPen;
extern HPEN hWhitePen;
extern HPEN hBlackPen;
extern HBRUSH hUBoxBrush;		// Color used for user list box
extern HBRUSH hNullBrush;
extern HBRUSH hBackBrush;		// Color used for background
extern HPALETTE hPalette;	// palette used for display 

extern BOOL DoingPopDlg;

extern OFSTRUCT ofBuf;		// Struct for open file..
extern short EndTick;	// Timer var used for when game ends in autoplay..
extern short SparePal[];	// Spare pal for animation
extern PALETTEENTRY ExtraPal [];	// Colours to add in
extern struct tm timeCalender; // Current time/date structure - set on running

//--------------------------------------------------------------------
// More funct declares, dependand on above struct declarations
//
void SaveWin (WRECT *,HWND, short );

//--------------------------------------------------------------------
//   IDM_.. defines..
// Menu-IDs - also loc of language string in Strings[] array..
//

#define IDM_SELECTED 90
#define IDM_NOACTION 91

#define IDM_ANALY2COMMENT 40
// IDM_ codes for menu functions - also used as indexes into String arrays..

#define MENU_1 209
#define IDM_COMMANDS	209
#define IDM_COMPUTE	210
#define IDM_MOVE	211
#define IDM_SETUP	212
#define IDM_HINT	213
#define IDM_GAME2CLIP	214
#define IDM_CLIP2GAME	215
#define IDM_UBOOKEDIT	216
#define IDM_UBOOKADD	217
#define IDM_NEXTBEST	218
#define IDM_TAKEBACK	219
#define IDM_TAKEBACKALL	220
#define IDM_STEPFWD	221
#define IDM_STEPFWDALL	222
#define IDM_GOTO	223
#define IDM_NEWGAME	224
#define IDM_QUIT	225
#define IDM_HASHSIZE	226
#define IDM_REFUEL      227   // ,"&Refuel",
#define IDM_CLIPLOAD    228
#define IDM_CLIPSAVE    229
#define IDM_GAMESPAWN   230
#define IDM_NEW3RND     231
#define IDM_NEW3SEL     232

#define MENU_2 239
#define IDM_LEVELS	239
#define IDM_USERLEVELS	240
#define IDM_LVINSTANT	241
#define IDM_LV2SPM	242
#define IDM_LV5SPM	243
#define IDM_LV10SPM	244
#define IDM_LV30SPM	245
#define IDM_LV60SPM	246
#define IDM_LV120SPM	247
#define IDM_LV60M1H	248
#define IDM_LV40M1H	249
#define IDM_LV60M2H	250
#define IDM_LV40M2H	251
#define IDM_LV5MPG	252
#define IDM_LV10MPG	253
#define IDM_LV30MPG	254
#define IDM_INFINITE	255
#define IDM_EASY	256
#define IDM_MATEIN	257
#define IDM_FIXEDDEPTH	258

#define R_LEVBEG 240     	// Total IDM Range for user-levels..
#define R_LEVEND 259		
#define R_QUICKBEG 241		// Range for quick levels..
#define R_QUICKEND 255

#define MENU_3 260
#define IDM_OPTIONS	260
#define IDM_SOUND	261
#define IDM_RESIGN	262
#define IDM_RANDOMPLAY	263
#define IDM_RANDOMBOOK	264
#define IDM_PERMANENT	265
#define IDM_HASH	266
#define IDM_PAWN	267
#define IDM_TIMEADJUST	268
#define IDM_MAINBOOK	269
#define IDM_USERBOOK	270
#define IDM_OTHEROPTIONS 271
                        
#define MENU_4 272
#define IDM_OPPONENTS	272
#define IDM_NORMAL	273
#define IDM_2PLAYER	274
#define IDM_COMPVCOMP	275
#define IDM_COMPVCOMPCONT 276
#define IDM_ANALYSE	277
#define IDM_PROCESSEPD	278
 
#define MENU_5 280
#define IDM_DISPLAY	280
#define IDM_INVERT	281
#define IDM_DISPLAYOPT	282
#define IDM_FONTS	283
#define IDM_ENGLISH	284
#define IDM_LANG2	285
#define IDM_LANG3	286
#define IDM_LANG4	287
#define IDM_LANG5	288
#define IDM_LANG6	289
#define IDM_LANG7	290
#define IDM_LANG8	291
#define IDM_LANG9	292
#define IDM_WINDOWS	293
#define IDM_DEFAULTLAYOUT 294
#define IDM_REARRANGELAYOUT 295
#define IDM_BOARD	296
#define IDM_MOVEBOX 	297
#define IDM_SEARCH 	298
#define IDM_CLOCK 	299
#define IDM_SHOWBOOK 	300
#define IDM_TOOLBAR	301
#define IDM_SAVEALL     302
                        
#define MENU_6 304
#define IDM_FILE	304
#define IDM_LOADGAME	305
#define IDM_SAVEGAMES	306
#define IDM_SAVEGAMEO	307
#define IDM_SETEXPORTOPT 308
#define IDM_EXPORTMSF	309
#define IDM_EXPORTPOS	310
#define IDM_RECORDGAME	311
#define IDM_RECORDGAMANAL 312
#define IDM_EXPORTUBOOK	313
#define IDM_SAVEUBOOK	314
#define IDM_LOADUBOOK	315
#define IDM_IMPORTEPD	316 
#define IDM_EXPORTEPD	317
#define IDM_IMPORTNEXTEPD 318
 
#define MENU_7 319
#define IDM_DATABASE	319
#define IDM_SELECTDATABASE 320
#define IDM_LISTGAMES	321
#define IDM_DB_SEARCH	322
#define IDM_UNUSED_XXXX	323
#define IDM_SAVEDBGAME	324
#define IDM_EDITDB	325


#define MENU_8 327
#define IDM_eHELP	327
#define IDM_HELP	328
#define IDM_ABOUT	329

#define IDM_STEPFWD10	338
#define IDM_TAKEBACK10	339
#define IDM_EXPORTOFF   340
#define IDM_EXPORTTODISK 341
#define IDM_EXPORTTOPRN 342
// unused 343 
#define IDM_RUNTUTOR    344
#define IDM_EXITTUTOR   345
#define IDM_SLIDE       346
#define IDM_EDITGAMEDET	347
#define IDM_ADDCOMMENT	348
#define IDM_PDNDISPLAY  349
#define IDM_PDNIMPORT   350
#define IDM_PDNEXPORT   351
#define IDM_PDNIMPORTNEXT 352
#define IDM_PDNIMPORTAGAIN 353
#define IDM_PDNTRANSFER 354
#define IDM_PDNNUMBERING 355
#define IDM_FIGURINES   357

#if FlagALTLAYOUT
 #define IDM_SETCLOCKS  390
 #define IDM_BOARDINC   391
 #define IDM_BOARDDEC   392
 #define IDM_BOARDINC3  393
 #define IDM_BOARDDEC3  394
 #define IDM_IMPORTBOOK	395
 #define IDM_2NDANAL    152
#endif
 #define IDM_FULLANAL 153	// Full anal string/menu function..
 #define IDM_NUMBERING 163	// Full anal string/menu function..

	// unused..
//#define IDM_EXTRASEARCH 341
//#define IDM_LONGNOTATION 342
//#define IDM_GRAPHICPIECES 343
