/* SAGE DRAUGHTS, a checkers playing program for Windows (32bit).
   Written by and Copyright Adrian Millett, 1992-2025. 
   Released as free/open software under the GNU GPL3 licence.
                                              
Take SAGE, convert to 32bit.. 12/12/97
->SAGE32C, 13.12.97
 Add in 32bit libs from Genius, G32WIO.C & G32DLG.C
->SAGE32D, 13.12.97
 Chop a few vars to make it compile & partly work..
->SAGE32E, 7.1.99
 Take latest libs from genius, make small changes for .CPP->.C
   then implement in SAGE. 
   Start work on converting to use new dlg_ routines 
   - convert easy dlgs like goto, engine-options, timeset etc.
->SAGE32F,  7.1.99
 Convert all dialog routines to new code.
 Bug in loading game from DB solved..
->SAGE32G, 18.1.99
 Imp 6 piece endgame database code, works ok..
 Imp various experimental small changes to engine.
 Bug in TermNode - only set TRUEEVAL bits at end..
->SAGE32H, 27.1.99
 dont do db6 lookup for first 80% of search.
->SAGE32I, 31.1.99
 imp manual protection..
->SAGE32J, 6.2.99
 imp new style toolbars..
->SAGE32K, 9.2.99
 imp new book window with all movs & db analysis.
->SAGE32L, 11.2.99
 Imp edit db as txt file.
 Imp display col in RGB dialog.
->SAGE32N, 
 If DB6 not avail, default DB5
->SAGE32O, 23.2.99
 Bug - screen updates when book win closed..
->SAGE32P, 23.2.99  - FINAL VERSION USED FOR SAGE5000 MAIN RELEASE..
inc # DPD hashop to 512K entries..
bug in engine when play enddb pos - search pruning func incorrect,
  often never works!
 Imp PDN book export function
 Detect col rev on search for pos..
 Experiment with engine improvements, inc fwd pruning, etc..
->SAGE32Q, 19.3.2000.
 More engine experiments,add bestmove to hash entries.
 Enable 2 player compute, even in book..
 Bug on resize brd - crashes! add GMEM_MOVEABLE to GlobalReAlloc in ReadDib()
 Experiment with various schemes to improve engine performance, ie, double hash entries, etc..
 Imp AUTOLEARNING feature.
 Imp new serial key code protection, with user name disp. 
  (Write support SERIAL.CPP prog to gen keys..)
->SAGE32R, 3.4.2000.
 Imp CLIPBOARD load/save feature
 Imp GameSpawn function.
->SAGE32S, 4.4.2000.  First SAGE6000 Beta (SEXE32S.ZIP) sent by EMAIL..
 Bug - in endgame db if uncrowned man on last row..
->SAGE32T, 20.4.2000.  First main release of SAGE6000, up onto www site.
->SAGE32U, 11.5.2000.  2nd release SAGE6000..
 Update db to use new style dialog, misc small debug/mods..
   Release SAGE7000
->SAGE32W, 28.11.01
  Imp multi engine support.
->SAGE32X, 22.07.02
 version 8.1 for alioto, correct bugs 4 ital engines, reverse color in setup
->SAGE32Z
 imp alterations to work with CakeLV
 ver 8.2 
->SAGE33A
 bug when new game for non-std games..
 ver 8.3
->SAGE33C
 bkup again
->SAGE33D
 Make it remember external engine selected when re-run..
->SAGE33E  (SAGE 9.0 release) 
->SAGE33F
 Remove copy protection. Tidy up source code a bit. Alter various texts.
->SAGE34A, 03.08.2024  (SAGE 10.0)
 Write batch file "sagemake.bat" to build from command line.
->SAGE342, 26.11.2024  
 Working ver..
->SAGE343, 27.11.2024  
 Tidy up filenames, some var names. Change text for GPL3/open source. Remove redundant stuff.
->SAGE344, 27.11.2024 
 More tidying
->SAGE345, 30.11.2024 
 rem OLD_PROT
->SAGE346, 30.11.2024  (SAGE 10.346)


IMPORTANT RUNTIME FILES:
chkdat.def (bmps), TOOL.BMP, sage.par (toolbar), scheck1.lng (language)

Make window size properly. Rebuild make, make work on cmd line VC clmak..

*/

#define PROG_VERSION  ". Version: 10.346"

#define STRICT		// strict type checking (put before #include)
#include <windows.h>	// include file for all Windows programs
#include <stdlib.h>	// RAND
			// prototype for WndProc()
#include <stdio.h> 
#include <dos.h>	// Defines union REGS, INT86,
#include <conio.h>	// _INPW 
#include <string.h>	// STRLEN 
#include <ctype.h>	// ISDIGIT 
#include <time.h>	// Mix TIME functions..

#include <commdlg.h>	// for common dialogs (print..
#include <memory.h>	// for memset() (print..
#include <shellapi.h>	// for ShellExecute
#include <mmsystem.h>	// Multimedia inc (SOUND..)
#include <direct.h>	// _getcwd
//#include <toolhelp.h>	// MEMMANINFO

#include "sageio.h"	// Generic IO code..
#include "sagewio.h"
#include "sagedlg.h"
#include "genio.h"	// Header for General IO routines..
#include "sagemain.h"	// Header with function/var prototype, & #defines..
#include "chengine.h"	// Header with info on CHECKER ENGINE..
#include "chdbase.h"	// Header with info on DataBase subroutines..

extern BOOL analy2ComFlag;	// When set, analy sent to comments..
void analy2Comment ();
void Move2Short (char *mstr, short mfrom,short mto);
void DrawNumbering (short );
void auto_Move ();
char *eng_getname (int eng);
void DlgEngOptions ();
void DlgFeatureNotImplemented ();

#define TOOLBAR 1

#if TOOLBAR  // New Win32 toolbars..

 BMPHEAD sBmp;	// Static struct with new bmp data (new toolbars etc)

 #define BMP_TOOLBAR 0   // Index for toolbar bmp
 TOOL_BAR tb_Main;
 TOOL_BUTTON tbb_Main[40] = {
 //  {IDM_GAMENEW,0,0,TOOL_STY_BUTTON},
 //  {IDM_GAMEOPEN,1,0,TOOL_STY_BUTTON},
 //  {IDM_GAMESAVE,2,0,TOOL_STY_BUTTON},
 //  {IDM_GAMEPRINT,6,0,TOOL_STY_BUTTON},
 //  {0,0,0,TOOL_STY_SEP},
 //  {IDM_SETUP,3,0,TOOL_STY_BUTTON},
 TOOL_STYLE_END};

 char szParamFile [] = "sage.par";
#endif

time_t timeSecs;	// Time in seconds since 1.1.1970. Set when prog run
struct tm timeCalender; // Current time/date structure - set on running

short debugflag = 0;
int movenumbering = 1;   // Flag for move numbering

short charx = 38;		// board square size in pixels
short chary = 38;

short WndBorderx;		// Window border sizes..
short WndBordery;
short WndTitley;		// Child Window title size..
short WndExtrax,WndExtray; // Total extra x/y size of borders,titles..
short MainTitley;		// Main  Window title size..

short minsetchr = 19;	// Minimum sqr size
short chrx,chry;		// Cur Screen Font sizes 
USHORT setscale;		// Scale for current set..
short SysChrx,SysChry;	// Default system font size
short btopy = 5;		// current top of board on vdu
short btopx = 16;
short SetBrdPos;		// Top of brd in Setup mode
short brdsizex,brdsizey;	// brd size..

short inkey,cmdkey;
short cpos,zpos;
short xpos,ypos;		// General pos 
short temp,temp2;
long templong;

short mousex,mousey,mbutton;
short lastmousex,lastmousey;	// Pos of last mouse co-ord
short mouseoffx,mouseoffy;	// Offsets for mouse help piece.
short movingpiece;		// type of Piece in motion..

short movefrom,moveto,movedir;	// Curr mv

USHORT tempx,tempy;	// Used for range checks..

short SparePal [7];	// Spare pal for animation
short nanim = 0;

short ModeVATXT = 0;	// INI-file vartxt=RGB..
short ModeHITXT = 0;	// INI-file hitxt=RGB..
short ModeUBOX = 0;	// INI-file ubox=RGB..


	// Extra ENGINE variables..
BYTE lastsm;	// Last engine search mode..
BYTE menuclock = 0x80;
short lengameall,lengameset;
MOVES far *const Phint_move = (MOVES far *) &eng.hint_move;
MOVES far *const Pmove_test = (MOVES far *) &eng.move_test;                          
MOVES far *const Pmove_info = (MOVES far *) eng.move_info;

char dummy = 0;
char resigned = 0;		// Set when comp resigned
void int_step_move (short step)	// Alt parametised step move
{
	eng.param_ax_pass = step;
	eng.param_pass = 0;		// Clr all old analysis
	ext_step_move ();
}

void int_step_move2 (short step)	// Alt parametised step move
{
	eng.param_ax_pass = step;
	eng.param_pass = 1;		// Keep old analysis
	ext_step_move ();
}

typedef struct {
  PRERGB back,box,txt,lsqr,dsqr;	// Colours of misc components..
  BYTE pieceset,scontrast,pcontrast,sqpattern;
} DEFAULTCOLORS;



		// SAGE DRAUGHTS engine - specific strings
  char STprogramname [256] = "Sage Draughts";
  #define PROG_NAME "SAGE  10"
  char STprogramname2 [] = PROG_NAME;
  #define CHSETFILE "chkdat.def"	// File for Checker-set bmp data..
  char szLASTGAMEFILE [] = "$chkdat.chk";// Last-game/settings file..
  #define LANGUAGE_FILE "SCHECKx.LNG"	// Language file..
  #define LANGUAGE_FILEPR "SCHECK%d.LNG"	// For printing msg
  #define DEFAULT_FONT "pcs12"	// Default main font..
  #define CLIPGAME "$saved.chk"
  char szIniName [] = "WSAGE.INI";	// Initialisation file name
  char szIniHead [] = "PARAMS";		// Heading within that ini file
  //char szHelpFile [] = "sage-1.hlp\0\0\0";	// help file name.,.
  char szBmpFont [] = "pcs.fon\0\0\0";		// name of bitmap font
  char szIntroBMP [] = "sagefr_.bmp";		// intro screen bmp..
  char DEFsetname [] = "check1.bmp";
  char szWavFile [] = "check1.wav\0A.Millett";		// Wave file name
	// Define 2 lots of settings - 1 for normal, 1 for 16 colours..
  DEFAULTCOLORS DCsettings [2] = {
   50,50,50,0,  75,71,80,0, 0,0,0,0, 49,67,80,0, 41,58,70,0,  1,0,10,0,
   50,50,50,0,  75,75,75,0, 0,0,0,0,  0,75,75,0,  0,50,50,0,  3,0, 9,0
  };

short retv;		// General AX param ret from EXT_ functions
short levIDMmenu;		// Linear menu play-level ref - IDM code..
short calccode = 0;	// Code back from calcmove start (force move?)

char szLevel1 [50]="";	// Level info in text form (for move box)
char szLevel2 [50]="";
char szLevel1old [sizeof (szLevel1)];	// shadow buffers..
char szLevel2old [sizeof (szLevel2)];
char szCount [50];			// String for countdown clock..
char szCountold [sizeof (szCount)];	// Shadow buffer for compare
short UseCount = 0;	// Set if countdown active..
short ExceededTime = 0;	// Set if count-clock exceeds time limit.
 // (bit0= black over, bit1=white over, bit 5=just exceeded (noise)
short LastExceed;
short ForceMove = 0;	// Set to force comp move

short cmainkey,mainkeys [560];	// Menu mainkeys..
#define Mmenuidms 100		// Max menu idms
short menuidms [Mmenuidms];	// Array (1..nidms) of Menu IDM_.. codes.
short menubits [Mmenuidms];	// Graying status bits..
  // bit0=gray when thinking, bit1=gray when not thinking
  // bit2=gray when no takeback bit3 = gray when no fwd
  // bit4=gray when no next best
short nidms;

short gfrom,gto;		// Move from/to from Getmove
short gprom,gtypemov,gtypecap;	// Other Getmove info
short gnotate;			// Notation flags

short mainbx,mainby;	// MAIN window bottom right (client area)
			// MOVE BOX variables..
short mvboxLines=0;	// No of lines for moves in move-box..
short mvboxTx;		// Move box coords top x/y mv-rec area pixels
short mvboxTy;
short mvboxBx,mvboxBy;	// Move box coords bot x/y
short mvboxBot;		// Bottom of move-display area in pixels..
short mvboxWide = -1;	// Width of move box (-1 = undef) in pixels
short mvboxLastScroll = 999; // Last pos set in scroll bar
short mvboxCurScroll = 0; // Current scroll pos (0-100%) 
			// or (-4..-1) pgup,lnup,lndn,pgdn)
short lastgamst = 1;	// If set overwrite old eng.game_status txt
#define mvboxMAXSCROLL 100	// range for mv box scroll bar

short searchtx = 9999;	// Search info box top pixels (9999=undefined)
short searchty;		
short searchbx,searchby;	// Search info box bot
short schline = 12;	// Length of search line..
const short SchIconx = 27;// Width of icon bmp in pixels
#define SchIcony 26	// Hight of icon bmp in pixels
#define ScoreWidth 9	// Chr Width of score field in searchbox
short bookchrx, bookchry;	// Pos to start book print
short bookmaxx;		// width book box in chrs
short bookcols;		// no of columns for book box
#define BOOKMOVEx 9	// width in chrs of a book move, inc space..
short sbokx,sboky;	// Pos of alt-layout book (pixels) in anal window
short sbokNmov = 7;	// Alt layout-#book moves across per line
		

char szLangFile[] = LANGUAGE_FILE;	// Language file name..
HFILE hLangFile;
char *szIn;
short nin;
short MaxLang = 2;	// No of languages (read from INI file..)

USHORT HashSize = 8;	// Size of hash table in KB..
USHORT MaxHash = 32767;	// Maximum possible hash table size..
HGLOBAL hHashMem = NULL; // Handle for Hash table memory;
char HUGE_ *ptrHash;	// ptr to start of hash table memory..
extern short schMixedFlagsVar;

	// Profile entry strings..
#define PROF_HASH "hash"		// Hash table size in K
#define PROF_DIR "dir"			// Dir Genius is installed
#define PROF_NLANG "nlang"		// no of languages
#define PROF_CLANG "curlang"		// cur def lang
#define PROF_DRV "xtl"			// CD inst drive
#define PROF_TIME "timing"		// timing constants
#define PROF_PRNEDGE "prnedge"		// flag - edges on tilburg prn
#define PROF_PRNSIZE "prnsize"		// %scaling of default prn font
#define PROF_BALIGN "bytealign"		// Flag - enable byte align win
#define PROF_VATXT "vartxt"		// var txt RGB val
#define PROF_HITXT "hitxt"		// hilite txt RGB val
#define PROF_UBOX "ubox"		// userbox RGB val
#define PROF_DBMODE "dbmode"		// Extra database mode bits..
#define PROF_MIXEDFLAGS "mixedflags"	// Mixed flags..
#define PROF_WEIGHTS "weights"		// Engine weights (bridge,doghole...)
#define PROF_DRAWREP "drawbyrep"	// # moves before draw by rep..
#define PROF_ENDDBFILE "enddbfile"	// Endgame database file
#define PROF_ENDDBBUFFER "enddbbuffer"	// Endgame database buffer
#define PROF_ENDDBTYPE "enddbtype"	// Endgame database buffer
#define PROF_ENGNAME "engname"		// Endgame database buffer


#define PROF_CLKFONT "clkfont"		// Clock font selector..
#define PROF_CLKFONTSIZE "clkfontsize"
 
char szClkFont [50] = "pcs18";
short ClkFontSize = -18;

short dbProfileMode = 0;	// Misc flags..
short PrnSize = 100;	// %scaling of default prn font
short ByteAlign = 0;	// Byte align window boundaries..
short clktime[] = {989,17,934,4};  // mix 17 at 989 millisec, 4 at 934 ms

short SerialNo = 1234;	// Program serial number.
long booksize;		// size of cur user book
short bookaltered;	// indicates if book is changed
short xedbook,yedbook;	// X/Y size of book window..

USERLISTBOX EdBook = {20,20,0,0,21,21,0L,0L,1L,NULL,NULL,NULL,9999,&hPopDC};

WRECT tmpmovwnd;		// Temporary shadow copy
WRECT popdlgwnd = {0,0,630,470}; // Popup custom dialog window
WRECT mainwnd = {0,0,640,480};	// Pos main window..


short clktxtx,clktxty;		// Pos 1st digit disp in window.. (pixels)
short clktxtx2;			// Pos 2nd digit display
short clkfullx, clkfully;		// Pos of full display 
				// - if clkfully > clkbottom, none..
short clkchrx = 12, clkchry = 18;	// size of clock chars
short clkoffx = 3;
short clkoffy = 3;		// Offset for centering LED digits
short clkdispy = 6;		// Add to height of clk display
short clksizex,clksizey;		// Size of clock digit area
short clkledx,clkledy;		// Position of clock LED
short clkledx2;			// Pos of 2nd clock LED..
short clkmode;			// =1 for LED, =0 for full info,=2 for both
short clkright,clkbottom;
short CurClkFont = 0;

#define CLK_LEDsize 11		// Height/width of LED bmp in HOT.BMP
#define CLK_LEDtopy 37		// Y pos start in bmp..

LOGFONT clklogf;		// LED font for clock
HFONT hClkFont = NULL;

short whplayer = 0,blplayer = 1;	// 0 = human, 1 = computer
short editx = -1;		// Move input box pos.
short edity;

	// TIMING variables..
	
long LastWhTime = 0;	// Last w/b time displayed
long LastBlTime = 0;
short EndTick = 0;	// Timer var used for when game ends in autoplay..
short timefix = 0;	// counter used to keep clock accurate
clock_t twaste;		// Time lost to other processing..
clock_t temptime;	// Time lost to other processing..

clock_t timebeg;	// Time search started..
clock_t timefin;	
clock_t timenow;	// current CLOCK time
clock_t timelast; // Used by CLOCK() funct.See CLOCKS_PER_SEC

short timeslice;		// Time in clock() units (millisecs) for each think
#define sboxslice CLOCKS_PER_SEC / 2		// Search box update
clock_t sboxlast;	// Time of last update

short hdcmode = 0;	// Current mode, for ALLON/ALLOFF

short MainMode = DoingGame;	// Cur mode, edit/comp/game..

short ThinkMode = ThinkNone;	// Cur Comp thinking mode, comp/game/none

#define Mboard 350
short frBoard [Mboard+4];		// Playing area 
char UserMoveIn [20] = ">";
short nsqrs,csqr,cnum;

short scratchx,scratchy;		// loc Temp work area for overlays.. 
short scratchx1,scratchy1;	// Usable piece for moving
short scratchx2,scratchy2;	// Saved background from screen
short scratchx3,scratchy3;	// BIG Scratch area for smooth move..
short scratchx4,scratchy4;	// Scratch for PUTAT
short sourcex,sourcey;		// Temp loc of source bmp
//short maskx,masky;		// Loc of MASKs
short finechrx,finechry;		// Temp size of curr FINE sprites
short BlsqLocx,BlsqLocy;		// Loc of Blk sqr BMP in hPieceDC
short WhsqLocx,WhsqLocy;

short MoveSpeed = 100;		// Sliding move-speed (% of normal..)

short settype;			// Set type - 1= black back, 2= colored
short setchrx,setchry;		// Size of pieces in bitmap..
short thissetno = -1;		// Actual set ref # in CHSET.DEF
short workx,worky;
short tinyset;			// alt Tiny piece set..

					// Square colour vars
					// NOTE col below %, NOT 0-255..
//COLORREF rgbLSquare = RGB (40,65,80);	// % Current color for light sqr
//COLORREF rgbDSquare = RGB (36,54,63);	// % Current color for dark sqr..

//short scontrast = 20;		// % contrast dif wh/bl sqrs (0=use rgbDSquare)
//short pcontrast = 12;		// % contrast dif for patterns
//short SqPattern = 0;		// Pattern style in sqr
//short CurPreset = 1;		// Current preset (0=user)

short outlineset = 0;		// Set once 1st outline defined..
short maxsetx,maxsety;

short nVduX = 640;
short nVduY = 480;		// Screen size in pixels..
short nVduColor = 4;			// no of color-planes for screen..

	// New Variables

char *bookstr = szTemp + 1024;	// Temp for book display..

#define SIZEszInitDir 200
char szInitDir [SIZEszInitDir + 5];
char szPath [BUFFSIZE];		// buffer for file path+name
char szTitle [100];		// buffer for file name (no path)
char szExportInfo [60];		// Temp area for Export info menu str..
short InitDrive = 3;		// Working drive:1=a,2=b,c=3..
char *szWorkDir = "C:\\";
short WorkDrive = 3;
static long NodeCount;			// Terminal node count..

#define OLD_PROTECT 0		// Old copy protection code

clock_t RunTutorTime = 0L;	// Enable execution of tutor..

	// EPD vars..
char szEPDfile [BUFFSIZE + 2] = "demo.dpd";	// Current EPD file being processed
short CurEPD = 0;			// Current pos being analysed in EPD..

gamINITBRD EPD;		// EPD Board position, side to move, castling..

PAINTSTRUCT ps;

HDC hUsrDC = NULL;	// HDC for User list box
HDC hTinyDC = NULL;	// HDC for Tiny piece set..

short WMclosing = 0;	// Bits of this Flag indicates win creation
HGDIOBJ hold;
	// Now some Pen handles 
HPEN hOldpen = NULL;
HPEN hLightPen = NULL;
HPEN hDarkPen = NULL;
HPEN hLtgreyPen = NULL;
HPEN hDkgreyPen = NULL;
	// Stock pen handles
HPEN hWhitePen = NULL;
HPEN hBlackPen = NULL;
HPEN hNullPen = NULL;
	// Brush handles..
HBRUSH hBackBrush=NULL;		// Color used for background
HBRUSH hOldBrush = NULL;
HBRUSH hBoxBrush = NULL;		// Color used for move & search box
HBRUSH hUBoxBrush=NULL;		// Color used for user list box
HBRUSH hTempBrush = NULL;
HBRUSH hNullBrush = NULL;
HBRUSH hClockBrush = NULL;		// Clock background
	// Stock Brush handles
HBRUSH hWhiteBrush = NULL;
HBRUSH hGrayBrush = NULL;	// Some stock brushes
HBRUSH hBlackBrush = NULL;
	// Instance handles
HANDLE hCInstance;
	// Cursor handles
HCURSOR hNormCursor = NULL;
HCURSOR hWaitCursor = NULL;	// Handles on mouse cursors..
HCURSOR hEmptyCursor = NULL;
HCURSOR hCurCursor = NULL;
	// Bitmap handles
HBITMAP hHotBmp = NULL;		// Handle for Hot-keys bmp
HBITMAP hOldHotBmp = NULL;	// Old one for DC
HBITMAP hTinyBmp = NULL;	// Handle for tiny piece bmp
HBITMAP hOldTinyBmp = NULL;	// Old one for DC
	// Font handles
HFONT hFont = NULL;		// Handle of main window font..
HFONT hSysFont = NULL;		// Handle of orig system fonts on loading..
HFONT hAnsiFont = NULL;		// STOCK-FONT - ansi font..
HFONT hSysVarFont = NULL;
short ansichrx,ansichry;		// size ansi font..
TEXTMETRIC txtmet;	// Font info struct
HMENU hMenu = NULL;	// Handle on main menu..
HMENU hSubMenu [10];	// Sub-menu handles, used when creating menu..

short movemode = 0;	// Flag (=1) indicates piece being held and moved..
short PieceWndIndex = W_BRD;	// Index of window that mving piece is on..
short clickedsq;

	// File spool-out vars..
HFILE hOutFile = NO_FILE;	// File handle used for out-spool
HFILE hInFile = NO_FILE;	// File used for temp in during prn..
short FileMode = 0;		// Set if spooling to hOutFile..
				// 0=off, 1=just move, 2=full anal..4-just spool
#define MFileBuf 128		// Size of spool buffer
BYTE FileBuf [MFileBuf + 5];	
short iFileBuf = 0;		// Current ptr in buffer.

	// PRINTER VARS & ROUTINES..

short PageLen = 0;	// Page length for printer (0=prn to file..)
short cPrnLine;		// Current line in page being printed 
			// (when >= PageLen, print-page activates)
short selgtype = 0;	// Prn-graphics-Selection type..
short lastselg = -1;	// When new type selected, set defaults..
long prnscale = 100;	// %Amount to scale prn-font height by..
HFONT hPrnFont = NULL;	// Cur printer font
HFONT hOldPrnFont;	// Old printer font
LOGFONT lfPrint;	// Struct for printer font info..
LOGFONT lfPrnNorm = {	// Define sensible default for normal printing
  -14,0,0,0,400,0,0,0,0,3,2,1,49,"Courier New"};
  
 LOGFONT lfTilNorm = {	// Define sensible default for tilburg font..
  -45,0,0,0,400,0,0,0,0,3,2,1,2,"CheckerPCS"};
 LOGFONT lfGenNorm = {	// Define sensible default for normal printing
  -14,0,0,0,400,0,0,0,0,3,2,1,49,"Courier New"};

#define PRN_FILENAME "$prn$.tmp"	// Filename of temp print spool
PSTR szDocName = "Genius Document";    // document name
short pagex, pagey;	// page dimensions, in pixels
short prlpix, prlpiy;	// pixels per inch on printing surface
short prtx, prty;		// Width of cells..
PRINTDLG prnd;		// for PrintDlg()
DOCINFO di;		// for StartDoc()
HCURSOR hCursor, hOldCursor; // cursor handles
TEXTMETRIC cprn;	// Info on print fonts..
short PrnEdges = 1;	// Flag - enable print-edge on board printout..(INI read)

short prnx,prny;		// Char size..
short pmaxx,pmaxy;	// Max chars per page
short hmovefrom = -1, hmoveto;	/* Human move; -1= non made yet */
short sqrhit ;
		// Hot key vars
short chotkey;

short xoff [18];		// x/y offsets into current bitmap
short yoff [18];


	// Preset Offset for CHECJ2.BMP  
short xoff2 [] = {0,3 ,43,84,123,164,204,0,0,2,43,83,124,164,204,0,0,0};  
short yoff2 [] = {0,50,50,50, 50, 50, 50,0,0,3, 3, 3,  5,  3,  3,0,0,0};

short pxpos,pypos;

static short idTimer = 0;	// Stat for interupt timer..

short gomove;	// Var for GOTO MOVE..
#define SIZEStrSpace 10000

char StrSpace [SIZEStrSpace + 100];	// Alloc some local space for them..

char *Strings[440];	// Array of pointers to multi-eng.language strings..

	//- Various obscure numbers to use as constants..
#define Q_CHKOK 0x4099
#define Q_FAIL1 0x51a0
#define Q_FAIL2 0xa177

USHORT QuickChkResult = 0;
USHORT *pQuickChkResult = &QuickChkResult;

	// Graphical piece codes (see STpiecesa for alphabetic)
char STpiecesg [] =  "\xa7\xa4\xa5\xa6\xa3\xa2 ";	// 
char STpiecetil [] = "\xb9\xbb\xba\xbc\xbd\xbe ";	// tilburg
char *STpieces;		// Ptr to current set.
char *STpiecesvdu;	// Ptr to set in use by screen.
char *STpiecesprn = STpiecesg;	// Ptr to set in use by printer.


char SToptpieceset [205] = "Genius\0\0";
char STspace20 [] = "                    ";


		/* WINDOWS PROGRAM */

char *szMainWinClass = "EBDPLOOHWW";
#define Maxx 640	// Window size
#define Maxy 480

void dialog_End ()
{
    InvalidateRect (NULL,NULL,TRUE);
}

int prog_Init (HINSTANCE hInstance)
{
	  // Init any dialog vars/resources (DBUx/y,etc)
    dlg_Reset ();
    dlgs.fnInit = NULL; //dialog_Init; 
    dlgs.fnEnd = dialog_End; 
    dlgs.fnShowPalette = NULL; 
    dlgs.hInst = hInstance;
    dlgs.phFont = NULL; //&hFont;
    dlgs.phPal = NULL; //&(gen.dBmp.hPal);
    dlgs.phParent = &hMainWnd;		// Ptr to parent window handle for dialogs..
    dlgs.MaxFilename = 256;		// Nominal max file-name/path size allowed.. 
    dlg_CalcFontSize ();        // A kludge to compute the dialog font size..
    ini_Init ("wsage.ini", "PARAMS");
    
    return TRUE;
}

/////////////////////////////////////////////////////////////////////
// WinMain() -- program entry point                                //
/////////////////////////////////////////////////////////////////////

int PASCAL WinMain (HINSTANCE hInstance,    // which program are we?
		   HINSTANCE hPrevInst,    // is there another one?
	           LPSTR lpCmdLine,        // command line arguments
	           int nCmdShow)           // window size (icon, etc)
{
   HWND hWnd;
   MSG msg;			// message from GetMessage
   WNDCLASS wndclass;		// window class structure
   int cret;
   
   cret = prog_Init (hInstance);
   if (cret == FALSE) return 0;   // Abort prog..
   if (!hPrevInst) {		// if this is first such window
      ReadProInt (PROF_BALIGN,&ByteAlign,1);	// Flag-Byte align windows..
      wndclass.style         = CS_HREDRAW | CS_VREDRAW 
      				| CS_DBLCLKS
				| CS_OWNDC; 		// Permanant HDC
      if (ByteAlign) wndclass.style |= CS_BYTEALIGNWINDOW;
					     // WndProc address
      wndclass.lpfnWndProc   = (WNDPROC) WndProc;
      wndclass.cbClsExtra    = 0;		// no extra class data
      wndclass.cbWndExtra    = 0;		// no extra window data
      wndclass.hInstance     = hInstance;	// which program?
					     // stock arrow cursor
      wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
					     // stock blank icon
      wndclass.hIcon         = LoadIcon(hInstance,"OurIcon"); // from resource
      wndclass.lpszMenuName  = NULL;	// No resource menu (szMainWinClass)
					     // no background (use own rect)
      wndclass.hbrBackground = GetStockObject(NULL_BRUSH);
      wndclass.lpszClassName = szMainWinClass; // window class name

      RegisterClass(&wndclass); // register the class
      
		// Now change attributes for Other Child-box Window
      wndclass.style         = CS_HREDRAW | CS_VREDRAW 
				| CS_DBLCLKS;
      if (ByteAlign) wndclass.style |= CS_BYTEALIGNWINDOW;
      wndclass.lpfnWndProc   = (WNDPROC) ChildBoxProc;
      wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
      wndclass.lpszClassName = "ChildClass"; // window class name
      RegisterClass (&wndclass); 	// register the CHILD-BOX window class
      
      wndclass.lpfnWndProc   = (WNDPROC) PopDlgProc;
      wndclass.lpszClassName = "PopDlgClass"; // window class name
      RegisterClass (&wndclass); 	// register the CHILD-BOX window class
     /*
		// Now change attributes for User list box window
      wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
      wndclass.lpfnWndProc   = (WNDPROC) UserBoxProc;
      wndclass.lpszClassName = "UserBoxClass"; // window class name
      RegisterClass (&wndclass); 	// register the search window class
     */
   }  // end if
   
   hWnd = hMainWnd = CreateWindow (szMainWinClass,       // window class name
		       STprogramname,
		       WS_CLIPCHILDREN | WS_MAXIMIZE | WS_OVERLAPPEDWINDOW,  // style
		       0,        // default x position
		       0,        // default y position
		       Maxx,        // default width
		       Maxy,        // default height
		       NULL,                 // parent's handle
		       NULL,                 // menu handle
	               hInstance,            // which program?
		       NULL);                // no init data

   ShowWindow (hWnd, SW_SHOWMAXIMIZED /*nCmdShow*/ );      // make window visible
   
    while (1) {		//  MAIN WINDOWS LOOP.. Process commands..
      while (PeekMessage (&msg,NULL,0,0,PM_REMOVE)) {
        if (msg.message == WM_QUIT) {
          goto ExitMain;
        } else {
	  TranslateMessage(&msg);       // convert keystrokes
          DispatchMessage(&msg);        // call window procedure
        }
      }
      if (ThinkMode == ThinkNone) {
        WaitMessage ();
      } else {
        ThinkProcess ();		// Process computer thinking..
      }
		// Slack time here, do thinking..
    }
ExitMain:
    return msg.wParam;        // return value from PostQuitMessage()
}  // end WinMain

void ThinkProcess (void)		// Process computer thinking..
{
      if (ThinkMode == ThinkNone) return;
      if (ThinkMode == ThinkOpp || ThinkMode == ThinkHint) {	// Continue thinking..
	do {
	  if (eng.game_status == 0) {	// Only if game not ended..
	    if (calccode == 0) {
	      eng.param_ax_pass = movemode & 1;  // When =1, faster processing
	      retv = ext_calcmove_continue ();
	    } else {
	      calccode = 0;
	      retv = calccode;
	    }
	  }
	  timenow = clock ();	// Cont think for timeslice millisec
	} while (retv == 0 && (dbProfileMode & 8) == 0 && timenow - timelast < timeslice && movemode == 0);
	timelast = timenow;
	if (retv == 0) {		// Still thinking..
	  if (eng.anal_flag && timenow - sboxlast >= sboxslice) {
	    sboxlast = timenow;
	    UpdateSearch (0);
	    eng.anal_flag = 0;
	  }
	}
	return;
      }		// End think in opp time.
      if (ThinkMode == ThinkComp) {	// Continue normal thinking..
	
	  do {
	    if (eng.game_status == 0) {// Only if game not ended..
	      if (calccode == 0) {
	          eng.param_ax_pass = 0;
	        retv = ext_calcmove_continue ();
		#if Debug
		  NodeCount ++;	// Terminal node count..
		#endif
	      } else {
	        retv = calccode;
	        calccode = 0;
	      }
	    }
	    timenow = clock ();// Cont think for timeslice millisec
	  } while (retv == 0 && timenow - timelast < timeslice);
	
	timelast = timenow;
	if (retv == 0 && ForceMove) {	// CTRL-M hit, force a move..
	  ForceMove = 0;
	  StopAutoPlay ();	// If comp v comp, back to normal
	  if (eng.game_status == 0) {		// Only if game not ended..
	    ext_calcmove_stop ();
	  }
	  retv = 1;
	}
        
	if (retv == 0) {		// Still thinking..
	  if (lastsm != eng.search_mode) {
	    SearchBox ();
	  } else {
	    if (eng.anal_flag && timenow - sboxlast >= sboxslice) {
	      sboxlast = timenow;
	      UpdateSearch (0);
	      eng.anal_flag = 0;
	    }
	  }
	} else {		// Thinking is over.. DO COMP MOVE..
	
	  if (retv == -2) {		// cannot solve Mate, exit..
	    SoundIt ();
	    HaltClock
	    DoMessage (STnomatefound);
	    eng.play_mode = PlayNormal;
	    RestoreClock
	    InitThink (ThinkOpp);
	    goto ThinkEnd;	// Done..
	  }

	  mlaUpdate (AN_EXEC);

	  		// ANALYSE GAME //
	  if (IsPlayAnalMode) {	// Analysis mode
	    NextAnal (1);		// start next analysis (printing last)
	    if (!FlagFwdOk) {		// No more moves, stop anal..
	      SoundIt ();
	      eng.play_mode = PlayNormal;
	      InitThink (ThinkNone);		
	    }
	    goto ThinkEnd;	// Done..
	  }
	  if (eng.oper_time) {	// Add any OPERATOR TIME to computer clock..
	    if (eng.move_number & 1) {	// Black move..
	      eng.black_time += (long) eng.oper_time;
	    } else {
	      eng.white_time += (long) eng.oper_time;
	    }
	  }
		// DO THE COMP MOVE //	  
	  BeepSnd ();
	  if (0) {
	    ExecMove (Manaly->moves, 9);	// Execute & show move in Main Anal line
          } else {	// Recursively exec computer move in main line, inc multi jumps..
	    GAMESTORE *pMov = (GAMESTORE *) Manaly->moves;
	    int cmov = 0;
	    do {   // Exec & slide multijumps 1 move at a time..
	      int cret;
	      GAMESTORE tmov[2];
	      tmov[0] = pMov[cmov];
	      tmov[1].src = tmov[1].dest = 0xff;
	      cret = ExecMove ((BYTE *) tmov, 9);	// Execute & show move in Main Anal line
	      if (cret) break;
	      cmov ++;
	      if (pMov[cmov].src != pMov[cmov-1].dest) break;
	    } while (cmov < 12);
	  }
	  PrintSearch (FileMode);	// Print analysis to prn/file if FileMode..
	  	// Wipe any old comment
	  comAddBlock (gamCOMMENTS + eng.move_number,"",comAUTOLEN);
	  analy2Comment ();
          SetWindowText (hMovWnd, eng_getname (1));
	  if (eng.play_mode == PlayEPD) {	// EPD mode
	    NextEPD (1);		// Load & anal next EPD (printing last)
	    goto ThinkEnd;	// Done..
	  }
	  if (eng.play_mode == PlayAuto) {
	    InitThink (ThinkComp);		// Start think of next move..
	    if (eng.game_status) {		// game end, Comp v Comp off.
	      SoundIt ();
	      eng.play_mode = PlayNormal;
	      InitThink (ThinkNone);		
	    }
	  } else if (eng.play_mode == PlayCont) {
	   #if AUTOTEST
	    auto_Move ();    // Prepare auto-test before next move..
	   #endif
	    #if AUTOOLDTEST
	      ServeAutoTest (1);	// Set up parameters for side to move
	    #endif  // AUTOOLDTEST
	    InitThink (ThinkComp);	// Start think of next move..
	    if (eng.game_status) {		// End of game, restart another..
	      SoundIt ();
	      InitThink (ThinkOpp);	// No thinking mode..
	      EndTick = 10;		// Timer till next game starts..
					// (Allowing time to backtrack, etc)	      
	    }
	  } else {		// PlayNormal - human reply..
	    #if UseResign
	     if (FlagResign && FlagResigned == 0) {	// Not yet resigned..
	     		// losing by >10 pawns? (bit7=sign,lo bits=#pawn)
	      if ((BYTE) Manaly->scorelo > 0x8a && (BYTE) Manaly->scorelo < 0xf8) {
	        SetResigned		// Set res flag, so dont do it twice
	  	SearchBox ();		// update search box
	        if (DoYesNo (STresign) == IDNO) {
	          NewGame (1);
	      	  RedrawAllWindows ();	// Redraw brd & boxes
	      	  return;
	        }
	      }
	     }
	    #endif
	    UserMoveIn [0] = '>'; UserMoveIn [1] = 0;
	    InitThink (ThinkOpp);		// think in opp time?
	  }
	  if (eng.game_status) {	// game over, big sound..
	    SoundIt ();
	  }
ThinkEnd:	  
	  MoveBox (0);		// update move list
	  SearchBox ();	// update search box
	  return;
        }		// END OF COMP-MOVE
      }
}

 //-------------------------------------------------------------------------
 // Engine names: ""= Sage engine..


char *eng_getname (int eng)
{
    if (eng == 1) {
      if (*dll_szEng1 == 0) {
        return STprogramname2;
      } else {
        return dll_szEngName1;
      }
    } else {
      if (*dll_szEng2 == 0) {
        return STprogramname2;
      } else {
        return dll_szEngName2;
      }
    }
}

void InitThink (short imode)
{
	if (imode == ThinkOpp && FlagPermanent == 0) {	// Perm brain off.
	  imode = ThinkNone;
	}
	if (imode == ThinkOpp && eng.play_mode == PlayTwo) {  // Force hint mode in 2player
	  imode = ThinkHint;
	}
	if (imode == ThinkOpp && schIsMultiJump) {
	  imode = ThinkNone;
	}
	ThinkMode = imode;
	timebeg = clock ();
	timeslice = CLOCKS_PER_SEC / 20;	// Between refreshes
	UserMoveIn [0] = '>'; UserMoveIn [1] = 0;
	MainMode = DoingGame;
	ClockOn
	if (ThinkMode == ThinkComp) {
	  UserMoveIn [0] = 0;  
	  timeslice = CLOCKS_PER_SEC / 20;
	  if (dbProfileMode & 8) timeslice = CLOCKS_PER_SEC / 20; // Fine
	  //MainMode = DoingComp;
	  eng.param_ax_pass = -1;
	  TimerOff (); TimerOn ();		// Start new time!
	} else if (ThinkMode == ThinkOpp) {
	  eng.param_ax_pass = 1;
	} else if (ThinkMode == ThinkHint) {	// 'hint' 2 player mode
	  eng.param_ax_pass = 2;
	} else {		// Null think mode (ThinkNone)
	  eng.param_ax_pass = 0;
	}
	if (eng.game_status) {		// If game ended..
	  ThinkMode = ThinkNone;	// Disable thinking
	  eng.param_ax_pass = 0;
	}
	timelast = timebeg - timeslice / 2;
// EXT_CALCMOVE_START If it returns with ax=1 the  program has found a move
//If it returns with ax=1,-1 or -2 then srvc_calcmove_continue must not be called
//If it returns with ax=0 then the client should perform whatever input/output
//is required and then call either srvc_calcmove_continue or srvc_calcmove_stop.
//Call with ax=ffh,1,2,0. calculate move, anticipate move, hint search, no search
	calccode = ext_calcmove_start ();
	#if Debug
	  NodeCount = 0L;	// Terminal node count..
	#endif
	ForceMove = 0;		// Reset ready for CTRL-M
	ShowUserMove ();	// Redraw user move txt..
	if (AtNewStart) {	// At beginning of game, so turn clock off.
	  ClockOff
	}
	EndTick = 0;		// Clr any auto play timer..
}

void StopThinking (void)	// Stop the engine thinking..
{
	if (ThinkMode == ThinkNone) return;
	if (eng.game_status == 0) {
	  ext_calcmove_stop ();
	}
	ThinkMode = ThinkNone;
	calccode = 0;		// Ensure no force move code..
}

void ReThink (void)	// Just restart thinking in current mode..
{
	short tcl = eng.clock_flag & 0x80;
	InitThink (ThinkMode);
	eng.clock_flag = (eng.clock_flag & 0x7f) | tcl;	// Put back as before..
}

void NextBest (void)		// Init process for next best move..
{
	if (ThinkMode == ThinkComp) return;
	if (!FlagNextBOk) return;	// Next best not possible
	int_step_move (-1);	// Step back one move
	FastMakeMove ();	// Update screen
	timebeg = clock ();
	timeslice = CLOCKS_PER_SEC / 20;	// Between refreshes
	timelast = timebeg - timeslice / 2;
	TimerOff (); TimerOn ();	// Start new time!
	eng.param_ax_pass = 0;	// Ok, so do next best..
	retv = ext_next_best ();	// Now just like calcmove_start
	eng.clock_flag |= 0x80;
	UserMoveIn [0] = 0;  	// Kill human mv
	ForceMove = 0;		// Reset ready for CTRL-M
	ShowUserMove ();	// Redraw move list box
	//MainMode = DoingComp;
	ThinkMode = ThinkComp;
// ext_next_best()
//Before calling this bits 0 and 1 of _step_flag must be examined to determine
//if next best is possible, and a move must have been taken back. Else crash!
//When called the program will start to calculate a next best move.
//see the notes on srvc_calcmove_start for return values
}

void StopAutoPlay (void)	// If comp v comp, back to normal
{
	  if (eng.play_mode != PlayTwo) {
	    eng.play_mode = PlayNormal;
	  }
          eng_touse = 1;
}


 //-------------------------------------------------------------------------
 //
 // AUTO-TEST tournement mode routines..
 //

 
#if AUTOTEST			// Auto-test mode..

int auto_mode = 0;	// 0=off,1=side1 moves, 2=swap sizes..
char auto_szOpen [512] = "";
char auto_szSave [512] = "autosave.pdn";
char auto_szRes [256];
int auto_ngame;
int auto_nplay = 0;
int auto_ndraw,auto_nwin1,auto_nwin2;
int auto_ndb;  // # game sin db if randomise..
int auto_pick = 0;
BYTE auto_score [1024];
int auto_nmoves;
int auto_termdb = TRUE;
int auto_maxmoves = 300;
int auto_maxtime = 999999;
long auto_gamestart = 0;

void auto_headers (BYTE result)
{
    gamDETAILS gamDet;
    memset (&gamDet,0,sizeof(gamDETAILS));
    gamDet.h.result = result;
    gamDet.h.eco = 0;
    gamDet.h.year = timeCalender.tm_year + 1900;
    if (auto_mode == 2) {
      strcpy (gamDet.play1,eng_getname (1));
      strcpy (gamDet.play2,eng_getname (2));
    } else {
      strcpy (gamDet.play2,eng_getname (1));
      strcpy (gamDet.play1,eng_getname (2));
    }
    sprintf (auto_szRes,STauto ,
	  auto_ngame,eng_getname (1),auto_nwin1,auto_ndraw,eng_getname (2),auto_nwin2,
	  timeCalender.tm_mday,timeCalender.tm_mon+1,timeCalender.tm_year + 1900);
    strcpy (gamDet.venue,auto_szRes);
    gamSetDetails (&gamDet,1);	// Set game details,,
}

int auto_New ()
{
    int cret;
    if (auto_mode < 1) return FALSE;  // Not in auto mode..
    NewGame (0);		// Start new game..
    auto_nmoves = 0;
    auto_ngame ++;
    RedrawAllWindows ();
    if (auto_nplay && auto_ngame > auto_nplay) goto stopauto;  // played all games, match over
    if (auto_szOpen[0]) {  //Load next game from opening database?
      if (auto_nplay) {  // # specified, play n games rand choice..
	if ((auto_ngame & 1) == 1) {  // Pick new game every odd # :1,3,5.. (swap sides same game for 2,4,6..)
	  auto_pick = (rand () % auto_ndb) + 1;
	}
        cret = pdnImport (auto_szOpen,auto_pick);
      } else {     // Seq play all games from db..
        cret = pdnImport (auto_szOpen,(auto_ngame+1)/2);
      }
      if (cret <= 0) goto stopauto;   // EOF/read fail, end autoplay mode..
    }
    auto_headers (3);
    auto_gamestart = time (NULL);
    return TRUE;

stopauto:
    StopAutoPlay ();
    auto_mode = 0;
    return FALSE;
}


void auto_Start ()
{
    int cret,hitbut;
    char szTxt1[512];
    char szTxt2[512];
auto_again:
    IDM2String (IDM_COMPVCOMPCONT);
    cret = dlg_Init (MenuStr,-1,-1,290,200,1);
    if (cret == FALSE) return ;

    dlg_Define (dBUTTON, STdlgauto, IDD_BUTTONS + 1,  30,20,70,14,0);  
    sprintf (szTxt1,str_GetNth(STdlgauto,1),eng_getname(1),eng_getname(2));
    dlg_DefText (110,20,szTxt1);

    dlg_Define (dBUTTON, STdlgauto, IDD_BUTTONS + 2,  30,40,70,14,0);  
    sprintf (szTxt1,str_GetNth(STdlgauto,2),auto_szOpen);
    dlg_DefText (110,40,szTxt1);

    dlg_Define (dBUTTON, STdlgauto, IDD_BUTTONS + 3,  30,60,70,14,0);  
    sprintf (szTxt2,str_GetNth(STdlgauto,3),auto_szSave);
    dlg_DefText (110,60,szTxt2);

    dlg_DefSpinTxt (30,90,6,auto_nplay,0,999,1,0,str_GetNth(STdlgauto,4),170);
    dlg_DefSpinTxt (30,110,6,auto_maxmoves,0,999,1,0,str_GetNth(STdlgauto,6),170);
    dlg_DefSpinTxt (30,130,7,auto_maxtime,0,999999,1,0,str_GetNth(STdlgauto,7),170);
    dlg_DefCheck (30, 150, 200, str_GetNth(STdlgauto,5), auto_termdb);

    dlg_DefOKCancel (40,20,STok,NULL,40);
    hitbut = dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
    if (hitbut  == IDCANCEL) {
      return ;
    }
    auto_termdb = ReadCheck ();
    auto_maxtime = dlg_ReadSpin ();
    auto_maxmoves = dlg_ReadSpin ();
    auto_nplay = dlg_ReadSpin ();
    if (hitbut == IDD_BUTTONS + 1) {
      DlgEngOptions ();
      goto auto_again;
    }
    if (hitbut == IDD_BUTTONS + 2) {
      cret = dlg_Open (auto_szOpen, STpdnfilter, szTxt1,0);
      if (cret == FALSE) auto_szOpen[0] = 0;
      goto auto_again;
    }
    if (hitbut == IDD_BUTTONS + 3) {
      cret = dlg_Open (auto_szSave, STpdnfilter, szTxt2,DLG_COM_CREATEPROMPT);
      if (cret == FALSE) auto_szSave[0] = 0;
      goto auto_again;
    }

    auto_gamestart = time (NULL);
    auto_mode = 1;
    auto_ndb = auto_ngame = auto_ndraw = auto_nwin1 = auto_nwin2 = 0;
    if (auto_szOpen[0] && auto_nplay) {   // Randomise choice..
      auto_ndb = pdn_ngames (auto_szOpen);   // Count games in db..
    }
    srand ((unsigned) time(NULL));
    cret = auto_New ();
    if (cret == FALSE) return;
    eng.play_mode = PlayCont;   // Start auto-play mode..
    InitThink (ThinkComp);
}

void auto_Move ()
{
    #define ENG_1WIN 1
    #define ENG_2WIN 2
    #define ENG_DRAW 3
    int score;
    int res = 0;  
    int cret;
    if (auto_mode < 1) return;
    eng_touse =  1 + ((eng.move_number ^ auto_mode) & 1);
    SetWindowText (hMovWnd, eng_getname (eng_touse));
    // eng.disp_mvlist [0].score == 0

    auto_score [auto_nmoves] = score = eng.disp_mvlist [0].score;
    auto_nmoves ++; 
    if (auto_nmoves > 1000) auto_nmoves = 1000;
    if (eng.game_status) {   // Game ends..
      if (eng.game_status >= 0x20) {   
        res = ENG_DRAW;
      } else {
        if (eng_touse == 2) {	// Side to move..
          res = ENG_1WIN;
        } else {
          res = ENG_2WIN;
        }
      }
    } else {
      if (eng.move_number > auto_maxmoves) res = ENG_DRAW;
      if (time(NULL) - auto_gamestart > auto_maxtime) res = ENG_DRAW;
      if (auto_termdb) {
        if (drawbyrep > 4) res = ENG_DRAW;
        if (eng.disp_nmoves > 1 && auto_nmoves > 50) {
          if (score == auto_score [auto_nmoves-1]) 
	  if (score == 0) res = ENG_DRAW;
	  if (score == 1) res = (auto_mode == 1) ? ENG_1WIN : ENG_2WIN;
	  if (score == 2) res = (auto_mode == 1) ? ENG_2WIN : ENG_1WIN;
	}
      }
    }

    if (res) {
      BYTE result;  // draw
      if (res == ENG_DRAW) auto_ndraw ++;
      if (res == ENG_1WIN) auto_nwin1 ++;
      if (res == ENG_2WIN) auto_nwin2 ++;
	  	// Send result to anal window header..
      result = 1;  // PDN header draw
      if (res == ENG_1WIN) result = 0;
      if (res == ENG_2WIN) result = 2;
      if (auto_mode == 2) {
	if (res == ENG_1WIN) result = 2;
	if (res == ENG_2WIN) result = 0;
      }
      auto_headers (result);
      SetWindowText (hSchWnd,auto_szRes);

      auto_mode = 3 - auto_mode;   // 1= eng1=start, 2=eng2=start
      if (auto_szSave[0]) {	// Save game to "autotest.pdn"..
        open_ClassifyCurGame ();
        pdnExport (auto_szSave);
      }
      cret = auto_New ();
      if (cret == FALSE) return;
      if (auto_ngame > 2 && VER_ != FULL_) {
        StopAutoPlay ();
        DlgFeatureNotImplemented (); return;
      }
    }
}

#endif

 //-------------------------------------------------------------------------
 //
 // CLOCK update/maintanence routines..
 //
 
char clkdbuf [2];	// clock asc buffer - 1 digit
#define SIZEclkbuf 20
char clkbuf [SIZEclkbuf];	// clock asc buffer: h:mm:ss,h:mm:ss..
char clkbufold [SIZEclkbuf];	// clock asc buffer: h:mm:ss,h:mm:ss..

#define SIZEfullclk 28		// Full clk chr size
#define SIZEhalfclk (SIZEfullclk >> 1)
char fullclk [SIZEfullclk + 4] = "00:00 0:00:00  00:00 0:00:00";
char fullclkold [sizeof (fullclk)];
long tbdif,twdif;	// Dif between last/this time..


#define NO_COLOR (COLORREF) -1L
	// Selective text-print - FAST printing only updated bits..
	// cmode bit 0 set to force print all anyway..
	// cmode bit 1 set do not update shadow-buffer (also prn all..)
	// clen = -1 calc str len, -2 = auto center
	// ccolor = color to print, -1=no colour change
void UpdateTextOut (HDC hDC, short xpos, short ypos, 
	char *ibuf, char *oldbuf,	// Strings - to prn, old str..
	short clen, short cchrx, 		// length, char-width
	short cmode, COLORREF ccolor)	// mode & txt color
{
	short cpos;		// current char pos..
	short stpos;		// start pos..
	if (clen < 0) {		// -1= calc len null str, -2=auto-center str
	  cpos = strlen (ibuf);
	  if (clen == -2) xpos -= ((cpos * cchrx) >> 1);
	  clen = cpos;
	}
	if (clen == 0) return;	// no string to print..
	if (cmode & 3) {		// Simple flush all..
	  if (ccolor != NO_COLOR) {
	    SetTextColor (hWDC, ccolor);	// Set text colour
	  }
	  TextOut (hDC, xpos, ypos, ibuf,clen);
		// Save old string for next time..
	  if (!(cmode & 2) && oldbuf != NULL) {
	    for (cpos = 0; cpos < clen; cpos ++) {
	      oldbuf [cpos] = ibuf [cpos];
	    }
	  }
	} else {		// Selective print update..
	  cpos = 0;
	  do {
		// While buffers match, scan until mis-match..
	    while (cpos < clen && ibuf [cpos] == oldbuf [cpos]) {
	      cpos ++;
	    }
	    if (cpos >= clen) break;
	    stpos = cpos;	// save start print position..
	    if (!(cmode & 2)) oldbuf [cpos] = ibuf [cpos];	// save update..
	    cpos ++;
		// Now scan mismatch, until match found..
	    while (cpos < clen && ibuf [cpos] != oldbuf [cpos]) {
	      if (!(cmode & 2)) oldbuf [cpos] = ibuf [cpos];	// save update..
	      cpos ++;
	    }
		// Now print mis-matching section..
	    if (ccolor != NO_COLOR) {
	      SetTextColor (hWDC, ccolor);	// Set text colour
	      ccolor = (COLORREF) -1L;			// Ensure only do once..
	    }
	    TextOut (hDC, xpos + stpos * cchrx, ypos, ibuf + stpos, cpos - stpos);
	    cpos ++;
	  } while (cpos < clen); // Loop to try to find another section
	}
}

COLORREF colw,colb,colgr;	// temp colours for white/black times..

  // Print the main clock.. (cmode set for complete repaint)
  // if cmode==0, just updates selectivly..	
void PrintClock (short cmode)
{
	  	// Human(x,y),greyed(x,y),Calc(x,y),grayed(x,y)..
	static short playicons [] = {61,69,96,69,210,5,132,69};
	const short ixlen = 31, iylen = 28;	// Size of icons..
	const BYTE flag2clocks = 1;		// Double-clock display..
	//short curx,cury;
	char *cstr;
	//if (FlagClock == 0) return;
				// Output to move box..
	if (hMovWnd == NULL) return;
	GetMyDC (W_MOV, 0);
	if (cmode == 2) {	// Draw graphical clock face, calc pos....
	  clkmode = 1;
	  SelectObject(hWDC, hClkFont);	// select LED font
	  CalcMetrics (hWDC, &clkchrx, &clkchry);	// Get font size..
		// Calc size of each digit area
	  clksizex = clkchrx * 8;
	  clksizey = clkchry * (flag2clocks + 1) + clkdispy;
		// Calc top left of clock displays	
	  clktxtx = (mvboxBx >> 1) - clksizex;
	  clktxty = mvboxBy - max (clksizey + 4,iylen + 2);
	  mvboxBot = clktxty - 3;	// Set bottom mvbox print area
	  clktxtx2 = clktxtx + clksizex - 1;	// 2nd disp..
		// Pos for full info display (if any) below LED
	  clkfully = clktxty + clkchry + chry + 4;
		// Player Icons start positions
	  clkledx = clktxtx - ixlen;
	  clkledy = clktxty + ((clksizey - iylen) >> 1); // center y pos..
	  clkledx2 = clktxtx2 + clksizex; 
		// Set pens..
	  SelectObject (hWDC,hBlackPen);
	  SelectObject (hWDC,hUBoxBrush);
	      	// Draw clockface
	  Rectangle (hWDC,clktxtx, clktxty, clktxtx + clksizex, 
		clktxty + clksizey);
	  Rectangle (hWDC,clktxtx2, clktxty, clktxtx2 + clksizex,
		clktxty + clksizey);
		// Draw borders about icons..
	  Rectangle (hWDC,clkledx - 1, clkledy - 1, clkledx + ixlen + 1, 
		clkledy + iylen + 1);  
	  Rectangle (hWDC,clkledx2 - 1, clkledy - 1, clkledx2 + ixlen + 1, 
		clkledy + iylen + 1);  
		// Calc text start pos
	  clktxtx += clkoffx; clktxty += clkoffy;
	  clktxtx2 += clkoffx;
	}
	    
	    // Now orig service routine..
	//if (eng.clkmode & 1) {	// no colour
	//  colgr = colw = colb = RGB (0,0,0);
	//} else {
	colw = ExtraRGB (PALTXT);
	colb = ExtraRGB (PALLOTXT);
	if (IsBlacksMove) {	// Text colour for active/inactive clocks..
	  SWAPVAR (colw,colb,COLORREF);
	}
	//}
	LastExceed = ExceededTime;
	SetCountdownStr ();	// If in countdown mode, set countdown str..
	if ((ExceededTime & 32) && LastExceed != ExceededTime) SoundIt ();	// Time up noise..
	SelectObject(hWDC, hClkFont);	// select LED font
	SetBkColor (hWDC, ExtraRGB (PALUBOX));
		// Countdown LED clock mode?
	if (UseCount) {
	  cstr = szCount + 6;
	  if (ExceededTime & 2) cstr = STtimeup; // White time up
	  UpdateTextOut (hWDC,clktxtx,clktxty,cstr,clkbufold,
		7,clkchrx, cmode,colw);
	  cstr = szCount + 21;
	  if (ExceededTime & 1) cstr = STtimeup; // Black time up
	  UpdateTextOut (hWDC,clktxtx2,clktxty,cstr,clkbufold+8,
		7,clkchrx, cmode,colb);
	} else {			// Normal LED clock
	  time2asc (clkbuf,eng.white_time,1);
	  UpdateTextOut (hWDC,clktxtx,clktxty,clkbuf,clkbufold,7,
		clkchrx, cmode,colw);
	  time2asc (clkbuf + 8,eng.black_time,1);
	  UpdateTextOut (hWDC,clktxtx2,clktxty,clkbuf+8,clkbufold+8,7,
		clkchrx, cmode,colb);
	}
	if (flag2clocks) {	// 2nd row of clock - current move time..
	  time2asc (fullclk, eng.white_move_time,1);
	  UpdateTextOut (hWDC,clktxtx,clktxty + clkchry,fullclk,fullclkold,7,
		clkchrx, cmode,colw);
	  time2asc (fullclk + SIZEhalfclk + 1, eng.black_move_time,1);
	  UpdateTextOut (hWDC,clktxtx2,clktxty + clkchry,fullclk + SIZEhalfclk + 1,
		fullclkold + SIZEhalfclk + 1,7,	clkchrx, cmode,colb);
	}
	if (cmode) {		// Also show Player icons..
	  short cicon;
	    	// First for 'White' (left) icon..
	  cicon = 4;		// Computer icon..
	  if (eng.play_mode == PlayTwo || 
	  	(eng.play_mode == PlayNormal && !(HumanIsBlack))) {
	    cicon = 0;	// Human icon
	  }
	  if (IsBlacksMove) {		// Grey out for black..
	    cicon += 2;
	  }
	  BitBlt (hWDC, clkledx, clkledy, ixlen,iylen,
		hHotDC,playicons [cicon],playicons [cicon + 1] ,SRCCOPY);
	  	// Now for 'Black' (right) icon..
	  cicon = 4;		// Computer icon..
	  if (eng.play_mode == PlayTwo || 
	    	(eng.play_mode == PlayNormal && (HumanIsBlack))) {
	    cicon = 0;
	  }
	  if (IsWhitesMove) {		// Grey out if not Blacks move
	    cicon += 2;
	  }
	  BitBlt (hWDC, clkledx2, clkledy, ixlen,iylen,
		hHotDC,playicons [cicon],playicons [cicon + 1] ,SRCCOPY);
	}
	ReleaseMyDC (W_MOV);
}


	// Set timer up with a new time..
void ResetTimer (short settime)
{
	if (idTimer) KillTimer (hMainWnd, idTimer);
	idTimer = SetTimer (hMainWnd, 1,settime,NULL);
}

void TimerOn (void)		// Start timer, sends WM_TIMER each sec
{
	idTimer = SetTimer (hMainWnd, 1,clktime [0],NULL);
	timefix = 0;
}

void TimerOff (void)
{
	if (idTimer) {
	  KillTimer (hMainWnd,idTimer);
	}
	idTimer = 0;
}

	// Clock timing vars - time setting 1 & # uses, setting 2 & uses..
void ProcessTimer (void)	// Called once/sec for CLOCK update
{
      #if CLOCKTYPE
        ext_second ();		// Update CHECKER ENGINE clock
        timefix ++;
	if (timefix >= clktime [1]) {	// Adjust clock timing?
	  if (timefix >= clktime [1] + clktime [3]) {	// Back to normal speed
	    ResetTimer (clktime [0]);
	    timefix = 0;
	  } else {		// Every so often, change time a little
	    if (timefix == clktime [1]) ResetTimer (clktime [2]);
	  }
	}
      #else 
        ext_second ();		// Update CHECKER ENGINE clock
      #endif
      if (EndTick > 0) {		// Countdown after CompVComp Auto..
	if (EndTick == 1) {		// Time up, restart game.. 
	  int cret;
	  NewGame (0);
	  DrawBoard ();
	  #if AUTOTEST
            cret = auto_New ();
            if (cret == FALSE) return;
	  #endif
	  InitThink (ThinkComp);		// Start think of 1st move..
	} else {
	  EndTick --;
	}
      }
      if (ClockIsOff) return;
      PrintClock (0);		// Print the clock..
}

#if Debug
 short nObjDel = 0,retx,rety;

 BOOL DeleteMyObject (HGDIOBJ hMyGdiObj)
 {
	BOOL retx = DeleteObject (hMyGdiObj);
	nObjDel ++;
	if (retx == 0) {
	  Dink ();
	  //msgprintf (NULL,1,1,"NOTE:DeleteObject no %d (Handle=%d) failed",nObjDel,hMyGdiObj);
	}
	return retx;
 }
#else
 #define DeleteMyObject DeleteObject
#endif

	// Calc current char size..
void CalcMetrics (HDC hDC, short *chx, short *chy)
{
	GetTextMetrics (hWDC, &txtmet);	// Get font size..
	*chx = (short) txtmet.tmAveCharWidth;
	*chy = (short) txtmet.tmHeight;
	//if ((txtmet.tmPitchAndFamily & 15) == TMPF_TRUETYPE) {
	//}
}

	// Change to a directory path in (istr), NULL for default..
void GotoDir (char *istr) 
{
	short cdrv;
	if (istr == NULL) {
	  istr = szWorkDir;
	  cdrv = WorkDrive;
	} else {
	  cdrv = (istr [0] & 31);
	}
	if (_chdir (istr) == 0) {	// Changed dir OK..
	  _chdrive (cdrv);		// Change drive
	}
	
}


	// Disable minimize in system-menu
void ModSysMenu (HWND hSWnd) 
{
	HMENU hSysMenu;
	hSysMenu = GetSystemMenu (hSWnd, 0);
	//DeleteMenu (hSysMenu, SC_MAXIMIZE, MF_BYCOMMAND);
	DeleteMenu (hSysMenu, SC_MINIMIZE, MF_BYCOMMAND);
	//DeleteMenu (hSysMenu, SC_RESTORE, MF_BYCOMMAND);
	//DeleteMenu (hSysMenu, SC_SIZE, MF_BYCOMMAND);
	//DeleteMenu (hSysMenu, SC_TASKLIST, MF_BYCOMMAND);
	//DeleteMenu (hSysMenu, SC_MOVE, MF_BYCOMMAND);
}

char szProf [100];		// temp workspace
	// Write a private profile string (->WGENIUS.INI)
void WrtProStr (char *szEntry, char *szString)
{
        WritePrivateProfileString (szIniHead, szEntry, szString, szIniName);
}

	// Write a private profile number (->WGENIUS.INI)
void WrtProInt (char *szEntry, short *iVal, short nwrite)
{
	char *istr = szProf;
	while (nwrite > 0) {
	  istr += wsprintf (istr,"%d ",iVal [0]);
          nwrite --; iVal ++;
	}
	WrtProStr (szEntry, szProf);
}

void ReadProStr (char *szEntry, char *szString)
{
        GetPrivateProfileString (szIniHead, szEntry, szString, szString, 70, szIniName);
}

  // Read in NREAD integers from entry in profile string into INT array..
void ReadProInt (char *szEntry, short *iVal, short nread)
{
	char *istr = szProf;
	szProf [0] = 0;		// wipe string..
	ReadProStr (szEntry, szProf);
	while (nread > 0) {			// Until no more integers..
	  if (isdigit (istr [0]) == 0) break;   // not digit, end of str..
	  iVal [0] = atoi (istr);
	  while (isdigit (istr [0])) istr ++;
	  if (istr [0] == ' ' || istr [0] == ',') istr ++;// Space seperator
	  nread --; iVal ++;
	}
}

BUTTONINFO iBtn;		// General purpose buttons..

 //-------------------------------------------------------------------------
 //
 // DIB Library - for loading 256 colour bmps/palettes..
 //

#define  SEEK_CUR 1
#define  SEEK_END 2
#define  SEEK_SET 0
#define MAXREAD  32768		// MAX Number of bytes to be read during load

short nExtraPal = 0;		// No of extra palette cols to add in
PALETTEENTRY ExtraPal [40];	// Colours to add in
short nTotalPal;			// Total size palette for BMP


	// Fast way to fill a palette entry
#define SetRGBF(Array,cR,cG,cB,cF) \
	Array.peRed = (BYTE) cR; Array.peGreen = (BYTE) cG; \
	Array.peBlue = (BYTE) cB; Array.peFlags = (BYTE) cF;

	// Set an ExtraPal entry as % of a 0-99 scale..
void SetRGBFper (short cpal, short cr, short cg, short cb, short cf, short cper) 
{
	cper = (cper * 255) / 100;	// Scale 0-99 up to 0-255 color..
		// apply each colr, fixing range 0..255
	cr = max (0,min ((cr * cper) / 100,255));
	cg = max (0,min ((cg * cper) / 100,255));
	cb = max (0,min ((cb * cper) / 100,255));
	if (nVduColor < 8) {	// 16 colour mode - round off to nearest
	  cr = min (255,((cr + 31) >> 6) << 6);
	  cg = min (255,((cg + 31) >> 6) << 6);
	  cb = min (255,((cb + 31) >> 6) << 6);
	}
	SetRGBF (ExtraPal [cpal], cr,cg ,cb,cf);
}

	// Read a COLORREF entry from ExtraPal array..
COLORREF ExtraRGB(short Ind) 
{
	char cr,cg,cb;
	cr = ExtraPal[Ind].peRed; cg = ExtraPal[Ind].peGreen;
	cb = ExtraPal[Ind].peBlue;
	return (PALETTERGB (cr,cg,cb));
}

#if Debug
 PALETTEENTRY PalApe[257];
#endif

short errtype;

BOOL bDIBLoaded = FALSE;	// initially no DIB is loaded 
WORD offBits;			// offset to the bits 
HANDLE hDIBInfo = NULL;		// the DIB header 
	// HDC handles
HDC hPieceDC = NULL;		// Dev Con for piece bmps
HDC hWorkDC = NULL;		// DC for work - scratchpads,etc
HDC hMaskDC = NULL;		// DC for masks..
	// Bitmap handles
HBITMAP hWorkBmp = NULL;	// Bitmap for scrathcpad work..
HBITMAP hMaskBmp = NULL;	// Bitmap with piece masks
HBITMAP hPieceBmp = NULL;	// a device dependent copy of the DIB 
HBITMAP hOldPcBmp = NULL;


HPALETTE hPalette = NULL;	// palette used for display 
HANDLE hPalHeader = NULL;	// DIB header with indices for color table 
HPALETTE hOldPal,hOldPiecePal;	// Temp for prev palette

DWORD PASCAL lread (short, VOID far *, DWORD);
HPALETTE PASCAL NEAR MakeDIBPalette (LPBITMAPINFOHEADER, short);
HANDLE PASCAL NEAR MakeIndexHeader (LPBITMAPINFOHEADER);


	// A FAST replacement for RealizePalette - if the PALBOX/PALTXT
	//   colours are already system colours, no RealizePalette is
	// performed, saving time. Tests for grey scales:-
	// (0,0,0), (50,50,50) or (75,75,75) percentages RGB
UINT qRealizePalette (HDC hCDC)
{
	register BYTE cr;
	cr = ExtraPal[PALBOX].peRed; 
	if ((cr == 50 || cr == 75 || cr == 0) 
		&& ExtraPal[PALBOX].peGreen == cr 
		&& ExtraPal[PALBOX].peBlue == cr) {
	  cr = ExtraPal[PALTXT].peRed; 
	  if ((cr == 50 || cr == 75 || cr == 0) 
		&& ExtraPal[PALTXT].peGreen == cr 
		&& ExtraPal[PALTXT].peBlue == cr) {
	    return 0;		// All system colours, so no realize!
	  }
	}
	return (RealizePalette (hWDC));	// Normal Realize
}

/****************************************************************************
 *									    *
 *  FUNCTION   : MakeIndexHeader(lpInfo)				    *
 *									    *
 *  PURPOSE    : Given a BITMAPINFOHEADER, create a new info header 
 *		 using the DIB_PAL_COLORS format.
 *									    *
 *  RETURNS    : non-zero - global handle of a new header
 *		 zero - unable to create new header
 *									    *
 ****************************************************************************/
HANDLE PASCAL NEAR MakeIndexHeader(LPBITMAPINFOHEADER lpInfo)
{
    HANDLE hPalInfo;
    LPBITMAPINFOHEADER lpPalInfo;
    WORD FAR *lpTable;
    WORD i;

    if (lpInfo->biClrUsed) {
	hPalInfo = GlobalAlloc (GMEM_MOVEABLE, lpInfo->biSize + 100 +
					lpInfo->biClrUsed * sizeof(WORD));
	if (!hPalInfo)
	    return(NULL);
	lpPalInfo = (LPBITMAPINFOHEADER) GlobalLock(hPalInfo);

	*lpPalInfo = *lpInfo;
	lpTable = (WORD FAR *)((LPSTR) lpPalInfo + lpPalInfo->biSize);

        for (i = 0; i < (WORD) lpInfo->biClrUsed; i++) {
	  *lpTable++ = i;
	}

	GlobalUnlock(hPalInfo);
	return(hPalInfo);
    } else {
	return(NULL);
    }
}

/****************************************************************************
 *									    *
 *  FUNCTION   : MakeDIBPalette(lpInfo)					    *
 *									    *
 *  PURPOSE    : Given a BITMAPINFOHEADER, create a palette based on 
 *		 the color table.
 *		 
 *									    *
 *  RETURNS    : non-zero - handle of a corresponding palette 
 *		 zero - unable to create palette
 *									    *
 ****************************************************************************/
HPALETTE PASCAL NEAR MakeDIBPalette (LPBITMAPINFOHEADER lpInfo, short mode)
{
    NPLOGPALETTE npPal;
    RGBQUAD far *lpRGB;
    HPALETTE hLogPal; 
    short i,tmp;
    nanim = 0;

    // since biClrUsed field was filled during the loading of the DIB,
    // we know it contains the number of colors in the color table.
    
      if (lpInfo->biClrUsed) {
	nTotalPal = (WORD) lpInfo->biClrUsed;
		// Grab some mem for our palette 
	npPal = (NPLOGPALETTE) LocalAlloc (LMEM_FIXED, sizeof(LOGPALETTE) + 
		(WORD)(nTotalPal) * sizeof(PALETTEENTRY));
	if (!npPal)
	    return(FALSE);

	npPal->palVersion = 0x300;	// Must be done, but why?
        npPal->palNumEntries = nTotalPal;

	  // get pointer to the color table 
	lpRGB = (RGBQUAD FAR *) ((LPSTR) lpInfo + lpInfo->biSize);
	
	tmp = nExtraPal;	// Extra palette entries to slip in.
	  // copy colors from the color table to the LogPalette structure 
	for (i = 0; i < nTotalPal; i++, lpRGB++) {
		// If cur pal duplicate entry, slip in our palette entry        
	  if (tmp && i && StructEQ (lpRGB, lpRGB-1) == TRUE && mode == 0) {
	    tmp --;
	    npPal->palPalEntry[i].peRed = ExtraPal[tmp].peRed ;
	    npPal->palPalEntry[i].peGreen = ExtraPal[tmp].peGreen;
	    npPal->palPalEntry[i].peBlue = ExtraPal[tmp].peBlue;
	    npPal->palPalEntry[i].peFlags = ExtraPal[tmp].peFlags;
	    if (tmp >= PALANIMLT && tmp <= PALANIMBX 
	    	&& nanim < aSizeOf (SparePal)) {
	      SparePal [nanim] = i;	// Save anim index in pal.
	      nanim ++;
	    }
	  } else {	// Copy from bitmap to our LogPal..
	    npPal->palPalEntry[i].peRed = lpRGB->rgbRed;
	    npPal->palPalEntry[i].peGreen = lpRGB->rgbGreen;
	    npPal->palPalEntry[i].peBlue = lpRGB->rgbBlue;
	    npPal->palPalEntry[i].peFlags = 0;
	  }
	  
	  #if Debug	// Copy into our debug struct
	    SetRGBF (PalApe[i],
	    npPal->palPalEntry[i].peRed,
	    npPal->palPalEntry[i].peGreen,
	    npPal->palPalEntry[i].peBlue,
	    npPal->palPalEntry[i].peFlags);
	    //StructMV (PalApe + i, npPal->palPalEntry + i);
	  #endif
	}

	hLogPal = CreatePalette ( (LPLOGPALETTE) npPal);
	LocalFree ( (HANDLE) npPal);
	return (hLogPal);


      } else {
	// 24-bit DIB with no color table.  return default palette.  Another
	// option would be to create a 256 color "rainbow" palette to provide
	// some good color choices.
	return (GetStockObject (DEFAULT_PALETTE));
      }
}


/****************************************************************************
 *									    *
 *  FUNCTION   : ReadDIB()						    *
 *									    *
 *  PURPOSE    : Reads a DIB from a file, obtains a handle to it's          *
 *		 BITMAPINFO struct. and loads the DIB.                      *
 *									    *
 *  RETURNS    : TRUE  - DIB loads ok					    *
 *		 FALSE - otherwise					    *
 *									    *
 ****************************************************************************/
 
short ReadDIB (char *achFileName)
{
	unsigned fh;
	LPBITMAPINFOHEADER lpbi;
	OFSTRUCT of;
	BITMAPFILEHEADER   bf;
	WORD	nNumColors;
	WORD	result = FALSE;		// assume failure 
	long msize;
	HANDLE hNewDibInfo;

	errtype = 0;
	  // Open the file and get a handle to it's BITMAPINFO 

	fh = OpenFile (achFileName, &of, OF_READ);
	if (fh == HFILE_ERROR) {
	  msgprintf (NULL,0,0,"Can't open file '%ls'", (LPSTR) achFileName);
	  return (FALSE);
	}

	lpbi = (LPBITMAPINFOHEADER) GlobalLock(hDIBInfo);

	  // read the BITMAPFILEHEADER 
	if (sizeof (bf) != _lread (fh, (LPSTR)&bf, sizeof (bf)))
	  goto ErrExit;
	
	errtype = 1;
	if (bf.bfType != 0x4d42)	// first letters must be 'BM' 
	  goto ErrExit;

	errtype = 2;
		// Read 1st real part of bitmap - info header
	if (sizeof (BITMAPINFOHEADER) != _lread (fh, (LPSTR) lpbi, sizeof(BITMAPINFOHEADER)))
	  goto ErrExit;

	  // !!!!! for now, don't even deal with CORE headers 
	errtype = 3;
	if (lpbi->biSize == sizeof (BITMAPCOREHEADER))
	  goto ErrExit;

	if (!(nNumColors = (WORD)lpbi->biClrUsed)) {
	  // no color table for 24-bit, default size otherwise 
	  if (lpbi->biBitCount != 24) {
	    nNumColors = 1 << lpbi->biBitCount;	// standard size table
	  }
	}

	// fill in some default values if they are zero 
	if (lpbi->biClrUsed == 0) {
          lpbi->biClrUsed = (DWORD) nNumColors;
        }

	if (lpbi->biSizeImage == 0) {
	  lpbi->biSizeImage = ((((lpbi->biWidth * (DWORD)lpbi->biBitCount) + 31) & ~31) >> 3)
			 * lpbi->biHeight;
	}

	  // get a proper-sized buffer for header, color table and bits 
	GlobalUnlock (hDIBInfo);
	//GlobalFree (hDIBInfo);
	msize = lpbi->biSize + nNumColors * sizeof(RGBQUAD) + lpbi->biSizeImage + 100;
	//hDIBInfo = GlobalAlloc (GMEM_MOVEABLE, msize);
	hDIBInfo = GlobalReAlloc (hDIBInfo, msize,GMEM_MOVEABLE);
	errtype = 4;
	if (!hDIBInfo)	/* can't resize buffer for loading */
	  goto ErrExit2;

	lpbi = (LPBITMAPINFOHEADER) GlobalLock (hDIBInfo);

	  // read the color table 
	_lread (fh, (LPSTR)(lpbi) + lpbi->biSize, nNumColors * sizeof(RGBQUAD));

	    // offset to the bits from start of DIB header 
	offBits = (WORD)lpbi->biSize + nNumColors * sizeof(RGBQUAD);

	if (bf.bfOffBits != 0L) {
          _llseek(fh,bf.bfOffBits,SEEK_SET);
	}
	if (lpbi->biSizeImage == lread (fh, (LPSTR) lpbi + offBits, 
		lpbi->biSizeImage)) {
	  result = TRUE;
	}

ErrExit:
	_lclose (fh);
	GlobalUnlock (hDIBInfo);
ErrExit2:
	if (result == FALSE) {
          msgprintf (NULL,0,0,"Can't read DIB: error %d", errtype);
	} else {
	  bDIBLoaded = TRUE;		// there is a DIB loaded now 
	  GlobalLock(hDIBInfo);
	}
	return (result);
}

/**************** PRIVATE ROUTINE TO READ MORE THAN 64K *********************/
/****************************************************************************
 *									    *
 *  FUNCTION   : lread(short fh, VOID FAR *pv, DWORD ul)			    *
 *									    *
 *  PURPOSE    : Reads data in steps of 32k till all the data has been read.*
 *									    *
 *  RETURNS    : 0 - If read did not proceed correctly. 		    *
 *		 number of bytes read otherwise.			    *
 *									    *
 ****************************************************************************/
DWORD PASCAL lread (short fh, VOID far *pv, DWORD ul)
{
    DWORD     ulT = ul;
    BYTE HUGE_ *hp = pv;

    while (ul > (DWORD)MAXREAD) {
	if (_lread(fh, (LPSTR)hp, (WORD)MAXREAD) != MAXREAD)
		return 0;
	ul -= MAXREAD;
	hp += MAXREAD;
    }
    if (_lread(fh, (LPSTR)hp, (WORD)ul) != (WORD)ul)
	return 0;
    return ulT;
}
/**************** PRIVATE ROUTINE TO READ MORE THAN 64K *********************/


void ReleaseDIB (void)		// Clean up handles, palettes, bmps, DCs
{
	if (bDIBLoaded == FALSE) return;
	bDIBLoaded = FALSE;
		// Switch back to orig palettes..
	SelectPalette (hWDC, hOldPal, FALSE);
	if (hPalHeader) {
	  GlobalUnlock (hPalHeader);
	  GlobalFree (hPalHeader);	// Added to free header
	  hPalHeader = NULL;
	} 
	GlobalUnlock (hDIBInfo);
	if (hPieceBmp) {	// Remove piece bitmap/DC..
	  SelectPalette (hPieceDC, hOldPiecePal, FALSE);
	  SelectObject (hPieceDC, hOldPcBmp);
	  DeleteDC (hPieceDC);
	  DeleteMyObject (hPieceBmp);
	  hPieceBmp = NULL;
	  hPieceDC = NULL;
	}
	if (hWorkBmp) {		// Remove scratchpad bitmap/DC..
	  DeleteDC (hWorkDC);
	  DeleteMyObject (hWorkBmp);
	  hWorkBmp = NULL;
	  hWorkDC = NULL;
	}
	if (hMaskBmp) {		// Remove mask bitmap/DC..
	  DeleteDC (hMaskDC);
	  DeleteMyObject (hMaskBmp);
	  hMaskBmp = NULL;
	  hMaskDC = NULL;
	}
	if (hPalette) {		// Remove old palette
	  DeleteMyObject(hPalette);
	  hPalette = NULL;
	}
}


//BYTE NotPow2 [] = {0xfe,0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xbf, 0x7f};
BYTE Pow2 [] = {1,2,4,8,16,32,64,128};

HBITMAP MakeMonoBmp (BYTE far *bmpdata)
{
	HGLOBAL hGlbMem;
	HBITMAP hMonoBmp;
	BYTE far *bmpptr = bmpdata;
	BYTE far *maskdata;
	BYTE far *maskptr;
	USHORT lenx = maxsetx;
	USHORT leny = maxsety;
	USHORT mlenx;      
	USHORT colsize;
	USHORT xpos,ypos,cbit;
	USHORT backcol;
	lenx = (lenx + 3) & (~3);	// Force width to 32 bit boundary
	mlenx = ((lenx + 31) & (~31)) >> 3;	// Mask width..
	colsize = mlenx * leny;
		// Alloc mono mask bmp array, clearing to zero..
	hGlbMem = GlobalAlloc (GMEM_MOVEABLE,  colsize + 20);
	if (!hGlbMem) {
	  DoMessage ("Out of Memory!");
	  return NULL;
	}
	maskdata = (char HUGE_ *) GlobalLock (hGlbMem);	// Mono bmp data
		// Fill mono bmp all white..
	for (xpos = 0; xpos <= colsize + 1; xpos ++) {
	  maskdata [xpos] = 0;
	}
		// Calc scaling in sixteenths (>= 16 no adjustment)
	setscale = (USHORT) min ((charx << 4) / setchrx, (chary << 4) / setchry);
		// Rescale set, to (setscale) sixteenths?
	if (setscale < 16 && (settype & 2)) {
	  short ty,ty2;
	  for (ypos = leny - 1; ypos < leny; ypos --) {
	  	// Remember upside down, so calc invert y scale co-ord..
	    ty = lenx * (leny - 1 - (((leny - 1 - ypos) * setscale) >> 4));
	    ty2 = ypos * lenx;
	    for (xpos = 0; xpos < lenx; xpos ++) {
	      bmpdata [((xpos * setscale) >> 4) + ty] = bmpdata [xpos + ty2];
	      
	    }
	  }
	  	// Rescale the co-ordinates..
	  for (xpos = 0; xpos < aSizeOf (xoff) - 1; xpos ++) {
	    xoff [xpos] = (xoff [xpos] * setscale) >> 4;
	    yoff [xpos] = (yoff [xpos] * setscale) >> 4;
	  }
	  maxsetx = (maxsetx * setscale) >> 4;
	  maxsety = (maxsety * setscale) >> 4;
	  setchrx = (setchrx * setscale) >> 4;
	  setchry = (setchry * setscale) >> 4;
	}
	backcol = 0;
	if (settype & 1) backcol = bmpdata [0];
	for (ypos = 0; ypos < leny; ypos ++) {
		// set ptr to start source 256 col bmp line (upside-down!)
	  bmpptr = bmpdata + ((leny - ypos - 1) * lenx); 
	  	// set ptr to dest mono bmp line
	  maskptr = maskdata + (ypos * mlenx);
	  for (xpos = 0; xpos < mlenx; xpos ++) {
	    for (cbit = 7; cbit <= 7; cbit --) {	// process bit by bit..
	      if (*bmpptr == backcol) {
		//SetPixel (hMainDC, xpos,ypos,RGB (0,0,0));
		*maskptr ^= Pow2 [cbit];
		if (settype & 1) *bmpptr = 0;	// mask back colour to black..
	      }
	      bmpptr ++;
	    }
	    maskptr ++;		// ok, next byte..
	  }
	}
	hMonoBmp = CreateBitmap (mlenx << 3, leny, 1,1, maskdata);
	GlobalUnlock (hGlbMem);
	GlobalFree (hGlbMem);
	return hMonoBmp;
}


/****************************************************************************
 *									    *
 *  FUNCTION   : ResetDIB( mode)
 *									    *
 *  PURPOSE    : Set up DIB in private HDC
 *									    *
 *  RETURNS    : None.
 *									    *
 ****************************************************************************/
 
  // Reset DIB info - having loaded with (ReadDIB) strip out Palette, etc.
  // mode = 0 for normal piece set (make mono bmp, workpad areas, etc.
  // == 1 for load BMP for display purposes only.
  // RETURN TRUE if ok. Returns  (hPalette,hPieceBmp,hPieceDC,hMaskBmp/DC..)
  
short PASCAL NEAR ResetDIB (short mode)
{
	HDC hDC;
	LPBITMAPINFOHEADER lpInfo;
	LPBITMAPINFOHEADER lpHeader;

	hDC = hWDC;
	lpInfo = (LPBITMAPINFOHEADER) GlobalLock(hDIBInfo);

	    // if using a palette for drawing and there is actually 
	    // a color table, then get a palette and realize it.
	    
	if (hPalette == NULL) {
	  hPalette = MakeDIBPalette (lpInfo, mode);
	}
	if (hPalette == NULL) {
	  DoMessage ("Can't create palette");
	  return FALSE;
	}
	hOldPal = SelectPalette (hDC, hPalette, FALSE);
	RealizePalette (hDC);

	    // if using DIB_PAL_COLORS and the bitmap is not 24-bit,
	    // then use a header with a color table of indices.
	
	if (lpInfo->biBitCount != 8 || lpInfo->biCompression != BI_RGB) {
	  DoMessage ("!Must be uncompressed 256 colour bitmap");
	  return FALSE;
	}
	
	if (!hPalHeader) {
	  hPalHeader = MakeIndexHeader (lpInfo);
	}
	if (!hPalHeader) {
	  DoMessage ("!Can't create Indexed color table");
	  return FALSE;
	}
	lpHeader = (LPBITMAPINFOHEADER) GlobalLock(hPalHeader);
    
	if (hPieceBmp) return FALSE;
	
		// get total size of bitmap..
	maxsetx = (short) lpInfo->biWidth;	// Width of loaded bitmap..
	maxsety = (short) lpInfo->biHeight; 	// Height..
	
	if (mode == 0) {	// Normal piece-load, get mono mask
		// Make mask 2-colour bitmap, and DC..
	  hMaskBmp = MakeMonoBmp ((LPSTR) lpInfo + offBits);
	  hMaskDC = CreateCompatibleDC (hDC);
	  SelectObject (hMaskDC, hMaskBmp);
	}
		// OK, create memory DC & put bitmap into it
	hPieceDC = CreateCompatibleDC (hDC);
	hOldPiecePal = SelectPalette (hPieceDC, hPalette, FALSE);
	RealizePalette (hPieceDC);
	hPieceBmp = CreateCompatibleBitmap (hDC, 
		(short) lpInfo->biWidth, (short) lpInfo->biHeight);
	SetDIBits (hDC, hPieceBmp, 0, (short) lpInfo->biHeight, 
		(LPSTR) lpInfo + offBits, 
		(LPBITMAPINFO) lpHeader, DIB_PAL_COLORS);
	hOldPcBmp = SelectObject (hPieceDC, hPieceBmp);
	if (mode) {	// Non-piece BMP (picture) load, finished..
	  return TRUE;
	}

		// Check if sqr size too small, then 1/2 size pieces..
	//if (charx < setchrx || chary < setchry && halfscale == 0) {
	//  halfscale = 1;
		// Set best stretch mode for 256 colour..
	//  SetStretchBltMode (hPieceDC,STRETCH_DELETESCANS);
		// Stretch bitmap to half size..
	//  StretchBlt (hPieceDC,0,0,(maxsetx >> 1) - 1, (maxsety >> 1) - 1,
	//	hPieceDC, 0,0,maxsetx - 1,maxsety - 1,SRCCOPY);
	//  StretchBlt (hMaskDC,0,0,(maxsetx >> 1) - 1, (maxsety >> 1) - 1,
	//	hMaskDC, 0,0,maxsetx - 1,maxsety - 1,SRCCOPY);
	  //BitBlt (hPieceDC,0,0,maxsetx >> 1,maxsety >> 1,hPieceDC, 0,maxsety + 1,SRCCOPY);
	  //BitBlt (hPieceDC,0,(maxsety >> 1),maxsetx >> 1,maxsety,hPieceDC, 1,1,WHITENESS);
		// Half all size variables..		
	//  maxsetx = (maxsetx >> 1);
	//  maxsety = (maxsety >> 1);
	//  setchrx = setchrx >> 1;
	//  setchry = setchry >> 1;
	//}
	  	// Calc size each area in WorkDC..
	workx = ((max (charx, setchrx) + 9) >> 3) << 3;   // byte align..
	worky = max (chary, setchry) + 4;
		// Now make scratchpad work DC
	hWorkDC = CreateCompatibleDC (hDC);
	SelectPalette (hWorkDC, hPalette, FALSE);
	RealizePalette (hWorkDC);
	hWorkBmp = CreateCompatibleBitmap (hDC, workx * 5 + 4, worky * 2 + 4);
	SelectObject (hWorkDC, hWorkBmp);
	return TRUE;
}


    //
    /// DIB library ends
    //


RECT rct,urct,winrct;	// Temp rectangle for window-size read
RECT absmain;		// main client area pos in abs desktop wnd coords
RECT mainrct = {0,0,639,479};	// Current rect for main window..

short ncx,ncy;		// new sqr size
short wastex=8,wastey=27;	// x/y waste in a window (title bar, etc)
MINMAXINFO FAR *lpmmi;	// ptr to min/max info structure, for minimize..

void GetMainInfo ()	// Get info on position of main window
{
	if (hMainWnd == NULL) return;
		// calc size & ans pos of main parent window
	GetClientRect (hMainWnd, &absmain);
		// convert Main client area RECT 2 abs desktop co-ordinates
	MapWindowPoints (hMainWnd, HWND_DESKTOP, (POINT far *) &absmain, 2);
		// Get main window rectangle..
	GetWindowRect (hMainWnd, &mainrct);
	
}

	// Save window size, relative to main window rectangle..
void SaveWin (WRECT far *Cur,HWND hCurWnd, short mode)
{
	GetMainInfo ();		// Get pos info on main window..
	GetWindowRect (hCurWnd, &winrct);	// Rect for current..
	if (mode && IsZoomed (hCurWnd)) {
	  return;	// Window maximised, so dont save pos..
	}
	Cur->tx = (short) winrct.left; 
	Cur->ty = (short) winrct.top;
	if (hMainWnd != hCurWnd) {
	  if (FlagPopUp) {	// Relative to main window
	    Cur->tx -= (short) mainrct.left; 
	    Cur->ty -= (short) mainrct.top;
	  } else {		// Child window.. conv Desktop coord->MainWnd coords
	    Cur->tx -= (short) absmain.left; 
	    Cur->ty -= (short) absmain.top;
	  }
	}
	Cur->lx = (short) (winrct.right - winrct.left);
	Cur->ly = (short) (winrct.bottom - winrct.top);
}

BOOL DoingPopDlg = FALSE;


char szNag [] = 
  "Please remember - this is the SHAREWARE version of "
  "SAGE draughts. You may use it for 30 days. If after "
  "this 30 day evaluation period you wish to continue to "
  "use this product, you must purchase the licensed version "
  "\x22SAGE DRAUGHTS\x22. The licensed version does not have "
  "this NAG screen, and it also has some additional advanced "
  "Annotation, Database, Opening book and Analysis features. "
  "For details on how to purchase SAGE on-line, press the \x22Go To WWW site\x22 button "
  "now, or see the HELP file if you wish to purchase by mail-order.. ";


void DlgNAG (int units)
{
    int cret;
    if (VER_ != SHARE_) return;    // Full version, ignore this routine..
    cret = dlg_Init (STprogramnamefor, -1,-1,300,110,1);
    if (cret == FALSE) return ;
    dlg_DefTextBox (30,10,240,70,szNag,SS_LEFT);
    dlg_Define (dBUTTON, STok, IDOK, 40,90,70,14,0);  
    dlg_Define (dBUTTON, STwwwsite, IDD_BUTTONS+1, 190,90,70,14,0);  
    cret = dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
    if (cret == IDD_BUTTONS+1) {    // WWW site..
      //ShellExecute(0,0,str_GetNth(STwwwsite,1),0,0,SW_SHOWDEFAULT);
      exit (0);
    }
}

void DlgFeatureNotImplemented ()
{
    int cret;
    cret = dlg_Init (STprogramnamefor, -1,-1,300,100,1);
    if (cret == FALSE) return ;
    dlg_DefTextBox (30,10,240,30,
        "This feature is unimplemented on this version of SAGE. ",
	SS_LEFT);
    dlg_Define (dBUTTON, STok, IDOK, 40,60,70,14,0);  
    dlg_Define (dBUTTON, STwwwsite, IDD_BUTTONS+1, 190,60,70,14,0);  
    cret = dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
    if (cret == IDD_BUTTONS+1) {    // WWW site..
      //ShellExecute(0,0,str_GetNth(STwwwsite,1),0,0,SW_SHOWDEFAULT);
      exit (0);
    }
}

void DlgAbout ()	// Display ABOUT dialog box..
{
	int cret;
	cret = dlg_Init (STprogramnamefor, -1,-1,300,100,1);
	if (cret == FALSE) return ;
	dlgs.FocusID = IDOK;
	dlg_Define (dBUTTON, STok, IDOK, 130,82,40,14,0);  
	wsprintf (szTemp,STabout, HashSize * 64);
	dlg_DefTextBox (30,10,240,54,szTemp,SS_CENTER);
	//dlg_Define (dTEXT,szTemp ,IDD_AUTOIDD,30,14,160,54,WS_CHILD | WS_VISIBLE | SS_CENTER);
	//dlg_Define (dTEXT,"",IDD_AUTOIDD,28,8,164,60,	SS_ETCHEDFRAME | WS_CHILD | WS_VISIBLE);
	dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();

        	// Try to stop optomiser altering these..
        #if HackTest		// Simple debug check..
	  msgprintf (NULL,1,1,"sg%x,xor%x,=%x,Spoil Game is %d",
	  	*pSpoilGame, SpoilXOR,*pSpoilEQUAL,IsSpoilGame);
	#endif
}

short StartDlgUsed = 0;	// Flag set once used..
short MainTitle = 1;	// Show Title screen on main window..


int dbox_Start ()	// START-up dialog box..
{
	short wrk,cret;
	const short stlenx = 270;
	const short stleny = 110;
	short ltxtx = stlenx - 54;
	short ltxty = stleny - 38;
	int ExitButton;
	wrk = 120;
	cret = dlg_Init (STprogramnamefor, -1,-1,stlenx,stleny,0);
	if (cret== FALSE) return 0;	// Premature abort..
	dlgs.FocusID = IDD_BUTTONS + 1;
	wrk = dlgs.leny - 20;
	/*
	dlg_Define (dBUTTON, STcontinue, IDD_BUTTONS + 1, 10,wrk,70,14,0);  
	dlg_Define (dBUTTON, STreset,   IDD_BUTTONS + 3, stlenx/2 - 35,wrk,70,14,0);  
	dlg_Define (dBUTTON, STwwwsite, IDD_BUTTONS + 2, stlenx - 80,wrk,70,14,0);  
	*/
	dlg_Define (dBUTTON, STcontinue, IDD_BUTTONS + 1, 10,wrk,70,14,0);  
	dlg_Define (dBUTTON, STreset,   IDD_BUTTONS + 3, stlenx - 80,wrk,70,14,0);  
	wrk = (stlenx - ltxtx) >> 1;
	dlg_DefTextBox (wrk,7,ltxtx,ltxty,STinitdialog,SS_CENTER);
	ExitButton = dlg_Execute ();	// EXECUTE DIALOG BOX..
	dlg_End ();
	if (ExitButton == IDCANCEL) exit (0);
	if (ExitButton == IDD_BUTTONS+2) {
          //ShellExecute(0,0,str_GetNth(STwwwsite,1),0,0,SW_SHOWDEFAULT);
	  exit (0);
	}
	return (ExitButton - IDD_BUTTONS);
} 

#define StepFwdAll 2000		// Useful macros 
#define StepBackAll -2000
	// First move number in move list..
#define FirstMove (eng.init_moven & 0x07ff)

void StepMove (short mvstep)	// Step engine fwd/back (mvstep) moves
{
	short newmv,tstep;
	short smode = 0;
	tstep = abs (mvstep);
	if (tstep > 1 && tstep < 1000) smode = 1;
	if (mvstep < -1000) mvstep = -2;	// to start
	if (mvstep > 1000) mvstep = 2;		// to end
	if (mvstep < 0 && (!FlagBackOk)) {	// Cant go back
	  Dink (); return;
	}
	if (mvstep > 0 && (!FlagFwdOk)) {
	  Dink (); return;		// Cant go fwd
	}
		// IMPORTANT - STOP engine before move step..	
	StopThinking ();
	StopAutoPlay ();	// If comp v comp, back to normal
	if (smode) {	// Not simple fwd/back, so..
	  newmv = eng.move_number + mvstep;	// Calc new nove no..
	  if (newmv < FirstMove) newmv = FirstMove;
	  mvstep = 0x8000 + newmv;
	}
//ax=-2,-1,0,1,2 replay,take back, restore, step forward, step to end
//new function ax= 8xxx if go directly to move xxx. bit 14=0 and 15=1
	int_step_move (mvstep);
	if (tstep == 1) {
	  MakeMove (8);	// Slide move on screen, update VDU board
	} else {
	  FastMakeMove ();// Fast Make moves on screen, update VDU board
	}
    	if (FlagNumbering) DrawNumbering (1);
	InitThink (ThinkOpp);
}

short LastMove ()		// Calc last move of game
{
	short last;
	short cmoveno = eng.move_number;	// save cur move #
	int_step_move (2);		// goto game end
	last = eng.move_number;
	int_step_move (0x8000 + cmoveno);	// go back to current
	return (last);
}

void DlgGoto ()		// GOTO dialog - Input GOMOVE
{
        int cret;
	gomove = 1 + (eng.move_number >> 1);  // Default current..
	cret = dlg_Init (IDM2String (IDM_GOTO),-1,-1,110,100,1);
	if (cret == FALSE) return ;
	dlgs.FocusID = IDD_SPIN + 1;
	StopThinking ();
	StopAutoPlay ();	// If comp v comp, back to normal
	dlg_DefSpin (40,37,4,gomove,1,9999,1,0);
	dlg_DefOKCancel (10,10,STok,NULL,40);
	dlg_DefTextCent (-1,25,STgotomove);
	dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	gomove = (short) dlg_ReadSpin ();
	if (dlgs.ButtonHit == IDOK) {
	  int_step_move (0x8000 + (gomove << 1) - 2);
	  MakeMove (40);	// Make move on screen, update VDU board
	}
	InitThink (ThinkOpp);
}

	// Implement a new piece set - load bmp, etc.
	// mode set to redraw all other windows..
void ImpNewSet (short mode)
{
	short lastset = thissetno;
		// Now implement piece/color combination	
	SetWaitCursor 		// Macro - set hour-glass mouse..
	SetSqrCol ();		// Calc board colours in ExtraPal array
	ReleaseDIB ();		// Release all Bitmap related handles, mem, DCS..
	SelectSet (eng.pieceset);	// Load in bitmap for set.. (does ReadDIB)
	ResetDIB (0);		// Strip out & get pallette, make mono bmp, work areas..
	CreateBoardGraphics ();	// Create Wht/Blk sq bmps @ WhtsqLocx
	if ((mode & 1) || ((mode & 2) && thissetno != lastset)) {
	  RedrawAllWindows ();	// Redraw all windows, new palette..
	}
	SetNormCursor         // Normal mouse..     
}


	// Mixed dialog routines..

	// Reset to default screen colours, pieces..
	// Bit0 set to rescale brd, bit1 to reload orig colours/pieceset
void SetDefault (short mode)
{
	
	if (mode & 1) {
		// Ok, now auto-scale board to current resolution..
	  charx = 38;
	  //if (pieceset == 4) charx = 43;	// Big stauton
	  if (nVduX > 750 && nVduY > 550) {	// Large screen area..
	    charx = 50;
	  }
	  if (nVduX > 1000 && nVduY > 700) {	// Extra large..
	    charx = 54;
	  }
	  chary = charx;
	}
	if (mode & 2) {		// Set Colours
		// Copy colour default settings block to engine..
	  _fmemcpy (&eng.back,DCsettings + (nVduColor < 8),
	  	sizeof (DEFAULTCOLORS));
	}
}

/*
void RGBDef (short xpos, short ypos, short width, PRERGB far *prgb, char *title)
{
	//DialogDef (dTEXT,"",IDD_AUTOIDD,xpos,ypos,width,56,
	//	SS_WHITEFRAME | WS_CHILD | WS_VISIBLE);
	//xpos += 4; width -= 8;
	dlg_DefTextCent (xpos + (width >> 1),ypos + 3,title);
	width -= 20;
	dlg_DefSliderTxt (xpos,ypos + 14,width,prgb->r,0,100,1,10,"R",6);
	dlg_DefSliderTxt (xpos,ypos + 28,width,prgb->g,0,100,1,10,"G",6);
	dlg_DefSliderTxt (xpos,ypos + 42,width,prgb->b,0,100,1,10,"B",6);
}

void RGBread (PRERGB far *prgb)		// Read slider val back
{
	prgb->b = (BYTE) dlg_ReadSlider ();
	prgb->g = (BYTE) dlg_ReadSlider ();
	prgb->r = (BYTE) dlg_ReadSlider ();
	prgb->preset = 0;		// Indicates user-set..
}

*/

  // SAGE select colours, pieces..
void DlgDisplay (void)
{
	const short dlgy = 275,dlgx = 310;
	short sqrsize = charx;
	short nopts;		// # piece-set options
	int cret;
	static BYTE my2pat[] = {0,0,5,2,3,0};
	static BYTE pat2my[] = {1,1,3,4,4,2,0};
	nopts = ReadPieceOpt ();	// Read piece option combo-text..
	IDM2String (IDM_DISPLAYOPT);

	cret = dlg_Init (MenuStr,-1,-1,dlgx,dlgy,1);
	if (cret == FALSE) return ;
		// Enable RGB color box at loc in CHAR units..
	dlg_DefRadio (20,10,D_GROUPBOX | 70,(nopts > 6) ? 10 : 12,SToptpieceset,eng.pieceset,0);
	dlg_DefRadio (dlgx - 100,10,D_GROUPBOX | 70,12,SToptsquarestyles,
		pat2my [eng.sqpattern],0);
	dlg_DefText (110,10,STpatterncontrast);
	dlg_DefSliderTxt (110,25,70,eng.pcontrast,1,25,1,5,"",0);
	//SpinDef (12,40,3,eng.pcontrast,1,30,1,0);
	dlg_DefRGB (10,110,125,60,*((COLORREF *) &eng.lsqr),STlightsqrcolour);
	dlg_DefRGB (170,110,125,60,*((COLORREF *) &eng.dsqr),STdarksqrcolour);
	dlg_DefRGB (10,180,125,60,*((COLORREF *) &eng.txt),STtextcolour);
	dlg_DefRGB (170,180,125,60,*((COLORREF *) &eng.box),STboxcolour);
	
	dlg_DefOKCancel (40,15,STok,NULL,40);
	
	cret = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	if (cret  != IDOK) return;
		// Read check boxes back..
	eng.sqpattern = my2pat [dlg_ReadRadio ()];	// Pattern..
	eng.pieceset = (BYTE) dlg_ReadRadio ();	// Piece set selected
		// Read back sqr colors (REVERSE ORDER off stack.)
        *((COLORREF *) &eng.box) = dlg_ReadRGB ();
        *((COLORREF *) &eng.txt) = dlg_ReadRGB ();
        *((COLORREF *) &eng.dsqr) = dlg_ReadRGB ();
        *((COLORREF *) &eng.lsqr) = dlg_ReadRGB ();
	
	eng.pcontrast = (BYTE) dlg_ReadSlider ();	// Get contrast back..
	eng.scontrast = 0;
	ImpNewSet (1);
}


FLAGDATA Opt [8] = {
  &eng.option_bits, 0x10,0,
  &eng.play_levex,  0x80,THINK_OPP_DEFAULT,
  &eng.option2_bits,0x80,1,
  &eng.option2_bits,0x40,0,
  &eng.option_bits, 0x02,1,
  &VarEndgameDB,BitEndgameDB,XorEndgameDB,
  &dummy,0,0,NULL		// Terminator
};                 


  // SAGE options dialog.. CTRL-O
  // Set play style, piece vals, operator time..
void DlgSageOptions ()
{
        int hitbut;
	short tcount;
	short nanal;
	const short lopval = 25, hipval = 175;	// Extend slider ranges..
	const short sltxtlen = 70;	// Slider block positions/lengths..
	const short sllen = 70,slxp = 115,slyp = 15;
	const short dlgbot = 195;
	ALY USHORT chash;
	int cret;

	calccode = 0;		// Ensure no force move code..
	ext_calcmove_stop ();	// Stop any thinking - HASH adjust?
	IDM2String (IDM_OTHEROPTIONS);
	cret = dlg_Init (MenuStr,-1,-1,300,240,1);
	if (cret == FALSE) return ;
	//IddFocus = IDOK;	// Initial edit focus..
	 // Define a set of dialog check boxs, as given in a FLAG_DATA struct
	dlg_DefTicks (Opt, 20, slyp, 70, 12, 290, 170, STopteng);
	if (dbProfileMode & 4) {
	  dlg_DefSpinTxt (20,slyp + 100,6,schMixedFlagsVar,0,32767,1,0,"Mixed flags",50);
	}
	//dlg_DefSpinTxt (20,slyp + 135,4,eng.histanal,0,100,1,0,SThistoricanal,90);
	
	dlg_DefSliderTxt (slxp,slyp,sllen,eng.gammisc1,-10,10,2,2, STbookstrength,sltxtlen);
	dlg_DefSliderTxt (slxp,slyp + 15,sllen,((char) eng.piece_value [0]) * 5 + 100,lopval,hipval,5,5, STpawnvalue,sltxtlen);  // Man
	dlg_DefSliderTxt (slxp,slyp + 30,sllen,((char) eng.piece_value [1]) * 5 + 100,lopval,hipval,5,5, STknightvalue,sltxtlen);  // King
	dlg_DefSliderTxt (slxp,slyp + 45,sllen,((char) eng.piece_value [2]) * 5 + 100,lopval,hipval,5,5, STbishopvalue,sltxtlen);  // Abwin
	dlg_DefSliderTxt (slxp,slyp + 60,sllen,((char) eng.piece_value [3]) * 5 + 100,lopval,hipval,5,5, STrookvalue,sltxtlen);   // Clamp
	dlg_DefSliderTxt (slxp,slyp + 75,sllen,eng.hash_mode,0,100,1,5, SThashdepth,sltxtlen);
	dlg_DefSliderTxt (slxp,slyp + 90,sllen,(eng.contempt / 16) * 25,-75,75,25,25, STcontempt,sltxtlen);
	dlg_DefSliderTxt (slxp,slyp + 105,sllen,eng.short_depth,0,100,2,2, STshortlook,sltxtlen);
	dlg_DefSliderTxt (slxp,slyp + 120,sllen,eng.endgame_db,0,100,2,2, STendgamedb,sltxtlen);
	dlg_DefSpinTxt (20,slyp + 135,7,((long) HashSize) << 6,128,MaxHash * 64L,128,0,STenterhash,75);
	dlg_DefSpinTxt (20,slyp + 155,6,eng.autolearn,0,255,1,0,STautolearn,125);
	        
	dlg_DefOKCancel (40,20,STok,NULL,40);
	
	hitbut = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	if (hitbut  != IDOK) {
	  ReThink ();		// Restart thinking..
	  return;  // Cancel/close win..
	}
	dlg_ReadTicks (Opt);	// Read back tick values..
	eng.autolearn = (BYTE) dlg_ReadSpin ();
	autol_Quit ();   // Free up auto learn mem..
	chash = (USHORT) ((long) dlg_ReadSpin () >> 6);	// Divide by 64 for Segments..
	eng.endgame_db = (BYTE) dlg_ReadSlider ();	// Endgame DB cutoff depth..
	eng.short_depth = (BYTE) dlg_ReadSlider ();	// Short-look depth (0-100)
	eng.contempt = (dlg_ReadSlider () / 25) * 16;	// eng.contempt factor..
	eng.hash_mode = (BYTE) dlg_ReadSlider ();		// Hash depth..
		// Read back queen..pawn % settings..        
	for (tcount = 3; tcount >= 0; tcount --) {
	  eng.piece_value [tcount] = (dlg_ReadSlider () - 100) / 5;
	}
	eng.gammisc1 = dlg_ReadSlider ();	// Book strength
	//nanal = (short) dlg_ReadSpin ();	// # hist anal lines..
	//if (nanal !=eng.histanal) mlaInit (nanal);
	if (dbProfileMode & 4) {
	  schMixedFlagsVar = (short) dlg_ReadSpin ();
	}
	if (chash != HashSize) {	// Set new table hash size..
	  HashSize = chash;
	  SetHash (0);
	}
	int_step_move (0);		// Re-read DRAWS info, with correct HASH vals..
	ReThink ();		// Restart thinking..
}

#if EXT_ENG

char STextdlg[] = "";


int dlgSetExtOpt (int eng)
{
    int bookmode;
    int hashsize;
    int cret,hitbut;
    char *szReply;
    char szCmd [256];
again:
    cret = dlg_Init (str_GetNth(STdlgeng,3),-1,-1,290,210,1);
    if (cret == FALSE) return FALSE;
    szReply = dll_engcmd ("name", eng);
    if (szReply == NULL) return FALSE;
    dlg_DefText (10,10,szReply);
    szReply = dll_engcmd ("get book", eng);
    if (szReply == NULL) {
      bookmode = -1;
    } else {
      bookmode = atoi (szReply);
    }
    szReply = dll_engcmd ("get hashsize", eng);
    if (szReply == NULL) {
      hashsize = -1;
    } else {
      hashsize = atoi (szReply);
    }
    dlg_DefCheck (10, 30, 100, "Use SAGE book", (eng == 1) ? dll_usesagebook1 : dll_usesagebook2);
    if (bookmode > -1) {
      dlg_DefCheck (10, 50, 100, "Use engine book", bookmode);
    }
    if (hashsize > -1) {
      dlg_DefSpinTxt (10,70,6,hashsize,1,512,1,0,"Hash table size (Mb)",125);
    }
    dlg_DefOKCancel (40,20,STok,NULL,40);
    hitbut = dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
    if (hitbut  == IDCANCEL) {
      ReThink ();		// Restart thinking..
      return FALSE;  // Cancel/close win..
    }
    if (bookmode > -1) {
      bookmode = dlg_ReadCheck ();
      sprintf (szCmd,"set book %d",bookmode);
      szReply = dll_engcmd (szCmd, eng);
    }
    if (eng == 1) {
      dll_usesagebook1 = dlg_ReadCheck ();
    } else {
      dll_usesagebook2 = dlg_ReadCheck ();
    }
    if (hashsize > -1) {
      hashsize = dlg_ReadSpin ();
      sprintf (szCmd,"set hashsize %d",hashsize);
      szReply = dll_engcmd (szCmd, eng);
    }
    return TRUE; 
}

int eng_Setup (char *szFile, int errmsg)
{
    char szF[256];
    char *pDot;
    if (file_Length(szFile) < 5) {   // Use sage engine
      *szFile = 0; 
      return FALSE;
    }
    if (file_Length(szFile) > 256) return FALSE;  // Ok, use DLL direct..
    strcpy (szF,szFile);
    file_Load (szF,szFile,0,256);
    pDot = strrchr(szFile, '.');
    if (pDot == NULL) goto err;
    if (_strnicmp(pDot, ".dll", 4)) goto err;
    pDot[4] = 0;
    if (file_Exists (szFile) == FALSE) goto err;
    return TRUE;
err:
    if (errmsg) msg_Printf (NULL,0,0,STprogramname,"File \x22%s\x22 not installed!",szFile);
    *szFile = 0; 
    return FALSE;
}

void DlgEngOptions () 
{
    int cret,hitbut;
    IDM2String (IDM_OTHEROPTIONS);
    cret = dlg_Init (MenuStr,-1,-1,290,210,1);
    if (cret == FALSE) return ;
    dlg_DefTextBox (30,10,230,60,STdlgeng,SS_LEFT);
    dlg_DefText (30,20,eng_getname(1));
    dlg_Define (dBUTTON, str_GetNth(STdlgeng,2), IDD_BUTTONS + 1,  40,40,90,14,0);  
    dlg_Define (dBUTTON, str_GetNth(STdlgeng,3), IDD_BUTTONS + 2,  140,40,90,14,0);  

    dlg_DefTextBox (30,90,230,60,str_GetNth(STdlgeng,1),SS_LEFT);
    dlg_DefText (30,100,eng_getname(2));
    dlg_Define (dBUTTON, str_GetNth(STdlgeng,2), IDD_BUTTONS + 3,  40,120,90,14,0);  
    dlg_Define (dBUTTON, str_GetNth(STdlgeng,3), IDD_BUTTONS + 4,  140,120,90,14,0);  

    dlg_DefOKCancel (40,20,STok,NULL,40);
    hitbut = dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
    if (hitbut  == IDCANCEL) {
      ReThink ();		// Restart thinking..
      return;  // Cancel/close win..
    }
    if (hitbut == IDD_BUTTONS + 1) {
      cret = dlg_Open (dll_szEng1, str_GetNth(STdlgeng,4), str_GetNth(STdlgeng,2),0);
      if (cret == FALSE) *dll_szEng1 = 0;
      eng_Setup (dll_szEng1,TRUE);
      dll_initialize ();
    }
    if (hitbut == IDD_BUTTONS + 2) {
      if (*dll_szEng1 == 0) {
        DlgSageOptions ();
      } else {
        dlgSetExtOpt (1);
      }
    }
    if (hitbut == IDD_BUTTONS + 3) {
      cret = dlg_Open (dll_szEng2, str_GetNth(STdlgeng,4), str_GetNth(STdlgeng,2),0);
      if (cret == FALSE) *dll_szEng2 = 0;
      eng_Setup (dll_szEng2,TRUE);
      dll_initialize ();
    }
    if (hitbut == IDD_BUTTONS + 4) {
      if (*dll_szEng2 == 0) {
        DlgSageOptions ();
      } else {
        dlgSetExtOpt (2);
      }
    }
    ReThink ();		// Restart thinking..
}

#else

void DlgEngOptions () { DlgSageOptions ();}

#endif

  // SAGE Set up elapsed time-clocks..
void DlgSetClocks ()
{
    int cret;
    int hitbutton;

    cret = dlg_Init (IDM2String (IDM_SETCLOCKS), -1,-1,150,120,1);
    if (cret == FALSE) return ;
    dlg_DefTimeSpinTxt (10, 30, eng.white_time, SThms, D_SECS | D_TITLE,
	(FlagInitCol) ? STwhitetime : STblacktime,40);
    dlg_DefTimeSpinTxt (10, 50, eng.black_time, SThms, D_SECS,
	(FlagInitCol) ? STblacktime : STwhitetime,40); 
    dlg_DefOKCancel (20,10,STok,NULL,50);
    hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX.. 
    dlg_End ();
    if (hitbutton != IDOK) return;
    eng.black_time = dlg_ReadTimeSpin (D_SECS);	
    eng.white_time = dlg_ReadTimeSpin (D_SECS);
    return;
}


//---------------------------------------------------------------------
//  LEVELS set functions..
//

short leveltype=0;	// Type of play level (0=tim/sec,1=usr,2=time/game..
long timepermove=5;	// Default secs/move in User lev dialog
long tpm;
short nmov;
long timepergame=300;	// Def Secs for all game in User lev Dlg..
short matein = 2;
short fixeddepth =2;
short easylevel =2;

short  WmoveCtrl1 = 30;	
long WtimeCtrl1 = 300;	// in secs
short  WmoveCtrl2 = 30;	
long WtimeCtrl2 = 300;
short  BmoveCtrl1 = 30;	
long BtimeCtrl1 = 300;
short  BmoveCtrl2 = 30;	
long BtimeCtrl2 = 300;

#define SetUserLevel(Wmove1,Wtime1,Wmove2,Wtime2,Bmove1,Btime1,Bmove2,Btime2) \
	eng.levw1 = MAKELONG (Wmove1,Wtime1); \
	eng.levw2 = MAKELONG (Wmove2,Wtime2); \
	eng.levb1 = MAKELONG (Bmove1,Btime1); \
	eng.levb2 = MAKELONG (Bmove2,Btime2); \
	eng.play_level = 0x0007; \
	retv = ext_set_level ();

#define GetUserLevel(Wmove1,Wtime1,Wmove2,Wtime2,Bmove1,Btime1,Bmove2,Btime2) \
	Wmove1 = LOWORD (eng.levw1); Wtime1 = HIWORD (eng.levw1) * 60; \
	Wmove2 = LOWORD (eng.levw2); Wtime2 = HIWORD (eng.levw2) * 60; \
	Bmove1 = LOWORD (eng.levb1); Btime1 = HIWORD (eng.levb1) * 60; \
	Bmove2 = LOWORD (eng.levb2); Btime2 = HIWORD (eng.levb2) * 60;
	
MYINLINE void SetLevel (void)	// Set  engine level by leveltype.
{
	KillSecsMove		// kill Secs/move flag 
	switch (leveltype) {
	  case 0:	// Time per move..
	    nmov = 60; tpm = timepermove;
	    if (tpm > 0x7fff) {		// Overflow..
	      tpm /= 10; nmov = 6;	// Round to tens of seconds
	      if (tpm > 0x7fff) {	// Still overflow
	        tpm /= 6; nmov = 1;	// Round to minutes
	      }
	    }
	    SetUserLevel (nmov,tpm,nmov,tpm,nmov,tpm,nmov,tpm);
	    SetSecsMove		// set Secs/move flag 
	    return;
	  case 1:	// Full user ctrls.
	    SetUserLevel (WmoveCtrl1,WtimeCtrl1/60,WmoveCtrl2,WtimeCtrl2/60,
		BmoveCtrl1,BtimeCtrl1/60,BmoveCtrl2,BtimeCtrl2/60)
	    return;
	  case 2:	// Time per game
	    SetUserLevel (0,timepergame/60,0,0,0,timepergame/60,0,0)
	    return;
	  case 3:
	    eng.play_level = ((matein - 1) << 8);	// 0=mate in, hiby=depth
	    retv = ext_set_level ();
	    return;
	  case 4:
	    eng.play_level = ((easylevel - 1) << 8) + 3;	// 3=easy, hiby=depth
	    retv = ext_set_level ();
	    return;
	  case 5: 			// Infinite..
	    eng.play_level = 0x1f02;	// 2=fixed depth, 31=inf..
	    retv = ext_set_level ();
	    return;
	  case 6:
	    eng.play_level = (fixeddepth << 8) + 2;	// 2=fixed mode, hiby=depth
	    retv = ext_set_level ();
	    return;
	}
}

	// SET LEVELS dialog box..
void DlgLevels (short newleveltype)
{
	static BYTE my2lev [] = {0,0,1,6,5,0};
	static BYTE lev2my [] = {1,2,1,1,1,4,3,1,1};
	short allpos = 120 - (strlen (STall) << 2) - 2;
	const short ctly = 100;		// Y-Pos of pop-up controls..
	int cret;
	int hitbutton;
	const int MasterID = 1;
        short allbut1,allbut2;

	cret = dlg_Init (IDM2String (IDM_USERLEVELS), -1,-1,260,170,1);
	if (cret== FALSE) return ;

	dlgs.FocusID = IDD_RADIO + 1;
	dlg_DefRadio (80,10,D_SPECIAL | D_GROUPBOX | 100,14,SToptplaylevels,lev2my [newleveltype],MasterID);
	
		// The following grouped controls are dynamically selected
		//  by the above SPECIAL combo box..	
        dlgroup_New (MasterID);	 		// 1:Time per move..
	dlg_DefTimeSpin (90,ctly,timepermove,SThms,D_SECS | D_TITLE); 
	dlg_DefText (100,ctly+15,STsettimepermove); 
					// User level set..
		// Initialise Sub-group startup settings..	
		// White 1st control..	
        dlgroup_Next ();	    // 2: User level set..
        allbut1 = (WmoveCtrl1 == 0);
	if (allbut1) {WmoveCtrl1 = 60; WmoveCtrl2 = 0;}
	dlg_DefText (15,ctly+2,STwhitefirstcontrol);
        dlgroup_New (MasterID+1);	// Group 2, subgroup 1.
	dlg_DefSpin (90,ctly,3,WmoveCtrl1,1,99,1,0);
        dlgroup_Next ();
	dlg_DefText (allpos,ctly+2,STall);
        dlgroup_End ();	// End of subgroup..
	dlg_DefTimeSpinTxt (120, ctly, WtimeCtrl1, SThms, D_TITLE,STmovesin,35); 
        dlg_DefTogButton (215,ctly,STall,30,allbut1,MasterID+1);
	//DialogDef (dBUTTON, STall, IDD_FLAGBUTTONS,215,ctly,30,12,0);
		// White 2nd control..	
        allbut2 = (WmoveCtrl2 == 0);
	if (allbut2) WmoveCtrl2 = 30;
	dlg_DefText (15,ctly+17,STwhiteothercontrols);
        dlgroup_New (MasterID+2);	// Group 2, subgroup 2.
	dlg_DefSpin (90,ctly+15,3,WmoveCtrl2,1,99,1,0);
        dlgroup_Next ();
	dlg_DefText (allpos,ctly+17,STall);
        dlgroup_End ();	// End of subgroup..
	dlg_DefTimeSpinTxt (120, ctly+15, WtimeCtrl2,SThms, 0,STmovesin,35); 
        dlg_DefTogButton (215,ctly+15,STall,30,allbut1,MasterID+2);
	//DialogDef (dBUTTON, STall, IDD_FLAGBUTTONS+1,215,ctly+15,30,12,0);
	
        dlgroup_Next ();	// 
	dlg_DefSpinTxt (95,ctly+7,3,fixeddepth,1,30,1,0,STfixeddepth,45);
        dlgroup_Next ();	// 
	dlgroup_End ();	// End of grouped controls..
	
	dlg_DefOKCancel (20,10,STok,NULL,50);
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX.. 
	dlg_End ();
	if (hitbutton != IDOK) return;
	
		// Read back param stack in REVERSE order..
	fixeddepth = (short) dlg_ReadSpin ();
	BtimeCtrl2 = WtimeCtrl2 = dlg_ReadTimeSpin (0);
	BmoveCtrl2 = WmoveCtrl2 = (short) dlg_ReadSpin ();
	BtimeCtrl1 = WtimeCtrl1 = dlg_ReadTimeSpin (0);
	BmoveCtrl1 = WmoveCtrl1 = (short) dlg_ReadSpin ();
		// Set group flags for ALL moves options..	
        allbut2 = dlg_ReadTogButton ();
        allbut1 = dlg_ReadTogButton ();
	if (allbut1) BmoveCtrl1 = WmoveCtrl1 = 0;
	if (allbut2) BmoveCtrl2 = WmoveCtrl2 = 0;
	timepermove = dlg_ReadTimeSpin (D_SECS);
	leveltype = my2lev [dlg_ReadRadio ()];
	SetLevel ();		// Set the  engine level..
	levSetString ();
	//RedrawAWindow (W_CLK);	// Force clock repaint..
}


short LevelsInfo [] = {	// eng.play_level settings for menu..
	0x0006,0x0106,0x0206,0x0306,0x0506,0x0606,0x0806,0x0008,0x0108,
	0x0208,0x0308,0x0205,0x0405,0x0705,0x1f02,0,0,0};
	 
BYTE lSecs [] = {0,2,5,10,15,30,60,90,120,180};

	// Set a menu level.. IDM_ code in midm
void levSetMenu (WPARAM midm)
{
        ALY short oldml;
        oldml = levIDMmenu;		// Save in case of cancel
	levIDMmenu = midm;		// Store linear ref to play level for menu
	if (midm >= R_QUICKBEG && midm <= R_QUICKEND) {	// no further action needed
	  eng.play_level = LevelsInfo [midm - R_QUICKBEG];
	  KillSecsMove		// Not a secs/move level, unless..
	  if ((eng.play_level & 0xff) == 6) {	// Quick set secs/move
	    SetSecsMove		// Enable sec/move flag..
	    timepermove = lSecs [eng.play_level >> 8]; // Save time as default
            nmov = 60; tpm = timepermove ;
	    SetUserLevel (nmov,tpm,nmov,tpm,nmov,tpm,nmov,tpm);
	  }
	  retv = ext_set_level ();
	  levSetString ();
	  RedrawAWindow (W_CLK);	// Force clock repaint..
	} else {
	  switch (midm) {
	    case IDM_USERLEVELS:	// Menu:219
	      DlgLevels (leveltype);	// Input level dialog,,
	      if (DlgButton == IDCANCEL) levIDMmenu = oldml;
	    break;
	    case IDM_EASY:	// Menu:216
	      DlgLevels (4);
	      if (DlgButton == IDCANCEL) levIDMmenu = oldml;
	    break;
	    case IDM_MATEIN:	// Menu:217
	      DlgLevels (3);
	      if (DlgButton == IDCANCEL) levIDMmenu = oldml;
	    break;
	    case IDM_FIXEDDEPTH:	// Menu:218
	      DlgLevels (6);
	      if (DlgButton == IDCANCEL) levIDMmenu = oldml;
	    break; 
	  }
	}
	MoveBox (0);
	SearchBox ();
	InitThink (ThinkOpp);
}

void levGetMenu ()	// Determine linear menu ref (levIDMmenu) from engine (eng.play_level)
{
	ALY short clev;
	clev = eng.play_level;
	levSetString ();
	if ((eng.play_level & 0xff) == 6) {	// Quick set secs/move
	  SetSecsMove		// Enable sec/move flag..
	  timepermove = lSecs [eng.play_level >> 8]; // Save time as default
	}
		// Search levels-info for match..
	for (levIDMmenu = 0; levIDMmenu < (IDM_EASY - IDM_LVINSTANT); levIDMmenu ++) {
	  if (clev == LevelsInfo [levIDMmenu]) {	// Found it!
	    levIDMmenu += IDM_LVINSTANT;
	    return;
	  }
	}
	clev = clev & 255;
	if (clev == 0) {
	  matein = eng.play_level >> 8;		// Read for default..
	  levIDMmenu = IDM_MATEIN; return;
	}
	if (clev == 2) {
	  fixeddepth = eng.play_level >> 8;
	  levIDMmenu = IDM_FIXEDDEPTH; return;
	}
	if (clev == 3) {		// mode3=easy levels
	  easylevel = (eng.play_level >> 8) + 1;
	  levIDMmenu = IDM_EASY; return;
	}
		// Read default setting from engine variables	
	GetUserLevel (WmoveCtrl1,WtimeCtrl1,WmoveCtrl2,WtimeCtrl2,
		BmoveCtrl1,BtimeCtrl1,BmoveCtrl2,BtimeCtrl2)
	levIDMmenu = IDM_USERLEVELS;
}

	// Format a LEVXX engine var as string: all in XX:XX or XX in XX:XX
void SetLevUser (char *szLev, unsigned long clev)
{
	ALY WORD cmove;
	ALY WORD ctime;
	cmove = LOWORD (clev);
	ctime = HIWORD (clev);
	while (szLev [0]) szLev ++;	// move ptr to str end.. (concat)
	if (cmove == 0) {	// all moves..
	  wsprintf ((char far *) szLev, "%s %02d:%02d",
		(char far *) STallin, ctime / 60, ctime % 60);
	  return;
	}
	wsprintf ((char far *) szLev, " %02d %s %02d:%02d",
		cmove,(char far *) STin, ctime / 60, ctime % 60);
}

void levSetString (void)	// Set level text strings giving cur level
{
	ALY short clev;
	ALY WORD cwtime;
	WORD cwmove,cbmove;
	cwmove = LOWORD (eng.levw1);	// temps used for 1st wht ctrl
	cbmove = LOWORD (eng.levb1);
	cwtime = HIWORD (eng.levw1);
	clev = eng.play_level & 255;
	  // (loword: move number of first time control (0 if all moves)
	  // (hiword: time of first time control minutes)
	UseCount = 0;				// no countdown..
	szLevel1 [0] = szLevel2 [0] = 0;	// Erase both..
	if (eng.play_level == 0x1f02) {	// Infinite..
	  wsprintf ((char far *) szLevel1, "%s",(char far *) STinfinite);
	  return;
	}
	if (clev == 0) {	// Mate in..
	  wsprintf ((char far *) szLevel1, "%s %02d",
		(char far *) STmatein, (eng.play_level >> 8) + 1);
	  return;
	}
	if (clev == 2) {	// Fixed depth
	  wsprintf ((char far *) szLevel1, "%s %02d",
		(char far *) STfixeddepth,eng.play_level >> 8);
	  return ;
	}
	if (clev == 3) {	// Easy level.
	  wsprintf ((char far *) szLevel1, "%s %02d",
		(char far *) STeasylevel,(eng.play_level >> 8) + 1);
	  return ;
	}
	if (clev == 6 && cwmove) {	// Normal level (secs/move)
	  wsprintf ((char far *) szLevel1, "%02d:%02d %s",
		cwtime / cwmove, cwtime % cwmove,(char far *) STpermove);
	  return;
	}
		// See if simple secs per move
	if (eng.levw1 == eng.levw2 && eng.levw1 == eng.levb1 && eng.levb1 == eng.levb2 && cwmove) {
	  if (FlagSecsMove) {	// Secs per move..
	    cwtime = (short) ((long) (((long) cwtime * 60L) / cwmove) % 3600L);
	    wsprintf ((char far *) szLevel1, "%02d:%02d %s",
		cwtime / 60, cwtime % 60,(char far *) STpermove);
	    return;
	  }
	}
	UseCount = 1;			// Do a count-down..
	if (cwmove + cbmove == 0) {	// Both 1st ctrls "all mvs in.."
	  SetLevUser (szLevel1, eng.levw1);
	  if (eng.levw1 != eng.levb1) {
	    strcat (szLevel1,"    ");
	    SetLevUser (szLevel1, eng.levb1);
	  }
	  return;
	}
	SetLevUser (szLevel1, eng.levw1);	// Setup text 1st ctrl..
	if (eng.levw1 != eng.levb1) {		// If not the same, also blk
	  strcat (szLevel1,"    ");
	  SetLevUser (szLevel1, eng.levb1);
	} else if (eng.levw2 == eng.levb2) {	// Both w/b ctrls same..
	  SetLevUser (szLevel2, eng.levw2);
	  return;
	}
	if (cwmove != 0) {		// Wht 1st Not all mvs, so show 2nd
	  SetLevUser (szLevel2, eng.levw2);
	} else {			// Pad out-same spc as "all in xx:xx"
	  strcat (szLevel2,"            ");
	}
	strcat (szLevel2,"    ");
		// Blk 1st Not all mvs, show 2nd	
	if (cbmove != 0) {
	  SetLevUser (szLevel2, eng.levb2);
	} else {			// Pad out
	  strcat (szLevel2,"            ");
	}
}


//---------------------------------------------------------------------
//  Countdown clocks..
//


void SetACount (char *szLev, ULONG clev, ULONG clev2, long elaptime, short elapmove)
{
	WORD cmove = LOWORD (clev);	// moves for ctrl, 0=all
	WORD ctime = HIWORD (clev);	// time in mins
	long ttime = ((long) ctime * 60L) - elaptime;
	short mvleft = cmove - elapmove;
CountAgain:		// Reloop point..
	if (cmove == 0) { // STplay (all in)..
	  if (ttime < 0) goto ExceedTime;
	  memcpy (szLev, STplay,6);
	  time2asc (szLev + 6, ttime,1);
	} else {
	  if (mvleft > 0) {	// not yet reached this time ctrl..
	    if (ttime < 0) goto ExceedTime;
	    int2asc (szLev, mvleft,2);
	    memcpy (szLev + 3, STin,2);
	    time2asc (szLev + 6, ttime ,1);
	  } else {		// Time ctrl reached, calc next ctrl..
	    cmove = LOWORD (clev2);	// moves for ctrl, 0=all
	    ctime = HIWORD (clev2);	// time in mins
	    ttime += (long) ctime * 60L;  // add in xtra time
	    mvleft += cmove;		// add next lot of time ctrl moves..
	    goto CountAgain;		// Recurse to calc next lot..
	  }
	}
	return;
ExceedTime:
	if (ttime == -1) ExceededTime |= 0xf0;	// Make a noise when time up..
	ExceededTime |= 1;
	memcpy (szLev, STexceededtime, strlen (STexceededtime));
}

 // Build a string giving countdown info..
 // ExceededTime: bit0= black over, bit1=white over, bit 5=just exceeded (noise)
void SetCountdownStr ()
{
	short clev = eng.play_level & 255;
	WORD cwmove = LOWORD (eng.levw1);	// temps used for 1st wht ctrl
	WORD cbmove = LOWORD (eng.levb1);
	WORD cwtime = HIWORD (eng.levw1);
	short cpos;
	  // (loword: move number of first time control (0 if all moves)
	  // (hiword: time of first time control minutes)
	szCount [0] = 0;
	ExceededTime = 0;
	if (UseCount == 0) return;  // no countdown info
	for (cpos = 0; cpos < SIZEfullclk; cpos ++) {
	  szCount [cpos] = 32;
	}
	szCount [cpos] = 0;
	SetACount (szCount, eng.levw1, eng.levw2, eng.white_time, (eng.move_number + 1) >> 1);
	ExceededTime <<= 1;	// Shift 1 left
	SetACount (szCount + 15, eng.levb1, eng.levb2, eng.black_time, eng.move_number >> 1);
}

CHOOSEFONT chf;		// Struct for choosing a font..

  // Create the current font in (eng.mainlogf) & select into hWDC..
  // MODE - bit 0 set = Also delete old first
  // MODE - bit 1 set = Select default genius set.
	
void ResetFonts (short mode)
{
	if ((mode & 1) && hFont) {	// Delete old font from mem
	  SelectObject (hWDC,hSysFont);
	  DeleteMyObject (hFont);
	}
	if (mode & 2) {		// Reset to default font
	  _fmemset (&eng.mainlogf, 0, sizeof (LOGFONT));	// clr struct
	  ((LOGFONT *) &eng.mainlogf)->lfHeight = -12;	// default
	  ((LOGFONT *) &eng.mainlogf)->lfPitchAndFamily = FIXED_PITCH;	// default pitch
	  strcpy (((LOGFONT *) &eng.mainlogf)->lfFaceName,DEFAULT_FONT);// Font name to select
	}
	hFont = CreateFontIndirect((LOGFONT *) &eng.mainlogf);   // create new logical font
	eng.anyfont = 1;		// new font was chosen
	if (hFont == NULL) {		// Could not do it, select system..
	  hFont = GetStockObject (SYSTEM_FIXED_FONT);
	  eng.anyfont = 0;		// no loadable font was chosen
	}
	SelectObject(hWDC, hFont);	// select it 
	CalcMetrics (hWDC, &chrx, &chry);	// Get font size..
}

void DlgFonts ()	// Choose a screen font..
{
	BOOL fresult;
		// Fill the choose font structure
	_fmemset ((LPCHOOSEFONT) &chf, 0, sizeof (CHOOSEFONT));	// clr struct
	chf.lStructSize = sizeof(CHOOSEFONT);	// struct size
	chf.hwndOwner = hMainWnd;      		// owner window
	chf.lpLogFont = (LOGFONT *) &eng.mainlogf;		// Struct Addr
	chf.Flags = CF_SCREENFONTS | CF_FIXEDPITCHONLY	// screen fonts
		| CF_INITTOLOGFONTSTRUCT 	// default data in (eng.mainlogf)
		| CF_FORCEFONTEXIST;		// Only accept legal fonts.
	LockFocus ();
	fresult = ChooseFont (&chf);
	ReleaseFocus ();
	if (fresult) {	// get new font from user (results in eng.mainlogf)
	  ResetFonts (1);
		// Set graphic piece display for font..	  
	  if ((tolower (((LOGFONT *) &eng.mainlogf)->lfFaceName [0]) == 'g') ^ (FlagFigurine != 0)) {
	    TogFigurine
	    SetPiecePtrs ();		// Set STpieces to new ptr..
	  }
	  RedrawAllWindows ();
	  return;
	}
}


void DlgWindows ()	// Toggle child/popup windows..
{	
	ALY short wtx,wty;
	Dink ();
	ProcessFloatingWindows (0);
	TogPopUp
	ProcessFloatingWindows (3);	// Re-align for new mode..
	GetMainInfo ();
		// Adjust popup window position..
	wtx = (short) (mainrct.left - absmain.left);
	wty = (short) (mainrct.top - absmain.top);
	if (FlagPopUp) { // Add main wnd pos to this window pos
	  wtx = -wtx; wty = -wty;
	}
	popdlgwnd.tx += wtx;
	popdlgwnd.ty += wty;
}

	// Start next anal.. (mode set to step to next first)
void NextAnal (short mode) 
{
	ALY short tstep;		// temp to flag step fwd
	tstep = 0;
	if (mode) {
	  int_step_move2 (1);	// Step to next move
	  PrintSearch (FileMode);// Print last anal to prn/file if FileMode..
	  analy2Comment ();
	}
		// Skip a move for this side?	
	if (eng.move_number & 1) {	// Black move
	  if (!(eng.play_mode & 2)) tstep = 1;
	} else {
	  if (!(eng.play_mode & 1)) tstep = 1;
	}
	if (tstep) {
	  int_step_move2 (1);	// Skip a move..
	  PrintSearch (1);	// Print last move to prn/file if FileMode.. (no anal)
	}
	FastMakeMove (); // Fast Make moves on screen, update VDU board
	InitThink (ThinkComp);
	if (eng.game_status) {		// End of game - end anal.
	  eng.play_mode = PlayNormal;
	  SoundIt ();
	  InitThink (ThinkNone);
	}
}
	    
short DlgAnalyse ()	// Dialog box for analyse
{
	char szAnal [100];	// temp area to build string..
	int cret;
	int hitbutton;

	cret = dlg_Init (IDM2String (IDM_ANALYSE), -1,30,200,110,1);
	if (cret== FALSE) return 0;

		// Build Analyse game string
	wsprintf ((LPSTR) szAnal,"%s (%d-%d)",(LPSTR) STanalysegame,
		(eng.move_number >> 1) + 1, (LastMove () >> 1) + 1);
	dlg_DefTextCent (-1,20,szAnal);	// Centered text field
		// Combo for anal wh/bl/both sides select
	dlg_DefCombo (SToptanalsides,65,35,70,40,2,0);
	dlg_DefOKCancel (10,10,STok,NULL,40);
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();

	if (hitbutton != IDOK) return 0;
	eng.play_mode = dlg_ReadCombo () + 0x41;	// Calc play mode setting
	return 1;
}


  // Start new game dialog..
short DlgNewGame ()
{
        const int MasterID = 1;
	static FLAGDATA ChkFlg [7] = {
	  &VarInitCol,  BitInitCol, 0, //&STchkwhitestarts,
	  &VarInvNum,   BitInvNum,  0, //&STchkinvertnum,
	  &VarChessNot, BitChessNot,0, //&STchkchessnot,
	  &VarCornMode, BitCornMode,0, //&STchkinvertplay,
	  &VarLightA1,  BitLightA1 ,0, //&STchklighta1,
	  &dummy,0,0,NULL		// Terminator
	};                 
        BYTE cgamtype = eng.gamtype + 2;	//ff=usr,0=eng,1=ital
	int cret;
	int hitbutton;

	cret = dlg_Init (IDM2String (IDM_NEWGAME), -1,-1,200,210,1);
	if (cret== FALSE) return 0;

	StopThinking ();
	StopAutoPlay ();	// If comp v comp, back to normal

	dlgs.FocusID = IDD_COMBO + 1;
	dlg_DefTextCent (-1,15,STnewsure);
        dlg_DefRadio (20,30,(short) D_SPECIAL | D_GROUPBOX | 100,12,SToptgametype,max (1,cgamtype),MasterID);
	// ComboDef (SToptgametype,70,30,60,40,cgamtype,DD_SPECIAL);
	
		// The following grouped controls are dynamically selected
		//  by the above SPECIAL combo box..	
        dlgroup_New (MasterID);	    // User Defined
	dlg_DefCombo (SToptgamerules,20,90,70,40,eng.gamrules,0);
	dlg_DefSpinTxt (20,115,3,eng.boardx,4,12,1,0,STboardx,44);
	dlg_DefSpinTxt (20,140,3,eng.boardy,4,12,1,0,STboardy,44);
	dlg_DefSpinTxt (20,165,3,eng.menperside,1,40,1,0,STmenperside,44);
	dlg_DefTicks (ChkFlg, 110,90, 120,18, 250,160,SToptnew);
        dlgroup_Next ();	// English
        dlgroup_Next ();	// Dama Italiana
        dlgroup_End ();	// End of grouped controls..

	dlg_DefOKCancel (10,10,STok,NULL,40);
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	if (hitbutton != IDOK) return 0;
	dlg_ReadTicks (ChkFlg);			// Read back tick-flag data
	eng.gamrules = (BYTE) dlg_ReadCombo ();		// 0=eng,1=ital
	eng.menperside = (BYTE) dlg_ReadSpin ();
	eng.boardy = (short) dlg_ReadSpin ();
	eng.boardx = (short) dlg_ReadSpin ();
	eng.gamtype = (BYTE) dlg_ReadRadio () - 2;	//ff=usr,0=eng,1=ital
	return (1);
}

char *ParsePtr,*ParseBeg;

short ParseInt ()		// Read an short from (ParsePtr), -32767=error
{
	ALY short tmp;
	short cchr;
	ParseBeg = ParsePtr;
	tmp = atoi (ParsePtr);		// get short value
	//printsi (",",tmp);
	cchr = *ParsePtr;
	if ((isdigit (cchr) | isspace (cchr)) == 0) return -32767;
	while (isdigit (cchr) | isspace (cchr)) {
	  ParsePtr ++;
	  cchr = *ParsePtr;
	}
	if (*ParsePtr == ',') ParsePtr ++;
	return tmp;
}

	// Read a string from (ParsePtr), add NULL. Ret end char.
short ParseStr ()
{
	char cchr;
	ParseBeg = ParsePtr;
	while (cchr = *ParsePtr, 
	  cchr != ',' && cchr != 0 && cchr != ';') {
	    ParsePtr ++;
	}
	*ParsePtr = 0;		// Null term string..
	ParsePtr ++;
	return (cchr);
}

	// Load pos on line (cEPD) from the current EPD file into EPD brd
	// If wmode set, write back last analysis to file at (cEPD-1)..
	// This is done to a temp file first, which then overwrites main.
	// Ret 0=error or EOF, 1=ok.
short LoadEPD (short cEPD, short wmode)
{
	HFILE hEPDfile = NO_FILE;	// handle to input file..
	HFILE hEPDtemp = NO_FILE;	// handle to temp output file..
	ALY short nread;
		// Exit: 0= error, 1=ok, 2= EOF, but writeback first.	
	short exitmode = 0;		// handle exit error etc
	#define EPDTEMPFILE "$epdtmp.$pd"
		// Open input .EPD file	
	hEPDfile = OpenFile (szEPDfile, &ofBuf, OF_READ);
	if (hEPDfile == NO_FILE) return 0;
	if (wmode) {	// open temp write file
	  hEPDtemp = OpenFile (EPDTEMPFILE, &ofBuf, OF_CREATE);
	  if (hEPDtemp == NO_FILE) {
	    _lclose (hEPDfile);
	    return 0;
	  }
	}
	while (cEPD) {	// Spool past early lines..
		// Read an asc line from input file
	  if (LineInput (hEPDfile, szTemp, SIZEszTemp,0) < 0) {
	    if (cEPD > 1) goto LoadEPDerror;	// EOF encountered, error..
	    exitmode = 2;	// If last line, do writeback
	    goto SpoolRest;
	  }
	  if (cEPD < 3) {		// Also parse..
		// Try to parse asc EPD line into a position at EPD.brd..
	    nread = ConvertAsc2Pos (szTemp, &EPD);
	    if (nread == 0) {	// Parse error, bad position..
	      if (wmode) {
		LineOutput (hEPDtemp, szTemp);	// Write line to out file
	      }
	      if (cEPD > 1) goto LoadEPDerror;
	      exitmode = 2;	// If last line, do writeback
	      goto SpoolRest;
	    }
	  }
	  if (wmode) {		// Writeback mode..
	    if (cEPD == 2) {	// Append analysis to end of szTemp..
	      Panaly = (ANALY far *) &eng.analy_moveno;
	      tprintflag = 3;			// Enable prn to buffer
	      PrtBuffer = szTemp + nread;	// End of curr line = prn loc
	      PrtCount = SIZEszTemp - nread;	// Max chars to out
	      prints (" ce ");
		// Print the score - nn.nn, or book or mate in..	  
	      EPDPrintEval (Panaly->scorelo, Panaly->scorehi);
		// Print best line: 12 moves, no padding.
	      prints ("; pv ");
	      PrintBestLine (-12,6);
	      printc (';');
	      printc (0);			// add null term to string.
	      tprintflag = PrtCount = 0;	// Prn to buffer off
	    }
		// Write a null term str to out file, adding CR/LF..	  
	    LineOutput (hEPDtemp, szTemp);
	  }
	  cEPD --;
	}
	exitmode = 1;		// means sucsess!
SpoolRest:			// Spool any remainder to out file
	if (wmode) {		// if write mode, spool rest of out-file..
	  while (1) {
		// Read an asc line from input file
	    if (LineInput (hEPDfile, szTemp, SIZEszTemp,0) < 0) {
	      break;		// EOF encountered, end..
	    }
	    LineOutput (hEPDtemp, szTemp);	// Write line to out file
	  }
	}
LoadEPDerror:
	_lclose (hEPDfile);	// Close read file
	if (wmode) {		// Deal with writeback stuff..
	  _lclose (hEPDtemp);	// Close write file
	  if (exitmode) {	// If ok, write back new file.
	    CopyAFile (EPDTEMPFILE, szEPDfile);
	  }
	}
	return (exitmode == 1);	// 1 = Sucessful load!
}

	// Go to next EPD anal.. 
	// nmode == 0 for just load, set for load, write anal & start anal..
short NextEPD (short nmode)
{
	register short bpos;
	CurEPD ++;
	if (LoadEPD (CurEPD, nmode) == 0) {	// No more, end
	  CurEPD = 0;
	  goto EndNextEPD;
	}
	//DoMessage ("OK,loaded");
	for (bpos = 0; bpos < 64; bpos ++) {	// Copy EPD board to cur.
	  eng.checker_board [bpos] = EPD.brd [bpos];
	}
	eng.param_ax_pass = (WORD) EPD.side	// 0 wht,1=blk to move
	  | (((WORD) EPD.castle) << 8);	// Set castling status & EP capture sqr in (ah)
	retv = ext_set_board_pos (); 
	FastMakeMove (); // Update VDU board
	if (eng.game_status) {		// Error in pos set..
	  DoMessage (GameStatusText ());
	  NewGame (0);
	  eng2brd ();
	  DrawBoard ();
	  goto EndNextEPD;
	}
	if (nmode) {
	  InitThink (ThinkComp);	// Start think on new EPD..
	} else {
	  InitThink (ThinkOpp);
	}
	return 1;
EndNextEPD:		// No more, end EPD mode	
	eng.play_mode = PlayNormal;
	SoundIt ();
	InitThink (ThinkOpp);
	return 0;
}


  // Print cur SAGE pos as an EPD line
MYINLINE void PrintEPD ()
{
	ConvertPos2Asc (szTemp, eng.checker_board, eng.move_number & 1,0);
	prints (szTemp);
}


	// Add current board position to start of EPD file
void ExportEPD ()
{
	HFILE hEPDFile = 0;
	int cret;
	int ceval;
	if (SaveDialog (szPath, STepdfilter, IDM_EXPORTEPD,0) == FALSE) {	// Cancel/Error
	  return;
	}
		// Dialog box to eval..
	cret = dlg_Init (IDM2String (IDM_EXPORTEPD), -1,-1,120,100,1);
	if (cret== FALSE) return ;
	dlgs.FocusID = IDD_SPIN + 1;
	dlg_DefSpin (36,37,5,0,-9999,9999,1,0);
	dlg_DefTextCent (-1,25,"Enter pos evaluation in 1/100ths.. ");
	dlg_DefOKCancel (10,10,STok,NULL,40);
	cret = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	if (cret != IDOK) return;
	ceval = (short) dlg_ReadSpin ();
	szTemp [0] = 13;		// temp buff start
	SetWaitCursor			// Hour glass mouse..     
	hEPDFile = OpenFile (szPath, &ofBuf, OF_READWRITE); 
	if (hEPDFile == NO_FILE) {	// cannot read source
	  hEPDFile = OpenFile (szPath, &ofBuf, OF_CREATE); 
	  if (hEPDFile == NO_FILE) {	// cannot write
	    goto ExportEPDError;
	  }
	} else {		// Read old ok, goto (end-2)..
	  if (_llseek (hEPDFile, -2L, 2) == HFILE_ERROR) {
	    goto ExportEPDError;
	  }
	  _lread (hEPDFile, szTemp,2);	// Read last two chars prev line..
	}
	tprintflag = 3;			// Enable Prn to buffer
	PrtBuffer = szTemp;		// End of curr line = prn loc
	PrtCount = SIZEszTemp;	// Max chars to out
	if (szTemp [0] != 13) {		// If prev line didnt have CR/LF
	  printc (13); printc (10);	// Add them!	
	}
	PrintEPD ();
	printc (0);
	PrtCount = tprintflag = 0;
	if (ceval) wsprintf (szTemp + strlen(szTemp), " ce %c%04d",(ceval < 0) ? '-':' ',(ceval < 0) ? -ceval : ceval);
	LineOutput (hEPDFile, szTemp);
ExportEPDError:
	_lclose(hEPDFile); 
	SetNormCursor         // Normal mouse..     
	return ;
}

  // Input DPD import file, select line..
void ImportEPD (WPARAM wParam)
{
	int cret;
	int hitbutton;
	StopAutoPlay ();	// If comp v comp, back to normal
	if (wParam == IDM_IMPORTEPD) {
	  if (OpenDialog (szEPDfile, STepdfilter, IDM_IMPORTEPD) == FALSE) return;
	  StopThinking ();
		// Dialog box to input 	
	  cret = dlg_Init (IDM2String (IDM_IMPORTEPD), -1,-1,120,100,1);
	  if (cret== FALSE) return ;
	  dlgs.FocusID = IDD_SPIN + 1;
	  dlg_DefSpin (36,37,3,CurEPD + 1,1,99,1,0);
	  dlg_DefTextCent (-1,25,STimportepdline);
	  dlg_DefOKCancel (10,10,STok,NULL,40);
	  hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
          dlg_End ();
	  if (hitbutton != IDOK) return;
	  CurEPD = (short) dlg_ReadSpin () - 1;
	} else {	// Just load next dpd..
	  StopThinking ();
	}
		// Now load that EPD from szEPDfile	
	if (NextEPD (0) == 0) {
	  DoMessage (STEinvalidfile);
	}
	InitThink (ThinkOpp);
}

	// Output to printer/file spool functions..


void OpenFileBuf (char *ifile)		// Open spool file
{
	hOutFile = OpenFile ((LPSTR) ifile, &ofBuf, OF_CREATE);
}

void FlushFileBuf (short fmode)	// Write buf to file, also close if (fmode)
{
	if (hOutFile == NO_FILE) return;
	_lwrite (hOutFile,FileBuf,iFileBuf);
	iFileBuf = 0;
	if (fmode) {		// Also close file,,
	  if (PageLen) {
	    PrintFlush (1);	// Send any left over print to printer.
	  }
	  _lclose (hOutFile);
	  hOutFile = NO_FILE;
	}
}

void fprintc (short ichr) 	// Print a char to spooled output file..
{
	nprint ++;
	if (hOutFile == NO_FILE) return;
	if (iFileBuf >= MFileBuf) {		// Buf full, print it..
	  FlushFileBuf (0);
	}
		// Add char to buffer
	FileBuf [iFileBuf] = (BYTE) ichr;
	iFileBuf ++;
	
	if (PageLen) {		// Printing to printer via buffer file..
	  if (ichr == 13) {	// Line end, inc count, flush to prn?
	    cPrnLine ++;
	    if (cPrnLine >= PageLen) {	// End of page, print page..
	      FlushFileBuf (0);		// Flush any left over to prn file.
	      PrintFlush (0);		// Flush temp prn file to prn..
	    }
	  }
	}
}

void PrintEnd ()	// Terminate printing process
{
	if (hPrnFont) {				// Any printer font?
	  SelectObject (prnd.hDC, hOldPrnFont);	// select old
	  DeleteMyObject (hPrnFont);		// Kill font
	  hPrnFont = NULL;
	}
	       // Tidy & end..
	DeleteDC(prnd.hDC);
	if(prnd.hDevMode != NULL)
	  GlobalFree(prnd.hDevMode);
	if(prnd.hDevNames != NULL)
	  GlobalFree(prnd.hDevNames);
	PageLen = 0;		// Disable further printing
}

char InBuf [400];
#define IBsize ((short) sizeof (InBuf) - 10)

	// Flush print buffer file to printer..
	// opens printer DC, prints, then ends.
void PrintFlush (short mode)
{
	short nread,cread,lastread;
	short prposy;
	_lclose (hOutFile);		// Close old file
	SetWaitCursor         // Hour glass mouse..     
	BeepSnd ();
	//StartDoc (prnd.hDC, &di);	// tell printer new document
	StartDoc (prnd.hDC, &di);	// tell printer new document
	StartPage (prnd.hDC);		// tell printer start new page
	if (hPrnFont) SelectObject (prnd.hDC, hPrnFont);// select font
	prposy = 0;
	lastread = 0;
	hInFile = OpenFile (PRN_FILENAME, &ofBuf, OF_READ);
	do {
		// Read a buffer load of info from spool file.	
	  nread = _lread (hInFile,InBuf + lastread,IBsize - lastread);
	  nread += lastread;
	  lastread = 0;
		// Now print that buffer, splitting lines at (CR) as we go..	  
	  for (cread = 0; cread < nread; cread ++) {
	    if (InBuf [cread] == 13) {	// Next line found..
	      if (InBuf [lastread] == 10) lastread ++;
	      if (cread > lastread) {
		TextOut (prnd.hDC, 1, prposy, InBuf + lastread, cread - lastread);
	      }
	      lastread = cread + 1;
	      prposy += prny;		// next line..
	    }
	  }
		// Now move any left-over back to start of next buffer..	  
	  for (cread = lastread; cread < nread; cread ++) {
	    InBuf [cread - lastread] = InBuf [cread];
	  }
	  lastread = nread - lastread;
	} while (nread == IBsize);
	if (lastread > 1) {	// Print any left over
	  TextOut (prnd.hDC, 1, prposy, InBuf + 1, lastread - 1);
	}
	_lclose (hInFile);		// Close old file
	
	OpenFileBuf (PRN_FILENAME);	// Re-open spool for next page..
	if (EndPage (prnd.hDC) < 0) {	// tell printer to end page - error?
	  mode = 1;		// End job..
	}
	EndDoc (prnd.hDC);		// tell printer print that page!
	if (mode || hOutFile == NO_FILE) {	// End print job
	  PrintEnd ();
	}
	BeepSnd ();
	cPrnLine = 1;
	SetNormCursor         // Normal mouse..     
}

short DlgPrnFonts ()	// Choose a screen font..
{
	BOOL fresult;
		// Fill the choose font structure
	_fmemset ((LPCHOOSEFONT) &chf, 0, sizeof (CHOOSEFONT));	// clr struct
	chf.lStructSize = sizeof(CHOOSEFONT);	// struct size
	chf.hwndOwner = hMainWnd;      		// owner window
	chf.lpLogFont = &lfPrint;		// Struct Addr
	chf.hDC = prnd.hDC;			// Printer device context
	chf.Flags = CF_PRINTERFONTS		// printer fonts
		| CF_INITTOLOGFONTSTRUCT 	// default data in (eng.mainlogf)
		| CF_FORCEFONTEXIST;		// Only accept legal fonts.
	LockFocus ();
	fresult = ChooseFont (&chf);
	ReleaseFocus ();
	if (fresult == FALSE) return (0);	// failed
		// get new font from user (results in eng.mainlogf)
	return (1);	// ok..
}


  // Open dialog for redirection - ret 0=fail, 1=ok,,
short DlgOutputGame (short cidm)
{
	char *istr = SToutputto;
	int cret;
	int hitbutton;

	if (IDM2String (cidm)) {	// If IDM spec, use text from menu..
	  wsprintf (szTemp, "%s - %s",(LPSTR) MenuStr,(LPSTR) SToutputto);
	  istr =  szTemp;
	}
	cret = dlg_Init (istr, -1,-1,300,60,1);
	if (cret== FALSE) return 0;

	if (cidm == IDM_EXPORTPOS) {	// Force right charset..
	  selgtype = 2;
	} else {
	  if (selgtype == 2) selgtype = 1;
	}
	//ComboTDef (SToptgraphictypes,65,35,70,40,selgtype,0,STpiecegraphics);
	dlg_Define (dBUTTON, STprinterfont, IDD_BUTTONS + 3,  20,20,60,14,0);  
	dlg_Define (dBUTTON, STprint,       IDD_BUTTONS + 1,  90,20,60,14,0);  
	dlg_Define (dBUTTON, STcancel,      IDCANCEL,        160,20,60,14,0);  
	dlg_Define (dBUTTON, STfile,        IDD_BUTTONS + 2, 230,20,60,14,0);  
	
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	//selgtype = ReadCombo ();
	
	//STpiecesprn = STpiecesa;
	//if (selgtype == 1) {		// Genius/chessbase..
	//  STpiecesprn = STpiecesg;
	//}
	//if (selgtype == 2) {		// Tilburg..
	//  STpiecesprn = STpiecetil;
	//}
	if (hitbutton == IDCANCEL) return (0);
	
		// Initialise Output to file...
	if (hitbutton == IDD_BUTTONS + 2) {
	  if ( SaveDialog (szPath, STtxtfilter,0,1) == FALSE) return (0);
	  OpenFileBuf (szPath);
	  wsprintf ((LPSTR) szExportInfo, "%.25s \x22%.14s\x22)",
	    	(LPSTR) Strings [IDM_EXPORTTODISK],(LPSTR) szTitle);
	  if (hOutFile == NO_FILE) return (0);
	  return (1);
	}
	  // Otherwise init output to printer..
	  // set up PRINTDLG structure for PrintDlg()
	memset( &prnd, 0, sizeof(PRINTDLG) );	// clear it
	prnd.lStructSize = sizeof(PRINTDLG);	// size
	prnd.hwndOwner = hMainWnd;		// our window
	prnd.Flags = PD_RETURNDC |	// return dev context
		   PD_NOPAGENUMS |	// gray Pages button 
		   PD_NOSELECTION |	// gray Selection button
		   PD_HIDEPRINTTOFILE;	// hide Print-to-file

               // call Print Dialog Box.. (SET a printer DC..)
	if( PrintDlg (&prnd) == FALSE) return (0); // if null return, abort.
        pagex = GetDeviceCaps (prnd.hDC, HORZRES);	// # pixels on page
	pagey = GetDeviceCaps (prnd.hDC, VERTRES);
	prlpix = GetDeviceCaps (prnd.hDC, LOGPIXELSX);	// Pixels/inch
	prlpiy = GetDeviceCaps (prnd.hDC, LOGPIXELSY);
	
	if (selgtype != lastselg) { // New selection-or 1st use, set a default
	    
	  if (selgtype == 0) {	// Normal font..
	    	// copy preset struct (lfPrnNorm) with default info..
	    memcpy (&lfPrint, &lfPrnNorm, sizeof (lfPrint));
	  } 
	  if (selgtype == 1) {	// Genius font..
	    	// copy preset struct (lfGenNorm) with default info..
	    memcpy (&lfPrint, &lfGenNorm, sizeof (lfPrint));
	  }
	  if (selgtype == 2) {	// Tilburg font..
	  	// copy preset struct (lfTilNorm) with default info..
	    memcpy (&lfPrint, &lfTilNorm, sizeof (lfPrint));
	  }
	}
	if (hitbutton == IDD_BUTTONS + 3) {	// Printer font select..
	  if (DlgPrnFonts () == 0) {
	    PrintEnd ();			// Cancel hit..
	    return 0;
	  }
	  	// Scale, so its same for all prn..
	}
	lastselg = selgtype;	// save last selection type..
	{	// Try to create new logical font from spec in (lfPrint)
	  short oldlfh = (short) lfPrint.lfHeight;
	  prnscale = ((long) PrnSize * prlpiy) / 100;	// % to scale..
	  		// Scale up by (prnscale) %..
	  lfPrint.lfHeight = (short) ((long) ((long) oldlfh * prnscale) / 100);
	  hPrnFont = CreateFontIndirect (&lfPrint);
	  lfPrint.lfHeight = oldlfh;		// get old height back..
	}
	PageLen = 0;
	if (hPrnFont) {				// Any printer font?
	  hOldPrnFont = SelectObject (prnd.hDC, hPrnFont);	// select it 
	}
	OpenFileBuf (PRN_FILENAME);	// Spool filename for printer
	if (hOutFile == NO_FILE) return (0);	// Can't open..
	
	
	       // Read Printer output dimensions..
	GetTextMetrics (prnd.hDC, &cprn);	
	prnx = (short) cprn.tmMaxCharWidth;			// Char width.
	prny = (short) (cprn.tmHeight + cprn.tmExternalLeading);	// Char height
	pmaxx = pagex / prnx; pmaxy = pagey / prny;	// chrs/page
	//prtx = prlpix / 3; prty = prlpiy / 3;		// 1/3 inch..
		// Calc lines per page (-1/16th for margin)
	PageLen = pagey/ prny; PageLen -= (PageLen >> 4);
	       // Make Printer ready
	di.cbSize = sizeof(DOCINFO);  // set DOCINFO struct
	di.lpszDocName = szDocName;   // for StartDoc()
	di.lpszOutput = NULL;
	// StartPage(prnd.hDC);      // tell printer new page
	// EndPage(prnd.hDC);        // tell printer end page
	cPrnLine = 1;		// Current printer line.
	return (1);		// Ok, sucsessful..
}

	// Toggle RECORD MOVES [AND ANALYSIS] mode..
short SetExportMode (WPARAM cidm)
{ 
	if (FileMode) {		// Already spooling, close..
	  FlushFileBuf (1);		// Flush old, close..
	  FileMode = 0;		
	  return 1;
	}
	
	//short tmode = 1;		// Moves only (IDM_RECORDGAME)
	//if (cidm == IDM_RECORDGAMANAL) tmode = 2; // Full analysis
	//if (cidm == IDM_SETEXPORTOPT) tmode = 4; // Open export option..
	if (DlgOutputGame (cidm) == FALSE) {	// Open dlg..
	  return 0;		// Fails..
	}
	FileMode = 2;
	return 1;	// ok, sucsessful
}


  //
  // MENU SET-UP & UPDATE FUNCTIONS..
  //

void settick (short menuitem, short cstatus)	// Update 1 menu item
{
	if (cstatus) {
	  CheckMenuItem (hMenu,menuitem,MF_BYCOMMAND | MF_CHECKED);
	} else {
	  CheckMenuItem (hMenu,menuitem,MF_BYCOMMAND | MF_UNCHECKED);
	}
}

void setgray (short menuitem, short cstatus)	// Update 1 menu item
{
	if (cstatus) {
	  EnableMenuItem (hMenu,menuitem,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	} else {
	  EnableMenuItem (hMenu,menuitem,MF_BYCOMMAND | MF_ENABLED );
	}
}

short buildstatus (void)		// Work out bitwise status flag..
{
	short statflag = (short) 0x8000;		// bitwise status flag..
	// bit0= is thinking,1=not th,2=cant tb,3=cant fwd,4=cant nextbest
	// bit 5=game over, cant move.
	// bit 6=
	// bit 7=gray edit userbook
	// bit 8=gray add userbook
	if (ThinkMode == ThinkComp) {
	  statflag |= 1;
	} else {
	  statflag |= 2;
	}
	if (!FlagBackOk) statflag |= 4;
	if (!FlagFwdOk) statflag |= 8;
	if (!FlagNextBOk) statflag |= 0x10;
	if (eng.game_status) statflag |= 0x20;	// game is over
	if ((Phint_move->from & 0x3f) == (Phint_move->to & 0x3f)) statflag |= 0x40;
	eng.param_ax_pass = 4; retv = ext_userbook (); // test userbook status
	if (!(retv & 1)) statflag |= 0x80;		// edit userbook ok
	if (!(retv & 2)) statflag |= 0x100;	// add line to userbook ok..
	  //bit 0 set if database is open. if set then _dbase_gamecount gives total no. of games
	//if (!(dbase_flag & 1)) statflag |= 0x200;
	  //bit 1 set if game has been loaded and following long word gives the number
	//if (!(dbase_flag & 2)) statflag |= 0x400;
	return (statflag);
}

void MenuGraying (void)
{
	short cidm;
	short statflag = buildstatus ();
		// Ok, scan menu data, graying/ungraying items..	
	for (cidm = 1; cidm <= nidms; cidm ++ ) {
	  if (menubits [cidm] & statflag) {	// Should be grayed
	//    if ((menubits [cidm] & 0x80) == 0) { // Not, so gray it
	      EnableMenuItem (hMenu,menuidms [cidm],
		MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	//      menubits [cidm] ^= 0x80;		// Store grayed status
	//    }
	  } else {			// Should be ungrayed
	//    if ((menubits [cidm] & 0x80) == 0) { // Not, so ungray it
	      EnableMenuItem (hMenu,menuidms [cidm],MF_BYCOMMAND | MF_ENABLED);
	//      menubits [cidm] ^= 0x80;		// Store ungrayed status
	//    }
	  }
	} 
}

void MenuFlags (void)		// Update menu ticks according to flags.
{
	short cmenu;
	MenuGraying ();
	//#if FlagALTLAYOUT
	  settick (IDM_SLIDE,FlagSlide);
	  settick (IDM_SOUND, FlagSound);
	  settick (IDM_2NDANAL, FlagExtraAnal);
	  settick (IDM_FULLANAL, FlagFullAnal);
	//#else
		// Windows ticks..
	  settick (IDM_SEARCH, FlagMainAnal);
	  settick (IDM_MOVEBOX, FlagMoveBox);
	  settick (IDM_BOARD, FlagBoard);
	//#endif
	settick (IDM_ANALY2COMMENT, analy2ComFlag);
	settick (IDM_PDNDISPLAY, Flag_(PgnMoves));
	settick (IDM_PDNNUMBERING, movenumbering);
	settick (IDM_INVERT, FlagInvert);
	settick (IDM_NUMBERING, FlagNumbering);
	
	settick (IDM_MAINBOOK, FlagMainBook);
	settick (IDM_SHOWBOOK, FlagBookMoves);
	settick (IDM_WINDOWS, FlagPopUp);
	settick (IDM_CLOCK, FlagClock);
	
	settick (IDM_SETEXPORTOPT,FileMode);
       
	settick (IDM_NORMAL, (eng.play_mode == PlayNormal));
	settick (IDM_2PLAYER, (eng.play_mode == PlayTwo));
	settick (IDM_COMPVCOMP, (eng.play_mode == PlayAuto));
	settick (IDM_COMPVCOMPCONT, (eng.play_mode == PlayCont));
	settick (IDM_ANALYSE, (IsPlayAnalMode));
	
	for (cmenu = R_LEVBEG; cmenu <= R_LEVEND; cmenu ++) {
	  if (levIDMmenu == cmenu) {
	    settick (cmenu,1);
	  } else {
	    settick (cmenu,0);
	  }
	}
	for (cmenu = IDM_ENGLISH; cmenu <= IDM_LANG9; cmenu ++) {
	  if (eng.language == cmenu - IDM_ENGLISH) {
	    settick (cmenu,1);
	  } else {
	    settick (cmenu,0);
	  }
	}
}

#define CtrlA 301
#define CtrlB 302
#define CtrlC 303
#define CtrlD 304
#define CtrlE 305
#define CtrlF 306
#define CtrlG 307
#define CtrlH 308
#define CtrlI 309
#define CtrlJ 310
#define CtrlK 311
#define CtrlL 312
#define CtrlM 313
#define CtrlN 314
#define CtrlO 315
#define CtrlP 316
#define CtrlQ 317
#define CtrlR 318
#define CtrlS 319
#define CtrlT 320
#define CtrlU 321
#define CtrlV 322
#define CtrlW 323
#define CtrlX 324
#define CtrlY 325
#define CtrlZ 326
#define KeyPlus 343
#define KeyMinus 345

#define xMENU_BEG -1
#define xMENU_SEP -2
#define xMENU_END -3
#define MENU_BYE -4


#define MENU_BEG(MENUPAR) xMENU_BEG,0,MENUPAR,0,
#define MENU_SEP xMENU_SEP,0,0,0,
#define MENU_END(MENUPAR) xMENU_END,MENUPAR,0,0,

	// MENU ARRAY FILE DATA START
	// (Empty quotes = same as english.)
	// Main key codes are either 300+ascii, or one of the win VK_ codes
	// IDM_ codes must be set in .H inc file.
	// Add '!' to insert vertical break, or Msep for horiz break
	
typedef struct {	// DATA for MENU
  short mode;		// Mode of current item
  short idm;		// Index in String array for menu-string
  short key;		// key-code
  short flag;		// greying flags (0=always enabled,1=not when think..
} MENUDATA;



MENUDATA Mnu [150] = {

 MENU_BEG (0)
  0, IDM_NEWGAME,	CtrlN, 0,
  0, IDM_NEW3RND,	0, 0,
  0, IDM_NEW3SEL,	0, 0,
  0, IDM_LOADGAME,	CtrlO, 0x801,
  0, IDM_SAVEGAMEO,	CtrlS, 0x801,
  0, IDM_SAVEALL,	CtrlA, 0x801,
  0, IDM_GAMESPAWN,	0,  0x801,
  MENU_SEP
  0, IDM_EXPORTMSF,	0,  0x801,
  0, IDM_EXPORTPOS,	0,  0x801,
  0, IDM_SETEXPORTOPT,	0,  0x801,
  MENU_SEP
  0, IDM_CLIPLOAD,	0,  0x801,
  0, IDM_CLIPSAVE,	0,  0x801,
  MENU_SEP
  //0, IDM_REFUEL,	0,  0x801,
  //MENU_SEP
  0, IDM_QUIT,	  	CtrlQ, 0,
 MENU_END (IDM_FILE)
 
 MENU_BEG (1)
  0, IDM_USERLEVELS,	CtrlL,  0x801,
 MENU_SEP
  0, IDM_LVINSTANT,	0,  0x801,
  0, IDM_LV2SPM,	0,  0x801,
  0, IDM_LV5SPM,	0,  0x801,
  0, IDM_LV10SPM,	0,  0x801,
  0, IDM_LV30SPM,	0,  0x801,
  0, IDM_LV60SPM,	0,  0x801,
  0, IDM_LV120SPM,	0,  0x801,
 MENU_SEP
  0, IDM_SETCLOCKS,	0,  0x801,
 MENU_END (IDM_LEVELS)
 
 MENU_BEG (2)
  0, IDM_SETUP,		CtrlE,  0x801,
  0, IDM_OTHEROPTIONS,	CtrlT,  0x801,
  MENU_SEP
  0, IDM_EDITGAMEDET,	0,  	1,
  0, IDM_ADDCOMMENT,	0,  	1,
  MENU_SEP
  0, IDM_NORMAL,	0,  0x800,
  0, IDM_2PLAYER,	0,  0x801,
  0, IDM_COMPVCOMP,	0, 0x821,
  0, IDM_COMPVCOMPCONT, 0, 0x821,
 MENU_END (IDM_OPTIONS)
 
 MENU_BEG (3)
  0, IDM_COMPUTE,	CtrlG,  0x821,
  0, IDM_MOVE,		CtrlF,  0x802,
  0, IDM_NEXTBEST,	CtrlB,  0x810,
  0, IDM_HINT,		CtrlH, 0x861,
  MENU_SEP
  0, IDM_TAKEBACK,	VK_PRIOR,  0x804,
  0, IDM_TAKEBACK10, 	VK_UP,  0x804,
  0, IDM_TAKEBACKALL,	VK_HOME,  0x804,
  0, IDM_STEPFWD,	VK_NEXT,  0x808,	
  0, IDM_STEPFWD10,  	VK_DOWN,  0x808,
  0, IDM_STEPFWDALL, 	VK_END,  0x808,
  0, IDM_GOTO,	  	0,  0x800,
 MENU_END (IDM_COMMANDS)
 
 MENU_BEG (4)
  0, IDM_DISPLAYOPT,	0,  1,
  0, IDM_FONTS,		0,  1,
  MENU_SEP
  0, IDM_INVERT,	0,  0,
  0, IDM_SOUND,		0,  0,
  0, IDM_NUMBERING,     0,  0,
  0, IDM_SLIDE,		0,  0,
  //0, IDM_WINDOWS,	0,  1,
  0, IDM_DEFAULTLAYOUT, 0,  0x801,
  0, IDM_2NDANAL,       0,  0,
  0, IDM_PDNDISPLAY,    0,  0,
  0, IDM_PDNNUMBERING,  0,  0,
  0, IDM_FULLANAL,      0,  0,
  0, IDM_ANALY2COMMENT, 0,  0,
  MENU_SEP
  0, IDM_ENGLISH,	0,  0x801,
  0, IDM_LANG2,		0,  0x801,
  0, IDM_LANG3,		0,  0x801,
  0, IDM_LANG4,		0,  0x801,
  0, IDM_LANG5,		0,  0x801,
  0, IDM_LANG6,		0,  0x801,
  0, IDM_LANG7,		0,  0x801,
  0, IDM_LANG8,		0,  0x801,
  0, IDM_LANG9,		0,  0x801,
 MENU_END (IDM_DISPLAY)
 
 MENU_BEG (5)
  0, IDM_PDNIMPORT,	CtrlI, 0x801,
  0, IDM_PDNIMPORTNEXT,	CtrlJ, 0x801,
  0, IDM_PDNIMPORTAGAIN,CtrlR, 0x801,
  0, IDM_SELECTDATABASE,CtrlW, 0x801,
  0, IDM_DB_SEARCH,     0,     0x801,
  0, IDM_PDNEXPORT,	CtrlK, 0x801,
  0, IDM_EDITDB,        0,0x801,
  0, IDM_PDNTRANSFER,       0,0x801,
  MENU_SEP
  0, IDM_ANALYSE,	0, 0x809,
  0, IDM_PROCESSEPD,	0,  0x801,
  0, IDM_IMPORTEPD,	0,  0x801,
  0, IDM_IMPORTNEXTEPD,	CtrlX, 0x801,
  0, IDM_EXPORTEPD,	0,  0x801,
  MENU_SEP
  0, IDM_EXPORTUBOOK,	0,  0x801,
  0, IDM_SAVEUBOOK,	0,  0x801,
  0, IDM_LOADUBOOK,	0,  0x801,
  0, IDM_UBOOKADD,	0,  0x901,	
  0, IDM_IMPORTBOOK,	0,  0x801,	

 MENU_END (IDM_DATABASE)
  
 MENU_BEG (6)
  0,  IDM_BOARD,        0,  1,
  0,  IDM_SEARCH,       0,  1,
  0,  IDM_MOVEBOX,      0,  1,
  0,  IDM_SHOWBOOK,     0,  1,
 MENU_END (IDM_WINDOWS)

 MENU_BEG (7)
  0, IDM_HELP,	VK_F1, 0,
  MENU_SEP
  0, IDM_ABOUT,	0,  0,
 MENU_END (IDM_eHELP)
 MENU_BYE,0,0,0};



		// MENU ARRAY FILE DATA ENDS

short csubmenu;

void Mbeg (short xsub)	// Start a menu, specify number.
{
	csubmenu = xsub;
	hSubMenu [csubmenu] = CreatePopupMenu ();
}

			// End a menu, specify heading
void Mend (short cidm)
{
		// Attatch sub menu to main menu
	AppendMenu (hMenu,MF_ENABLED | MF_POPUP, (USHORT) hSubMenu [csubmenu],Strings [cidm] );
}

		// Define a menu item: ID,mainkey, texts..
void Mdef (short cidm, short cmainkey, short cstat)
{
	short temp = 0;
	char *stext = Strings [cidm];
	mainkeys [cmainkey & 511] = cidm;	// Main key for function..
	if (stext [0] == 0) return;		// Just key set..
	if (nidms < Mmenuidms) {	// not over max..
	  nidms ++;
	  menuidms [nidms] = cidm;	// save menu IDM_ code
	  menubits [nidms] = cstat;	// Save graying status flag bits
	}
		// If name starts with !, vertical menu split..	
	if (stext [0] == '!') {temp = MF_MENUBREAK; stext ++;}
	AppendMenu (hSubMenu [csubmenu],MF_STRING | temp,cidm,stext);
}

void Msep (void)	// Add a Separator to menu..
{
	AppendMenu (hSubMenu [csubmenu],MF_SEPARATOR,0,"");
}

	// Read menu data from (Mnu) structure, use it..
void DefineMenu (void) 	
{
	short cmenu = 0;
	short cmode;
	short cidm;
	while (cmode = Mnu [cmenu].mode, cmode != MENU_BYE) {
	  cidm = Mnu [cmenu].idm;
	  if (cmode >= 0) {	// +ve - Define normal menu item
	  	// Ignore out-of-range eng.language IDM_s..
	    if (cidm > IDM_LANG9 || cidm < IDM_ENGLISH + MaxLang) {
	      Mdef (cidm, Mnu [cmenu].key , Mnu [cmenu].flag);
	    }
	  } else if (cmode == xMENU_SEP) {
	    Msep ();
	  } else if (cmode == xMENU_BEG) {	// New sub menu
	    Mbeg (Mnu [cmenu].key);
	  } else if (cmode == xMENU_END) {	// End sub menu..
	    Mend (cidm);
	  }
	  cmenu ++;
	}
}

	// Define a string for current eng.language.
#define Sdef(STring,Eng,Ger,Fre,Spa) \
	Sdefine (Eng,Ger,Fre,Spa); STring = STtemp;
	
	// Define a string for menu
#define SMdef(Cidm,Eng,Ger,Fre,Spa) \
	Sdefine (Eng,Ger,Fre,Spa); Strings[Cidm] = STtemp;
	
char *STtemp;	

void Sdefine (char *senglish, char *sgerman, char *sfrench, char *sspain)
{
	if (eng.language == 1) {
	  STtemp = sgerman;
	} else if (eng.language == 2) {
	  STtemp = sfrench;
	} else if (eng.language == 3) {
	  STtemp = sspain;
	} else {		// Zero, or other eng.language..
	  STtemp = senglish;
	}
	if (STtemp [0] == 0) STtemp = senglish;
}

void Linput ()
{
	szIn = szTemp;
	nin = LineInput (hLangFile, szTemp, SIZEszTemp,1);
	if (nin != NO_FILE) {
	  while (*szIn == ' ') szIn ++;	// Strip leading spc
	}
}

	// Read text for eng.language (clang)(0-n) into StrSpace
void ReadLanguageFile (short clang)
{
	char *szDest = StrSpace;	// Write to lang-string-space
	short cline = 0;		// Count of lines inputed
	short cstr = 0;		// Count of strings..
	short cchr;		// Gen vars
	SetWaitCursor		// Hour glass mouse..     
	for (cchr = 0; cchr + cchr < SIZEszTemp; cchr ++) { // Wipe in-array..
	  szTemp [cchr] = 0;
	}
	szLangFile [6] = 49 + clang;
	hLangFile = OpenFile (szLangFile, &ofBuf, OF_READ); 
	BufReset ();		// Reset input buffer..(for LineInput)
	if (hLangFile == NO_FILE) {	// cannot read source
	  goto LangError;
	}
	do {		// Read & process, chunk by chunk
	  Linput ();
	  cline ++;
	  if (nin == NO_FILE) goto LangError;
	  cchr = szIn [0];
	  if (szIn [0] == 34) {		// " - start of eng.language string..
	    Strings [cstr] = szDest;	// Save ptr to string start..
	    cchr = StrConvCpy (szDest, szIn + 1, 400);
	    szDest += cchr;
	    cstr ++;
	  } else if (szIn [0] == '/') {	// '/' - rem or command..
	    cchr = szIn [2];
	    if (cchr == '<') break;	// OK, reached EOF sucsesfully
	    if (cchr == '=') {
	      cstr = atoi (szIn + 3);
	    }
	    if (cchr == '+') {
	      cstr += atoi (szIn + 3);
	    }
	  }
	  if (cstr < 0 || cstr >= aSizeOf (Strings) 
	  	|| szDest - StrSpace > SIZEStrSpace) goto LangError;
	} while (1);
	SetNormCursor         // Normal mouse..     
	_lclose (hLangFile);
	return;
LangError:
	if (hLangFile != NO_FILE) _lclose (hLangFile);
	BeepSnd ();
	msgprintf (NULL,ABORT_PROG,1,"ERROR in eng.language file "
		LANGUAGE_FILEPR " line %d",clang+1,cline);
}

void DefLangStr (void)
{
    short cstr;
    	// Set all strings to point to NULL str..
    for (cstr = 0; cstr < aSizeOf (Strings) - 3; cstr ++) {
      Strings [cstr] = "";
    }
    ReadLanguageFile (eng.language);
    #if ECOSTR		// Read in CHECOx._CG - ECO text file..
      ReadECOFile (eng.language);
    #endif

 Sdef (STprogramnamefor,
   PROG_NAME " for Windows",
   "",
   "",
   "");

 Sdef (STinitdialog,		
   "Copyright � A.Millett 1992-2025, All Rights Reserved.\n\n" 
   PROG_VERSION "\n\n"
   "Released as free software under the GNU GPL-3 License.\n\n"
   "WWW: https://github.com/orac81/Orac-Draughts\n"
  "\0                ",
  "",
  "",
  "");

 Sdef (STabout,		
   "Sage Draughts - Copyright A.Millett 1992-2025.\n"
   __DATE__  PROG_VERSION "\n"
   "EMAIL: mobius9@mail.com\n"
   "WWW: https://github.com/orac81/Orac-Draughts\n"
   "Released as free software under the GNU GPL-3 License.\n"
   "Hash: %d Kilobytes.\n"
   "\0               ",
  "",
  "",
  "");


	SetPiecePtrs ();
}

void SetPiecePtrs (void)
{
	static short cchr;
	short gConv[] = {5,4,1,2,3};  // Converts Genius->Chessbase order
	STpieces = STpiecesa;	// Alphabetic piece codes
	if (FlagFigurine) {	// Put piece graphics symbols in,,
	  STpieces = STpiecesg;	// Graphical piece codes..
	}
	STpiecesvdu = STpieces;	// In use by screen
}

void ResetMenu (void)		// Initialise menu for LANGUAGE..
{
	if (hMenu) {		// Kill any old one
	  DestroyMenu (hMenu);
	  hMenu = NULL;
	}
        for (cmainkey = 0; cmainkey < 559; cmainkey ++) {
          mainkeys [cmainkey] = 0;
        }
	hMenu = CreateMenu ();
	nidms = 0;		// no of idms stored
	DefLangStr ();		// Menu eng.language INCLUDE file..
 	DefineMenu ();		// Load new eng.language strings into menu
	SetMenu (hMainWnd,hMenu);	// Attatch to main window
	MenuFlags ();
}
  
  //
  // GRAPHICS + SLIDING PIECES.. 
  //
  
void fineputinit (short cpiece)		// Make usable piece at (scratchx1)
{
    static short tindex;
    if (hWDC == NULL) hWDC = hMainDC;	// Redirect to main win.

    finechrx = setchrx; finechry = setchry;
	// Calc locations of scratchpads in hWorkDC
    scratchx  = workx; scratchy  = 1;
    scratchx1 = workx; scratchy1 = worky + 1;
    scratchx2 = workx + workx; scratchy2 = 1;
    scratchx3 = workx + workx + workx; scratchy3 = 2;	// the big area..
    if (cpiece < 0) cpiece = 8 - cpiece;
    tindex = (cpiece & 31);
	// Calc (source) loc of piece in hWorkDC, and loc of (mask) for it.
    sourcex = xoff [tindex] ; 
    sourcey = yoff [tindex] ; 
	// Make inverted copy of mask at scratch1..
    BitBlt (hWorkDC,scratchx1,scratchy1,finechrx,finechry,hMaskDC, sourcex,sourcey,NOTSRCCOPY);
	// AND with piece to leave piece at scratch 1..	    
    BitBlt (hWorkDC,scratchx1,scratchy1,finechrx,finechry,hPieceDC, sourcex,sourcey,SRCAND);
}

void fineputat (short xpos, short ypos)	// Overlay cur piece on background
{
		// Save area of screen to be used..
    BitBlt (hWorkDC,scratchx2,scratchy2,finechrx,finechry,hWDC, xpos,ypos,SRCCOPY);
		// Copy White/black outline mask to scratch
    BitBlt (hWorkDC,scratchx,scratchy,finechrx,finechry,hMaskDC, sourcex,sourcey,SRCCOPY);
		// Take area of screen to use, AND with mask, put in scratch
    BitBlt (hWorkDC,scratchx,scratchy,finechrx,finechry,hWDC, xpos,ypos,SRCAND);
    		// Merge in piece with background with OR..
    BitBlt (hWorkDC,scratchx,scratchy,finechrx,finechry,hWorkDC, scratchx1,scratchy1,SRCPAINT);
    		// Copy result back to screen.
    BitBlt (hWDC,xpos,ypos,finechrx,finechry,hWorkDC, scratchx,scratchy,SRCCOPY);
}

void finerenew (short xpos, short ypos)	// Restore orig background
{
		// Get orig screen back....
    BitBlt (hWDC,xpos,ypos,finechrx,finechry,hWorkDC, scratchx2,scratchy2,SRCCOPY);
}

  // NEW SMOOTH MOVE - move piece smoothly, without erasing
  // Uses scratch area which can be upto 4x normal..
  //         +-----+
  //  FROM-> |  B  |
  //         |---+-+---+
  //         | A |C| D |
  //         +---+-+---|  <- TO
  //             |  E  |
  //             +-----+
  //
	// Overlay cur piece on background
	// Moves from (fx,fy) to (tx,ty)
	// if (mode) set, then calls SYNCFLY for sw/hw delay
void finemoveto (short fx, short fy, short tx, short ty, short mode)
{
    short sfx,sfy;	// From pos in scratch area
    short stx,sty;	// To pos in scratch area
    short bigx,bigy;	// Total size of scratch area
    short xpos,ypos;	// Top-left of screen area to blit
    xpos = fx; ypos = fy;
    bigx = finechrx + abs (fx - tx);	// calc total work area size
    bigy = finechry + abs (fy - ty);
	// Now calc from/to positions in work area..    
    sfx = stx = scratchx3;	// Scratch-3 is the big area..
    sfy = sty = scratchy3;
    if (fx > tx) {
      sfx += abs (fx - tx);
      xpos = tx;
    } else {
      stx += abs (fx - tx);
    }
    if (fy > ty) {
      sfy += abs (fy - ty);
      ypos = ty;
    } else {
      sty += abs (fy - ty);
    }
    
		// Get area of screen to be used..
    BitBlt (hWorkDC,scratchx3,scratchy3,bigx,bigy,hWDC, xpos,ypos,SRCCOPY);
    		// Get old background, wiping old piece
    BitBlt (hWorkDC,sfx,sfy,finechrx,finechry,hWorkDC, scratchx2,scratchy2,SRCCOPY);
		// Save new background, for next time..    
    BitBlt (hWorkDC,scratchx2,scratchy2,finechrx,finechry,hWorkDC, stx,sty,SRCCOPY);
		// Take area of screen to use, AND with mask, put in scratch
    BitBlt (hWorkDC,stx,sty,finechrx,finechry,hMaskDC, sourcex,sourcey,SRCAND);
		// Merge in piece with background with OR..
    BitBlt (hWorkDC,stx,sty,finechrx,finechry,hWorkDC, scratchx1,scratchy1,SRCPAINT);
    if (mode) syncfly ();	// Sync to screen refresh?
    		// Copy result back to screen.
    BitBlt (hWDC,xpos,ypos,bigx,bigy,hWorkDC, scratchx3,scratchy3,SRCCOPY);
}

short xbrd2vdu (short xpos)		// Conv frBoard X pos to real VDU pos
{
	if (FlagInvert) {
	  xpos = eng.boardx + 1 - xpos;
	}
	return (btopx + (xpos - 1) * charx);
}

short ybrd2vdu (short ypos)		// Conv frBoard X pos to real VDU pos
{
	if (FlagInvert) {
	  ypos = eng.boardy + 1 - ypos;
	}
	return (btopy + (ypos - 1) * chary);
}

void putat (short xin, short yin, short cpiece)	// Put cpiece at xin,yin
{
      static short xpos,ypos,tindex;	//tmaskx,tmasky;                
      short sourcex,sourcey;
      BYTE sqcol;
      if (hWDC == NULL) hWDC = hMainDC;	// Redirect to main win.
      #if Debug
        if (xin < 1 || yin < 1) {
	  msgprintf (NULL,0,0,"x:%d,y:%d,cp:%d,mvmod:%d",xin,yin,cpiece,movemode);
        }
      #else        
        if (xin < 1 || yin < 1) return;
      #endif
      xpos = xbrd2vdu (xin); 
      ypos = ybrd2vdu (yin); 
      if (cpiece == EdgeSq) cpiece = 0;
      if (cpiece < 0) cpiece = 8 - cpiece;
      tindex = (cpiece & 31);
	// Overlay on background..
      scratchx4  = workx + workx; scratchy4  = worky + 1;
	// Create background square      
      sqcol = (xin + yin) & 1;
        if (FlagLightA1) sqcol = !sqcol;
      if (sqcol) {	// White or Black sqr?
        BitBlt (hWorkDC,scratchx4,scratchy4,charx,chary,hWorkDC,BlsqLocx,BlsqLocy,SRCCOPY);
      } else {
        BitBlt (hWorkDC,scratchx4,scratchy4,charx,chary,hWorkDC,WhsqLocx,WhsqLocy,SRCCOPY);
      }
      if (cpiece) {	// Not empty, overlay piece..
        static short tx,ty;
	sourcex = xoff [tindex]; 
	sourcey = yoff [tindex]; 
	tx = (charx - setchrx) >> 1; 
	ty = ((chary - setchry) >> 1) - 1;
          ty ++;
		// AND with mask
	BitBlt (hWorkDC,scratchx4 + tx,scratchy4 + ty,setchrx,setchry,hMaskDC,sourcex,sourcey,SRCAND);
		// OR in piece..	
	BitBlt (hWorkDC,scratchx4 + tx,scratchy4 + ty,setchrx,setchry,hPieceDC,sourcex,sourcey,SRCPAINT);
      }
		// Blit result to screen..
      BitBlt (hWDC,xpos,ypos,charx,chary,hWorkDC,scratchx4,scratchy4,SRCCOPY);
}

void bputat (short xpos, short ypos, short cpiece)	// Like putat, but pick from brd
{
	if (cpiece == -1) {		/* -1, so take from board [] */
	  cpiece = Getboard (xpos,ypos) ;
	}
	putat (xpos, ypos, cpiece);
}

/*
#define gputat(Xp,Pp) \	// A neat debug macro..
	{\
	  if ((Xp) < 11 ) {\
	    msgprintf (NULL,0,0,"brd:%d,cp:%d,lin:%d", \
	    Xp,Pp,__LINE__);\
	  }\
	  ggputat (Xp,Pp);\
	}
*/	

void gputat (short xbrd, short cpiece)	// Draw piece using straight brd index
{
	bputat (Xposof (xbrd), Yposof (xbrd), cpiece);
}

void boxit3d (short xtop, short ytop, short xbot, short ybot, short linewidth)
{
    SelectObject (hWDC,hBlackPen);
    MoveToEx (hWDC, xtop, ybot,NULL);
    LineTo (hWDC, xtop, ytop); LineTo (hWDC, xbot, ytop); 
    SelectObject (hWDC,hWhitePen);
    LineTo (hWDC, xbot, ybot); LineTo (hWDC, xtop, ybot);
    //boxit (xtop,ytop,xbot,ybot);
    xtop -= linewidth; ytop -= linewidth; 
    xbot += linewidth; ybot += linewidth;
    SelectObject (hWDC,hWhitePen);
    MoveToEx (hWDC, xtop, ybot,NULL);
    LineTo (hWDC, xtop, ytop); LineTo (hWDC, xbot, ytop); 
    SelectObject (hWDC,hBlackPen);
    LineTo (hWDC, xbot, ybot); LineTo (hWDC, xtop, ybot);
}

	// New version - set foreground/background..
void TextCol (BYTE ctxt, BYTE cback)
{
	if (ctxt != PALLEAVE) SetTextColor (hWDC, ExtraRGB (ctxt));
	if (cback != PALLEAVE) SetBkColor (hWDC, ExtraRGB (cback));
}

void SetClkFont (short cfont, HDC hDC)	// Init clock-face..
{
	if (hClkFont) {		// Remove any old font..
	  SelectObject (hDC, GetStockObject (SYSTEM_FIXED_FONT));
	  DeleteObject (hClkFont);
	}
	memset (&clklogf, 0, sizeof (LOGFONT));	// clr struct
	strcpy (clklogf.lfFaceName,szClkFont);	// Font name to select
	clklogf.lfHeight = ClkFontSize;
	clklogf.lfWidth = 0;
	clklogf.lfWeight = 0;
	hClkFont = CreateFontIndirect(&clklogf);   // create new logical font
	if (hClkFont == NULL) {		// Could not do it, select system..
	  hClkFont = GetStockObject (SYSTEM_FIXED_FONT);
	}
	SelectObject (hDC,hClkFont);
	CalcMetrics (hMainDC, &clkchrx, &clkchry);	// Get font size..
	clkoffx = clkchrx >> 1;		// Centering offset..
	clkoffy = 4;
	clkdispy = 6;
	if (clklogf.lfItalic) clkoffx = (clkoffx >> 1) + 2;
}


void objon (void)	// Default Pens & fonts on
{
    hOldpen = SelectObject (hWDC,hBlackPen);
    hOldBrush = SelectObject (hWDC,hBackBrush);
	// OK, select a SYSTEM stock font (default)..
    hFont = GetStockObject (SYSTEM_FIXED_FONT);
    hSysFont = SelectObject (hWDC,hFont);	// Save old font for DC
    CalcMetrics (hWDC, &chrx, &chry);		// Get size..
	// OK, now new font stuff..
    SysChrx = chrx; SysChry = chry;	// Save default system font size..
	// Select LED font for clock
    if (hClkFont == NULL) {
      SetClkFont (0,hWDC);
    }
	// Now get ansi font..
    //hAnsiFont = GetStockObject (ANSI_FIXED_FONT);
    if (hAnsiFont == NULL) {    // CHeap and cheerful load font fn , 11.2001
      LOGFONT logFont;
      memset (&logFont,0,sizeof (LOGFONT));
      logFont.lfHeight = -12;
      logFont.lfPitchAndFamily = FIXED_PITCH;
      strcpy (logFont.lfFaceName,"pcs12");
      hAnsiFont = CreateFontIndirect(&logFont);   // create new logical font
      if (hAnsiFont == NULL) hAnsiFont = GetStockObject (ANSI_FIXED_FONT);
    }
    SelectObject (hWDC,hAnsiFont);
    CalcMetrics (hWDC, &ansichrx, &ansichry);		// Get size..
    SelectObject (hWDC,hFont);
	// Try to load genius font..
    if (eng.anyfont) {	// Font spec in $last.gam (eng.mainlogf)..
      ResetFonts (0);		// Load & select font in (mainlogf)
    } else {
      ResetFonts (2);		// Load & select default font (genius12b)
    }	
    TextCol (PALTXT,PALBOX);				// color for box print
}

#define ExtendBrd4Nums 0
	// Draw a tiny board..
void DrawNumbering (short getDC)
{
	short cmove,cx,cy;
	HFONT hOldFont;
	char xstr [5];
	if (getDC) GetMyDC (W_BRD, 1);	
	SelectObject (hWDC,hNullPen);
	SelectObject (hWDC,hBoxBrush);
	TextCol (PALVATXT,PALBOX);		// Hi-lite txt colour..
	hOldFont = SelectObject (hWDC, hAnsiFont);
        	// SAGE Draughts board numbering..
	TextCol (PALTXT,PALBOX);		// Normal txt colour..
	SetBkMode (hWDC,TRANSPARENT);
        for (cy = 0; cy < eng.boardy; cy ++) {
          for (cx = 0; cx < eng.boardx; cx ++) {
	    cmove = ext_pos2num (cy * eng.boardx + cx);
            if (cmove) {
	      wsprintf (xstr,"%2d",cmove);
              if (xstr [0] == 32) {xstr [0] = xstr [1]; xstr [1] = 32;}
	      TextOut (hWDC,xbrd2vdu (cx+1), ybrd2vdu (cy+1),xstr,2);
            }
          }
        }

	SetBkMode (hWDC,OPAQUE);
	SelectObject (hWDC, hOldFont);
	SelectObject (hWDC,hBlackPen);
	SelectObject (hWDC,hNullBrush);
	if (getDC) ReleaseMyDC (W_BRD);	
}

	// Draw a board on current DC
	// DMODE - bit 0 set to add Hot key offsets on top..
void DrawBoard (void)
{
    short xpos,ypos;
    if (hBrdWnd == NULL) return;
			
		// Re-Draw a floating board window..
	GetMyDC (W_BRD, 1);	
	btopx = 0; btopy = 0;
	for (xpos = 1; xpos <= eng.boardx; xpos ++) {
	  for (ypos = 1; ypos <= eng.boardy; ypos ++) {
	    putat (xpos, ypos, frBoard [Posof (xpos,ypos)]);
	  }
	}
		// Print numbering on sides..
    	if (FlagNumbering) {
    		// wipe area along board sides for numbering
      	  DrawNumbering (0);
    	}
	ReleaseMyDC (W_BRD);	
}

	// Draw a box
void FXbox (short tx, short ty, short bx, short by)
{
	SelectObject (hWDC,hBlackPen);
	SelectObject (hWDC,hNullBrush);
	  Rectangle (hWDC, tx, ty,bx,by);
}

	// Draw brd on index..
void DrawBoardOn (short WndIndex)
{
	if (WndIndex) GetMyDC (WndIndex,1);
	//if (FlagNumbering) btopx += chrx;
	for (xpos = 1; xpos <= eng.boardx; xpos ++) {
	  for (ypos = 1; ypos <= eng.boardy; ypos ++) {
	    putat (xpos, ypos, frBoard [Posof (xpos,ypos)]);
	  }
	}
	FXbox (btopx - 1,btopy - 1,charx * eng.boardx + btopx + 1, chary * eng.boardy + btopy + 1); 
	if (WndIndex) ReleaseMyDC (WndIndex);
}

void qDrawBoard (void)		// Draw frBoard, refresh boxes
{
	DrawBoard ();
	MoveBox (1);
	SearchBox ();
}

	// Slide a piece across the screen..
void DoSlide (short fxpos, short fypos, short txpos, short typos, short cpiece, short cspeed)
{
	short temp,offx,offy;
	short fx,fy;
	offx = (charx - setchrx) >> 1;
	offy = (chary - setchry) >> 1;
	fineputinit (cpiece);
		// Conv to real VDU coords..
	fxpos = xbrd2vdu (fxpos) + offx; 
	fypos = ybrd2vdu (fypos) + offy; 
	txpos = xbrd2vdu (txpos) + offx;
	typos = ybrd2vdu (typos) + offy;
	fineputat (fxpos,fypos);
	while (txpos != fxpos || typos != fypos) {
	  fx = fxpos; fy = fypos;
	  	// Calc next pos..
	  if (txpos != fxpos) {
	    temp = txpos - fxpos;
	    if (temp > cspeed) temp = cspeed;
	    if (temp < -cspeed) temp = -cspeed;
	    fxpos += temp;
	  }
	  if (typos != fypos) {
	    temp = typos - fypos;
	    if (temp > cspeed) temp = cspeed;
	    if (temp < -cspeed) temp = -cspeed;
	    fypos += temp;
	  }
	  finemoveto (fx,fy,fxpos,fypos,1);
	}
	finerenew (fxpos,fypos);	// clr old..
}

short slidepiece (short cpiece, short cspeed)
{
	static short fxpos,fypos,txpos,typos;	// From,To sqrs..
	short cpos;
	cpos = 0;
	for (fypos = 1; fypos <= eng.boardy; fypos ++) {
	  for (fxpos = 1; fxpos <= eng.boardx; fxpos ++) {
	    if (frBoard [Posof (fxpos,fypos)] == cpiece
	      && eng.checker_board [cpos] != cpiece) goto slidefr;
	    cpos ++;
	  }
	}
	return (0);	// No more to slide..
slidefr:
	cpos = 0;
	for (typos = 1; typos <= eng.boardy; typos ++) {
	  for (txpos = 1; txpos <= eng.boardx; txpos ++) {
	    if (frBoard [Posof (txpos,typos)] != cpiece
	      && eng.checker_board [cpos] == cpiece) goto slideto;
	    cpos ++;
	  }
	}
	return (0);	// No more to slide..
slideto:
	frBoard [Posof (fxpos,fypos)] = 0;
	putat (fxpos, fypos, 0);
	DoSlide (fxpos,fypos,txpos,typos,cpiece,cspeed);
	frBoard [Posof (txpos,typos)] = cpiece;
	putat (txpos, typos, cpiece);
	return (1);
}

void FastMakeMove (void)	// Fast VDU frBoard update..
{
	short cpiece,cpos,xpos,ypos;
	if (hBrdWnd == NULL) {
	  eng2brd ();
	  return;
	}
	GetMyDC (W_BRD, 1);	
	cpos = 0;
	for (ypos = 1; ypos <= eng.boardy; ypos ++) {
	  for (xpos = 1; xpos <= eng.boardx; xpos ++) {
	    cpiece = eng.checker_board [cpos];
	    if (frBoard [Posof (xpos,ypos)] != cpiece) {
	      frBoard [Posof (xpos,ypos)] = cpiece;
	      putat (xpos, ypos, cpiece);
	    }
	    cpos ++;
	  }
	}
	ReleaseMyDC (W_BRD);	
}
	
	
void MakeMove (short cspeed)	// Update diff between Engine frBoard & VDU frBoard, slide..
{
	short cpiece;
	if (hBrdWnd == NULL) {
	  eng2brd ();
	  return;
	}
	if (FlagSlide == 0) {	// Simple fast update..
	  FastMakeMove ();
	  return;
	}
	GetMyDC (W_BRD, 1);	
		// Speed is 'step' for moving pieces - bigger, the faster
		// Keep within range
	cspeed = max (1,min ((cspeed * MoveSpeed) / 100,charx >> 1));
	for (cpiece = 6; cpiece; cpiece --) {
	  while (slidepiece (cpiece,cspeed));
	  while (slidepiece (-cpiece,cspeed));
	}
	ReleaseMyDC (W_BRD);	
	FastMakeMove ();	// Mop up any Insert/Delete
}

void ShowHint (void) 
{
	short fxpos,fypos,txpos,typos,cpiece,mfrom,mto;
	BeepSnd ();
	if ((Phint_move->from &0x3f) == (Phint_move->to & 0x3f)) return;
	mfrom = cg2my (Phint_move->from);
	fxpos = Xposof (mfrom); fypos = Yposof (mfrom);
	cpiece = frBoard [mfrom];
	mto = cg2my (Phint_move->to);
	txpos = Xposof (mto); typos = Yposof (mto);
	GetMyDC (W_BRD, 1);	
	putat (fxpos,fypos,0);
	DoSlide (fxpos, fypos, txpos, typos, cpiece, 6);
	DoSlide (txpos, typos, fxpos, fypos, cpiece, 6);
	putat (fxpos,fypos,cpiece);
	ReleaseMyDC (W_BRD);	
}

  // Convert move to Draughts numbers..
  //  4/5 digits, no null term.
  // Set bit 6 mflag for Capt (x), bit 8 for no -x (4 digits)
void SageMove2Str (char *mstr, BYTE msrc, BYTE mdest, short mflag)
{
	msrc = (BYTE) ext_pos2num ((BYTE) msrc);
	mdest = (BYTE) ext_pos2num ((BYTE) mdest);
	if (msrc < 10) {
	  *mstr = 32; mstr ++;
	  *mstr = 48 | msrc; mstr ++;
	} else {
	  *mstr = 48 | (msrc / 10); mstr ++;
	  *mstr = 48 | (msrc % 10); mstr ++;
	}
	if ((mflag & 256) == 0) {
	  *mstr = '-'; if (mflag & 64) *mstr = 'x';
	  mstr ++;
	}
	if (mdest < 10) {
	  *mstr = 48 | mdest; mstr ++;
	  *mstr = 32; mstr ++;
	} else {
	  *mstr = 48 | (mdest / 10); mstr ++;
	  *mstr = 48 | (mdest % 10); mstr ++;
	}
}

	// gprom info..
//the flags byte of a move gives information about check,capture,promotion
//bit 7 set if check, bit 6 set if capture, bit 5 set if castling/ep capture
//bit 2 set if promotion and if promotion bits 1 and 0 are 00,01,10,11 q,r,n,b
//other bits are zero.

MYINLINE short getmove (short cmove, BYTE mode)	// Get info on spec Move no..
{
	eng.param_ax_pass = 0;
	 // Move to get info on: bit 1-15=(move# - 10), bit 0 set for black
	eng.param_pass = cmove;
	retv = ext_misc_service ();
	gfrom = eng.move_info [0];
	gto = eng.move_info [1];
	gprom = eng.move_info [2];		// Promotion flags
	gnotate = eng.move_info [3];	// Hi-bits:notation:b7=showFile.b6=row
	gtypemov = gnotate & 15;	// Type moved 1..6=P..K
	gtypecap = eng.move_info [4];	// Type captured 0..6
	if (mode & 1) {			// Force long notation
	  gnotate = 0xff;
	}
	return retv;
}

  // Put info on move into a 9 char string (NO NULL TERM)..
  // Move is in eng.move_number format - 0 =1st wht,1=1st blk, etc..
  // mode bit 0 set for long notation, clr for SAN..(always left-just)
void Move2Str (char *mstr, short cmove, BYTE mode)
{
	short cpos;
	for (cpos = 0; cpos < 9; cpos ++) {	// Wipe old first..
	  mstr [cpos] = 32;
	}
	if (cmove >= eng.move_number || cmove < FirstMove) {	// Out of range
	  return;
	}
	retv = getmove (cmove, mode);
	if (retv == -1 || gfrom == gto) {	// Null move...
	  mstr [1] = mstr [2] = '.';
	  return;
	}
	  if (FlagChessNot == 0) {	// Checkers numeric notation?
		// Convert move-> Sage numbers
	    SageMove2Str (mstr, (BYTE) gfrom, (BYTE) gto, LOBYTE (gprom));
	    // if (gprom & 64) mstr [2] = 'x';
	    return;
	  }
	if (gprom & 32) {	// Bit 5 set for castling/ep..
	  if (gtypemov == 6) {	// King moved..
	    if (mode & 1) mstr ++;	// Space out long not..
	    if ((gto & 7) == 6) {	// castle:which way?
	      if (mode & 1) mstr ++;	// Space out long not..
	      memcpy (mstr,"O-O",3);
	    } else {
	      memcpy (mstr,"O-O-O",5);
	    }
	    return;
	  }
	}
	if (gtypemov > 1) {	// Show piece moved..
	  *mstr = (STpieces [(gtypemov - 1) & 7] );
	  mstr ++;
	} else { 	// Long not? leave space for pawn..
	  if (mode & 1) mstr ++;
	}
		// Show file..(force if pawn captures)
	if ((gnotate & 0x80) || (gtypemov == 1 && gtypecap)) {
	  *mstr = (97 + (gfrom % eng.boardx));
	  mstr ++;
	}
	if (gnotate & 0x40) {	// Show row..
	  *mstr = (48 + eng.boardy - (gfrom / eng.boardx)) ;
	  mstr ++;
	}
	if (gprom & 64) {	// Capture?
	  *mstr = ('x');
	  mstr ++;
	} else {
	  if (mode & 1) {
	    *mstr = ('-');
	    mstr ++;
	  }
	}
	*mstr = (97 + (gto % eng.boardx));
	mstr ++;
	*mstr = (48 + eng.boardy - (gto / eng.boardx));
	mstr ++;
	if (gprom & 4) {	// Promo..
	  *mstr =  ('=');
	  mstr ++;
	  *mstr = (STpieces [4 - (gprom & 3)]);
	  mstr ++;
	}
	if (gprom & 128) {	// Check?
	  *mstr = ('+');
	  mstr ++;
	}
}

void PrintMove (short cmove)	// Get info on move & print it in full
{
	char mstr [15];
	Move2Str (mstr, cmove, (BYTE) (FlagShortNot == 0));
	  mstr [7] = 0;
	prints (mstr);
}

short lcurx,lcury;	// X/Y of cur printed move.

void ShowUserMove (void)	// Show inputed user text..
{
	short temp = nprint + 9;
	if (eng.game_status || mvboxLines < 1 || editx < 0 || FlagMoveBox == 0) {
	  return;	// Game end/no window, print nothing.
	}
	GetMyDC (W_MOV, 0);	
	gotoxy (editx,edity);
	prints (UserMoveIn);
	while ((temp - nprint) > 0) printc (' ');
	ReleaseMyDC (W_MOV);	
}

char *szWht,*szBlk;	// Ptrs to player names..

char * GameStatusText(void)	// get game-end text from (eng.game_status)
{
  // eng.game_status: 0 norm,1 to f illegal position,10h to 1f checkmate
  // 20h to 2f stalemate,30h to 3f draw
  // 1=toomany/fewK,2=toomanypieces,3=pawn1/8rank,4=Kcanbecapt
  // 31h=draw3rep,32h=draw50mv,33h=insuf.material
	if (eng.game_status >= 0x33) {		// Drawn material
	  return (STdrawmaterial);
	} 
	if (eng.game_status == 0x32) {	
	  return (STdraw50move);
	} 
	if (eng.game_status == 0x31) {	
	  return (STdraw3rep);
	} 
	if (eng.game_status >= 0x20) {	// Stalemate
	  return (STstalemate);
	} 
	if (eng.game_status >= 0x10) {	// Game over..
	  return (STgameover);
	}
	//if (eng.game_status == 2) {	
	//  return (STillegalkings);
	//} 
	if (eng.game_status == 3) {	
	  return (STtoomanypieces);
	} 
	if (eng.game_status == 4) {	
	  return (STpawnonillegalsquares);
	} 
	//if (eng.game_status == 5) {	
	//  return (STkingcanbecaptured);
	//} 
	
	return (STillegalposition);
}


  // Write PDN moves to move-box
  // Top (x,y) in pixels, len (x,y) in chars. scroll-pos 0-100%..
MYINLINE void mboxWritePDN (short topx, short topy, short lenx, short leny, short *scpos)
{
	short nline;		// Count total # lines..
	short cline;		// Current line..
	static short stline;	// Start line..
	short nchr;
	BYTE curcol;		// Cur colour - 0=blk,1=red,2=blue,3=none (head)
	lcurx = -1;		// Default kill edit field
	lenx = min (lenx, sizeof (outBuf) - 5);
	if (lenx < 15 || leny < 1) return;	// Too small
		// First, count # lines..
	nline = 0;
	memset (&pdnInfo, 0,sizeof (pdnInfo));
	pdnInfo.outstr = outBuf;
	pdnInfo.wide = lenx;
	pdnInfo.maxwide = lenx;
	pdnInfo.centwide = lenx + 1;		// Auto-center header..
	pdnInfo.flags = (Flag_(PgnMoves) == 0) | 0x14;	// Full header
	if (Flag_(PgnMoves)) topx += chrx;
	nchr = pdnExportLine (&pdnInfo);	// get 1st line
	do {
	  nline ++;
	  if (pdnInfo.mode & 1) break;
	  nchr = pdnExportLine (NULL);	// Next line ..
	} while (1);
	    	// RECOMPUTE SCROLL BAR POS
	cline = stline;		// Keep old start line
	stline = nline - leny;	// Calc new max start line..
	if (stline < 1) {
	  stline = 0; *scpos = 100;
	} else if (*scpos < 0) {		// Move rel to last pos..
	  switch (*scpos) {
	    case -4:		// Page Up..
	      cline -= leny; break;
	    case -3:		// Line Up..
	      cline --; break;
	    case -2:		// Line Down..
	      cline ++; break;
	    case -1:		// Page Down..
	      cline += leny; break;
	  }
	  cline = max (min (stline, cline),0);	// Keep in range
	  	// Calc new % pos..
	  *scpos = (short) ((long) ((long) cline * 100L) / (long) stline);
	  stline = cline;	// and save start line..
	} else {
	    	// Calc new start-line, based on scroll bar pos..
	  stline = (short) ((long) ((long) stline * (long) *scpos) / 100L);
	}
		// Now rescan for real print..
	TextCol (PALVATXT,PALBOX);		// blue header..
	curcol = 2;		// Header colour
	cline = 0;
	nchr = pdnExportLine (&pdnInfo);	// get 1st line
	do {
	  cline ++;
	  if (lcurx < 0 && (pdnInfo.mode & 1) && *scpos == 100) {
	    lcurx = topx / chrx + nchr + 1;
	    lcury = topy / chry + 1;
	    if (nchr + 7 > lenx) {	// Wrap to next line
	      lcurx = topx / chrx + 1;
	      lcury ++;
	    }
	  }
	  if (cline > stline) {	// Ok, print..
	    short xpos,xbeg;
	    char cchr;
	    short cpos = nchr;
	    while (cpos <= lenx + 3) {	// Pad out with spaces..
	      outBuf [cpos] = 32;
	      cpos ++;
	    }
	    if (curcol == 2) {
	      if (pdnInfo.headitem > 0x80) {
	        TextCol (PALTXT,PALBOX);	// Main body starts..
	        curcol = 3;
	      }
	    }
	    xpos = 0; xbeg = 0;
	    do {
	      do {
	        cchr = outBuf [xpos];
	        if (cchr == '}') {		// Comment ends
	          outBuf [xpos] = 32;
	          curcol = 0;			// Switch colour
	          cchr = '{';
	          break;
	        }
	        if (cchr == '{') {		// Comment starts
	          outBuf [xpos] = 32;
	          curcol = 1;			// Switch colour
	          break;
	        }
	        xpos ++;
	      } while (xpos < cpos);
	      TextOut (hWDC, topx + xbeg * chrx, topy, outBuf + xbeg, 
				xpos - xbeg);
	      if (curcol < 2) {
	        BYTE tmp = curcol ? PALHITXT : PALTXT;
	        TextCol (tmp, PALBOX);	// Comments..
	        curcol = 3;
	      }
	      xbeg = xpos;
	      xpos ++;
	    } while (xpos < cpos);
	    topy += chry;
	  }
	  nchr = pdnExportLine (NULL);	// Next line ..
	} while (cline < stline + leny);
	TextOut (hWDC, topx, topy, "   ", 3);
}

	// Draw MOVE + info status box
	// if mmode > 0, redo background & borders. <0 no reposition (window)
void MoveBox (char mmode)
{
	short boty;
	{
	  char szTxt [256];
	  char *szOp;
	  szOp = open_Classify ();
	  if (szOp) {
	    sprintf (szTxt,"%s \x22%s\x22",STprogramname,szOp);
	    if (szOp[0] == 0) strcpy (szTxt,STprogramname);
            SetWindowText (hMainWnd,szTxt);
	  }
	}
	if (mvboxWide < 1) return;		// Move box unpainted..
	if (FlagMoveBox == 0 || mvboxBot < chry + chry) goto ExitMB; // Just update clock..
	
		// Out to floating window?
	if (hMovWnd == NULL) goto ExitMB;

	GetMyDC (W_MOV, 0);
	if (mmode > 0) {
	  mvboxLines = ((mvboxBot - mvboxTy - 4) / chry) - 2;  // #mv lines
	}
	TextCol (PALTXT,PALBOX);
	if (mmode >= 0) {		// Scroll back to bottom..
	  mvboxCurScroll = 100;
	}
	mboxWritePDN (mvboxTx, mvboxTy,
	    	mvboxWide / chrx - 2, mvboxLines, &mvboxCurScroll);
	editx = lcurx; edity = lcury;
	boty = mvboxTy + mvboxLines * chry;
	if (eng.game_status) {	// Game over, prt reason..
	  char *gstxt = GameStatusText ();
	  short ltxt = strlen (gstxt);
	  TextCol (PALRED,PALLEAVE);
	  TextOut (hWDC, (mvboxBx - (ltxt * chrx)) >> 1, boty, gstxt, ltxt);
	  lastgamst = 1;
	} else {
	  if (lastgamst) {	// Erase old reason..
	    TextOut (hWDC, (mvboxBx - (14 * chrx)) >> 1, boty,STspace20,14);
	    lastgamst = 0;
	  }
	  if (UserMoveIn [0]) {		// Show any user input..
	    ShowUserMove ();
	  }
	}
	  { short clen;
	    ((short *) szTemp) [0] = 0x2020;
	    lstrcpy (szTemp + 2, szLevel1);
	    clen = lstrlen (szTemp);
	    szTemp [clen] = szTemp [clen + 1] =32;
	    TextOut (hWDC, (mvboxBx - clen * chrx) >> 1, boty + chry, szTemp, clen + 2);
	  }
	ReleaseMyDC (W_MOV);	
		// Now calc new scroll bar position
	if (mvboxCurScroll != mvboxLastScroll) {
	  mvboxLastScroll = mvboxCurScroll;
	  SetScrollPos (hMovWnd, SB_VERT, mvboxCurScroll, TRUE);	// and show it
	}
ExitMB:	
	PrintClock (1);
}

void DlgAddBook (void)		// Add curr line to userbook
{
	//long booksize;
	int cret;
	int hitbutton;

	if (FlagUserBook == 0) return;
	eng.param_ax_pass = 0;
	ext_userbook ();	// Init user book..
	booksize = eng.param_pass;
	cret = dlg_Init (IDM2String (IDM_UBOOKADD), -1,-1,200,100,1);
	if (cret== FALSE) return ;

	wsprintf (szTemp, "%s %lu",(LPSTR) STaddlinetouserbook,booksize);
	dlg_DefTextBox (18,20,162,40,szTemp,SS_CENTER);
	dlg_DefOKCancel (10,10,STok,NULL,40);
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();

	if (hitbutton != IDOK) return ;
	StopAutoPlay ();	// If comp v comp, back to normal
	eng.param_ax_pass = 2;
	ext_userbook ();		// Add line to user book
	InitThink (ThinkOpp);	// Re-start thinking
}

	// Print the user-book to an ascii file..		
void DlgPrintBook (void)
{
        strcpy (szPath,"sbook1.pdn");
	if (SaveDialog (szPath, STpdnfilter, IDM_EXPORTUBOOK,1) == FALSE) {
	  return ;
	}
	SetWaitCursor         // Hour glass mouse..     
	eng.param_ax_pass = 5;
	eng.lparam1_pass = (long) ((char far *) szPath);
	retv = ext_userbook ();	// Print to user book..
	SetNormCursor         // Normal mouse..     
	if (retv == -1) {
	  DoMessage (STEbooknotsaved);
	}
	InitThink (ThinkOpp);	// Re-start thinking
}

void DlgImportBook ()
{
	long startgame;
	int cret;
	int hitbutton;

	if (OpenDialog (szPath, STpdnfilter, IDM_IMPORTBOOK) == FALSE) return;
		// Dialog - input start line
	cret = dlg_Init (IDM2String (IDM_IMPORTBOOK), -1,-1,120,100,1);
	if (cret== FALSE) return ;
	dlgs.FocusID = IDD_SPIN + 1;
	dlg_DefSpin (36,37,8,1,1,9999999,1,0);
	dlg_DefTextCent (-1,25,STstartfrompos);
	dlg_DefOKCancel (10,10,STok,NULL,40);
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();

	if (hitbutton != IDOK) return ;
	startgame = (short) dlg_ReadSpin () ;
	StopThinking ();
	SetWaitCursor 		// Macro - set hour-glass mouse..
	retv = ext_book_import (szPath,startgame - 1);
	Dink ();
	SetNormCursor 		// Macro - normal cursor
	if (retv) {
	  msgprintf (NULL,0,0,"%s:Line %d",(LPSTR) STEbooknotloaded, retv);
	}
	eng2brd ();	// Update displayed board..
	SoundIt ();	// Big sound
			// Force moves to come up..
	TogUserBook
	InitThink (ThinkOpp);
	StopThinking ();
	TogUserBook
	InitThink (ThinkOpp);
	RedrawAWindow (W_BRD);		// Redraw new board pos
}

	// Edit SAGE book flag..
void DlgEditBookFlag (short cbook) 
{
	BYTE cflag = bokFlags [cbook];
	BYTE HUGE_ *bPtr;	// Pointer to book data flag byte
	int cret;
	int hitbutton;

	bPtr = (BYTE HUGE_ *) ((long HUGE_ *) bokPtr [cbook]);
	bPtr += 2;
	if (cflag & 0x80) return;	// Not Colour reversed..
	if (cflag != *bPtr) {		// Must be a match..
	  return;
	}
	cflag ^= 3;	// Make a linear 1..5 (?<=>!)
	cret = dlg_Init (STprogramname, -1,-1,160,170,1);
	if (cret== FALSE) return ;
	dlg_DefTextCent (-1,20,STalterbookstrength);
	dlg_DefRadio (50,40,D_GROUPBOX | 60,14,STstrengthmove,cflag,0);
	dlg_DefOKCancel (10,10,STok,NULL,40);
	hitbutton = dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	if (hitbutton != IDOK) return ;
	cflag = (BYTE) dlg_ReadRadio ();
	*bPtr = cflag ^ 3;
	bokSave ();		// Save resultant book..
	int_step_move (0);	// Redraw book-move list
	RedrawAWindow (W_SCH);
}

void CalcWaste (HWND hWnd)	// calc wastex/y for window (titles, etc)
{
	GetWindowRect (hWnd, &winrct);
	GetClientRect (hWnd, &rct);
	    	// Calc wasteage (title bars, etc)
	wastex = (short) (winrct.right - winrct.left - rct.right);
	wastey = (short) (winrct.bottom - winrct.top - rct.bottom);
}

	// Standard Init box paint - palette, font, colours, background..
void InitBoxPaint (HWND hCWnd)
{
	hWDC = BeginPaint (hCWnd,&ps);
	SelectPalette (hWDC, hPalette, TRUE);	// get palette for window
	RealizePalette (hWDC);
	SelectObject (hWDC,hNullPen);	// Draw background colour
	SelectObject (hWDC,hBoxBrush);
	GetClientRect (hCWnd, &rct);
	Rectangle (hWDC,0,0,rct.right + 1, rct.bottom + 1);
	SelectObject(hWDC, hFont);	// select current font
	TextCol (PALTXT,PALBOX);			// and colour for it..
}

void SetMousePos (UINT wMsg, LPARAM lParam)	// Set up mouse pos..
{
	switch (wMsg) {
          case WM_LBUTTONUP:
          case WM_LBUTTONDOWN:     
          case WM_RBUTTONDOWN:     
          case WM_MOUSEMOVE:       
          case WM_NCMOUSEMOVE:
	    mousex = LOWORD(lParam); 	// Current mouse X/Y coords..
	    mousey = HIWORD(lParam);
	    break;
	}
}

//---------------------------------------------------------------
// MODULE: bok_ functions & WndProc
//---------------------------------------------------------------

LBOX_WIN lbBook;		// Book view-box..

void bok_GetField (char *pStr, int cfield, int cline)
{
    long cval = 0;
    DISPMOVE *pDM;
    BYTE bflag;
    pDM = &eng.disp_mvlist [cline];

    *pStr = NULL;
    switch (cfield) {
      case 1:	// Move/(root)..
        if (pDM->src == pDM->dest) {
	  strcpy (pStr,"Root");
	  return;
	}
        Move2Short (pStr, pDM->src, pDM->dest);
	return;
      case 2: {		// Attribute
        if (pDM->flag) {
	  bflag = bokFlags [pDM->flag - 1];
  	  pStr [0] = "=<?===!>" [bflag & 7];
	  pStr [1] = 0;
	  if (bflag & 0x80) {
	    pStr[1] = '#'; pStr[2] = 0;
	  }
	}
	return;
      }
      case 3: {		// DB eval:  + for WWin, - for Bwin
        // cval = pDM->score; break;
        pStr [1] = pStr [0] = "=+- " [pDM->score & 3];
	pStr [2] = 0;
	return;
      }

      default: return;   // No string..
    }
      // Val is in (cval), add as field..
    ltoa (cval,pStr,10);
    return;
    //str_fromval (pStr, cval, 11 | STR_NOLEAD_CHR | STR_ADD_NULL);
}

long bok_GetInfo (int msg, void *pDat)
{
    LBOX_WIN *pLbox = (LBOX_WIN *) pDat;
    LBOX_FIELD *pField = pLbox->pField;
    static int cline;
    int nmoves;

    switch (msg) {
      case LBOXSERV_ACCESS_START: {
        //book_pMoveInfo = Book_Get_Moves (&pGI->current_pos, &gen.pref.book_weights);
	//nmoves = book_pMoveInfo->flag;
	lbBook.totLines = eng.disp_nmoves + 1;
        return TRUE;
      }
      case LBOXSERV_ACCESS_END: {
        return TRUE;
      }
      case LBOXSERV_STARTLINE: {	// Start display of new line, get header data from db..
        cline = pField->rline - 1;
        //pBMI = &book_pMoveInfo [cline];	// Get info for this move (0=root)
        return TRUE;	// Line is ok!
      }
      case LBOXSERV_NEEDFIELD: {
	pField->lineColour = LBOX_COL_TEXT;

	if (eng.disp_mvlist[cline].flag) {   // Book move, hilite in blue
	  pField->lineColour = LBOX_COL_TEXT_RED;
	}
	bok_GetField (pField->pTxt,pField->rfield,cline);
	return TRUE;	// Data is ok..
      }
      case LBOXSERV_ITEM_SELECTED: {	// Mouse selects a move?
          if (pField->mouseCmd != WM_LBUTTONDBLCLK) return 0;   // Must be lmouse dbl click
        if (pField->rline > 0) {
          DISPMOVE *pDM = &eng.disp_mvlist [pField->rline - 1];
	  if (pField->rfield == 0) {
	    StopThinking ();
	    if (pDM->src != pDM->dest) {
	      Exec1Move (pDM->src,pDM->dest,0,5);
	    }
	    return 0L;
	  } else {	// Dbl clock on book attributes
	    short cbook = pDM->flag-1;
	    if (cbook>=0) {
	      InitThink (ThinkNone);		
	      DlgEditBookFlag (cbook);
	    }
	    return 0L;
	  }
	}
	return 0L;
      }
    }
    return TRUE;
}

LRESULT bok_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    LBOX_WIN *pLbox = &lbBook;
    RECT wrct;
    switch(wMsg) {                      // which message?

      case WM_CREATE: {
        memset (pLbox,0,sizeof (LBOX_WIN));
	pLbox->pHeadTxt = "Move\0Book\0DB\0\0";
	pLbox->nFields = 3;
	//pLbox->totLines = 10;
	pLbox->pfnServiceLbox = bok_GetInfo;	// Service routine..
	{ short t[] = {-14,-8,-300};  // Width each field (in 1/2 ave chars)
	  memcpy (pLbox->headx,t,pLbox->nFields * sizeof(short));
	}
	pLbox->szTitle = "";
	pLbox->llen.x = 10;	// Set up an initial window size (set properly by WM_SIZE)
	pLbox->llen.y = 10;
	pLbox->hParent = hWnd;
	pLbox->phFont = &hSysVarFont;
	pLbox->lboxtype = LBOX_TYPE_VERTSCROLL | LBOX_TYPE_SELECTABLE | LBOX_TYPE_ELASTIC;
	//pLbox->hPal = gen.dBmp.hPal;
        lbox_WinCreate (pLbox);	// Create "list-view-box" with analysis..
        return 0;
      }
      case WM_SIZE: {
	GetClientRect (hWnd, &wrct);
        lbox_Resize (pLbox,0,0,wrct.right+1, wrct.bottom+1);
      case WM_MOVE:
        SaveWin (&eng.bokwnd, hWnd,1);	// Save window size..
        return 0L;
      }
      case WM_DESTROY:		// Kill window..
	lbox_Close (pLbox);
	hBokWnd = NULL;
        break;
      case WM_CLOSE:	// Win closed manually by user..
        KillBookMovesFlag	// Kill search box..
	return 0;
    }
    return DefWindowProc (hWnd, wMsg, wParam, lParam);
}

void bok_Redraw ()
{
    InvalidateRect (lbBook.hWnd,NULL,TRUE);
    InvalidateRect (hBokWnd,NULL,TRUE);
}

//---------------------------------------------------------------
// MODULE: sch_ new sch window maintanance..
//---------------------------------------------------------------

#define SCH_USENEW 1    // Set to use new style sch window 

#if SCH_USENEW
extern short mlaTop;
extern short Search2Str (char *, ANALY *, short);
extern ANALY *mlaList;	// Array of analysis structures.
extern void Eval2Str (char *, BYTE,  BYTE);
extern void BestLine2Str (ANALY *, char *, short, short);

LBOX_WIN lbSch;		// 

void sch_GetField (char *pStr, int cfield, int cline)
{
    long cval = 0;
    int sline;
    ANALY *pAn;

    sline = (eng.histanal + mlaTop - cline) % eng.histanal;
    pAn = mlaList + sline;
        //Search2Str (pStr, pAn,(FlagFullAnal != 0));

    *pStr = NULL;
    if (pAn->moves[0] == pAn->moves[1]) return;  // no best line..

    switch (cfield) {
      case 1:	// Root..
	INT2ASC2 (pStr,pAn->number);	// Move index
	pStr[0] = ':';
	Move2Short (pStr+1,pAn->mvfrom,pAn->mvto);
	pStr[5] = 0;
	return;
      case 2:	// IQ
        wsprintf (pStr, "%u-%u",pAn->depthmin << 1,pAn->depthmax);
	return;
      case 3:	// Time
        time2asc (pStr,pAn->time,2);		// Target time..
	return;
      case 4:	// Nodes..
        cval = pAn->nodes; 
	break;
      case 5:	// Eval..
        if (cline == 0 && pAn->type == AN_MAIN) return;
	Eval2Str (pStr,pAn->scorelo, pAn->scorehi);
	pStr[6] = 0;
	return;
      case 6:	// Best
        if (cline == 0 && pAn->type == AN_MAIN) return;
        BestLine2Str (pAn,pStr,12,5);		// Print 12 move line..
	return;

      default: return;   // No string..
    }
      // Val is in (cval), add as field..
    ltoa (cval,pStr,10);
    return;
    //str_fromval (pStr, cval, 11 | STR_NOLEAD_CHR | STR_ADD_NULL);
}

long sch_GetInfo (int msg, void *pDat)
{
    LBOX_WIN *pLbox = (LBOX_WIN *) pDat;
    LBOX_FIELD *pField = pLbox->pField;
    static int cline;
    switch (msg) {
      case LBOXSERV_ACCESS_START: {
	lbSch.totLines = eng.histanal;
        return TRUE;
      }
      case LBOXSERV_ACCESS_END: {
        return TRUE;
      }
      case LBOXSERV_STARTLINE: {	// Start display of new line, get header data from db..
        cline = pField->rline - 1;
        //pBMI = &book_pMoveInfo [cline];	// Get info for this move (0=root)
        return TRUE;	// Line is ok!
      }
      case LBOXSERV_NEEDFIELD: {
        int sline;
        ANALY *pAn;

	pField->lineColour = LBOX_COL_TEXT;
        sline = (eng.histanal + mlaTop - cline) % eng.histanal;
        pAn = mlaList + sline;
	if (cline == 0) {  
	  pField->lineColour = LBOX_COL_TEXT_BLUE;
	} 
	if (pAn->type == AN_OPP) {   
	  pField->lineColour = LBOX_COL_TEXT_GREY;
	} 
	if (pAn->type == AN_EXEC) {   
	  pField->lineColour = LBOX_COL_TEXT_RED;
	} 
	sch_GetField (pField->pTxt,pField->rfield,cline);
	return TRUE;	// Data is ok..
      }
    }
    return TRUE;
}

LRESULT sch_WndProc (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    LBOX_WIN *pLbox = &lbSch;
    RECT wrct;
    switch(wMsg) {                      // which message?

      case WM_CREATE: {
        memset (pLbox,0,sizeof (LBOX_WIN));
	pLbox->pHeadTxt = "Cur\0IQ\0Time\0Nodes\0Eval\0Best Line\0\0";
	pLbox->nFields = 6;
	//pLbox->totLines = 10;
	pLbox->pfnServiceLbox = sch_GetInfo;	// Service routine..
	{ short t[] = {-18,-18,-14,-24,-18,-500};  // Width each field (in 1/2 ave chars)
	  memcpy (pLbox->headx,t,pLbox->nFields * sizeof(short));
	}
	pLbox->szTitle = "";
	pLbox->llen.x = 10;	// Set up an initial window size (set properly by WM_SIZE)
	pLbox->llen.y = 10;
	pLbox->hParent = hWnd;
	pLbox->phFont = &hSysVarFont;
	pLbox->lboxtype = LBOX_TYPE_INVERT | LBOX_TYPE_VERTSCROLL | LBOX_TYPE_ELASTIC;
	//pLbox->hPal = gen.dBmp.hPal;
        lbox_WinCreate (pLbox);	// Create "list-view-box" with analysis..
	searchtx = 0;
        return 0;
      }

      case WM_SIZE: {
	GetClientRect (hWnd, &wrct);
        pLbox->StartOffset += 9999;
        lbox_Resize (pLbox,0,0,wrct.right+1, wrct.bottom+1);
      case WM_MOVE:
        SaveWin (&eng.schwnd, hWnd,1);	// Save window size..
        return 0L;
      }

      case WM_DESTROY:		// Kill window..
	lbox_Close (pLbox);
	hSchWnd = NULL;
        break;

      case WM_CLOSE:	// Win closed manually by user..
        KillSearchFlags	// Kill search box..
	return 0;
    }
    return DefWindowProc (hWnd, wMsg, wParam, lParam);
}

void sch_Redraw ()
{
    InvalidateRect (lbSch.hWnd,NULL,TRUE);
    InvalidateRect (hSchWnd,NULL,TRUE);
}

#endif

long wndCreate = 0;

LRESULT CALLBACK ChildBoxProc(HWND hCWnd,  // our window's handle
				UINT wMsg,	   // message number
				WPARAM wParam,	   // word parameter
				LPARAM lParam)	   // long parameter
{
	HDC hDC;
	short nchanged;
	HPALETTE hpalT;	// old pal handle
	if (wndCreate) {    // Special bit flag set before CreateWindow to ID window..
	  if (wndCreate & (1 << W_SCH)) hSchWnd = hCWnd;
	  if (wndCreate & (1 << W_MOV)) hMovWnd = hCWnd;
	  if (wndCreate & (1 << W_BOK)) hBokWnd = hCWnd;
	  if (wndCreate & (1 << W_BRD)) hBrdWnd = hCWnd;
	  wndCreate = 0;
	}
		// Dialog box in progress, dont service child boxes..
	if (DoingDialog || DoingPopDlg) {
	  switch (wMsg) {
	    case WM_SETFOCUS:		// Do not process these
	    case WM_NCHITTEST:
	    case WM_WINDOWPOSCHANGING:
	      return 0L;
	    case WM_ACTIVATE:		// Only service if deactivating
	      if (wParam == WA_INACTIVE) break;		
	      return 0L;
	    case WM_ACTIVATEAPP:
	    case WM_NCACTIVATE:
	      if (wParam == 0) break;	//deactivated
	      return 0L;
	  }
	}
	SetMousePos (wMsg, lParam);    // Set up mousex/y vars, if mouse MSG

		// First Handle messages common to all dialogs
	switch (wMsg) {
		// Send keystroke back to main window	
          case WM_KEYDOWN:
          	  // has CTRL-F4 been hit?
	    if (wParam == VK_F4 && (GetKeyState (VK_CONTROL) & 0x8000)) {
	    	// yes - close window..
	      SendMessage (hCWnd,WM_SYSCOMMAND,SC_CLOSE,0L);
              return 0l;
            }
	  case WM_CHAR:
	    SendMessage (hMainWnd,wMsg,wParam,lParam);
	    return 0L;
	    
	  case WM_PALETTECHANGED:
	    if ( (HWND) wParam == hCWnd) return 0;
	  case WM_QUERYNEWPALETTE:
	      // If realizing the palette causes the palette to change,
	      // redraw completely.
	    hDC = GetDC (hCWnd);
	    hpalT = SelectPalette (hDC, hPalette, FALSE);
	    nchanged = RealizePalette (hDC); 	// # entries that changed 
	    SelectPalette (hDC, hpalT, TRUE);	// Orig back in..
		// If any palette entries changed, repaint the window.
	    if (nchanged > 0) {
	      InvalidateRect (hCWnd, NULL, TRUE);
	    }
	    ReleaseDC (hCWnd, hDC);
	    return nchanged;
	    
          case WM_RBUTTONUP:          //// Right mouse button up
          case WM_LBUTTONUP:          //// Left mouse button up
		// If hot key bmp hit, process..      
	    ProcessHotKey (HotLastInfo,0);		// Key up..
            break;		// continue processing..
        
          case WM_MOUSEMOVE:          //// Mouse movement
          case WM_NCMOUSEMOVE:
		// If hot key bmp held, process..      
	    ProcessHotKey (HotLastInfo,2);
		// If held-piece not moving in right window, kill it
	    if (hBrdWnd != hCWnd) {
	      KillPiece ();	// Let go of piece..
	    }
            break;		// continue processing..
            
	  case WM_GETMINMAXINFO:	// Set minimize window size..
	    lpmmi = (MINMAXINFO FAR *) lParam;
	    lpmmi->ptMinTrackSize.x = 60;// Never smaller than this..
	    lpmmi->ptMinTrackSize.y = 60;
	    if (FlagPopUp == 0) {
	      RECT rc;
	      GetClientRect (hMainWnd, &rc);
	      lpmmi->ptMaxTrackSize.x = rc.right + WndBorderx * 2;// Never bigger than this..
	      lpmmi->ptMaxTrackSize.y = rc.bottom + WndBordery;
	    }
	    return 0L;
            
          case WM_SYSKEYDOWN:	// System key..
            if (wParam == VK_F4) {  // ALT-F4..
              EndProg (1);		// Save last game, Post DESTROY msg
              return 0l;
            }
            break;
            
	  default:;	    // exit
	}
	
 		// Now deal with specific messages for each window
	if (hCWnd == hBrdWnd) goto BoardProc;
	if (hCWnd == hMovWnd) goto MoveBoxProc;
	if (hCWnd == hClkWnd) goto ClockProc;
	if (hCWnd == hBokWnd) goto BookProc;
	if (hCWnd == hSchWnd) goto SearchBoxProc;
	goto ExitBoxProc;
	
		// Deal with a search box update,,	
SearchBoxProc:
        #if SCH_USENEW 
	  return sch_WndProc (hCWnd, wMsg, wParam, lParam);
	#endif

	switch (wMsg) {
	  
	  case WM_PAINT:		// Refresh search box window..
	    InitBoxPaint (hCWnd);	// Init paint, palette, fonts, backg
	    hSchDC = hWDC;
	    searchtx = chrx; 
	    searchty = 0;
	    searchbx = (short) rct.right;
	    searchby = (short) rct.bottom;
	    
	    SearchBox ();
	    EndPaint (hCWnd,&ps);
	    hSchDC = NULL; 
	    hWDC = hMainDC;	// Back to normal DC..
	    return 0L;
	  
          case WM_LBUTTONDBLCLK: 	// Dbl click book move?
          case WM_RBUTTONDBLCLK: 
          	// calc char cell pos..
	    tempy = (USHORT) ((USHORT) mousey - sboky);
	    	// Could it be a book move selection?
            if (tempy <= (USHORT) chry * 16 && FlagBookMoves && FlagMainBook) {
              USHORT cbook,sbook;	// Calc book-move #
	      sbook = (USHORT) ((USHORT) mousex - sbokx) / (chrx * 6) 
	      	+ sbokNmov * (tempy / chry);
	      for (cbook = 0; eng.book_moves [cbook]; cbook ++) {	
	        if (cbook == sbook) {		// Found clicked mv..
	          if (wMsg == WM_LBUTTONDBLCLK) {
	            //msgprintf (NULL,1,1,"BOOK=%d",sbook);
	            Dink ();
		    StopThinking ();
		    Exec1Move (eng.book_moves [sbook],eng.book_moves [sbook] >> 8,0,5);
	            return 0L;
	          } else {	// Edit book move flag..
		    DlgEditBookFlag (cbook);
	          }
	        }
	      }
            }
            break;
            
	    		// Drop thro for hot-key hit-test..
	  case WM_SYSCOMMAND:
	    //if (wParam == SC_CLOSE) {
	    //KillSearchFlags	// Kill search box..
	    //}
	    goto ExitBoxProc;	// Default windows processing..
	    
	  case WM_SIZE:
	  case WM_MOVE:
	    SaveWin (&eng.schwnd, hCWnd,1);	// Save window size..
	    return 0L;
	    
	  case WM_CLOSE:	// Win closed manually by user..
	    KillSearchFlags	// Kill search box..
	    goto ExitBoxProc;	// Let WM_DESTROY continue..
	    
	  case WM_DESTROY:
	    hSchWnd = NULL;	// Disable future writes to this window
	    return 0L;
	    
	  default:
	    goto ExitBoxProc;
	}
	return 0L;
	
			// Deal with a BOARD window..
BoardProc:		
	btopx = 0; btopy = 0;	// Offset in window to start board
	switch (wMsg) {
	  
	  case WM_PAINT:		// Refresh board window..
	    hWDC = BeginPaint (hCWnd,&ps); 
	    hBrdDC = hWDC;
	    brdsizex = charx * eng.boardx;
	    brdsizey = chary * eng.boardy;
	    	// if Numbering on, and space to print it..
            
	    CalcWaste (hCWnd);	// Calc Wastex/y, also Client size -> rct..
	    if (IsZoomed (hBrdWnd)) {	// Window is maximized, dont rescale
	      //EndPaint (hCWnd,&ps);	// End current redraw
	      //hBrdDC = NULL; hWDC = hMainDC;	// Back to normal DC..
	      //ShowWindow (hBrdWnd,SW_RESTORE);
	      //MoveWindow (hBrdWnd, 0, 0, nVduY,nVduY,TRUE);
	      //SaveWin (&eng.brdwnd, hCWnd,1);	// Save window size..
	      SelectObject (hWDC,hNullPen);	// Fill background colour
	      SelectObject (hWDC,hBoxBrush);
	      Rectangle (hWDC,0,0,rct.right + 1, rct.bottom + 1);
	    } else {	// Non-maximise brd must always be exact sqr size..
	      if (rct.right != brdsizex || rct.bottom != brdsizey) {
		EndPaint (hCWnd,&ps);	// End current redraw
	        hBrdDC = NULL; 
	        hWDC = hMainDC;		// Back to normal DC..
	        SetWindowPos (hBrdWnd,(HWND) NULL,0,0,	wastex + brdsizex, 
	        	wastey + brdsizey,SWP_NOZORDER | SWP_NOMOVE);
	        //MoveWindow (hBrdWnd, winrct.left, winrct.top, 
		//  wastex + brdsizex, wastey + brdsizey,TRUE);
	        SaveWin (&eng.brdwnd, hCWnd,1);	// Save window size..
	        return 0L;
	      }
	    }
	    SelectPalette (hWDC, hPalette, TRUE);	// get palette
	    RealizePalette (hWDC);
	    SelectObject(hWDC, hFont);	// select font
	    TextCol (PALTXT,PALBOX);			// and colour
	    
	    DrawBoard ();		// Redraw board..
	    EndPaint (hCWnd,&ps);
	    hBrdDC = NULL; 
	    hWDC = hMainDC;	// Back to normal DC..
	    return 0L;
	  
	  case WM_SYSCOMMAND:
	    //if (wParam == SC_CLOSE ) {
	    //  KillBoardFlag	// Kill search box..
	    //}
	    goto ExitBoxProc;	// Default windows processing..
	    
	  case WM_SETCURSOR:		// Re init cursor
      	    if (movemode) {
              SetCursor (hEmptyCursor);
	      return 0L;
	    }
	    goto ExitBoxProc;	// Default windows processing..
	    
	  case WM_SIZE:		// Re-calc board square size..
	  			// lParam has x,y size..
	    GetWindowRect (hCWnd, &winrct);
	    	// Calc wasteage (title bars, etc)
	    wastex = winrct.right - winrct.left - LOWORD (lParam);
	    wastey = winrct.bottom - winrct.top - HIWORD (lParam);
	    	// Calc would-be x/y sqr size for this window..
	    ncx = (LOWORD (lParam) ) / eng.boardx;
	    ncy = (HIWORD (lParam) ) / eng.boardy;
	    	// Make ncx the most variant char size..
	    if (abs (ncx - charx) < abs (ncy - chary)) ncx = ncy;
		// Keep within Min/Max allowed..	    
	    
	    if (ncx < minsetchr) ncx = minsetchr;
	    if (FlagPopUp) {	// Floating window
	      temp = (nVduY - wastey + 6) / eng.boardy;	// calc max size
	    } else {		// child window
	      temp = (absmain.bottom - absmain.top - wastey) / eng.boardy;
	    }
	    if (ncx > temp) ncx = temp;
	    
	    if (ncx != charx) {		// Char size has changed..
	      charx = chary = ncx;
	      ImpNewSet (2);	// Re-load set for new size.. (repaint if set changed)
	    }
	    
	    if (IsZoomed (hBrdWnd)) {	// Window is maximized, dont rescale
	    } else {
			// Re-square up board size (not moving it..)
	      SetWindowPos (hBrdWnd, (HWND) NULL, 0,0, 
		wastex + charx * eng.boardx , 
		wastey + chary * eng.boardy ,
		SWP_NOZORDER | SWP_NOMOVE);
	    }
	    			// drop thro to save window size/pos..
	  case WM_MOVE:			// Only moved window..
	    SaveWin (&eng.brdwnd, hCWnd,1);	// Save window size..
	    return 0L;
	    
	  case WM_LBUTTONDOWN:          //// Left mouse button hit, PICKUP..
	  case WM_LBUTTONDBLCLK:
	    { 		// If WM_PAINT in queue, dont pickup (Palette repaint..)
	      MSG msg;
	      if (0 && PeekMessage (&msg, NULL, WM_PAINT,WM_PAINT, PM_NOREMOVE)) {
	        goto ExitBoxProc;
	       }
	    }
		// See if piece pick up.. 
	    if (ThinkMode != ThinkComp) {
	      PickupPiece (W_BRD);
	       { short destsqr;
	         do {
	           destsqr = islegalengine (movefrom, movefrom,255);
	           if (destsqr < 0) break;	// No moves left..
	           DropPiece ();
	           moveto = cg2my (destsqr);
	           DoHumanMove (movefrom,moveto,1);	// Sliding move
	           movefrom = moveto;	// reloop - see if any multijumps
	         } while (1);
	       }
	    }
	    return 0L;
                                   
	  case WM_LBUTTONUP:	// Left mouse button release, DROP..
	    if (movemode == 1) {	// Piece being held..
	      if (DropPiece ()) {	// Possible legal move  (movefrom,moveto)
	        if (DoHumanMove (movefrom,moveto,0) == 0) {	// Legal move made..
		  return 0L;
	        } 
	      } else {
	        GetMyDC (W_BRD, 1);	
	        gputat (movefrom,movingpiece);		// renew orig source
	        ReleaseMyDC (W_BRD);	
	      }
	    }
            return 0L;
                                   
	  case WM_MOUSEMOVE:          //// Mouse moved - redraw any piece held.
		// If piece held, move/process..
	    MoveAPiece (wParam);
            return 0L;
        

          case WM_MENUSELECT:
	    KillPiece ();		// Kill piece being held, back to normal.
	    return 0L;
                
	  case WM_CLOSE:	// Win closed manually by user..
	    if (IsZoomed (hCWnd)) ShowWindow (hCWnd,SW_RESTORE);
	    KillBoardFlag	// Kill board flag..
	    goto ExitBoxProc;	// Let WM_DESTROY continue..
	    
	  case WM_DESTROY:
	    hBrdWnd = NULL;	// Disable future writes to this window
	    RedrawAWindow (W_MAIN);	// repaint main
	    return 0L;
	    
	  default:
	    goto ExitBoxProc;
	}
	return 0L;


			// Deal with CLOCK box messages..	
ClockProc:	
	goto ExitBoxProc;
      return 0L;
	
MoveBoxProc:			// Process move box..	
		// Deal with a move box update,,	
	switch (wMsg) {
	  
	  case WM_VSCROLL:
	    switch (wParam) {		// Which scroll bar ctrl hit?
	      case SB_THUMBPOSITION:
	        mvboxCurScroll = LOWORD (lParam);	// Pos moved to by user
	        break;
	      case SB_LINEDOWN:		// down 1 line
	        mvboxCurScroll = -2;
	        break;
	      case SB_LINEUP:		// up 1 line
	        mvboxCurScroll = -3;
	        break;
	      case SB_PAGEDOWN:		// down 1 page
	        mvboxCurScroll = -1;
	        break;
	      case SB_PAGEUP:		// up 1 page
	        mvboxCurScroll = -4;
	        break;
	      default:
	        return 0L;	// no action on others..
	    }
	    MoveBox (-1);	// repaint at this new position..
	    return 0L;
	    
	  case WM_PAINT:		// Refresh move box window..
	    InitBoxPaint (hCWnd);	// Init paint, palette, fonts, backg
	    hMovDC = hWDC;
		// Set box top/bottom coords
	    mvboxTx = 0; 
	    mvboxTy = chry + chry;	// Top of prn area
	    mvboxBx = (short) rct.right; 
	    mvboxBy = (short) rct.bottom;
	    mvboxBot = mvboxBy;		// Bot of prn area
	    if (mvboxBx > chrx * 24) mvboxTx += chrx;
	    mvboxWide = mvboxBx - mvboxTx;	// Width prn area
	      #if _SAGE
	        mvboxTy = chry;		// No box at top..
	      #endif
	      PrintClock (2);		// Re-draw clock face..
	      SelectObject(hWDC, hFont);	// select current font
	      TextCol (PALTXT,PALBOX);		// and colour for it..
	      	// calc bottom of printable area..
	      mvboxBot = clktxty;		// Bottom of print area..
	    MoveBox (1);	// Refresh box..
	    EndPaint (hCWnd,&ps);
	    hMovDC = NULL; 
	    hWDC = hMainDC;	// Back to normal DC..
	    return 0L;

          case WM_LBUTTONDOWN:          //// Left mouse button hit
          case WM_LBUTTONDBLCLK: 
            return 0L;
        
          case WM_RBUTTONDOWN:          //// Right mouse button hit
          case WM_RBUTTONDBLCLK: 
            return 0L;
        
          
	  case WM_SYSCOMMAND:
	    //if (wParam == SC_CLOSE) {
	    //  KillMoveBoxFlag	// Kill search box..
	    //}
	    goto ExitBoxProc;	// Default windows processing..
	    
	  case WM_SIZE:
	  case WM_MOVE:
	    SaveWin (&eng.movwnd, hCWnd,1);	// Save window size..
	    return 0L;
	    
	  case WM_CLOSE:	// Win closed manually by user..
	    KillMoveBoxFlag	// Kill move box..
	    goto ExitBoxProc;	// Let WM_DESTROY continue..
	    
	  case WM_DESTROY:
	    hMovWnd = NULL;	// Disable future writes to this window
	    return 0L;
	    
	  default:
	    goto ExitBoxProc;
	}
	return 0L;
	
BookProc:			// Process book box
	return bok_WndProc (hCWnd, wMsg, wParam, lParam);

ExitBoxProc:	
	return DefWindowProc (hCWnd, wMsg, wParam, lParam);
}

void RedrawAWindow (short windex)	// Redraw a window..
{
	if (hAWnd [windex]) InvalidateRect (hAWnd [windex], NULL, TRUE);
}

void RedrawAllWindows (void)	// Redraw all windows..
{
	// Force repaint of all windows that exist (non-null)
	if (hMainWnd) InvalidateRect (hMainWnd, NULL, TRUE);
	if (hBrdWnd) InvalidateRect (hBrdWnd, NULL, TRUE);
	if (hSchWnd) InvalidateRect (hSchWnd, NULL, TRUE);
	if (hMovWnd) InvalidateRect (hMovWnd, NULL, TRUE);
	if (hClkWnd) InvalidateRect (hClkWnd, NULL, TRUE);
	if (hBokWnd) bok_Redraw ();
}

	// Create/detroy just 1 window..
void ProcessWindow (short fmode, short cwnd, WRECT far *Cur, 
		char *Titlestr)
{
	short wtx,wty;
	long wstyle;
	wstyle = WS_VISIBLE | WS_BORDER | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME;
	if (FlagFIXEDBRD && cwnd == W_BRD) {	// Fixed board window..
	    //wstyle = WS_CHILD | WS_TABSTOP | WS_VISIBLE | WS_BORDER;
	  wstyle = WS_TABSTOP | WS_VISIBLE | WS_SYSMENU | WS_BORDER | WS_CAPTION;
	}
	if (FlagPopUp) {
	  wstyle |= WS_POPUP;
	} else {
	  wstyle |= WS_CHILD | WS_CLIPSIBLINGS;
	}
	if (fmode & 8) wstyle |= WS_VSCROLL;
	if (fmode & 16) wstyle |= WS_MAXIMIZEBOX;
	if (fmode & 1) {	// Create this window	?
	  if (hMainWnd) {		// Relative to main window..
	    GetWindowRect (hMainWnd, &mainrct);	// Rect for main win..
	  }
	  wtx = Cur->tx; 	// Top-left pos to make/move this window..
	  wty = Cur->ty;
	  if (FlagFIXEDBRD && cwnd == W_BRD) {	// Fixed board window..
	    //Titlestr = "";
	  } else if (FlagPopUp) { // Add main wnd pos to this window pos
	    wtx += (short) mainrct.left;
	    wty += (short) mainrct.top;
	  }
	  if (hAWnd [cwnd] == NULL) {
	    wndCreate |= (1 << cwnd);
	    hAWnd [cwnd] = CreateWindow ("ChildClass", Titlestr, wstyle,
		wtx, wty, Cur->lx, Cur->ly, hMainWnd, NULL,hInstance, NULL);
	    //if (hAWnd [cwnd] == NULL) {	// Window create failed
	    //  TogFloat
	    //  return;
	    //}
	    ModSysMenu (hAWnd [cwnd]);	// Delete unwanted sys menu cmds
	    ShowWindow (hAWnd [cwnd], SW_SHOWNORMAL);	
	  } else if (fmode & 4) {	// Already exists, re-pos..
	    MoveWindow (hAWnd [cwnd], wtx, wty, Cur->lx, Cur->ly, TRUE);
	  }
	} else {			// Floating windows need killing		
	  if (hAWnd [cwnd] != NULL) {	// Kill this window
	    
	    DestroyWindow (hAWnd [cwnd]);
	    hAWnd [cwnd] = NULL;
	  }
	}
}

short InProcess = 0;

	// Deal with any floating windows - open/close as appropiate.
	// according to current (fmode) - set for float enabled
	// fmode == 0 to switch all off
	// bit 0 set to reopen at old pos
	// bit 1 set to reset positions
	// bit 2 set to repos existing windows..
	

void ProcessFloatingWindows (short fmode)
{
	short btx,bty;		// board top x,y
	short bbx,bby;		// board bot x,y
	short cbx,cby;		// clock bot x,y
	short sty;		// search top y
	short botx,boty;		// MAX Bottom right for placement..
	const short gap = 1;
	if (InProcess) return;		// Already doing it, dont recall!
	InProcess = 1;			// Disables any further calls while doing it..
	
	GetMainInfo ();	  // Get (absmain,mainrct) RECT info on hMainWnd
		// Calc border sizes..
	MainTitley = (short) (absmain.top - mainrct.top);	// size of window title-menu etc
		// Calc default positions to place pop-up windows
		// Board top x/y
	btx = 3;			// Board top x/y for Child window..
	bty = 3;
	//btx += HotMain.lenx;
	
	#if TOOLBAR
	  bty += tb_Main.ttop.y + tb_Main.tlen.y;    // Leave spc for toolbar
	#endif
	if (FlagPopUp) {	// Brd top x/y for Popup window..
	  btx += WndBorderx;
	  bty += MainTitley;
	}
		// Board bot x/y
	bbx = btx + charx * eng.boardx + 2 + gap;
	bby = bty + chary * eng.boardy + (WndTitley + 2) +  gap;
		// Ensure parent rect big enough
	if (FlagPopUp) {
	  botx = (short) min (nVduX + WndBorderx, max ((mainrct.right - mainrct.left), bbx + 40 * chrx));
	  boty = (short) min (nVduY, max (bby + chry * 6, (mainrct.bottom - mainrct.top)));
	} else {
	  botx = (short) (absmain.right - absmain.left);
	  boty = (short) (absmain.bottom - absmain.top);
	}
		// Clock bot x/y
	cbx = botx - WndExtrax - 5;
	cby = bty;//bty + clkchry + 40 + WndExtray;
		// Search top y
		// Board window - set defaults?
	if ((fmode & 2) || eng.brdwnd.lx < 15) {
	  eng.brdwnd.tx = btx;
	  eng.brdwnd.ty = bty;
	  eng.brdwnd.lx = bbx - btx - gap;
	  eng.brdwnd.ly = bby - bty - gap;
	}
	//sty = boty + WndBordery - WndExtray - (chry * 5);
	//if (FlagFullAnal == 0) sty += chry + chry;
	sty = eng.brdwnd.ty + eng.brdwnd.ly + gap;
		// Search window - set defaults?
	if ((fmode & 2) || eng.schwnd.lx < 15) {
	  eng.schwnd.tx = btx;
	  eng.schwnd.ty = sty + gap;
	  eng.schwnd.ly = boty - sty + WndBordery;	// box len + title height
	  eng.schwnd.lx = botx - btx - gap - gap;
	}
		// Move window - set defaults?
	if ((fmode & 2) || eng.movwnd.lx < 15) {
	  eng.movwnd.tx = bbx + gap + WndExtrax;
	  eng.movwnd.ty = bty;
	  eng.movwnd.lx = cbx - bbx - gap - gap - 80;
	  eng.movwnd.ly = sty - cby - gap - gap;
	}
	
	if ((fmode & 2) || eng.bokwnd.lx < 15) {
	  eng.bokwnd.tx = eng.movwnd.tx + eng.movwnd.lx;
	  eng.bokwnd.ty = bty;
	  eng.bokwnd.lx = 90;  //eng.movwnd.tx - bbx;
	  eng.bokwnd.ly = eng.movwnd.ly;
	}
	
	if (fmode & 1) {
	  WMclosing = 1;	// Indicates close, but keep flags..
	}
		// Create/destroy the Board window..	
	ProcessWindow ((16 | fmode) & ~(FlagBoard == 0), W_BRD, &eng.brdwnd, STboard);
	
		// Create/destroy the search window..	
	ProcessWindow ((16 | fmode) & ~(FlagMainAnal == 0), W_SCH, &eng.schwnd, STanalysis);
		
		// Create/destroy the Move window..	
	ProcessWindow ((24 | fmode) & ~(FlagMoveBox == 0), W_MOV, &eng.movwnd, STmoves);
	
		// Create/destroy the search window..	
	ProcessWindow (fmode & ~(FlagBookMoves == 0), W_BOK, &eng.bokwnd, STbook);

	WMclosing = 0;
	InProcess = 0;
}

short anyfly = 0;

unsigned long synctime = 0;
unsigned long tempclock;
long flywheel = 6;	// Val for flywheel sync..
short flycounts = 0;
long cfly;

void initsync (void)		// Estimate FLYWHEEL val
{
	short cfly1;
	synctime = clock ();
	while ((unsigned long) clock () == synctime);
	synctime = clock ();
	flywheel = 0;
	do {
	  for (cfly1 = 1; cfly1 < 2000; cfly1 ++) ;	// Delay loop
	  flywheel ++;
	} while ((unsigned long) clock () == synctime);
	synctime = clock ();
	flywheel = (flywheel * 3) / 14;
	flycounts  = 0;
}

void syncfly (void)		/* 03da bit 3 set during flyback - bot to top bdr */
{
	if (anyfly) { 			// Use Hardware..
	  while (_inpw (0x3da) & 8);
	  while ((_inpw (0x3da) & 8) == 0);
	} else {			// Use Flywheel sync timer..
	  short cfly1;
	  tempclock = clock ();
	  for (cfly = 1; cfly <= flywheel; cfly ++) {
	    for (cfly1 = 1; cfly1 < 2000; cfly1 ++) ;	// Delay loop
		// Never more 1/10 sec..	    
	    if (clock () - tempclock > CLOCKS_PER_SEC / 10) break;  
	  }
	}
}

short mouse2sqr (short xin, short yin)	//* Conv Mouse to square no.
{
	short xloc,yloc,temp;
	xloc = (xin - btopx) / charx + 1;
	yloc = (yin - btopy) / chary + 1;
	if (MainMode == DoingSetup) {	// Also edit panel..
	  if (yloc >= eng.boardy + 2 && yloc <= eng.boardy + 3 && xloc >= 2 && xloc <= 7) {// Panel hit
	    temp = xloc - 1;
	    if (yloc == eng.boardy + 3) temp =- temp;
	    return (1000 + temp);	// 1000 + piece val...
	  }	
	}
	if (xloc < 1 || xloc > eng.boardx || yloc < 1 || yloc > eng.boardy)
	  return (-1);
	if (FlagInvert) {	// Invert board coords
	  xloc = eng.boardx + 1 - xloc;
	  yloc = eng.boardy + 1 - yloc;
	}
	return (Posof (xloc,yloc));
}

//-----------------------------------------------------------------------
//
//  GAME LOAD/SAVE FUNCTIONS..
//


char far *gamestart;

typedef struct {	// SAGE Game-header structure..
  short glen;
  short comlen;
  short id;
} GAMHEAD;


char szLastLoad [512];

  // Load a SAGE game-file..
  // Ret 0=fail, 1= ok
short LoadGame (char *lfilename)
{
	short gamelen,cflag;
	GAMHEAD hgame;	// Temp store for game-header info
	if (lfilename [0] == 0) {	// No filename, dialog box..
	  if (OpenDialog (szPath, STgamfilter, IDM_LOADGAME) == FALSE) {
	    return (0);
	  }
	  lfilename = szPath;
	}
	strcpy (szLastLoad,lfilename);
		// LOAD 3-WORD GAME header (len,extra,id..)
	cflag = LoadHugeFile (lfilename,(void HUGE_ *) &hgame, 0, sizeof (hgame));
	if (cflag == HFILE_ERROR) {
	  if (lfilename [0] != '$') {	// if filename starts $, no msg
	    goto LoadError;
	  }
	  return (0);
	}
	StopThinking ();
	gamelen = hgame.glen;	// First word == len of file..
		// Determine game type..
	if (gamelen == 0) {		// Game only
	  gamestart = &eng.gameonly_start;
	} else if (gamelen == (&eng.gameonly_start - &eng.gamesett_start)) {	// Game + settings
	  gamestart = &eng.gamesett_start;
	} else if (gamelen == (&eng.gameonly_start - &eng.current_game_start)) { // ALL settings
	  gamestart = &eng.current_game_start;
	} else {		// Not a legal type..
	    // New colossus95 format?
          cflag = col_LoadNewFormat (lfilename);
	  if (cflag == TRUE) goto LoadOK;	// OK, loaded!
		// Is it old-format BLITZ/SAGE/DYNAMO/COLOSSUS game?
	  cflag = ext_load_old_format (lfilename, gamelen);
	  if (cflag == 0) goto LoadOK;	// OK, loaded!
	  SoundIt ();
	  DoMessage (STEgamenotloaded);
	  return (0);
	}
	comInitialise ();		// Clear comment memory..
	if (hgame.comlen > 2 && hgame.id == 0x44aa) {	// Load Comment block
	  BYTE far *cptr;
	  cptr = comAllocNew ((USHORT) hgame.comlen - 2);  // Alloc space..
	  if (cptr == NULL) goto LoadError;
	  cflag = LoadHugeFile (lfilename, (void HUGE_ *) cptr, 6L, (long) hgame.comlen - 2);
	  if (cflag == HFILE_ERROR) goto LoadError;
	}
		// Load game into real engine..
	gamelen = &eng.ioram_end - gamestart;
		// Load game moves data..
	cflag = LoadHugeFile (lfilename, (void HUGE_ *) gamestart, 
		4L + (long) hgame.comlen, gamelen - 4);
	if (cflag == HFILE_ERROR) goto LoadError;
	#if VARBOARDSIZE
LoadOK:
	  if (eng.boardx < 4 || eng.boardy < 4) {	// Keep board within limits
	    eng.boardx = 8; eng.boardy = 8;
	  }
	  bmult = eng.boardx + 2;
	#endif
	int_step_move (0);	// Spool engine up to end..
	StopAutoPlay ();	// Ensure normal mode, set flags..
	levGetMenu ();	// Determine linear menu ref (levIDMmenu) from engine (eng.play_level)
	ClrResigned		// Clear comp-resigned flag..
	eng2brd ();
	return (1);
LoadError:
	SoundIt ();
	DoMessage (STEgamenotloaded);
	return 0;
}

  // Load SAGE eng.language-byte from last game file
MYINLINE BYTE LoadLanguageByte ()
{
	short cflag;
	short clan = 0;		// Cur eng.language..
	short glen;
		// Load WORD offset for eng.language byte
	cflag = LoadHugeFile (szLASTGAMEFILE,(void HUGE_ *) &glen, 2,2);
	if (cflag != HFILE_ERROR) {
	  cflag = LoadHugeFile (szLASTGAMEFILE,(void HUGE_ *) &clan,4 + glen,1);
	  if (cflag != HFILE_ERROR && clan < 10) {	// Loaded OK!
	    return (BYTE) clan;  // return eng.language byte 0-9
	  }
	}
		// Could not get byte from file, so default to english..
	clan = 0;
	ReadProInt (PROF_CLANG,&clan,1);
	if (clan > 9) clan = 0;
	return (BYTE) clan;
}

  // Save a SAGE game file - mode=IDM_SAVEGAMEO/IDM_SAVEGAMES/IDM_SAVEALL
  //
void SaveGame (short smode, char *sfilename)	// 0=game,1=+settings,2=all
{
	short gamelen;
	HFILE hFile = FALSE;
	GAMHEAD hgame;	// Temp store for save-header info
        short stat;
        BYTE far *comPtr;	// Pointer to any comment/header data block
	if (sfilename [0] == 0) {	// No filename, dialog box..
          stat = SaveDialog (szPath, STgamfilter,smode,1);
	  if (stat == FALSE) return;
	  sfilename = szPath;
	}
	if (smode == IDM_SAVEGAMES) {	// Game + settings
	  gamestart = &eng.gamesett_start;
	} else if (smode == IDM_SAVEALL) {	// Game + ALL settings
	  gamestart = &eng.current_game_start;
	  eng.charx = (BYTE) charx; eng.chary = (BYTE) chary;
	} else {		// Just game
	  gamestart = &eng.gameonly_start;
	}
	gamelen = &eng.ioram_end - gamestart;
	hgame.glen = (short) gamelen - (&eng.ioram_end - &eng.gameonly_start);
	hgame.comlen = 0;	// Extra bytes in file..
	hFile = _lcreat (sfilename,0);
	if (hFile == HFILE_ERROR) goto SaveError;
		// Get ptr to whole comment data block
	comPtr = comGetWholeBlock (&hgame.comlen);
	if (hgame.comlen) {		// Yes, there is some comment data..
	  hgame.id = 0x44aa;	// Unique identifier
	  hgame.comlen += 2;		// 2 extra identifier bytes
	  stat = _lwrite (hFile, (char *) &hgame, sizeof (hgame));	// Write short header
	  if (stat == HFILE_ERROR) goto SaveError;
	  stat = _lwrite (hFile, comPtr, hgame.comlen - 2);
	  if (stat == HFILE_ERROR) goto SaveError;
	} else {	// No comment/header, save old format game..
	  stat = _lwrite (hFile, (char *) &hgame, 4);	// Write short header
	  if (stat == HFILE_ERROR) goto SaveError;
	}
	stat = _lwrite (hFile, gamestart, gamelen);	// Write body of data..
	if (stat == HFILE_ERROR) goto SaveError;
	_lclose (hFile);
	return;
SaveError:
	_lclose (hFile);
	SoundIt ();
	DoMessage (STEgamenotsaved);
        return;
}

void gam_Spawn ()
{
    char szExeName [1024] = "";
    int cret;
    SaveGame (IDM_SAVEALL,szLASTGAMEFILE);	// Write-back cur game & ALL settings
    cret = GetModuleFileName (NULL,szExeName,sizeof (szExeName));
    if (cret == 0) return;
    //strcat (szExeName, " r0");
    WinExec (szExeName,NULL);
    ext_calcmove_stop ();	// Stop this engine, let next copy of SAGE run fully..
}

//---------------------------------------------------------------
// MODULE: clip_ : clipboard save/load funtions
//---------------------------------------------------------------

char CLIP_TEMPFILE[] = "$clip.pdn";
extern char szTEMPGAMEFILE [];

int clip_Load ()
{
    int cret;
    HGLOBAL hClipMem = NULL;
    void *pClipMem = NULL;
    void *pCopy = NULL;
    int mlen;

    cret = OpenClipboard (NULL);
    if (cret == FALSE) goto err;
    hClipMem = GetClipboardData (CF_TEXT);
    if (hClipMem == NULL) goto err;
    pClipMem = GlobalLock (hClipMem);
    if (pClipMem == NULL) goto err;
    mlen = GlobalSize (hClipMem);
    pCopy = malloc (mlen);
    memcpy (pCopy,pClipMem,mlen);   // Quickly grab data from clipboard
    GlobalUnlock (hClipMem);
    CloseClipboard ();
    file_Save (CLIP_TEMPFILE,pCopy,mlen,0);
    free (pCopy);

    SaveGame (IDM_SAVEGAMEO,szTEMPGAMEFILE); // Write-back cur game & ALL settings to temp file..
    cret = pdnImport (CLIP_TEMPFILE, 1);  // Try to read game from clipboard..
    //if (cret <= 0) {	// Load failed, reinstate original game..
    //  LoadGame (szTEMPGAMEFILE);
    //}
    DeleteFile(CLIP_TEMPFILE);
    return cret;
 
err:
    CloseClipboard ();
    if (pCopy) free (pCopy);
    return FALSE;
}

int clip_Save ()
{
    int cret;
    int flen;
    HGLOBAL hClipMem;
    void *pClipMem;

    DeleteFile(CLIP_TEMPFILE);
    pdnExport (CLIP_TEMPFILE);
    flen = file_Length (CLIP_TEMPFILE);
    if (flen == -1) return FALSE;
    hClipMem = GlobalAlloc (GMEM_MOVEABLE | GMEM_DDESHARE,flen + 100);
    pClipMem = GlobalLock (hClipMem);
    if (pClipMem == NULL) goto err2;
    cret = file_Load (CLIP_TEMPFILE,pClipMem,0,flen);
    if (cret == 0) goto err2;
    GlobalUnlock (hClipMem);
    cret = OpenClipboard (NULL);
    if (cret == FALSE) goto err2;
    cret = EmptyClipboard ();
    if (cret == FALSE) goto err;
    SetClipboardData (CF_TEXT,hClipMem);
    CloseClipboard ();
    return cret;
err:
    CloseClipboard ();
err2:
    GlobalFree (hClipMem);
    return FALSE;
}


//-----------------------------------------------------------------------

void docmd (WPARAM wParam)	// Shortcut do a menu cmd..
{ 
	SendMessage (hMainWnd,WM_COMMAND,wParam,0L);
}

void docmdkey (short IdmCmd)	// Do a keystroke if not menu-grayed..
{
	short cidm;
	// Scan menu list for matching IDM_ code..
	for (cidm = 1; cidm <= nidms; cidm ++) {
	  if (IdmCmd == menuidms [cidm]) {
		// Found in menu, so only do if not grayed..	  
	    if ((menubits [cidm] & buildstatus ()) == 0) {
	      docmd (IdmCmd);
	      return;
	    }
	    Dink ();
	    return;
	  }
	}
	docmd (IdmCmd);		// Not a menu idm, so do it anyway..
}

//-----------------------------------------------------------------------
//
//       USER LIST BOX service routines..
//
	
	// Fill a 3d box..
	// Flag - bit 0 set for simple (not 3d) - if no 3d flag
	// Flag - bit 1 set for indent, not raised
	// Flag - bit 2 set for transparent
	// Flag - bit 3 set for double depth
	// Flag - bit 4 set for hUBoxBrush - extra light fill..
void Fill3d (HDC hDC, short rtx, short rty, short rex, short rey, short flag)
{
	HBRUSH hfillbrush = hBoxBrush;
	if (flag & 4) hfillbrush = hNullBrush;	// transparent..
	if (flag & 16) hfillbrush = hUBoxBrush;	// transparent..
	if ((flag & 1)) {	// simple box....
	  SelectObject (hDC,hWhitePen);
	  SelectObject (hDC,hNullBrush);
	  Rectangle (hDC,rtx,rty,rex,rey);  // wht rect border
	  SelectObject (hDC,hfillbrush);
	  SelectObject (hDC,hNullPen);
	  Rectangle (hDC,rtx + 2,rty + 2,rex - 2,rey - 2);  // box..
	  return;
	}
	hPen1 = hDkgreyPen;
	hPen2 = hWhitePen;
	if (flag & 2) {		// Invert (indented box, not raised
	  hPen1 = hWhitePen;
	  hPen2 = hDkgreyPen;
	}
	hTDC = hDC;
	SelectObject (hDC,hBlackPen);
	SelectObject (hDC,hNullBrush);
	Rectangle (hDC,rtx,rty,rex + 1,rey + 1);  // black rect border
	ltx = rtx + 1; lty = rty + 1;
	lex = rex - 1; ley = rey - 1;
	draw3dbox ();
	if (flag & 8) {			// Double border
	  ltx ++; lty ++; lex --; ley --;
	  draw3dbox ();
	}
	ltx ++; lty ++; 
	SelectObject (hDC,hNullPen);
	SelectObject (hDC,hfillbrush);
	Rectangle (hDC,ltx,lty,lex + 1,ley + 1);// paint background
}

static USHORT mhity;	// Mouse hit position..

	// Process a static custom User List Box.
	// umode == 0 - refresh text only.
	// bit 0 set to redraw box & borders (or to draw for 1st time..)
	// bit 1 set to hilite MOUSEX/Y
	
void ServeStaticBox (USERLISTBOX *Ubox, short umode)	// orig version
{
	static short botx,boty;	// Bottom (pixels)
	short curx = Ubox->tx;	// Get box top (pixels)
	short cury = Ubox->ty;
	short clist;
	char *cstr = Ubox->txt;
	short clen;
	if (umode & 2) {		// See if mouse hit hilites..
		// Exit if outside X range..
	  if ((USHORT) (mousex - curx) / chrx >= (USHORT) Ubox->nchx) return;
	  mhity = (USHORT) (mousey - cury + chry) / chry; 
		// Exit if outside Y range..
	  if (mhity - 1 >= (USHORT) Ubox->nchy) {
	    mhity = 0;		// No mouse hit..
	    return;
	  }
	  Ubox->hlist = mhity;		// Hi lite item 1..n
	}
	if (Ubox->hUWnd == NULL) return;	// No window..
	GetMyPDC (Ubox->hUWnd, Ubox->hUDC,1);
	if (umode & 1) {	// Repaint
	  Ubox->bx = botx = curx + Ubox->nchx * chrx;
	  Ubox->by = boty = cury + Ubox->nchy * chry;
	  Fill3d (hWDC, curx - 5, cury - 5, botx + 6, boty + 6,16);
	}
		// Now print each line in (cstr), hiliting selection
	for (clist = 1; clist <= Ubox->nchy; clist ++) {
	  if (clist == Ubox->hlist) {	// Hi-lite item
	    TextCol (PALUBOX, PALTXT);	// Inverse video
	  } else {
	    TextCol (PALTXT, PALUBOX);	// normal colour on box background
	  }
	  if (*cstr == 0) {
	    SelectObject (hWDC,hNullPen);	// Wipe rest of box..
	    SelectObject (hWDC,hUBoxBrush);
	    Rectangle (hWDC,curx,cury,botx + 1, boty + 1);
	    break;
	  }
	  clen = strlen (cstr);
	  TextOut (hWDC,curx,cury,cstr,clen);
	  cury += chry;
	  cstr += clen + 1;
	}
	Ubox->nlist = clist - 1;	// Save count of items..
	ReleaseMyPDC (Ubox->hUWnd, Ubox->hUDC);
}



//-----------------------------------------------------------------------
//
//       EDIT USER BOOK service routines..
//


LRESULT ServiceEditBook (HWND hCWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{return 0L;}
void ResetEditBook (void) {}


//-----------------------------------------------------------------------
//
//       Piece Pickup,Move,Drop and Kill functions..
//
//       Used for both Edit & Normal-move routines..
	
void KillPiece ()	// Kill any piece being held, back to normal.
{
	if (movemode) {		// Holding piece..
	  GetMyDC (PieceWndIndex, 1);	
	  finerenew (lastmousex,lastmousey);	// Off screen release, kill.
	  gputat (movefrom,-1);		// renew orig source
	  movemode = 0;
	  hCurCursor = hNormCursor;		// Normalise cursor..
	  SetCursor (hCurCursor);
	  ReleaseMyDC (PieceWndIndex);	
	}
}

void PickupPiece (short WndIndex)		// Mouse hit, PICK UP PIECE
{
	clickedsq = mouse2sqr (mousex,mousey);
	if (clickedsq < 0) {
	  movemode = 0; return;
	}
	if (movemode == 0) {	// No Source yet, get it..
	  short cpc;
	  movefrom = clickedsq;
	  if (clickedsq > 500) {		// Edit panel pickup
	    movingpiece = clickedsq - 1000;
	  } else {
	    if (frBoard [movefrom] == 0) return;
	    cpc = frBoard [movefrom];
	      if (cpc < Bman || cpc > Wking) return;
	    movingpiece = cpc;
	  }
	  PieceWndIndex = WndIndex;	// Save index of window that piece is on..
	  GetMyDC (PieceWndIndex, 1);	
	  fineputinit (movingpiece);	// Init sliding piece..
	  mouseoffx = setchrx >> 1; mouseoffy = setchry >> 1;
	  lastmousex = mousex - mouseoffx; 
	  lastmousey = mousey - mouseoffy;
	  if (MainMode == DoingSetup) {		// Edit mode..
	    if (movefrom < Mboard) {
	      frBoard [movefrom] = 0;
	      gputat (movefrom,0);		// Erase source
	    }
	  } else {			// Normal move
	    short retcode = islegalengine (movefrom, movefrom,0);
	    if (retcode != -1) {	// cant move this!
	      goto EndPickup;   	    // movemode is zero..
	    }
	    gputat (movefrom,0);	// Erase displayed source
	    MoveBox (0);
	    SearchBox ();
	  }
	  movemode = 1;			// Piece being held..
	  fineputat (lastmousex,lastmousey);
EndPickup:
	  ReleaseMyDC (PieceWndIndex);	
	} else {	// Piece already held?? drop!
	  KillPiece ();		// Kill piece being held, back to normal.
	}
}

	// Mouse release - DROP the piece..
	// Ret 1 if possible legal move, 0 for error..
short DropPiece ()
{
	if (movemode == 1) {	// In motion..
	  GetMyDC (PieceWndIndex, 1);	
	  hCurCursor = hNormCursor;	// Back to normal cursor
	  SetCursor (hCurCursor);
	  finerenew (lastmousex,lastmousey);	// Restore background under piece
	  moveto = mouse2sqr (mousex,mousey);	// Calc dest sqr
	  movemode = 0;
	  ReleaseMyDC (PieceWndIndex);	
	  if (moveto >= 0 && moveto != movefrom) {	// Possible leg move..
	    return 1;
          }
        }
        return 0;
}

void MoveAPiece (WPARAM wParam)	// If any piece held, MOVE it..
{
	short newmx,newmy;		// new mouse pos
	if (movemode == 1) {		// Holding piece..
	  if (wParam & MK_LBUTTON) {	// Left button still down
	    GetMyDC (PieceWndIndex, 1);	
	    newmx = mousex - mouseoffx; 	// Calc new position
	    newmy = mousey - mouseoffy; 
		// if dist moved < 8, use new SMOOTH move..
	    if (max (abs (newmx - lastmousex),abs (newmy - lastmousey)) < 8) {
	      finemoveto (lastmousex,lastmousey,newmx,newmy,0);
	    } else {	// Original - wipe old, redraw new..
	      finerenew (lastmousex,lastmousey);	// Wipe old
	      fineputat (newmx,newmy);		// Draw new piece
	    }
	    lastmousex = newmx;
	    lastmousey = newmy;
	    ReleaseMyDC (PieceWndIndex);	
	  } else {
	    KillPiece ();
	  }
	}
}

 //-----------------------------------------------------------------------
 //
 //         EDIT BOARD POSITION routines..
 //
 //      

 // ResetSetup called to init, RefreshSetup on VDU redraw, 
 // ServiceSetup replaces normal game windows processing loop

short xedbrd,yedbrd;	// Window size
short oldcharx,oldchary;	// old Board size
//char origbrd [65];
short SetHasFailed;	// Set if attempt at set pos fails..

void ResetSetup ()	// Initialise edit mode
{
	short maxedx,maxedy,bsize;
	char *szWinTitle;	// Ptr to window title..
	szWinTitle = IDM2String (IDM_SETUP);
	if (hPopWnd) return;	// window already on, dont try twice..
	ClockOff			// switch Clock off
	MainMode = DoingSetup;		// Tells WinProc we are editing
	StopThinking ();
	SetBrdPos = max (ansichrx,ansichry) + 10;	// top/left brd pos..
	bsize = 22 * SysChrx;		// Calc button size, based on font size
	  	// Calc size of window..
	xedbrd = min (nVduX - 6, charx * eng.boardx + 50 + bsize + SetBrdPos);
	yedbrd = nVduY - 4;
		// Calc max allowable x/y board extents
	maxedx = xedbrd - bsize - 30 - SetBrdPos;	// max X pos
	maxedy = yedbrd - SysChry - 25;		// Calc max Y pos
		// Calc Edit buttons parameters..
	iBtn.str = STeditbrdbuttons;
	iBtn.tx = maxedx + SetBrdPos;
	iBtn.ty = 50;
	iBtn.lx = -bsize;
	iBtn.ly = SysChry + 10;
	iBtn.xend = maxedx;
  
	if (chary * (eng.boardy + 3) > maxedy) {		// Ensure no vert overflow.
	  charx = chary = maxedy / (eng.boardy + 3);
	}
	if (charx * eng.boardx > maxedx) {	// Ensure no horiz overflow.
	  charx = chary = maxedx / eng.boardx;
	}
	//_fmemcpy ((char far *) origbrd, eng.checker_board, 64); // Save board pos
	SetHasFailed = 0;	// Set if attempt at set pos fails..
	ImpNewSet (1);		// Imp new size of piece set..
	movingpiece = 0;	// For double-click..
        BeepSnd ();
        
	DoingPopDlg = TRUE;
	  	// Create it..(centered)
	hPopWnd = CreateWindowEx (WS_EX_DLGMODALFRAME, "PopDlgClass", szWinTitle,
		WS_POPUP | WS_VISIBLE | WS_BORDER | WS_CAPTION | WS_SYSMENU,
		max (1,(nVduX - xedbrd) >> 1),max (1,(nVduY - yedbrd) >> 1),
		xedbrd,yedbrd, hMainWnd, NULL,hInstance, NULL);
	ModSysMenu (hPopWnd);	// Delete unwanted sys menu cmds
	ShowWindow (hPopWnd, SW_SHOWNORMAL);	
	
	// All msgs will now be handled by Service Setup, until exit..
}


void DrawSetupBox (void)		// Show an edit box..
{
      short cpiece;
      BYTE tinv = VarInvert;
      VarInvert &= (~ BitInvert);	// normalise for special edit box
		// Show edit box pieces..      		
        for (cpiece = Bman; cpiece <= Wking; cpiece ++) {
	  putat (1 + cpiece, eng.boardy + 2,cpiece);	// Show wht piece..
        }
        FXbox (btopx - 1 + charx + charx, btopy - 1 + chary * (eng.boardy + 1),
	  charx * 6 + btopx + 1, chary * (eng.boardy + 2)  + btopy + 1);
      VarInvert = tinv;
}


	// ServiceSetup replaces standard game Windows processing function
	// during set-up board.
LRESULT ServiceSetup (HWND hCWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
    short cbutton;
    	// Set brd top position..
    btopx = SetBrdPos;
    btopy = 10;
    switch (wMsg) {
    
      case WM_PAINT:
	InitBoxPaint (hCWnd);	// Init paint, palette, fonts, backg
	hPopDC = hWDC;
	DrawBoardOn (0);
	TextCol (PALVATXT,PALBOX);		// Hi-lite txt colour..
	DrawSetupBox ();		// Show Edit box with pieces..
		// All done..
	EndPaint (hCWnd,&ps);
	hPopDC = NULL; 
	hWDC = hMainDC;	// Back to normal DC..
	return 0L;

      
      case WM_CREATE:
	iBtn.hOwner = hCWnd;
	ButtonsOn (&iBtn, 0);	// Create buttons..
	return 0L;
	
      case WM_DESTROY:
	eng2brd ();		// Reget orig engine board
	hPopWnd = NULL;
	DoingPopDlg = FALSE;
	ClockOn			// switch Clock on
	ButtonsOff (&iBtn);		// Kill edit buttons
	MainMode = DoingGame;
	InitThink (ThinkOpp);	// Restart think in opp..
	RedrawAllWindows ();	// Force repaint..
	return 0L;
	
      case WM_SETCURSOR:		// Re init cursor
	if (movemode) {
          SetCursor (hEmptyCursor);
	  return 0L;
	}
	break;
	    
      case WM_CHAR:
        cmdkey = wParam;
	if (cmdkey == 27) {	// Emulate Abort button
	  PostMessage (hCWnd, WM_COMMAND, Button + 6, 0L);
        }
	return 0L;
      
      case WM_LBUTTONDOWN:	// Left mouse hit..
        PickupPiece (W_POP);			// Pickup (movingpiece)
        if (movemode == 0 && movingpiece && clickedsq 
		&& clickedsq < 500 && frBoard [movefrom] == 0) {
	  if (frBoard [movefrom] != EdgeSq) {
	    frBoard [movefrom] = movingpiece;
	  }
	  GetMyDC (W_POP,1);
	  gputat (movefrom,-1);		// On screen..
	  ReleaseMyDC (W_POP);
        }
	return 0L;
      
      case WM_LBUTTONUP:	// Left mouse button release, DROP..
        if (movemode) {
	  DropPiece ();	// Possible legal drop of (movingpiece) at (moveto)
	  if (moveto >= 0  && moveto < Mboard) {	// Ok, on frBoard..
	    if (frBoard [moveto] == EdgeSq) return 0;
            if (movingpiece == Wman && moveto > 55) return 0;  // Prevent man on Krow
            if (movingpiece == Bman && moveto < 8) return 0;
	    frBoard [moveto] = movingpiece;
	    GetMyDC (W_POP,1);
	    gputat (moveto,-1);
	    ReleaseMyDC (W_POP);
	  }
	}
        return 0L;
      
      case WM_MOUSEMOVE:	// Mouse move, redraw any held..
	MoveAPiece (wParam);
	  	// Keep kybd focus in this window..
	if (movemode == 0) SetFocus (hCWnd);
	return 0L;
      
      case WM_COMMAND:		// SETUP : BUTTON HIT..
        KillPiece ();	// Kill piece being held, back to normal.
        cbutton = (short) wParam - Button;
        switch (cbutton) {
          case 1:	// Clear frBoard
          case 2:	// New frBoard..
	    NewBoard (cbutton - 1);	// Set boar to startup position..
	    DrawBoardOn (W_POP);
	    return 0L;
	    
	  case 3:	// Invert frBoard
	    TogInvert
	    RedrawAWindow (W_POP);
	    return 0L;

	  case 4: {	// Reverse Colours
	    int cpos,mx ;
	    mx = eng.boardy * eng.boardx - 1;
            for (cpos = 0; cpos <= mx/2; cpos ++) {
	      short tmp,tmp2;
	      tmp = frBoard [cpos]; 
              tmp2 = frBoard [mx - cpos];
	      if (tmp >= EdgeSq) continue;
	      if (tmp >= Bman && tmp <= Wking) tmp ^= (Wman | Bman);
	      if (tmp2 >= Bman && tmp2 <= Wking) tmp2 ^= (Wman | Bman);
	      frBoard [cpos] = tmp2;
	      frBoard [mx - cpos] = tmp;
	    }
	    DrawBoardOn (W_POP);
	    return 0L;
	  }

	  case 5:
	  case 6:
	    brd2eng ();		// Copy frBoard to engine
	    eng.param_ax_pass = 0;			// White to move
	    if (cbutton == 6) eng.param_ax_pass = 1;	// Black to move
	    retv = ext_set_board_pos ();
	    if (retv) {		// Error in pos set..
	      SetHasFailed = 1;
	      if (eng.game_status) {
	        DoMessage (GameStatusText ());
	      } else {
	        DoMessage (STillegalposition);
	      }
	    } else {		// Ok accept & end edit.
	      SetResigned		// Set comp-resigned flag..
	      goto ExitSetup;
	    }
	    return 0L;
	    
	  case 7:	// Cancel edit
	    if (SetHasFailed) {  // Attemp at set has failed, get orig..
	      int_step_move (0);	// spool to Orig frBoard pos
	    }
	    goto ExitSetup;
	}
    }
    return ( DefWindowProc (hCWnd, wMsg, wParam, lParam) );
      
ExitSetup:	  	// Back to normal mode..
	DestroyWindow (hCWnd);	// see WM_DESTROY for rest of clean-up..
	return 0L;
}

LRESULT CALLBACK PopDlgProc (HWND hCWnd,  // our window's handle
				UINT wMsg,	   // message number
				WPARAM wParam,	   // word parameter
				LPARAM lParam)	   // long parameter
{
	HDC hDC;
	short nchanged;
	HPALETTE hpalT;	// old pal handle
	SetMousePos (wMsg, lParam);    // Set up mousex/y vars, if mouse MSG
	//if (wMsg == WM_CREATE) { // Special case, since hXXXWnd not yet set
		// So use bits of (WMclosing) flag..
	//  if (WMclosing & 1) {	// Creating PopDlg  window
	//    WMclosing &= (~1);	// clr bit 0..
	//    DoingPopDlg = TRUE;
	//    goto DBSelectProc;	// User popup dialog
	//  }
	//}
	  // Other Dialog box in progress, dont service this box..
	  // (or disable certain messages..)
	if (DoingDialog) {
	  switch (wMsg) {
	    case WM_SETFOCUS:		// Do not process these
	    case WM_NCHITTEST:
	    case WM_WINDOWPOSCHANGING:
	    case WM_MOUSEMOVE:
	      return 0L;
	    case WM_ACTIVATE:		// Only if deactivate msg..
	      if (wParam == WA_INACTIVE) break;
	      return 0L;
	    case WM_ACTIVATEAPP:
	    case WM_NCACTIVATE:
	      if (wParam == 0) break;	//deactivated
	      return 0L;
	  }
	}

		// First Handle messages common to all dialogs
	switch (wMsg) {
	    
	  case WM_PALETTECHANGED:
	    if ( (HWND) wParam == hCWnd) return 0;
	  case WM_QUERYNEWPALETTE:
	      // If realizing the palette causes the palette to change,
	      // redraw completely.
	    hDC = GetDC (hCWnd);
	    hpalT = SelectPalette (hDC, hPalette, FALSE);
	    nchanged = RealizePalette (hDC); 	// # entries that changed 
	    SelectPalette (hDC, hpalT, TRUE);	// Orig back in..
		// If any palette entries changed, repaint the window.
	    if (nchanged > 0) InvalidateRect (hCWnd, NULL, TRUE);
	    ReleaseDC (hCWnd, hDC);
	    return nchanged;
	    
	}
		// Setup board mode?
	if (MainMode == DoingSetup) {
	  return ( ServiceSetup (hCWnd,wMsg,wParam,lParam) );
	}
		// Edit User book mode?
	if (MainMode == DoingEditBook) {
	  return ( ServiceEditBook (hCWnd,wMsg,wParam,lParam) );
	}
		// Do Database service?
	return ( db_DlgProc (hCWnd,wMsg,wParam,lParam) );
	// return ( DBDlgProc (hCWnd,wMsg,wParam,lParam) );
}



void InitAnalPtrs (void)		// Init ptrs to analysis data
{
	Panaly = (ANALY far *) &eng.analy_moveno;
}

  // Convert move to short move form string for anal line
  // String must be min 5 chars..NOTE - NO NULL TERM ADDED
void Move2Short (char *mstr, short mfrom,short mto)
{
	if (FlagChessNot == 0) {	// Checkers numeric notation?
	   // Convert move-> draughts numbers
	  SageMove2Str (mstr, (BYTE) mfrom, (BYTE) mto, 256);
	  mstr [4] = 32; 
	  return;
	}
	
	mstr [0] = (97 + (mfrom % eng.boardx)) ;
	mstr [1] = (48 + eng.boardy - (mfrom / eng.boardx)) ;
	mstr [2] = (97 + (mto % eng.boardx)) ;
	mstr [3] = (48 + eng.boardy - (mto / eng.boardx)) ;
	mstr [4] = ' ';
}

  // Convert score eval to string - form (-)xx.xx or Matxx
  // Always 6 chars, no null term.
void Eval2Str (char *estr, BYTE sclo, BYTE schi)
{
	char *fstr = estr + 6;
	if ((sclo & 127) == 127) {	// Mate in..
	  if (sclo & 128) {
	    *estr =  ('-');
	  } else {
	    *estr =  (' ');
	  }
	  estr ++;
	  ADDSTR (estr,STmat);
	  INT2ASC2 (estr,schi);
	} else if ((sclo & 0xff) == 0xfe) {	// Book..
	  ADDSTR (estr,STbook);
	} else {			// Norm score
	  if (sclo & 0x80) {		// -ve?
	    *estr =  ('-');
	  } else {
	    *estr =  (' ');
	  }
	  estr ++;
	  INT2ASC2NOLEAD (estr,sclo & 0x7f);	// Print score (pawns)
	  *estr =  ('.'); estr ++;
	  INT2ASC2 (estr,schi);		// Print score (pawns/100)
	  if (isdigit (*(estr - 2)) == 0) {
	    temp ++;
	  }
	}
	while (estr < fstr) {		// Pad out to 6 chars
	  *estr = ' '; estr ++;
	}
}

void PrintEval (BYTE sclo, BYTE schi) 	// Print score..
{
	char mstr [7];
	Eval2Str (mstr, sclo, schi);
	mstr [6] = 0;
	prints (mstr);
}

	// Print score, format snnnn:
void EPDPrintEval (short sclo, short schi)
{
	if ((sclo & 0xff) == 0xfe) {	// Book..
	  prints (" 0000");
	  return;
	}
	if (sclo & 0x80) {		// -ve?
	  printc ('-');
	} else {
	  printc (' ');
	}
	if ((sclo & 127) == 127) {	// Mate in..
	  sclo = 99;
	  schi = 100 - schi;
	} 
	printi2 (sclo & 0x7f);		// Print score (pawns)
	printi2 (schi);			// Print score (pawns/100)
}

  // Convert best anal in Panaly->moves. to String..
  // llen = # moves, -ve no padding
void BestLine2Str (ANALY *pAn, char *mstr, short llen, short spc)
{
	short cbest,cfr,cto,tlen;
	llen *= 3;
	tlen = abs (llen) ;
	for (cbest = 0; cbest < tlen; cbest += 3) {
	  cfr = pAn->moves [cbest];
	  cto = pAn->moves [cbest + 1];
	  if (cfr == cto) {	// Null end, or from==to..
 	    break;
	  }
	  Move2Short (mstr, cfr, cto);
	  if (spc > 5) {	// Add '-'
	    mstr [5] = mstr [4];
	    mstr [4] = mstr [3];
	    mstr [3] = mstr [2];
	    mstr [2] = '-';
	  }
	  mstr += spc;		// Next section
	}
	while (cbest < llen) {	// Pad out rest of line, if llen +ve..
	  for (cfr = 0; cfr < spc; cfr ++) {
	    mstr [cfr] = 32;
	  }
	  mstr += spc;
	  cbest += 3;
	}
	*mstr = 0;	// Add null terminator..
}

	// Print best anal in Panaly->moves. llen = # moves, -ve no padding
void PrintBestLine (short llen, short spc)	
{
	char mstr [150];
	BestLine2Str (Panaly,mstr,llen,spc);
	prints (mstr);
}

 
  // Build SAGE analysis output (best line, etc) as an ascii string..
  // given an analysis structure..
  // Returns length of 1st string
  // amode:- bit 0 set for full info. bit 1 set to include cur move.
short Search2Str (char *mstr, ANALY far *panal, short amode)
{
	short cpos;
	char *cstr = mstr;
	//char *tstr;
	short slen ;		// Length of 1st string..
	Panaly = panal;
	if (Panaly->moves[0] + Panaly->moves[1] == 0) {	 // No leg anal.
	  goto NoAnal;
	}
	if (amode & 1) {	// FlagFullAnal - 2-line anal display
	  	// Print main move
	  Eval2Str (cstr,Panaly->scorelo, Panaly->scorehi);
	  cstr += 6;
	  ADDCHAR (cstr,' ');
	  if (amode & 2) {
	    INT2ASC2 (cstr,Panaly->number);	// Move index
	    ADDCHAR (cstr,':');
	    Move2Short (cstr,Panaly->mvfrom,Panaly->mvto);
	    cstr += 4;
	    ADDCHAR (cstr,',');
	  }
	    /*
	  temp = Panaly->wflag;
	  if (temp == 0) {		// Alphabeta fail lo/hi flag?
	    *cstr = ' ';		// none
	  } else if (temp < 0) {	// fail lo
	    *cstr = ('-');
	  } else {			// fail hi
	    *cstr = ('!');
	  }
	  cstr ++;*/
	  INT2ASC3 (cstr,Panaly->depthmin << 1);	// Current IQ depth
  	  ADDCHAR (cstr,'-');
	  INT2ASC2 (cstr,Panaly->depthmax);		// Max depth
  	  ADDCHAR (cstr,',');
  	  time2asc (cstr,Panaly->time,0);		// Target time..
  	  cstr += 5;
  	  ADDCHAR (cstr,',');
  	  ltoa (Panaly->nodes,cstr,10);		// Node count..
  	  cpos = strlen (cstr);
  	  cstr += cpos;
  	  ADDCHAR (cstr,'n');
  	  while (cpos < 8) {
  	    ADDCHAR (cstr,' ');
  	    cpos ++;
  	  }
  	  ADDCHAR (cstr,' ');
 	  BestLine2Str (Panaly,cstr,12,5);		// Print 12 move line..
 	  cstr += 60;
	  slen = cstr - mstr;			// Keep len of 1st str..
	  *cstr = 0; 				// End of 1st line
 	  return slen;
	}
		// Alt form of analysis line..
	Eval2Str (cstr,Panaly->scorelo, Panaly->scorehi);
	cstr += 6;
	ADDCHAR (cstr,':');
 	BestLine2Str (Panaly,cstr,12,5);		// Print 12 move line..
	return 5*12 + 7;
NoAnal:
	for (cpos = 0; cpos < 72; cpos ++) {
	  cstr [cpos] = cstr [cpos + 73] = 32;
	}
	cstr [cpos] = cstr [cpos] = 0;	// Null end..
	return 72;
}

  // Output SAGE search lines..
void ShowSearch (short smode)
{
	short len1;		// Len of line 1
	short xp = searchtx;
	short yp = searchty;
	BYTE afull = (FlagFullAnal != 0);	// Full 2line anal ?
	if (smode) {		// Extra anal ptr
	  len1 = Search2Str (szTemp, (ANALY far *) &eng.sanaly_moveno,2 | afull);
	  yp += chry;
	} else {		// Main anal ptr
	  len1 = Search2Str (szTemp, (ANALY far *) &eng.analy_moveno, 2 | afull);
	}
	TextOut (hSchDC,xp,yp,szTemp,len1);
}
 
  // Build SAGE book moves as null tterm string..
MYINLINE void BookMoves2Str ()	
{
	short cbook;
	short csrc,cdest;
	char *mstr = szTemp;
	const short spc = 6;
	cbook = 0;
	do {
	  csrc = eng.book_moves [cbook] & 0xff;
	  cdest = eng.book_moves [cbook] >> 8;
	  	// End of list?
	  if (csrc == cdest) {
 	    break;
	  }
	  Move2Short (mstr, csrc, cdest);
	  mstr [4] = " <?   !>" [bokFlags [cbook] & 7];
	  if (bokFlags [cbook] & 0x80) {	// Colour reversed..
	    mstr [5] = '~';
	  } else {
	    mstr [5] = ' ';
	  }
	  mstr += spc;		// Next section
	  cbook ++;
	} while (cbook < MAX_SHOWN_BOOK);
	while (mstr < szTemp + (MAX_SHOWN_BOOK * spc)) {
	  *mstr = 32; mstr ++;
	}
	*mstr = 0;
}

  // Show CHAMP book-move list..
MYINLINE void ShowBookMoves (void)
{
	short clen,cpos,yp;

	TextCol (PALVATXT,PALLEAVE);	// hilite colour..
	BookMoves2Str ();
	sbokx = searchtx; sboky = searchty;	// into global vars, for mouse..
	sbokNmov = max (1,(searchbx - searchtx) / (chrx * 6)); // # moves/line
		// Now print in wrapped output format..
	clen = lstrlen (szTemp);
	yp = sboky;
	for (cpos = 0; cpos < clen; cpos += sbokNmov * 6) {
	  TextOut (hSchDC,sbokx,yp,szTemp + cpos,min (clen - cpos,sbokNmov * 6));
	  yp += chry;
	}
}

  // GENIUS Multi-line analysis display routines..
// extern short eng.histanal = 0;	// Curr # line of old-analysis
short mlaTop = 0;		// Cur top of mla list
short mlaLastTop = -1;	// Prev top of mla list
HGLOBAL mlahGlob = NULL;
ANALY far *mlaList= NULL;	// Array of analysis structures.

  // Initialise/allocate Multi line anal
  // alloc mem for (nlist) 0= off, -ve=clr mem of current
void FASTCALL mlaInit (short nlist)
{
	mlaLastTop = -1; mlaTop = 0;
	if (nlist < 0 && eng.histanal && mlahGlob) {	// Just clear mem..
	  memset (mlaList,0,sizeof (ANALY) * eng.histanal);
	  return;
	}
	if (mlahGlob) {		// Free up any old mem..
	  GlobalUnlock (mlahGlob);
	  GlobalFree (mlahGlob);
	  mlahGlob = NULL;
	}
	eng.histanal = 0;		// #lines of anal..
	if (nlist > 0) {	// Grab some memory..
	  mlahGlob = GlobalAlloc (GHND, sizeof (ANALY) * nlist + 4);
	  if (mlahGlob == NULL) return;
	  mlaList = GlobalLock (mlahGlob);
	  eng.histanal = nlist;
	}
}

  // GENIUS Redraw Multi-line analysis window text..
MYINLINE void mlaDraw ()
{
	short cline;
	short clen;
	short nline = (searchby - searchty - 4) / chry;
	short tline = 0;		// Top line for hist anal lines..
	if (FlagMainAnal) tline = 1;
	if (FlagExtraAnal) tline = 2;
	nline = min (nline - tline,eng.histanal);
	if (nline < 1) return;	// No space for any lines..
	tline = tline * chry + 4;	// First line pos in pixels..
	cline = (mlaTop - nline + eng.histanal) % eng.histanal; // Wrapped start line
	TextCol (PALVATXT,PALBOX);
	do {
	  clen = Search2Str (szTemp, &(mlaList [cline]),(FlagFullAnal != 0));
	  if (mlaList [cline].moves[0] != mlaList [cline].moves[1]) {
	    TextOut (hSchDC,searchtx,tline,szTemp,clen);
	  }
	  cline = (cline + 1) % eng.histanal;
	  tline += chry;
	} while (cline != mlaTop);
}
                                                       
  // Has analysis changed? ret TRUE if so..
MYINLINE BOOL mlaHasChanged (ANALY far *an1, ANALY far *an2)
{
	short cpos;
	if (an1->depthmin != an2->depthmin) return TRUE;
	if (schMixedFlagsVar & 32) return TRUE;	// Force show all lines..
	for (cpos = 0; cpos < ANALY_NMOVES * 3; cpos += 3) {
	  if (an1->moves [cpos] != an2->moves [cpos]) return TRUE;
	  if (an1->moves [cpos + 1] != an2->moves [cpos + 1]) return TRUE;
	  if (an1->moves [cpos] == an1->moves [cpos + 1]) return FALSE;	// line ends..
	}
	return FALSE;
}

  // GENIUS If anal line has changed, add it to multi-line anal list.
void mlaUpdate (int force)
{
        if (force) {
	  Manaly->type = force;
	} else {
	  if (ThinkMode == ThinkOpp) Manaly->type = AN_OPP;
	}
		// Has Root move in main anal changed?
	if (FlagMainAnal && (eng.anal_flag & 0x80)) {
	  if (Manaly->moves[0] != Manaly->moves[1]) {
	    //Manaly->type = 1;	// Main analy
	    memcpy (&(mlaList [mlaTop]),Manaly,sizeof (ANALY));
	    if (!FlagExtraAnal && Manaly->type == AN_OPP) return;
	    if (force || mlaLastTop < 0 || mlaHasChanged (&(mlaList [mlaLastTop]),Manaly)) {
	      mlaLastTop = mlaTop;
	      mlaTop = (mlaTop + 1) % eng.histanal;
	      memcpy (&(mlaList [mlaTop]),Manaly,sizeof (ANALY));
	    }
	  }
	}
		// Has Root move in extra anal changed?
	/*if (FlagExtraAnal && (eng.anal_flag & 0x40)) {
	  if (Eanaly->moves[0] != Eanaly->moves[1]) {
	    Eanaly->type = 0;
	    memcpy (&(mlaList [mlaTop]),Eanaly,sizeof (ANALY));
	    if (mlaLastTop < 0 || mlaHasChanged (&(mlaList [mlaLastTop]),Eanaly)) {
	      mlaLastTop = mlaTop;
	      mlaTop = (mlaTop + 1) % eng.histanal;
	      memcpy (&(mlaList [mlaTop]),Eanaly,sizeof (ANALY));
	    }
	  }
	}*/
}

BOOL analy2ComFlag = FALSE;	// When set, analy sent to comments..

  // Send analysis to comments..
void analy2Comment ()
{
	short ccom = gamCOMMENTS + eng.move_number;	
	char *cstr = szTemp;
	if (analy2ComFlag == FALSE) return;
		// Send analysis to comemnts..
	ADDCHAR (cstr,'(');
	  	// Writes "SCORE [NULL] BESTLINE [NULL]"
	cstr += Search2Str (cstr, Manaly, (FlagFullAnal != 0));
	ADDCHAR (cstr,')');
	*cstr = 0;
	comAddBlock (ccom,szTemp,comAUTOLEN);	// Save comment..
}

  // Output SAGE search
void UpdateSearch (BYTE umode)
{
	BYTE canal = eng.anal_flag;
	if (umode & 1) canal = 0xff;	// force anal update..
	if (hSchWnd == NULL) return;
	  // If float window, get hSchDC..
	GetMyDC (W_SCH, 0);
	if (mlahGlob && eng.histanal) {		// Multi-line analysis on?
	  mlaUpdate (0);
          #if SCH_USENEW
	    sch_Redraw ();
	  #else 
	    mlaDraw ();
	  #endif
	  TextCol (PALTXT,PALBOX);
	}
	  	// Show book moves..
	//if (eng.book_moves [0] && FlagBookMoves && FlagMainBook) {
	//  ShowBookMoves ();
	//} else {
	if (umode && hBokWnd) bok_Redraw ();

        #if (SCH_USENEW==0)

	  if (FlagMainAnal && (canal & 0xa0)) {	// show MAIN ANAL line..
	    ShowSearch (0);
	  }
	  if (FlagExtraAnal && (canal & 0x50)) {	// Show EXTRA ANAL..
	    ShowSearch (1);
	  }

	#endif

	ReleaseMyDC (W_SCH );
}

  // Force Re-Draw SAGE Analysis window..
void SearchBox ()
{		
	sboxlast = clock ();
	if (searchtx == 9999) return;		// No win defined..
	UpdateSearch (1);
	lastsm = eng.search_mode;	// Last fully shown mode..(redraw when changed)
} 

	// Print search info to file/printer..
	// fmode:1=just mv, 2=full anal, 3=mv & time.
void PrintSearch (short fmode)
{
	short tmoveno = eng.move_number - 1;		// last move to output..
	if ((FileMode & 3) == 0 || hOutFile == NO_FILE) return;
	fmode &= 3;
	Panaly = (ANALY far *) &eng.analy_moveno;
	nprint = 0;
	tprintflag = 2;		// Prn to file enable..
	
	printi3 (1 + (tmoveno >> 1));		// Prt move no
	if (tmoveno & 1) {		// Black..
	  prints ("..         ");
	} else {
	  prints ("   ");
	}
	STpieces = STpiecesprn;		// Pieces for printer
	PrintMove (tmoveno);		// Print main move
	if (fmode > 1) {		// Prt full anal data/time
	  while (nprint < 25) printc (' ');
	  if (tmoveno & 1) {		// Black..
	    prints ("        ");
	    printatime (eng.black_time,1);
	  } else {
	    printatime (eng.white_time,1);
	  }
	  if (fmode == 2) {		// Full anal data..
	    while (nprint < 41) printc (' ');
		// Print the score - nn.nn, or book or mate in..	  
	    PrintEval (Panaly->scorelo, Panaly->scorehi);
	    while (nprint < 48) printc (' ');
		// Print best line: 5 moves, no padding.
	    PrintBestLine (-5,6);
	  }
	}
	if (eng.game_status) {		// Print check/stalemate/draw...
	  prints ("\n      ");
	  prints (GameStatusText ());
	}
	prints ("\n");
	tprintflag = 0;		// Back to norm print
	STpieces = STpiecesvdu;		// Back to normal pieces
}


  // Output moves played so far..
void PrintMovesSoFar ()	
{
	short nchr;
	if (FileMode == 0 || hOutFile == NO_FILE) return;
	tprintflag = 2;		// Prn to file enable..
	prints ("\n");
	nprint = 0;
	STpieces = STpiecesprn;		// Pieces for printer
	memset (&pdnInfo, 0,sizeof (pdnInfo));
	pdnInfo.outstr = outBuf;
	pdnInfo.wide = 70;
	pdnInfo.maxwide = 70;
	pdnInfo.flags = (Flag_(PgnMoves) == 0) | 4;	// Full header
	nchr = pdnExportLine (&pdnInfo);	// get 1st line
	do {
	  prints (pdnInfo.outstr);		// Print it..
	  prints ("\n");
	  if (pdnInfo.mode & 1) break;		// All over..
	  nchr = pdnExportLine (NULL);	// Next line ..
	} while (1);
	if (eng.game_status) {		// Print check/stalemate/draw...
	  prints ("      ");
	  prints (GameStatusText ());
	  prints ("\n");
	}
	prints ("\n");
	STpieces = STpiecesvdu;		// Back to normal screen pieces
	tprintflag = 0;		// Back to norm print
}

  // Print CHECKERS board position diagram to spool..
  // if selgtype==2 use TTF diag, else simple ascii (xXoO etc)
void PrintPos ()
{
	short cbrd,xpos,ypos;
	char cchr;
	static BYTE pc2prn [] = {128,128,130,132,131,133,129,32,32,120,88,111,79,46};
	short lchr = 32;		// left/right bounding char..
	short rchr = 32;
	if (FileMode == 0 || hOutFile == NO_FILE) return;
	tprintflag = 2;		// Prn to file enable..
	//STpieces = STpiecesprn;		// Pieces for printer
	if (PrnEdges && selgtype == 2) {		// top line of board..
	  prints ("\n ");
	  printnc (144,eng.boardx);
	  lchr = 141; rchr = 142;
	}
		// Print a board diagram..	
	for (ypos = 0; ypos < eng.boardy; ypos ++) {
	  prints ("\n"); printc (lchr);		// Left edge
	  for (xpos = 0; xpos < eng.boardx; xpos ++) {
	    cbrd = xpos + ypos * eng.boardx;
	    if (FlagInvert) cbrd = (eng.boardx * eng.boardy) - 1 - cbrd;
	    cchr = min (eng.checker_board [cbrd],6) + (selgtype != 2 ? 7 : 0);
	    printc (pc2prn [cchr]);
	  }
	  printc (rchr);	// Right edge
	}
	prints ("\n");
	if (PrnEdges && selgtype == 2) {		// bottom line of board..
	  printc (32);
	  printnc (143,eng.boardx);
	  prints ("\n");
	}
	tprintflag = 0;		// Back to norm print
}


void NewBoard (short nmode) {
	ext_new_board (frBoard, nmode);
}

void EndEngine ()
{
    if (dll_szEng1[0] == 0) {
      strcpy (dll_szEng1,"*");
    }
    WrtProStr (PROF_ENGNAME,dll_szEng1); 	// Endgame DB filename

}

void InitEngine ()	// Initialise  engine.. (CALL ONCE)
{
	short retv;
	int cret;
        ReadProStr (PROF_ENGNAME,dll_szEng1); 	// Endgame DB filename
	if (dll_szEng1[0] == 0) {
	  strcpy (dll_szEng1,"exteng.def");
          cret = eng_Setup (dll_szEng1,FALSE);
          if (cret == TRUE) {
	    cret = msg_Printf (NULL,msg_OPTIONS,MB_YESNO,STprogramname,"External engine \x22%s\x22 found!\n Use this as the main engine?",dll_szEng1);
	    if (cret == IDNO) {
	      strcpy (dll_szEng1,"");   // No external engine..
	    }
	  }
        }
	if (dll_szEng1[0] == '*') dll_szEng1[0] = 0;
	eng.param_ax_pass = LOWORD (clock());	// random number..
	retv = ext_initialize ();
}

void NewGame (short mode)	// Start a new game.. 
{
	ext_init_game ();	// Tell engine to set new frBoard..
	  comInitialise ();	// Clear old comment/header info..
				// Clear any old analysis	
	Panaly = (ANALY far *) &eng.sanaly_moveno;
	Panaly->mvfrom = 0; Panaly->mvto = 0; 
	Panaly = (ANALY far *) &eng.analy_moveno;
	Panaly->mvfrom = 0; Panaly->mvto = 0; 
	eng2brd ();
	ClrResigned		// Clear comp-resigned flag..
	if (mode) {		// Force small think to get book, then think off.
	  InitThink (ThinkOpp);
	}
	mlaInit (-1);	// Clear old analysis..
	sboxlast = clock () - sboxslice; // Last search box update
}

void eng2brd ()		// Move frBoard from engine to VDU playboard..
{
	//short xpos,ypos;
	short cpos;
	for (cpos = 0; cpos < MAX_CHECKER_BOARD; cpos ++) {
	  frBoard [cpos] = eng.checker_board [cpos];
	}
	/*cpos = 0;
	for (ypos = 1; ypos <= eng.boardy; ypos ++) {
	  for (xpos = 1; xpos <= eng.boardx; xpos ++) {
	    frBoard [Posof (xpos,ypos)] = eng.checker_board [cpos]; cpos ++;
	  }
	}*/
}

void brd2eng ()		// Move frBoard from VDU frBoard to engine
{
	//short xpos,ypos;
	short cpos;
	for (cpos = 0; cpos < MAX_CHECKER_BOARD; cpos ++) {
	  eng.checker_board [cpos] = (BYTE) frBoard [cpos];
	}
	/*cpos = 0;
	for (ypos = 1; ypos <= eng.boardy; ypos ++) {
	  for (xpos = 1; xpos <= eng.boardx; xpos ++) {
	    eng.checker_board [cpos] = frBoard [Posof (xpos,ypos)]; cpos ++;
	  }
	} */
}

_inline short my2cg (short csq)		/* Conv my coord to Chess Gen coord*/
{
	//return (csq - ((csq / eng.eng.bmult) << 1) - eng.boardx - 1);
	return (csq);
}

_inline short cg2my (short csq)
{
	//return (csq + ((csq / eng.boardx) << 1) + eng.boardx + 3);
	return (csq);
}

short islegalengine (short mfr, short mto, short prom)	// Returns move legality,0=ok
{
	// PROM is 4..7 for QRBN, 0 for none.  Returns:
	// 0  Move is legal. If promotion it is specified correctly
	//-1 The from square is legal. The to square is not.
	//-2 The from and to squares are legal but the move is a promotion 
	// & the promotion type is not specified.
	//-3 The from square is illegal. square empty
	//-4 The from square is illegal. contains opponents piece
	//-5 The from square is illegal. (piece has no legal moves)
	short retv;
	Pmove_test->from = (BYTE) my2cg (mfr);
	Pmove_test->to = (BYTE) my2cg (mto);
	Pmove_test->flags = (BYTE) prom;
	retv = ext_is_move_legal ();
	return (retv);
}

  // Execute a move..
  // MODE: set bit 0 for slide, 
  // bit 1 for legality check..
  // bit 2 set for start comp reply think..
  // bit 3 set to disable think-reinit & VDU update..
  // return 0=ok, nz for illegal move
short ExecMove (BYTE far *pmov, short mode)
{
	Pmove_test->from = pmov [0];
	Pmove_test->to =  pmov [1];
	Pmove_test->flags = pmov [2];
	if (mode & 2) {		// test legality first..
	  retv = ext_is_move_legal ();
	  if (retv) return (retv);	// ret nz =illegal move..
	}
	  retv = ext_checker_move ((GAMESTORE far *) pmov,1,NULL);// Exec complete line..
	if (mode & 1) {
	  MakeMove (8);			// Slide the move
	} else {
	  FastMakeMove ();		// Make move on screen
	}
    	if (FlagNumbering) DrawNumbering (1);
	if (mode & 8) return 0;		// No more action..
	  if (mode & 0x10 && schIsMultiJump) mode &= (~4);	
	if (eng.play_mode == PlayNormal && (mode & 4)) { 	// Move made, think about reply..
	  InitThink (ThinkComp);
	} else {
	  InitThink (ThinkOpp);
	}
	MoveBox (0);		// 2 player
	SearchBox ();
	PrintSearch (1);		// Print move to spool? (no anal)
	return 0;			// ok, legal move done..
}

  // As above, but accepts discrete locations for just 1 move..
short Exec1Move (short mfr, short mto, short prom, short mode)
{
	static BYTE pmov [6];
	pmov [0] = (BYTE) (mfr);
	pmov [1] = (BYTE) (mto);
	pmov [2] = (BYTE) (prom);
	pmov [3] = pmov [4] = 0;
	return (ExecMove (pmov, mode));
}

	// Exec a HUMAN move 
	// Ret 0 if legal move made..
short DoHumanMove (short mfr, short mto, short mode)
{
	short retv,prom = 0;
	retv = islegalengine (mfr,mto,254);
	//
	if (retv) {		// Move is either bad, or promo
	  //if (retv != -2) {	// Not promo, bad move.
	  goto DoHumanExit;
	  //}
	  //prom = DlgPromote ();	// input promotion piece
	  //if (prom < 4) goto DoHumanExit;		// move aborted.
	}
	    // Do the move, and start comp reply if not multi-jump..
	Exec1Move (my2cg (mfr),my2cg (mto),prom, 0x14 | mode);
	if (eng.game_status) SoundIt ();		// Game over - make noise..
    	if (FlagNumbering) DrawNumbering (1);

	return 0;
DoHumanExit:	  	// Not promo, illegal	
	SoundIt ();
	qDrawBoard ();
	return (retv);
}
                    
short cx,cy,dx,dy;
#define PALFLAG 0  //PC_RESERVED	// Default Palette flag..

void SetSqrCol ()		// Calc Square colouring..
{
	static short cr,cg,cb,t;
	short pcont = eng.pcontrast;
	short tflag;
	nExtraPal = 22;		// No of extra pal colours to slip in
	cr = eng.lsqr.r ;		// Read light sqr color.. (0-100)
	cg = eng.lsqr.g ;
	cb = eng.lsqr.b ;
		// Calc vals for wht sqr
	SetRGBFper (0, cr,cg,cb, PALFLAG,100);
	t = 100 - (pcont >> 2);
	SetRGBFper (1, cr,cg,cb, PALFLAG,t);
	t = 100 - (pcont >> 1);
	SetRGBFper (2, cr, cg, cb, PALFLAG, t);
	t -= (pcont >> 2);
	SetRGBFper (3, cr, cg, cb, PALFLAG, t);
	t = 100 - pcont;
	SetRGBFper (4, cr, cg, cb, PALFLAG, t);
		// Calc vals for DARK sqr palettes..
	if (eng.scontrast) {
	  t = 100 - eng.scontrast;
	  cr = cr * t / 100;
	  cg = cg * t / 100;
	  cb = cb * t / 100;
	} else {
	  cr = eng.dsqr.r;
	  cg = eng.dsqr.g;
	  cb = eng.dsqr.b;
	}
	SetRGBFper (5, cr,cg,cb,PALFLAG,100);
	t = 100 - (pcont >> 2);
	SetRGBFper (6, cr,cg,cb,PALFLAG,t);
	t = 100 - (pcont >> 1);
	SetRGBFper (7, cr, cg, cb, PALFLAG, t);
	t -= (pcont >> 2);
	SetRGBFper (8, cr, cg, cb, PALFLAG, t);
	t = 100 - pcont;
	SetRGBFper (9, cr, cg, cb, PALFLAG, t);
		// Now init vals for other palette needs..
		// Background = 67% of norm box colour..
	SetRGBFper (PALBACK,eng.box.r,eng.box.g,eng.box.b,PALFLAG,67);
		// Norm box colour
	SetRGBFper (PALBOX,eng.box.r,eng.box.g,eng.box.b,PALFLAG,100);
		// Text colour
	SetRGBFper (PALTXT,eng.txt.r,eng.txt.g,eng.txt.b,PALFLAG,100);
		// Animation palettes, for RGB selector..
	tflag = PC_RESERVED | PC_NOCOLLAPSE; 
	if (nVduColor < 8) tflag = 0;
	SetRGBFper (PALANIMLT,1,0,0,tflag,100); // light sqr
	SetRGBFper (PALANIMDK,1,1,0,tflag,100); // dark sqr
	SetRGBFper (PALANIMTX,0,1,0,tflag,100); // text
	SetRGBFper (PALANIMBX,1,0,1,tflag,100); // box..
		// Lo-lite (greyed) txt - mix txt & box color..
	cr = (eng.txt.r + eng.box.r + eng.box.r) / 3;
	cg = (eng.txt.g + eng.box.g + eng.box.g) / 3;
	cb = (eng.txt.b + eng.box.b + eng.box.b) / 3;
	SetRGBFper (PALLOTXT,cr,cg,cb,PALFLAG,100);	// Used for lo-lite txt
	if (ModeHITXT == 0) {
	  cr = 90;
	  cg = (eng.txt.g + eng.box.g) >> 2;
	  cb = (eng.txt.b + eng.box.b) >> 2;
	} else {	// INI has: hitxt=### (RGB 111..999)
	  cb = (ModeHITXT % 10) * 10;
	  cg = ((ModeHITXT / 10) % 10) * 10;
	  cr = ((ModeHITXT / 100) % 10) * 10;
	}
	SetRGBFper (PALHITXT,cr,cg,cb,PALFLAG,100);	// Used for hi-lite txt
	if (ModeVATXT == 0) {
	  cr = (eng.txt.r + eng.box.r) >> 2;
	  cg = (eng.txt.g + eng.box.g) >> 2;
	  cb = 90;
	} else {	// INI has: vartxt=### (RGB 111..999)
	  cb = (ModeVATXT % 10) * 10;
	  cg = ((ModeVATXT / 10) % 10) * 10;
	  cr = ((ModeVATXT / 100) % 10) * 10;
	}
	SetRGBFper (PALVATXT,cr,cg,cb,PALFLAG,100);	// Used for variant txt
	if (ModeUBOX == 0) {
	  cr = eng.box.r;	// Lighter userbox colour (15% lighter than box..)
	  cg = eng.box.g;
	  cb = eng.box.b;
	} else {	// INI has: ubox=### (RGB 111..999)
	  cb = (ModeUBOX % 10) * 10;
	  cg = ((ModeUBOX / 10) % 10) * 10;
	  cr = ((ModeUBOX / 100) % 10) * 10;
	}
	if (nVduColor < 8) {		// 16 colours, mix to grey..
	  cr = cg = cb = ((cb + cr + cg) / 75) * 25;
	}
	SetRGBFper (PALUBOX,cr,cg,cb,PALFLAG,115);	// Used for lo-lite txt
		// Non-palette SYSTEM palette colours..
	SetRGBFper (PALGREY,75,75,75, PALFLAG,100);
	SetRGBFper (PALDKGREY,50,50,50, PALFLAG,100);
	SetRGBFper (PALWHITE,100,100,100, PALFLAG,100);
	SetRGBFper (PALBLACK,0,0,0, PALFLAG,100);
	SetRGBFper (PALRED,100,0,0, PALFLAG,100);
}

	// Gen Square Backg graphics in hWorkDC for give Palette col & Loc.
void GenSqrGraphics (short Paloff, short SqLocx, short SqLocy)
{
	short rloop,xpos,ypos,cind,cc,tcol;
	short SqPattern = eng.sqpattern;
	cind = (SqPattern ? 2 : 0);	// If plain, use lightest color
	hTempBrush = CreateSolidBrush (ExtraRGB (Paloff + cind));   // Norm
	hDarkPen = CreatePen (PS_SOLID,1,ExtraRGB (Paloff + 4)); // Darker
	hLightPen = CreatePen (PS_SOLID,1,ExtraRGB (Paloff));    // Lighter
	SelectObject (hWorkDC,hTempBrush);
	SelectObject (hWorkDC,hDarkPen);
	Rectangle (hWorkDC, SqLocx-1, SqLocy-1,
		SqLocx + charx + 1, SqLocy + chary + 1);
	SelectObject (hWorkDC,hNullBrush);
		// Special FX..
	if (SqPattern == 1) {		// Concentric rects
	  for (rloop = 1; rloop < (charx >> 1); rloop += 4) {
	    Rectangle (hWorkDC, SqLocx + rloop, SqLocy + rloop,
		SqLocx + charx + 1 - rloop, SqLocy + chary + 1 - rloop);
	  }
	  SelectObject (hWorkDC,hLightPen);
	  for (rloop = 3; rloop < (charx >> 1); rloop += 4) {
	    Rectangle (hWorkDC, SqLocx + rloop, SqLocy + rloop,
		SqLocx + charx + 1 - rloop, SqLocy + chary + 1 - rloop);
	  }
	} else if (SqPattern == 2 || SqPattern == 3) {	// Wood grain/stony..
	  cind = 0; cc = 1;
	  for (ypos = 0; ypos <= chary; ypos ++) {
	    for (xpos = 0; xpos <= charx; xpos ++) {
	      cc --;
	      if (cc < 5) {
	        if (SqPattern == 2) {	// Long grain
	          cc = (myRand () % 6) * (myRand () % 6) + 5;
	        } else {		// Stony
	          cc = (myRand () % 5) * (myRand () % 5);
	        }
	        cind ++;	// gradual incremental color change..
	        if (cind >  4) cind = - 3;
	        tcol = Paloff + abs (cind);
	        //cind = Paloff  + (myRand () % 4);
	      }
	      SetPixel (hWorkDC,SqLocx + xpos,SqLocy + ypos,ExtraRGB (tcol));
	    }
	  }
	} else if (SqPattern == 4) {		// Shaded
	  for (ypos = 0; ypos <= chary; ypos ++) {
	    for (xpos = 0; xpos <= charx; xpos ++) {
	      cind = ((abs ((chary >> 1) - ypos) + abs ((charx >> 1) - xpos)) * 10 - 4) / (chary + charx);
	      if (Paloff) cind = Paloff + cind;
	      SetPixel (hWorkDC,SqLocx + xpos,SqLocy + ypos,ExtraRGB (cind));
	    }
	  }
	} else if (SqPattern == 5) {		// Random
	  for (ypos = 0; ypos <= chary; ypos ++) {
	    for (xpos = 0; xpos <= charx; xpos ++) {
	      SetPixel (hWorkDC,SqLocx + xpos,SqLocy + ypos,ExtraRGB (Paloff + (myRand () % 5)));
	    }
	  }
	  //Rectangle (hWorkDC, SqLocx + 1, SqLocy + 1,SqLocx + charx, SqLocy + chary);
	  //SelectObject (hWorkDC,hLightPen);
	  //MoveTo (hWorkDC, SqLocx + 1, SqLocy + 1 + chary);
	  //LineTo (hWorkDC, SqLocx + 1, SqLocy + 1); 
	  //LineTo (hWorkDC, SqLocx + 1 + charx, SqLocy + 1); 
	}
	SelectObject (hWorkDC,hBlackPen);
	DeleteMyObject (hTempBrush);
	DeleteMyObject (hLightPen);
	DeleteMyObject (hDarkPen);
}

	// Gen Square Backg graphics in hWorkDC for White/Black sqrs..
void CreateBoardGraphics (void)		// Create square graphics
{
		// Location of square BMPs in hWorkDC
	WhsqLocx = 0; WhsqLocy = 0;
	BlsqLocx = 0; BlsqLocy = worky;
	GenSqrGraphics (0,WhsqLocx,WhsqLocy);	// Create White square..
	GenSqrGraphics (5,BlsqLocx,BlsqLocy);	// Create Black square..
		// Create brushes for screen with new colours..	
	if (hBackBrush != NULL) {	// Delete any old first..
	  SelectObject (hWDC,hNullBrush);
	  DeleteMyObject (hBackBrush);
	  DeleteMyObject (hBoxBrush);
	  DeleteMyObject (hUBoxBrush);
	}
		// background color
	hBackBrush = CreateSolidBrush (ExtraRGB (PALBACK));
		// move/search boxes color
	hBoxBrush = CreateSolidBrush (ExtraRGB (PALBOX));
	hUBoxBrush = CreateSolidBrush (ExtraRGB (PALUBOX));
	TextCol (PALTXT,PALBOX);		// Init text/background colour.
}

MYINLINE short ReadPieceOpt ()	// Read piece option combo-text..
{
	HFILE hSetFile = NO_FILE;	// handle to input file..
	short clang = 0;
	short nopts = 0;	// Count of # options
		// Open input set.DEF file	
	hSetFile = OpenFile (CHSETFILE, &ofBuf, OF_READ);
	if (hSetFile == NO_FILE) return 0;
	do {
	  if (LineInput (hSetFile, szTemp, SIZEszTemp,0) < 0) {
	    break;			// End of file..
	  }
	  if (szTemp [0] == '!') break;
	  if (szTemp [0] == '/') continue;	// Ignore comments
	  if (clang == eng.language) {	// Copy& process to opt string
	    short cptr,cchr;
	    for (cptr = 0; cptr < sizeof (SToptpieceset) - 2; cptr++) {
	      cchr = szTemp [cptr];
	      if (cchr == ';' || cchr == 0) break;
	      if (cchr == ',') {
	        cchr = 0; nopts ++;
	      }
	      SToptpieceset [cptr] = (char) cchr;
	    }
	    SToptpieceset [cptr] = 0;
	    SToptpieceset [cptr + 1] = 0;
	  }
	  clang ++;
	} while (1);
	_lclose (hSetFile);	// Close read file
	return nopts;
}

void SelectSet (short cpieceset)	// Bitmap set to enable. (0 to kill)
{
	HFILE hSetFile = NO_FILE;	// handle to input file..
	ALY short cval;
	short ccol,cpc;
	ALY char *setname;
tryagain:
	thissetno = cpieceset;		// Save real ref # in CHSET..
		// Open input .EPD file	
	hSetFile = OpenFile (CHSETFILE, &ofBuf, OF_READ);
	BufReset ();		// Reset input buffer..
	if (hSetFile == NO_FILE) goto SelectDef;
	do {
scontinue:
	  if (LineInput (hSetFile, szTemp, SIZEszTemp,1) < 0) {
	    goto SelectClose;			// End of file..
	  }
	  if (szTemp [0] == '!') goto SelectClose;
	  if (szTemp [0] != '=') continue;	// Ignore other lines
	  szTemp [SIZEszTemp >> 1] = 0;
	  ParsePtr = szTemp + 1;
	  cval = ParseInt ();			// Set val in file
	  if (cval != cpieceset) continue;	
	  cval = ParseStr ();			// Filename?
	  if (cval != ',') continue;		// must end with comma
	  setname = ParseBeg;
	  settype = ParseInt ();
	  if (settype == -32767) continue;
	  setchrx = ParseInt ();
	  if ((USHORT) setchrx > 500) continue;
	  setchry = ParseInt ();
	  if ((USHORT) setchry > 500) continue;
	  minsetchr = ParseInt ();
	  if (minsetchr == -32767) continue;
	  tinyset = ParseInt ();
	  if (tinyset == -32767) continue;
	  if (tinyset && (charx < setchrx || chary < setchry)) {
	    cpieceset = tinyset;
	    _lclose (hSetFile);	// Close read file
	    goto tryagain;	// And try to load tiny set..
	  }
	  for (ccol = 0; ccol <= 9; ccol += 8) {
	    for (cpc = 1; cpc <= 6; cpc ++) {
	      cval = ParseInt ();		// Set val in file
	      if (cval == -32767) goto scontinue;
	      xoff [cpc + ccol] = cval;
	      cval = ParseInt ();
	      if (cval == -32767) goto scontinue;
	      yoff [cpc + ccol] = cval;
	    }
	  }
	  
		// Ok, now read in set..
	  _lclose (hSetFile);	// Close read file
	  if (ReadDIB (setname) == FALSE) {	// Load failed?
	    goto SelectDef;	// Genius (default set)
	  }
	  return;
	} while (1);
SelectClose:
	_lclose (hSetFile);	// Close read file
SelectDef:			// Default (genius) set
	DoMessage ("!Cannot load set");
	for (temp = 0; temp < aSizeOf (xoff) - 1; temp ++) {
	  xoff [temp] = xoff2 [temp];
	  yoff [temp] = yoff2 [temp];
	}
	setchrx = 36; setchry = 36;	// Size each piece
	minsetchr = 18;
	settype = 1;			// For older duplicate sets
	setname = DEFsetname;
	ReadDIB (setname);		// Genius (default set)
}

/*
// Find out how much total free ram there is, in 1K blocks..
MYINLINE long TotalRamSize ()
{
	long memsize;
	MEMMANINFO mmi;
	GlobalCompact (1);
	if (dbProfileMode & 2) {	// Allow hash size > RAM..
	  memsize = GetFreeSpace (0);
	} else {			// Get size from MEMMANINFO..
	  mmi.dwSize = sizeof (mmi);
	  MemManInfo (&mmi);
	  // memsize = (long) mmi.dwTotalPages * (long) mmi.wPageSize;
	  memsize = (long) mmi.dwTotalUnlockedPages * (long) mmi.wPageSize;
	}
	return (memsize / 1024); // 16 megs - 64K max globalloc.
}
*/

  // Set hmode bit 0 to reset from INI, bit 1 to reset to default
void SetHash (BYTE hmode)
{
	short cret ;
	if (hmode) {	// Init hash settings..
	  MaxHash = (USHORT) ((ULONG) wio_MaxRam () / (3*64*1024)); // 1/3rd mem max size..
	  /*max (2,(TotalRamSize () - 640) / 64);*/
	  HashSize = (USHORT) MaxHash * 32;
	  if ((hmode & 2) == 0) {
	    ReadProInt (PROF_HASH,&HashSize,1);	// Get size from INI file
	  }
	  HashSize = HashSize >> 6;
	}
		// Keep in range 128K..Max..
	HashSize = max (2,min (MaxHash, HashSize));
	cret = ext_hash_init ((long) HashSize * 0x10000L);
	if (cret == -1) {	// Try 128K..
	  HashSize = 2;
	  cret = ext_hash_init ((long) HashSize * 0x10000L);
	  if (cret == -1) {	// Failed.
	    return;
	  }
	}
}


#if Debug	// Misc debug-test key services..
extern void edbTest ();
extern void schIgnore (char *);

void DebugBits (short cmdkey)
{
	  if (cmdkey == '@') {	// Start playing midi file
	    HINSTANCE temp;
	    dlg_TextIn ("MPLAYER - PARAMETER",szTemp,80,STok,NULL);
	    //temp = ShellExecute (hMainWnd, "open","mplayer.exe",szTemp,"",SW_NORMAL);
	    //temp = execl ("mplayer.exe","canyon.mid",NULL);
	    gotoxy (1,1);
	    printsi ("error",(short) temp);
	    //DoMessage ("OK");
	  }
	  if (cmdkey == ':') {
	    anyfly = 1 - anyfly;
	  }
	  if (cmdkey == '?') {
	    #if ENDGAMEDB
	      //long BitBrd [3] = {1,0x40000000L,0x40000001L};
	      //msgprintf (NULL,0,0,"Db result = %lu ",DBLookup (BitBrd,0));
	      edbTest ();
	      ReThink ();	// Re-start thinking..
	    #endif
	    { char tt [100] = "";
	     dlg_TextIn ("HASH TEST - ENTER: mask,ignore.. (in hex)",tt,6,STok,NULL);
	     schIgnore (tt);
	    }
	  }
	  if (cmdkey == '(') {
	    debugflag = 1 - debugflag;
	  }
	  if (cmdkey == ' ') {
	    RedrawAllWindows ();	// Force repaint..
	  }
	  if (cmdkey == '<') {		// Poppup-child window mode..
	    Dink ();
	    ProcessFloatingWindows (0);
	    TogPopUp
	    ProcessFloatingWindows (1);
	  }
	  if (cmdkey == '!') {
	    BitBlt (hWDC,0,80,620,460,hPieceDC, 0,0,SRCCOPY);
	    BitBlt (hWDC,0,0,640,80,hWorkDC, 0,0,SRCCOPY);
	    msgprintf (hWDC,400,0,"workxy=%d,%d, wastexy=%d,%d",workx,worky,wastex,wastey);
	  }
	  if (cmdkey == '#') {
	    BitBlt (hWDC,0,0,620,460,hMaskDC, 0,0,SRCCOPY);
	    msgprintf (hWDC,0,300,"bits/pixel %d, planes %d",
		GetDeviceCaps (hWDC, BITSPIXEL),
		GetDeviceCaps (hWDC, PLANES));
	    msgprintf (hWDC,0,320,"BMP:x=%d,y=%d,Piece x=%d,y=%d,scale =%d,free=%lu",
	      maxsetx,maxsety,setchrx,setchry,setscale,GetFreeSpace (0));
	    _getcwd (szTemp,SIZEszTemp);
	    msgprintf (hWDC,0,340,"Current dir=%s, work dir = %s,%d",(LPSTR) szTemp,(LPSTR) szInitDir,InitDrive);
	  }
	  if (cmdkey == '*') {
	    SetStretchBltMode (hWDC,STRETCH_DELETESCANS);
	    StretchBlt (hWDC,0,0,(maxsetx >> 1) + 10,maxsety + 10,
		hPieceDC, 0,0,maxsetx + 20,(maxsety << 1) + 20,SRCCOPY);
	  }
	  
	  if (cmdkey == ')') {		// Palette anim test - how to..
	    dlg_TextIn ("Color ?",szTemp,5,STok,NULL);
	    if (isdigit (szTemp [0])) {
	      short xcol= atoi (szTemp);
	      SetRGBFper (PALANIMLT,xcol,xcol,0,PC_RESERVED,100);	// Used for anim palette
	      AnimatePalette (hPalette, SparePal [0],1, 
		(PALETTEENTRY FAR *) ExtraPal + PALANIMLT);
		
		//hTempBrush = CreateSolidBrush (PALETTEINDEX (SparePal));
		hTempBrush = CreateSolidBrush (ExtraRGB (PALANIMLT));
		SelectObject (hWDC,hTempBrush);
		Rectangle (hWDC,40,1,80,20);
		SelectObject (hWDC,hBackBrush);
		DeleteMyObject (hTempBrush);
	      DoMessage ("...");
	    }
	  }
}
#endif // Debug

	// Draw Checkered backdrop
void DrawChecker (RECT rct)
{ 
	 POINT pgpt [4]; 	// For polygon
	 short SqSize = 40;
	 const short SqOff = 2;
	 short xstart = 0;
	 short x2start = 0;
	 short x2pos;
	 BOOL IsDk = TRUE;
	 BOOL IsDk2;
	 short hlfx = (short) (rct.right >> 1);
	HBRUSH hLsqrBrush = CreateSolidBrush (RGB (0,192,192));
	HBRUSH hDsqrBrush = CreateSolidBrush (RGB (0,128,128));
	 SelectObject (hWDC,hLsqrBrush);	// Fill back light sqrs..
	 Rectangle (hWDC, 0,0,rct.right + 1, rct.bottom + 1);
	 SetPolyFillMode (hWDC, ALTERNATE);
	 SelectObject (hWDC,hDsqrBrush);
	 for (ypos = 0; ypos <= rct.bottom; ypos += SqSize) {
	   SqSize += SqOff + SqOff;		// Next row bigger..
	   x2pos = x2start ;
	   IsDk2 = !IsDk;
	   for (xpos = xstart; xpos <= hlfx; xpos += SqSize) {
	     if (IsDk) {	// Dark sqr
	       pgpt[0].x = hlfx + xpos; 
	       pgpt[0].y = ypos;
	       pgpt[1].x = hlfx + xpos + SqSize + 1; 
	       pgpt[1].y = ypos;
	       pgpt[2].x = hlfx + x2pos + SqSize + 1 + SqOff + SqOff;
	       pgpt[2].y = ypos + SqSize - SqOff- SqOff;
	       pgpt[3].x = hlfx + x2pos;
	       pgpt[3].y = ypos + SqSize - SqOff- SqOff;
	     } else {		// Reflected pos..
	       pgpt[0].x = hlfx - xpos; 
	       pgpt[0].y = ypos;
	       pgpt[1].x = hlfx - (xpos + SqSize + 1); 
	       pgpt[1].y = ypos;
	       pgpt[2].x = hlfx - (x2pos + SqSize + 1 + SqOff + SqOff);
	       pgpt[2].y = ypos + SqSize - SqOff - SqOff;
	       pgpt[3].x = hlfx - x2pos;
	       pgpt[3].y = ypos + SqSize - SqOff - SqOff;
	     }
	     Polygon (hWDC, pgpt, 4);
	     x2pos += SqSize + SqOff + SqOff;
	     IsDk = !IsDk;
	   }
	   IsDk = IsDk2;
	   ypos -= (SqOff + SqOff);
	 }
	SelectObject (hWDC, hNullBrush);
	DeleteObject (hLsqrBrush);
	DeleteObject (hDsqrBrush);
}

void ShowBitmap (HDC hBmpDC, short hxpos, short hypos, short sizex, short sizey, short mode)
{
	if (mode & 1) {		// Auto-center x..
	  hxpos -= (sizex >> 1);
	}
	if (mode & 2) {		// Auto-center x..
	  hypos -= (sizey >> 1);
	}
	SelectObject (hWDC,GetStockObject (NULL_BRUSH));
	SelectObject (hWDC,GetStockObject (BLACK_PEN));
	Rectangle (hWDC,hxpos - 1,hypos - 1,hxpos + sizex + 1, hypos + sizey + 1);
	BitBlt (hWDC, hxpos, hypos, sizex, sizey, hBmpDC,0,0, SRCCOPY);
}

void Checker2D (RECT rct)
{
	short cxpos,cypos;
	const short SqSize=16;
        HBITMAP hBmp = NULL;	// Handle for logo bmp
        HBITMAP hOldBmp;
        HDC hPatDC;		// DC for logo bmp
        BYTE crnd = 0;
        hBmp = LoadBitmap (hInstance, "ChkPat");	// Load logo bitmap
        if (hBmp) {
	  hPatDC = CreateCompatibleDC (hWDC);
          hOldBmp = SelectObject (hPatDC,hBmp);
	  for (cypos = (short) rct.top; cypos <= (short) rct.bottom; cypos += SqSize) {
	    for (cxpos = (short) rct.left; cxpos <= (short) rct.right; cxpos += SqSize) {
	      BitBlt (hWDC, cxpos, cypos, SqSize, SqSize, hPatDC,
	      	(((cxpos ^ 0x58a5) * cypos - (cxpos >> 3)) & (1 << (crnd & 15))) ? SqSize:0,0,SRCCOPY);
	      crnd ++;
	    }
	  }
	  SelectObject (hPatDC,hOldBmp);
	  DeleteDC (hPatDC);
	  DeleteObject (hBmp);
	}
}

static LOGFONT lfBig = {	// Define special big font
  -80,0,0,0,FW_NORMAL,1,0,0, 
  ANSI_CHARSET, OUT_STROKE_PRECIS, CLIP_STROKE_PRECIS, PROOF_QUALITY, 
  FF_ROMAN | VARIABLE_PITCH,"Courier New"}; 
  
	// Draw a big header..
MYINLINE void BigHeader (char *hstr, short hxpos, short hypos, short size)
{
	HFONT hBigFont = NULL;		// Font for big lettering
	SIZE ExtTxt;
        short tlen,xpos;
        const short mode = 1;
	HFONT hOldFont = NULL;
	SetTextColor (hWDC, RGB (255,255,255));
	SetBkColor (hWDC, RGB (0,0,0));
	lfBig.lfHeight = size;
	lfBig.lfWidth = size /2;
		// Create a big font
	hBigFont = CreateFontIndirect (&lfBig);   // create new logical font
	if (hBigFont == NULL) {		// Could not do it, select system..
	  hBigFont = GetStockObject (SYSTEM_FIXED_FONT);
	}
	SelectObject (hWDC,hBlackPen);
	SelectObject (hWDC,GetStockObject (LTGRAY_BRUSH));
	hOldFont = SelectObject (hWDC,hBigFont);
	tlen = strlen (hstr);
	GetTextExtentPoint (hWDC,hstr,tlen,&ExtTxt);
		// Write black shadow
	SetBkColor (hWDC, RGB (0,0,0));
	SetBkMode (hWDC,TRANSPARENT);
	SetTextColor (hWDC, RGB (0,0,0));
	TextOut (hWDC, hxpos - (ExtTxt.cx >> 1) + 21,
	      hypos + 40, hstr,tlen);
	for (xpos = 1; xpos < 40; xpos ++) {
	  if (xpos == 39) {
	    SetTextColor (hWDC, RGB (255,255,255));
	  } else {
	    //SetTextColor (hWDC, RGB (myRand (),myRand(),myRand()));
	    SetTextColor (hWDC, RGB (20 + xpos*5,20 + xpos*5,20 + xpos*5));
	  }
		// Write text..
	  TextOut (hWDC, hxpos - (ExtTxt.cx >> 1) + xpos - 20,hypos + xpos,hstr,tlen);
	}
		// Select old font back
	SelectObject (hWDC,hOldFont);
	if (hBigFont) DeleteObject (hBigFont);
}


	// PROGRAM INITIALISATION routine..
void MainInit ()
{
        int cret;
        #if _DEBUG
          con_open (NULL,"Engine info..");
	#endif
	//short cflag;
	hMainDC = hWDC = GetDC (hMainWnd);	// Device context for main window
	mySrand ((short) clock ());
	  // NEW STUFF..
	hSysVarFont = (HFONT) GetStockObject (DEFAULT_GUI_FONT);
        lbox_Reset (hInstance);
		// Init new toolbar bmps..
	#if TOOLBAR  // New Win32 toolbars..
          bmp_Reset (&sBmp, BMP_RST_INIT | BMP_RST_WIPE); // Init Bmp store obj, ready to use..
          bmp_Add (&sBmp,BMP_TOOLBAR,"tool.bmp",NULL,0,0,0);
          cret = bmp_LoadAll (&sBmp,BMP_LOAD_MAKEDC);
          if (cret) exit (0);   // Load errir, exit prog..
    	    // Initialise tool bar..
          tool_Reset (hInstance,&sBmp.hPal,&sBmp.i[BMP_TOOLBAR].hDC);
	  memset ((void *) & tb_Main,0, sizeof (tb_Main));
	  tb_Main.hParent = hMainWnd;
	  tb_Main.ttop.y = 0;
	  tb_Main.hBmpDC = &sBmp.i[BMP_TOOLBAR].hDC;
	  tb_Main.hPal = &sBmp.hPal;
	  tb_Main.pTbut = tbb_Main;
	  tool_Load (&tb_Main, szParamFile, "TOOLMAIN", 40);
	  tool_Create (&tb_Main);
	#endif

		// Set calender time..
	{	
	  struct tm *tptr;	// temp ptr to time structure
	  time (&timeSecs);
	  tptr = gmtime (&timeSecs);
	  memcpy (&timeCalender, tptr, sizeof (timeCalender)); // Save time..
	}
		// Calc size of all windows x/y-border
	WndBorderx = GetSystemMetrics (SM_CXFRAME);
	WndBordery = GetSystemMetrics (SM_CYFRAME);
	WndTitley = GetSystemMetrics (SM_CYCAPTION) 
		- GetSystemMetrics (SM_CYBORDER);  // Title height (no border)
	
		// Calc Total window wastage x/y - borders, caption..
	WndExtrax = WndBorderx << 1;
	WndExtray = WndTitley + (WndBordery << 1);
	DialogInit ();  // Init any dialog vars/resources (DBUx/y,etc)
		// Alloc memory for ECO eng.language strings..
	#if ECOSTR
	  hGlbECO = GlobalAlloc (GMEM_MOVEABLE, SIZEECO + 50);
	#endif

		// Determine & save working directorys
	_getcwd (szInitDir, SIZEszInitDir);
	InitDrive = _getdrive ();	// Save current drive..
	//if (GetDriveType (InitDrive-1) == DRIVE_REMOVABLE) {
	  szWorkDir = szInitDir; // something else here..
	  WorkDrive = InitDrive;
	//} else {	// Fixed-hd..
	//  szWorkDir = szInitDir;
	//  WorkDrive = InitDrive;
	//}
	GotoDir (NULL);		// Go to current directory..
	if (FileExists (CHSETFILE) == FALSE) {	// No CHSET, try INI setting
	  szWorkDir = szInitDir;
	  strcpy (szWorkDir, "C:\\WGENIUS");
	  ReadProStr (PROF_DIR,szWorkDir);	// or get INI setting..
	  WorkDrive = szWorkDir [0] - 64;
	  GotoDir (NULL);
	  if (FileExists (CHSETFILE) == FALSE) {	// No CHSET here, abort..
	    msgprintf (NULL, ABORT_PROG,0,"Cannot load %s!", 
	    	(LPSTR) CHSETFILE);
	  }
	}
		// Read some INI settings
	ReadProInt (PROF_NLANG,&MaxLang,1);	// no of languages..
	if (MaxLang < 1 || MaxLang > 9) MaxLang = 3;
	ReadProInt (PROF_PRNEDGE,&PrnEdges,1);	// Flag-disable prn edging..
	ReadProInt (PROF_TIME,clktime,4);	// 4 timing constants
	ReadProInt (PROF_PRNSIZE,&PrnSize,1);	// Printer font scaling %
	ReadProInt (PROF_VATXT,&ModeVATXT,1);	// var txt RGB val
	ReadProInt (PROF_HITXT,&ModeHITXT,1);	// hi txt RGB val
	ReadProInt (PROF_UBOX,&ModeUBOX,1);	// userbox RGB val
	#if OLD_PROTECT
	 ReadProInt (PROF_DRV,&InstallDrive,1); // Orig installation drive
	#endif
	ReadProInt (PROF_DBMODE,&dbProfileMode,1); // Database mode bits.
	ReadProInt (PROF_MIXEDFLAGS,&schMixedFlagsVar,1); // Misc flags
        ReadProInt (PROF_WEIGHTS,schIniWeights,15); // Misc weights
        ReadProInt (PROF_DRAWREP,&schDrawByRep,1); // # move before rep
        ReadProStr (PROF_ENDDBFILE,edbFile); 	// Endgame DB filename
        ReadProInt (PROF_ENDDBBUFFER,&edbBuffSize,1); // End DB buff size
        ReadProInt (PROF_ENDDBTYPE,&edbType,1); // End DB buff size
	
	ReadProStr (PROF_CLKFONT,szClkFont);	// Clock font
	ReadProInt (PROF_CLKFONTSIZE,&ClkFontSize,1);	// Clock font
	
		// Add bitmap font resources..
	temp = AddFontResource (szBmpFont);
        if (temp) SendMessage (HWND_BROADCAST, WM_FONTCHANGE, 0, 0L);
	
		// Load and select hot key bmps.	
	hHotBmp = LoadBitmap (hInstance, "HotKeys");
	hHotDC = CreateCompatibleDC (hWDC);
	hOldHotBmp = SelectObject (hHotDC, hHotBmp);
		// Load and select tiny board bmps
	hTinyBmp = LoadBitmap (hInstance, "TinyPieces");
	hTinyDC = CreateCompatibleDC (hWDC);
	hOldTinyBmp = SelectObject (hTinyDC, hTinyBmp);
		// Select default printer font..
	memset (&lfPrint, 0, sizeof (LOGFONT));	// clr struct
	lfPrint.lfHeight = 0;	// default
	strcpy (lfPrint.lfFaceName,"Roman 10cpi");	// Font name to select
		// Init cursor handles..	
	hNormCursor = LoadCursor (NULL, IDC_ARROW);
	hWaitCursor = LoadCursor (NULL, IDC_WAIT);
	hEmptyCursor = LoadCursor (hInstance, (LPCSTR) "NullCur");	// While grabbing piece
	hCurCursor = hNormCursor;
		// Init ptrs to engine vars..	
	InitAnalPtrs ();
	comInitialise ();	// Initialise memory for COMMENT/headers
	SetWaitCursor 
	InitEngine ();		// Initialise  engine
	SetNormCursor 
	eng.play_level = 0x0106;		// Set default level..
			
	SetHash (1);		// Alloc mem for hash..
	   // Examine screen capabilities, and thus set #color/sqr size..	
	nVduX = GetDeviceCaps(hWDC, HORZRES);	// # pixels across
	nVduY = GetDeviceCaps(hWDC, VERTRES);
	   // Calc tot bits per pixel..	
	nVduColor = GetDeviceCaps(hWDC, BITSPIXEL) // #Color planes..
		+ GetDeviceCaps(hWDC, PLANES) - 1;
	SetDefault (3);  	// Init default set & colours
	//if (nVduX > 1000 && nVduY > 700) {	// Extra large set..
	//  pieceset = 4;
	//}
	popdlgwnd.lx = nVduX;	// Init default pos window..
	popdlgwnd.ly = nVduY;
		// Set default level..
	eng.play_level = 0x0106;
	retv = ext_set_level ();
		// Try Load last game for settings..	
	MainMode = DoingGame;			// Normal play mode..
		// Define pens..	
	hLtgreyPen = CreatePen (PS_SOLID,1,RGB (192,192,192));
	hDkgreyPen = CreatePen (PS_SOLID,1,RGB (128,128,128));
		// Clr brushes	
	hBoxBrush = hBackBrush = NULL;
		// Stock brushes..
	hWhiteBrush = GetStockObject (WHITE_BRUSH);
	hGrayBrush = GetStockObject (GRAY_BRUSH);
	hBlackBrush = GetStockObject (BLACK_BRUSH);
	hNullBrush = GetStockObject (NULL_BRUSH);
	hClockBrush = GetStockObject (LTGRAY_BRUSH);
		// Stock pens
	hWhitePen = GetStockObject (WHITE_PEN);
	hBlackPen = GetStockObject (BLACK_PEN);
	hNullPen = GetStockObject (NULL_PEN);
	eng.language = LoadLanguageByte ();		// Load eng.language byte from last game..
	ResetMenu ();		// Load MENU & Strings for current eng.language.
	if (nVduColor < 8) {	// Warn about too few colours
	  DoMessage (STuse256colors);
	}
		// 256 col bmp setup.. Alloc mem for palette
	hDIBInfo = GlobalAlloc (GMEM_MOVEABLE, 100 + 
	   (DWORD) ( sizeof(BITMAPINFOHEADER) + 256 * sizeof(RGBQUAD)));
	SetErrorMode (SEM_FAILCRITICALERRORS);
	#if UseIntroBMP		// Special hi-res front screen..
	  if (FileExists (szIntroBMP)) {	// if BMP file is there
	    temp = 0;
	    LoadHugeFile (szIntroBMP, (char HUGE_ *) &temp, 0,2);
	    if (temp == 0x4d42) {	// First letters 'BM' == bmp..
	      ReadDIB (szIntroBMP);		// Load it in
	      ResetDIB (1);		// Strip out & get palette,DIB->DDB
	    }
	  }
	#endif
	open_Init ();
} 

	// Load last game, and set up data..
	//.. mode = 0 for no load (reset), or 1 to load
void LoadLast (short mode)
{
	if (mode && LoadGame (szLASTGAMEFILE)) {	// Ok, use settings..
	  charx = eng.charx; chary = eng.chary;
	  if (eng.pieceset < 1) {
	    SetDefault (3);
	  } else {
	    //ReadAllPresets ();	// update preset (if selected)
	  }
	} else {	// None loaded, reset..
	  #if VARBOARDSIZE
	    if (eng.boardx < 4 || eng.boardy < 4) {	// Keep board within limits
	      eng.boardx = 8; eng.boardy = 8;
	    }
	    bmult = eng.boardx + 2;
	  #endif
	  SetDefault (3);
	  NewGame (1);
		// Set default level..
	  eng.play_level = 0x0106;
	  retv = ext_set_level ();
	}
	SetPiecePtrs ();
	//ResetMenu ();		// Load MENU & Strings for current eng.language.
		// Alloc Extra palette colours
	SetSqrCol ();	
	//eng.play_mode = PlayNormal;
	//MainMode = DoingGame;			// Normal play mode..
	//eng.play_level = 0x0106;		// Set default level..
	//retv = ext_set_level ();
	//levIDMmenu = IDM_LV2SPM;
	
	TimerOn ();				// 1 sec timer..
	
        SelectSet (eng.pieceset);		// BITMAP:Load Chess piece set..
	objon ();		// Enable fonts, etc..
	ResetDIB (0);		// Strip out & get pallette, make mono bmp, work areas..
	CreateBoardGraphics ();
	initsync ();
	levSetString ();	// Set level text strings giving cur level
	//ProcessFloatingWindows (1);	// Open windows, if in Win mode
}


void EndProg (short mode)	// Save last game, post DETROY message
{
	eng.charx = (BYTE) charx; eng.chary = (BYTE) chary;
	SaveGame (IDM_SAVEALL,szLASTGAMEFILE);	// Write-back cur game & ALL settings
	if (mode) DestroyWindow (hMainWnd);		// Post DESTROY msg..
}

  // Exit program - release resources and Post quit message.
void DestroyMainWindow ()
{
		// Select orig obj into main DC
	SelectObject (hWDC,hNullPen);
	SelectObject (hWDC,hSysFont);
	SelectObject (hWDC,hNullBrush);
	SelectObject (hWDC,GetStockObject (DEFAULT_PALETTE));
	TimerOff ();		// Kill 1 sec timer..
	FlushFileBuf (1);	// Close spool file, if any..
	ProcessFloatingWindows (0);	// Kill any open windows..
	ReleaseDIB ();		// Release all Bitmap related handles, mem, DCS..
	if (hDIBInfo) {
	  GlobalFree (hDIBInfo);
	}
	#if ECOSTR
	  if (hGlbECO) {		// If any ECO text mem, free it..
	    GlobalFree (hGlbECO);
	  }
	#endif
		// Del hot key bmp & DC
	SelectObject (hHotDC,hOldHotBmp);
	DeleteDC (hHotDC);
	DeleteMyObject (hHotBmp);		// Rel hot key bmp
		// Del tiny piece bmp & DC
	SelectObject (hTinyDC,hOldTinyBmp);
	DeleteDC (hTinyDC);
	DeleteMyObject (hTinyBmp);		// Rel tiny piece bmp
	if (eng.anyfont || hFont) {
	  DeleteMyObject (hFont);		// Delete any installable font 
	}
	if (hClkFont) {
	  DeleteMyObject (hClkFont);	// Delete Clock LED font 
	}
	
	DeleteMyObject (hLtgreyPen);
	DeleteMyObject (hDkgreyPen);
	DestroyCursor (hEmptyCursor);	// Release mem
	
	DeleteMyObject (hBackBrush);
	DeleteMyObject (hBoxBrush);
	DeleteMyObject (hUBoxBrush);
	DeleteMyObject (hClockBrush);
	ReleaseDC (hMainWnd,hMainDC);	// Device context for main window
        	// kill bitmap font resource
	if (RemoveFontResource (szBmpFont)) {
          SendMessage (HWND_BROADCAST, WM_FONTCHANGE, 0, 0L);
	}
	if (hHashMem) {		// Unlock & release any hash table mem..
	  GlobalUnlock (hHashMem);
	  GlobalFree (hHashMem);
	}
        autol_Quit ();		// Prog ends, save & free autolearn data..
	bfFileClose (-1);	// Close any buffered input files..
	temp = HashSize << 6;
	WrtProInt (PROF_HASH,&temp,1);	// Save hash size..
	EndEngine ();

	if (hMenu) {		// Kill menu
	  DestroyMenu (hMenu);
	}
	  ext_finish ();	// Release book-memory, etc..
	  comFinish ();		// Release any Global COMMENT memory..
	mlaInit (0);		// Release multi line anal mem..
	hashClrPreset ();	// Free any hash-book mem.
	PostQuitMessage (0);        // send WM_QUIT - EXIT PROGRAM.
}

	// MAIN WINDOWS PROCESS FUNCTION
	// This function is set by WinMain (at beginning)
	// and is called every time a program event occurs.

LRESULT CALLBACK WndProc(HWND hCWnd,  // our window's handle
                                 UINT wMsg,       // message number
			         WPARAM wParam,  // word parameter
				 LPARAM lParam)  // long parameter
{
    hInstance = (HANDLE) GetInstance(hCWnd);
    hMainWnd = hCWnd;
    
    if (wMsg == WM_TIMER) {	// Clock processing..
      if (DoingDialog + DoingPopDlg == 0) {
        ProcessTimer ();
      }
      return 0L;
    }
    SetMousePos (wMsg, lParam);    // Set up mousex/y vars, if mouse MSG
    
    switch (wMsg) {
      case WM_CREATE:	// Called when prog first run..
        MainInit ();
        return 0L;
    
      case WM_CLOSE:	// User closed window, Exit prog 
        EndProg (1);		// Save last game, Post DESTROY msg
	return 0L;

      case WM_QUERYENDSESSION:	// EXIT FROM WINDOWS..
        EndProg (0);		// Save last game.. 
	FlushFileBuf (1);	// Close spool file, if any..
	temp = HashSize << 6;
	WrtProInt (PROF_HASH,&temp,1);	// Save hash size..
	EndEngine ();
        goto ExitWndProc;	// Default processing
    
      case WM_DESTROY:		// User closed window, Exit prog 
        DestroyMainWindow ();
	return 0L;
    
	  // if system palette change caused by someone else, force repaint 
      case WM_PALETTECHANGED:
      case WM_QUERYNEWPALETTE:
       {
        short nchanged;
        HPALETTE hpalT;	// old pal handle
        if (wMsg == WM_PALETTECHANGED && (HWND) wParam == hMainWnd) return 0;
	  // If realizing the palette causes the palette to change,
	  // redraw completely.
        hpalT = SelectPalette (hWDC, hPalette, FALSE);
        nchanged = RealizePalette(hWDC); 	// # entries that changed 
        SelectPalette (hWDC, hpalT, TRUE);	// Orig back in..
	  // If any palette entries changed, repaint the window.
        if (nchanged > 0) RedrawAWindow (W_MAIN);
        return nchanged;
       }
    
    }   // End of Switch (wMsg)
    		// Ensure main window disabled during dialogs..
    if (DoingDialog || DoingPopDlg) {
	  switch (wMsg) {
	    case WM_SETFOCUS:		// Do not process these
	    case WM_NCHITTEST:
	    case WM_WINDOWPOSCHANGING:
	      return 0L;
	    case WM_ACTIVATE:		// Only if deactivate wMsg..
	      if (wParam == WA_INACTIVE) break;
	      return 0L;
	    case WM_ACTIVATEAPP:
	    case WM_NCACTIVATE:
	      if (wParam == 0) break;	//deactivated
	      return 0L;
	  }
    }
	
    
    if (MainMode != DoingGame) { 	// Non game mode (Setup,EditUsrBook)
      if (wMsg != WM_PAINT) {		// 
        goto ExitWndProc;	// Default processing for rest of cmds..
      }
    }	// End of other MAINMODE options..


		// Normal mode main-screen service routine..
    switch(wMsg) {
      
      case WM_PAINT:		// Main Screen redraw 
	hWDC = BeginPaint(hMainWnd, &ps);    // get device context
	if (MainTitle) {		// Redraw title screen..
	  RECT mrct;
	  SelectObject (hWDC,hNullPen);
	  GetClientRect (hCWnd, &mrct);
	  if (hPieceDC) {	// Show Intro screen bmp.. (if any)
	    Checker2D (mrct);
	    ShowBitmap (hPieceDC, (short) (mrct.right >> 1), 
	    	(short) (mrct.bottom - DBUy * 9 + 80) >> 1, maxsetx, maxsety, 3);
	  } else {
	      DrawChecker (mrct);
	      BigHeader (STprogramname2, (short) mrct.right >> 1,28,-160);
	  }
	} else {		// Normal redraw of main window..
	  RealizePalette (hWDC);		// Refresh palette.. 
	  SelectObject (hWDC,hNullPen);	// Draw background colour
	  SelectObject (hWDC,hBackBrush);
	  GetClientRect (hMainWnd, &rct);	// Get window size
	  mainbx = (short) rct.right;		// save Main window size..
	  mainby = (short) rct.bottom;
	  Rectangle (hWDC,0,0,mainbx + 1, mainby + 1);
	}
	EndPaint(hMainWnd, &ps);            // painting complete
	
	if (StartDlgUsed == 0) {	// TITLE SCREEN strt-up dialog..
	  int cret;
	  int protmode;
	  StartDlgUsed = 1;
	  #if PROT_ENABLED
	    DlgNAG (2);     // Shareware NAG screen..
	    if (VER_ == SHARE_) {
	      strcat (STprogramname,", UNREGISTERED SHAREWARE DEMO. ");
	    }
	    if (VER_ == STD_) {
	      strcat (STprogramname,", Standard Version. ");
	    }
	    if (VER_ == FULL_) {
	      strcat (STprogramname," Pro. ");
	    }
	    SetWindowText (hMainWnd,STprogramname);
	    //if (prodat.isOK == FALSE) exit (0);   // Prot fails, abort prog..
	  #endif
	  DlgButton = IDD_BUTTONS  + dbox_Start ();
	  
	  #if HackTest
	    DoMessage ("Remove protection disk!");
	  #endif
	  MainTitle = 0;		// Now show normal game-board..
	  #if UseIntroBMP
	    if (hPieceDC) {	// Intro screen bmp active - delete..
 	      ReleaseDIB ();	// Release all Bitmap related handles, mem, DCS..
	    }
	  #endif
	  if (DlgButton == IDD_BUTTONS + 2) {	// New game..
	    LoadLast (1);
	    NewGame (1);
	    eng.play_mode = PlayNormal;
	    eng2brd ();			// update screen board..
	    ProcessFloatingWindows (1);	// Open windows, if in Win mode
	  } else if (DlgButton == IDD_BUTTONS + 3) {	// Reset engine..
	    SetHash (2);		// Reset hash mem..
	    LoadLast (0);
	    eng.play_mode = PlayNormal;
	    MainMode = DoingGame;	// Normal play mode..
	    eng2brd ();		// update screen board..
	    timepermove = 10;
	    SetLevel ();		// Set the  engine level..
	    levSetString ();
	    ProcessFloatingWindows (3);	// Reset window boxes
	  } else {			// Continue..
	    LoadLast (1);
	    ProcessFloatingWindows (1);	// Open windows, if in Win mode
	  }
	  //ResetMenu ();		// Load MENU & Strings for current eng.language.
          if (VER_ == SHARE_) { // Fix levels to 2 seconds per move..
            leveltype=0;
            timepermove=2;	
            SetLevel ();
          }
	  *pQuickChkResult ^= Q_CHKOK;	//- Zero if succeded..
	  retv = ext_set_level ();	// Set up current level..
	  levGetMenu ();	// Try to calc (levIDMmenu) from engine
	  eng.histanal = 256;
	  mlaInit (eng.histanal);		// Init multi line anal mem..

	  RedrawAWindow (W_MAIN);
	  if (!FlagPopUp) {
	    popdlgwnd.tx -= (short) absmain.left;
	    popdlgwnd.ty -= (short) absmain.top;
	  }
	  InitThink (ThinkOpp);		// Start thinking..
	     // Call to do 2nd LoadProtect, passing rndblock info
	}
	
        return 0L;
      
      case WM_MOVE: 	// Main window moves, move child-pop-ups?
	GetWindowRect (hCWnd, &rct);	// get window size..
        xpos = (short) rct.left - mainwnd.tx;	// calc amount win is moved..
        ypos = (short) rct.top - mainwnd.ty;
        //msgprintf (NULL,1,1,"x,y:%d,%d",xpos,ypos);
        if (FlagPopUp && (xpos | ypos)) { // Main Window moves, move all pop-ups..
          short cwnd; HWND hWnd;
          for (cwnd = 1; cwnd < NAWND; cwnd ++) {
            hWnd = hAWnd [cwnd];
            if (hWnd) {		// Not null, must be active pop-up..
	      GetWindowRect (hWnd, &rct);	// get window size..
			// Add (xpos,ypos) to move this window..
	      MoveWindow (hWnd, rct.left + xpos, rct.top + ypos, 
		rct.right - rct.left, rct.bottom - rct.top, TRUE);
	    }
	  }
	}
		// Drop thro to save new size..
      case WM_SIZE: {
        RECT wrct;
	SaveWin (&mainwnd, hCWnd,0);	// Save window size..
		// Resize toolbar
	GetClientRect (hCWnd, &wrct);
        tool_Resize (&tb_Main,0,0,wrct.right);
        return 0L;

        break;
      }
        
      case WM_KEYDOWN:                 // Keyboard hit - Funct keys..
	KillPiece ();		// Kill any piece held..
	cmdkey = wParam;
	temp = GetKeyState (VK_CONTROL) & 0x8000;
	if (cmdkey >= VK_F1 && cmdkey <= VK_F12 	// CTRL-Fkey..
	 	&& temp) {
	  return 0L;					// Ignore..
	}
	if (cmdkey < 256 && mainkeys [cmdkey]) {// MENU hot-key..
	  docmdkey (mainkeys [cmdkey]);		
	}
	return 0L;
      	
      case WM_CHAR:                 // Keyboard hit - Normal Char
	KillPiece ();		// Kill any piece held..
	cmdkey = wParam;
	if (VER_ != SHARE_) {
	 if (FlagTimeAdjust) {           // Quick time adjust mode..
	  unsigned long far *adj_time;		// Ptr to wh/bl clock..
	  adj_time = &eng.white_time;
	  if (IsBlacksMove) adj_time = &eng.black_time;
	  if (cmdkey == '-') {		// Deduct a minute
	    if (adj_time [0] > 30) {
	      adj_time [0] -= 30;
	    } else {
	      adj_time [0] = 0;
	    }
	    PrintClock (1);
	    return 0L;
	  }
	  if (cmdkey == '+') {		// Add on a minute..
	    adj_time [0] += 30;
	    PrintClock (1);
	    return 0L;
	  }
	 } else {			// QUICK TIME/PER ADJUST..
	  if (cmdkey == '+' || cmdkey == '-') {	// Alt time-per-move..
	    SetSecsMove
	    leveltype = 0;
	    timepermove = max (1,timepermove + (cmdkey == '+' ? 1 : -1));
	    SetLevel ();		// Set the  engine level..
	    levSetString ();
	    RedrawAWindow (W_MOV);
	    return 0;
	  }
	 }
	}
	temp = GetKeyState (VK_CONTROL) & 0x8000;
			// See if char is for Keyboard move entry..
			// Keyboard move entry on?
	if (temp == 0 && UserMoveIn [0] == '>' && ThinkMode != ThinkComp) {
	  short cstrlen = strlen (UserMoveIn);
	  short chrisok = 0;
	  if (cmdkey == 8) {	// Delete
	    if (cstrlen > 1) {
	      UserMoveIn [cstrlen - 1] = 0;
	      ShowUserMove();
	    }
	    return 0L;
	  }
	  if (cstrlen < 5) {		// Add typed char to user move..
	    if ((cstrlen & 1) == 0 ) {
	      if (isdigit (cmdkey)) chrisok = 1;
	    } else {
	        if (isdigit (cmdkey)) chrisok = 1;
	    }
	  }
	  if (chrisok) {		// Accept & add typed char
	    UserMoveIn [cstrlen] = (char) cmdkey;
	    UserMoveIn [cstrlen+1] = 0;
	    ShowUserMove();
	    if (cstrlen == 4) {		// 4 typed, Do the move..
	        movefrom = ext_num2pos ((BYTE) str2val (UserMoveIn + 1,10,2));
	        moveto = ext_num2pos ((BYTE) str2val (UserMoveIn + 3,10,2));
	      UserMoveIn [1] = 0;
	      if (DoHumanMove (movefrom,moveto,1) == 0) {	// Legal move made..
		return 0L;		// finished.
	      }
	    }
	    return 0L;		// finished.
	  }
	}
	if (cmdkey < 256 && mainkeys [cmdkey + 300]) {		// MENU hot-key..
	  docmdkey (mainkeys [cmdkey + 300]);
	}
	if (cmdkey == '$') {	// Set rnd seed
	  char tt [100] = "";
	  dlg_TextIn ("Rand seed (0-32767):",tt,6,STok,NULL);
	  if (tt [0]) {
	    mySrand ((short) str2val (tt,10,5));
	  }
	  return 0;
	}
        if (cmdkey == '^') {    // Test eng cmd..
          char tt [100] = "";
	  char *szReply;
          dlg_TextIn ("Enter cmd for eng 1..",tt,6,STok,NULL);
          szReply = dll_engcmd (tt, 1);
	  if (szReply) {
	    msg_Printf (NULL,0,0,STprogramname,"Cmd: \x22%s\x22 Eng 1 Reply: \x22%s\x22",tt,szReply);
	  } else {
	    msg_Printf (NULL,0,0,STprogramname,"No reply!");
	  }
	  
	}
        if (cmdkey == '%') {    // Dump weight tables..
          char tt [100] = "";
          dlg_TextIn ("View table (1-6 +16 for hex)",tt,6,STok,NULL);
	  if (tt[0] == '*') {
	    int z;
	    for (z = 1; z < 7; z ++) {
              DumpWeights ((short) z);
	    }
	  } else if (tt [0]) {
            DumpWeights ((short) str2val (tt,10,5));
          }
          return 0;
        }
	if (cmdkey == '(') {  // Colossus - load next game..
	  int cl;
	  static int doing;
	  if (doing == 1234) return 0;
	  doing = 1234;
	  while (1) {
	    cl = strlen (szLastLoad);
	    if (LoadGame (szLastLoad)) {
	      msg_Printf (NULL,0,0,"Colossus Load","%s loaded ok",szLastLoad);
	    } else {
	      msg_Printf (NULL,0,0,"Colossus Load","%s load fail",szLastLoad);
	      break;
	    }
	    if (pdnExport ("xgames.pdn") == 0) break;
	    RedrawAllWindows ();	// Force repaint..
	    if (isdigit(szLastLoad[cl-1])) {
	      szLastLoad[cl-1] ++; // Next game (ie G1->G2, G11->G12 etc..
	      if (szLastLoad[cl-1] > '9') {
	        if (isdigit(szLastLoad[cl-2])) {   // Wrap G19->G20 etc..
 	          szLastLoad[cl-2] ++; szLastLoad[cl-1] = '0';
	        }
	        if (szLastLoad[cl-2]=='G') {   // Wrap G9->G10 
                  szLastLoad[cl-1] = '1';
                  szLastLoad[cl] = '0';
                  szLastLoad[cl+1] = 0;
	        }
	      }
	    }
	  }
	  doing  = 0;
	  return 0;
	}
        
	#if Debug		// Misc debug & test bits..
	  DebugBits (cmdkey);
	#endif
	return 0L;	// END OF KEY-HIT processor
	
	
      case WM_LBUTTONDOWN:          //// Left mouse button hit, PICKUP..
      case WM_LBUTTONDBLCLK:
      case WM_RBUTTONDOWN:          //// Right mouse button hit, PICKUP..
      case WM_RBUTTONDBLCLK:
		// If hot key bmp hit, process..      
	return 0L;
                                   
      case WM_LBUTTONUP:	// Left mouse button release, DROP..
      case WM_RBUTTONUP:	// Right button release
		// If hot key bmp release, process..      
	ProcessHotKey (HotLastInfo,0);
        return 0L;
                                   
      case WM_MOUSEMOVE:          //// Mouse moved - redraw any piece held.
		// If hot key bmp held, process..      
	ProcessHotKey (HotLastInfo,2);
		// If not moving in main window, kill it
	if (hBrdWnd) {
	  KillPiece ();
	} else {
		// If piece held, move/process..
	  MoveAPiece (wParam);
	}
        return 0L;
        
      case WM_NCMOUSEMOVE:	// Move in menu/title area..
        mousex = mousey = -1;
	ProcessHotKey (HotLastInfo,2);
        return 0L;
        

      case WM_MENUSELECT:
			// Menu being closed..      
	if ( LOWORD (lParam) == -1 && HIWORD (lParam) == 0) {
	  // same as if (fwMenu == -1 && hmenu == 0).. see help on WM_MENUSELECT
	  if (menuclock & 1) {		
	    eng.clock_flag = menuclock & 0xfe;	// Restore old value..
	    menuclock = 0x80;
	  }
	} else {	// Menu being opened
	  if ((menuclock & 1) == 0) {	// Not already opened..
	    menuclock = eng.clock_flag | 1;	// Save clock status for later
	    ClockOff			// stop clock while menu being used.
	  }
	}
        KillPiece ();		// Kill piece being held, back to normal.
        MenuFlags ();
	return 0L;
                
      case WM_SYSKEYDOWN:	// System key..
        if (wParam == VK_F4) {  // ALT-F4..
          EndProg (1);		// Save last game, Post DESTROY msg
          return 0l;
        }
        goto ExitWndProc;
        
	
      case TOOL_NEEDTEXT:	// Tool bar tip-text request.. For (IDM_/STR_ get text..)
        if (wParam == TOOL_NEEDTEXT) {  
	  TOOL_TIPTEXT *pTip = (TOOL_TIPTEXT *) lParam;
          char *szTxt = IDM2String (pTip->idCommand);
          strcpy (pTip->szText,szTxt);
	}

        return 0L;

				////  MENU option selected..         
      case WM_COMMAND:
	if (wParam == IDM_QUIT) {
          EndProg (1);		// Save last game, Post DESTROY msg
	  return 0L;
	}
        KillPiece ();		// Kill piece being held, back to normal.
	if (wParam >= R_LEVBEG && wParam <= R_LEVEND) {
	  if (VER_ == SHARE_) {
	    DlgFeatureNotImplemented (); return 0;
	  }
	  levSetMenu (wParam);	// Set a Play level..
	  return 0L;
 	}
	switch (wParam) {
					// COMMAND..
	  case IDM_HELP:{	// Call help function
	    char szHelpFile [] = "doc\\sagedoc1.htm\0\0\0";
            szHelpFile [11] = 49 + eng.language;
            if (FileExists (szHelpFile) == FALSE) {	// cannot load file.. try english
              szHelpFile [11] = 49;
            }
            if (FileExists (szHelpFile)) {		// If file is there..
	      ShellExecute (NULL,"open",szHelpFile,NULL,NULL,SW_SHOWDEFAULT);
	    }
	    break;
	   }
	    
	  case IDM_COMPUTE:	// Force comp to take move
	    eng.play_mode = PlayNormal;
	    eng_touse = 1;
	    InitThink (ThinkComp);
	    MoveBox (0);		// Update Player/Genius disp
	    SearchBox ();
	    return 0l;
	    
	  case IDM_MOVE:	// Force comp to move if thinking..
	    ForceMove = 1;
	    StopAutoPlay ();
	    return 0L;
	  
	  case IDM_SETUP:	// Edit board
	    ResetSetup ();
	    DlgNAG (5);     // Shareware NAG screen..
	    return 0L;
	    
	  case IDM_HINT:	// Show hint move..
	    ShowHint ();
	    DlgNAG (0);     // Shareware NAG screen..
	    break;
	  
	  case IDM_GAME2CLIP:	// Save game to clipboard..
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    SaveGame (IDM_SAVEGAMEO,CLIPGAME);
	    break;
	  
	  case IDM_CLIP2GAME:	// Get from clipboard
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    LoadGame (CLIPGAME);
	    InitThink (ThinkOpp);	// Start think in opp time..
	    RedrawAllWindows ();	// Force repaint..
	    break;
	  
	  case IDM_UBOOKEDIT:	// Edit User Book..
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    ResetEditBook ();	// Start this mode..
	    return 0L;
	    
	  case IDM_UBOOKADD:	// Add current game line to user book
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    DlgAddBook ();
	    break;
	  
	  case IDM_NEXTBEST:	// Calc next best, if possible
	    NextBest ();	
	    break;
	    
	  case IDM_TAKEBACK:	// Back 1 mv
	    StepMove (-1);
	    break;
	    
	  case IDM_TAKEBACKALL:	// Undo all
	    StepMove (StepBackAll);
	    break;
	    
	  case IDM_TAKEBACK10:	// Undo 10
	    StepMove (-10);
	    break;
	    
	  case IDM_STEPFWD:	// Fwd 1 mv
	    StepMove (1);
	    break;
	    
	  case IDM_STEPFWDALL:	// to End
	    StepMove (StepFwdAll);
	    break;
	    
	  case IDM_STEPFWD10:	// Fwd 10 moves
	    StepMove (10);
	    break;
	  
	  case IDM_GOTO:	// exec GOTO MOVE dialog..
	    DlgGoto ();		// GOTO move dialog
	    break;
	  
	  case IDM_ABOUT:
	    DlgAbout ();
	    break;
	  
	  case IDM_NEWGAME:	// New game..
	    if (DlgNewGame ()) {	// Yes, start new game..
	      open_Init ();	// re-load opening classifications..
	      NewGame (1);
	      StopAutoPlay ();	// Make (eng.play_mode) either norm or 2play.
	      RedrawAllWindows ();
	      DlgNAG (5);     // Shareware NAG screen..
	    }
	    return 0L;
	
	  case IDM_NEW3SEL:	// Select opening
	    dbDlgListGames (open_szOpen);
	    return 0L;

	  case IDM_NEW3RND:	// Random Ballot
	    open_Random ();
            StepMove (StepFwdAll);
	    RedrawAllWindows ();
	    return 0;

	  case IDM_NORMAL:		// Normal hum/comp mode
	    StopThinking ();		// Stop old think
	    eng.play_mode = PlayNormal;	// Normal mode
	    InitThink (ThinkOpp);	// Restart opp-think in this mode
	    break;
	    
	  case IDM_2PLAYER:	// 2 player/analyse mode
	    StopThinking ();
	    eng.play_mode = PlayTwo;	// 2 player anal mode
	    InitThink (ThinkOpp);	// Restart opp-think in this mode
	    break;
	    
	  case IDM_COMPVCOMP:		// Init autoplay.
	    eng.play_mode = PlayAuto;
	    InitThink (ThinkComp);
	    MoveBox (0);
	    SearchBox ();
	    return 0l;
	    
	  case IDM_COMPVCOMPCONT:	// Autoplay, with start new games..
	   #if AUTOTEST
	    auto_Start ();
	   #endif
	    return 0L;
	 
	  case IDM_OTHEROPTIONS:
	    DlgEngOptions ();	// Set Play styles, piece %, clocks..
	    break;
	    
	  case IDM_ANALYSE:		// Auto analyse
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    if (DlgAnalyse ()) {	// Anal selected, do it..
	      if (FileMode != 2) {	// not in RECORD MOVE & ANAL mode
	        if (SetExportMode (IDM_RECORDGAMANAL) == 0) {	// Open up record anal mode
		  return 0L;		// Failed/cancel hit..
	        }
	      }
	      ext_set_level ();		// Refresh level - resets clock
	      NextAnal (0);		// Find & Start first anal
	      MoveBox (0);		// Redraw boxes..
	      SearchBox ();
	      return 0l;
	    }
	    break;
	    
	  case IDM_PROCESSEPD:		// Analyse positions in an EPD file
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
		// If an EPD file selected, do it..	  
	    if (OpenDialog (szEPDfile, STepdfilter, IDM_PROCESSEPD)) {
	      //ext_set_level ();		// Refresh level - resets clock
	      CurEPD = 0;
	      eng.play_mode = PlayEPD;
	      NextEPD (1);		// Find & Start first anal
	      MoveBox (0);
	      SearchBox ();
	      return 0l;
	    }
	    break;
	    
	
	  case IDM_WINDOWS:	// Toggle child/popup window mode..
	    DlgWindows ();
	    return 0L;
	    
	  case IDM_DEFAULTLAYOUT:	// Re-align windows to normal..
	    ProcessFloatingWindows (0);
	    SetDefault (1);		// Set board size to default..
	    ImpNewSet (0);
	    if (FlagBoard == 0) TogBoard;
	    if (FlagMoveBox == 0) TogMoveBox;
	    if (FlagMainAnal == 0) TogMainAnal;
	    ProcessFloatingWindows (7);
	    return 0L;
	    
	  case IDM_REARRANGELAYOUT:	// Re-align windows to normal..
	    ProcessFloatingWindows (7);
	    return 0L;
	    
	  case IDM_INVERT:	// Invert board
	    TogInvert 
	    DrawBoard ();
	    break;
	    
	  case IDM_BOARD:	// Tog board disp..
	    TogBoard
	    ProcessFloatingWindows (1);
	    break;
	    
	  case IDM_MOVEBOX:	// Disp move box
	    TogMoveBox
	    ProcessFloatingWindows (1);
	    RedrawAllWindows ();		// InvalRect all windows..
	    return 0L;	// DO NOT ALLOW MoveBox() refresh with break, until 1st paint
	    
	  case IDM_SEARCH:	// Disp main search
	    TogMainAnal
	    ProcessFloatingWindows (1);
	    SearchBox ();
	    DrawBoard ();
	    break;
	 
	  case IDM_CLOCK:	// Disp clock
	    TogClock
	    ProcessFloatingWindows (1);
	    break;
	    
	  case IDM_SHOWBOOK:	// Disp book moves..
	    TogBookMoves
	    ProcessFloatingWindows (1);
	    SearchBox ();
	    DrawBoard ();
	    break;
	 
	  case IDM_TOOLBAR:	// Disp Tool bar display
	    TogTool
	    ProcessFloatingWindows (0);		// Close all windows
	    RedrawAWindow (W_MAIN);	// Force repaint..
	    ProcessFloatingWindows (3);	// RePos windows
	    //RedrawAWindow (W_CLK);
	    break;
	    
	  case IDM_DISPLAYOPT:	// Change piece set
	    DlgDisplay ();	// Dialog - select a piece set..
	    SetPiecePtrs ();		// Set STpieces to new ptr..
	    levSetString ();
	    ProcessFloatingWindows (0);		// Close all windows
	    ProcessFloatingWindows (1);	// ReOpen windows (new lang)
	    break;
	    
	  case IDM_FONTS:	// Change default font..
	    HaltClock
	    DlgFonts ();	// Dialog - select a font..
	    RestoreClock
	    break;
	    
	  case IDM_ENGLISH:	// eng.language..
	  case IDM_LANG2:
	  case IDM_LANG3:
	  case IDM_LANG4:
	  case IDM_LANG5:
	  case IDM_LANG6:
	  case IDM_LANG7:
	  case IDM_LANG8:
	  case IDM_LANG9:
	    eng.language = wParam - IDM_ENGLISH;;
	    ResetMenu ();
	    levSetString ();
	    ProcessFloatingWindows (0);		// Close all windows
	    ProcessFloatingWindows (1);	// ReOpen windows (new lang)
	    qDrawBoard ();
	    break;
	    
	  case IDM_SAVEALL:    // Save Game with ALL settings
	  case IDM_SAVEGAMES:    // Save Game with  settings
	  case IDM_SAVEGAMEO:    // Game only
	    HaltClock
	    SaveGame (wParam,"");
	    RestoreClock
	    DlgNAG (5);     // Shareware NAG screen..
	    break;
	    
	  case IDM_LOADGAME:	// Load a game..
	    ClockOff
	    if (LoadGame ("")) {
	      if (gamestart == &eng.current_game_start) {	// has loaded full game
		ProcessFloatingWindows (0);	// Close old windows..
			// Try to load genius font..
		if (eng.anyfont) {	// Font spec in $last.gam (eng.mainlogf)..
		  ResetFonts (1); // Load & select font in (mainlogf)
		} else {
		  ResetFonts (3); // Load & select default font (genius12b)
		}	
		charx = eng.charx; chary = eng.chary;
		//ReadAllPresets ();	// update presets (if selected)
		ImpNewSet (1);	// and load this set..
		ProcessFloatingWindows (1);	// ReOpen windows (new lang)
	      } else {
	        RedrawAllWindows ();	// Force repaint..
	      }
	      InitThink (ThinkOpp);	// Start think in opp time..
	    }
	    DrawBoard ();
	    DlgNAG (3);     // Shareware NAG screen..
	    break;
	    
	  case IDM_EXPORTMSF:	// Print moves so far..
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    if (FileMode) {	// Spool already open, use it..
	      PrintMovesSoFar ();
	    } else {
	      if (DlgOutputGame (IDM_EXPORTMSF)) {// Open spool file, ok..
	        FileMode = 1;
		PrintMovesSoFar ();
		FlushFileBuf (1);	// Flush old, close..
		FileMode = 0;		
	      }
	    }
	    break;
	    
	  case IDM_EXPORTPOS:	// Print board position
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    if (FileMode) {	// Spool already open, just use it..
	      PrintPos ();
	    } else {		// open, use it, close.
	      if (DlgOutputGame (IDM_EXPORTPOS)) { // Open spool file, ok..
	        FileMode = 1;
		PrintPos ();
		FlushFileBuf (1);		// Flush old, close..
		FileMode = 0;		
	      }
	    }
	    break;
	    
	  case IDM_SETEXPORTOPT:	// Enable/Disable output redirection
	  case IDM_RECORDGAME:		// Print moves as played..
	  case IDM_RECORDGAMANAL:		// Print anal as played
	     if (VER_ != FULL_) {
	       DlgFeatureNotImplemented (); break;
	     }
	     SetExportMode (wParam);
	     break;
	  
	 
	  case IDM_EXPORTUBOOK:	// Print user book to file..
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    DlgPrintBook ();
	    break;
	  
	  case IDM_SAVEUBOOK:	// Save user book file 
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    if (SaveDialog (szPath, STbokfilter, IDM_SAVEUBOOK,1)) {
	        if (CopyAFile (bokName,szPath) == 0) {
	          DoMessage (STEbooknotsaved);
	        }
	    }
	    break;
	  
	  case IDM_LOADUBOOK:	// Load User book file
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    if (OpenDialog (szPath, STbokfilter, IDM_LOADUBOOK)) {
	      StopThinking ();
	        if (CopyAFile (szPath,bokName) == 0) {
	          DoMessage (STEbooknotloaded);
	        }
		eng.param_ax_pass = 17;		// Force Book reload..
		retv = ext_userbook ();
		// Force moves to come up..
	      TogUserBook
	      InitThink (ThinkOpp);
	      StopThinking ();
	      TogUserBook
	      InitThink (ThinkOpp);
	      RedrawAWindow (W_BOK);		// Redraw new book moves
	    }
	    break;
	  
	  case IDM_IMPORTEPD:	// Import a pos from an EPD file
	  case IDM_IMPORTNEXTEPD:
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    ImportEPD (wParam);
	    break;
	    
	  case IDM_EXPORTEPD:	// Export a pos from brd to an EPD file
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    ExportEPD ();
	    break;
	    
	  case IDM_EDITGAMEDET:	// Edit game header details..
	    DlgEditGameDetails (0);
	    DlgNAG (20);     // Shareware NAG screen..
	    break;
	    
	  case IDM_ADDCOMMENT:	// Add individual move comment..
	    DlgAddComment ();
	    DlgNAG (20);     // Shareware NAG screen..
	    break;
	  
	  case IDM_PDNDISPLAY:	// Toggle PDN display format
	    Tog_(PgnMoves);
	    MoveBox (0);
	    break;
	    
	  case IDM_PDNNUMBERING:	// Toggle PDN move numbering
	    movenumbering = !movenumbering;
	    RedrawAllWindows ();
	    break;
	    
	  case IDM_PDNIMPORT:	// List/Load from PDN file
	    DlgNAG (10);     // Shareware NAG screen..
	    dbDlgListGames (NULL);
	    break;
	    
	  case IDM_DB_SEARCH:	// List/Load from PDN file
	    if (db_DlgSearch () == FALSE) break;
	    dbDlgListGames (NULL);
	    break;

	  case IDM_SELECTDATABASE:  	// Change default database
	    DlgNAG (10);     // Shareware NAG screen..
	    dbDlgSelect (0);
	    dbDlgListGames (NULL);
	    break;
    
	  case IDM_PDNIMPORTNEXT:// Import next game from PDN file
	  case IDM_PDNIMPORTAGAIN:// Reload game from PDN file
	    pdnDlgImport ((BYTE) ((short) wParam == IDM_PDNIMPORTNEXT) ? 2 : 1);
	    eng2brd ();	// Update displayed board..
	    Dink ();	
	    InitThink (ThinkOpp);	// Force moves to come up..
	    RedrawAWindow (W_BRD);		// Redraw new board pos
	    RedrawAWindow (W_MOV);		// Redraw new move rec
	    DlgNAG (10);     // Shareware NAG screen..
	    break;
	    
	  case IDM_PDNTRANSFER:// Transfer/select/soft database..
	    DlgNAG (10);     // Shareware NAG screen..
	    pdnTransfer ();
	    break;

	  case IDM_EDITDB:
            dbEdit ();
	    break;

	  case IDM_PDNEXPORT:	// Export PDN file
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    pdnExport (NULL);
	    break;
	    
	  case IDM_BOARDINC:		// Increase/decrease board size..
	  case IDM_BOARDDEC:
	  case IDM_BOARDINC3:		// Increase/decrease board size..
	  case IDM_BOARDDEC3:
	    if (hBrdWnd) { 
	      RECT crct; short lenx;
	      char addb[] = {1,-1,5,-5};
	      GetWindowRect (hBrdWnd,&crct);
	      lenx = crct.right - crct.left + 1
	        + addb [wParam - IDM_BOARDINC] * eng.boardx;
	      SetWindowPos (hBrdWnd, (HWND) NULL, 0,0, 
		lenx,crct.bottom - crct.top,SWP_NOZORDER | SWP_NOMOVE);
	    }
	    break;

	  case IDM_FIGURINES:
	    TogFigurine;
	    RedrawAWindow (W_SCH);		// Redraw new anal line
	    RedrawAWindow (W_MOV);
	    break;
	    
	  case IDM_MAINBOOK:
	    TogMainBook
	    RedrawAWindow (W_SCH);		// Redraw new anal line
	    break;
	
	  case IDM_SOUND:		// Toggle sound flag..
	    TogSound
	    Dink ();
	    break;
	    
	  case IDM_SLIDE:		// Toggle sound flag..
	    TogSlide
	    break;
	    
	  case IDM_FULLANAL:		// Toggle full-anal display..
	    TogFullAnal
	    RedrawAWindow (W_SCH);		// Redraw new anal line
	    break;
	    
	  case IDM_ANALY2COMMENT:	// Toggle Analy->comment mode
	    if (VER_ != FULL_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    analy2ComFlag = !analy2ComFlag;
	    Dink ();
	    break;
	    
	  case IDM_NUMBERING:		// Toggle board numbering..
	    TogNumbering
	    RedrawAWindow (W_BRD);
	    break;
	  
	  case IDM_2NDANAL:		// 2nd anal line display..
	    TogExtraAnal;
	    break;
	    
	  case IDM_IMPORTBOOK:
	    DlgImportBook ();
	    break;

	  case IDM_SETCLOCKS:
	    DlgSetClocks ();
	    break;
	  
	  case IDM_CLIPLOAD:
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    clip_Load ();
	    eng2brd ();	// Update displayed board..
	    InitThink (ThinkOpp);	// Force moves to come up..
	    RedrawAllWindows ();		// InvalRect all windows..
	    break;

	  case IDM_CLIPSAVE:
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    clip_Save ();
	    break;

	  case IDM_GAMESPAWN:	// ,"Spawn &Game.."
	    if (VER_ == SHARE_) {
	      DlgFeatureNotImplemented (); break;
	    }
	    gam_Spawn ();
	    return 0;

	
	}
	MoveBox (0);
	SearchBox ();
       break;
       	  
      default:                      // handled by DefWindowProc
        goto ExitWndProc;
    }   // end switch(wMsg)
    return 0L;                      // return if we handled wMsg
    
ExitWndProc:
    return( DefWindowProc (hMainWnd, wMsg, wParam, lParam) );

}  		// end WndProc
