//  SAGWIO.H - Generic Windows C routines. Copyright A.Millett 1996-2025

	// Convert WRECT to RECT structure
#define WRECT2RECT(wr,r) {(r)->left = (wr)->tx; (r)->top = (wr)->ty;\
   (r)->right = (wr)->tx+(wr)->lx; (r)->bottom = (wr)->ty+(wr)->ly;}

#ifndef _WIN32
  #define GetTextExtentPoint32 GetTextExtentPoint
#endif
  
  // For a palette colour selected through RGB..
#define COLORREF_PAL(x) ((COLORREF) ((x) & 0x00ffffffL) | 0x02000000L)

  // Set a mouse-cursor - Can be IDC_ARROW, IDC_WAIT, etc..
#define CURSOR_SET(cur) SetCursor (LoadCursor (NULL, (cur)));

//---------------------------------------------------------------
// MODULE:msg_  msg box/printing functions..
//---------------------------------------------------------------


#define msg_ABORT (short) 0x8000		// MsgPrintf options..
#define msg_OPTIONS 0x4000

short msg_Printf (HDC, short, short, char *, char *,...);
void msg_Box (char *, char *);

//---------------------------------------------------------------
// MODULE:font_  misc font functions..
//---------------------------------------------------------------

void font_CalcSize (HFONT, short *, short *);
void font_CalcExtent (HFONT, char *, MYPOINT *);
void font_CalcSizeFromName  (char *, short, short *, short *);
#define FONT_BOLD   1
#define FONT_ITALIC 2
HFONT font_ForSize (char *, ULONG, MYPOINT, MYPOINT *);

//---------------------------------------------------------------
// MODULE:wio_ Misc windows i/o support funtions..
//---------------------------------------------------------------

void wio_SplitFileAndPath (char *, char *);
BOOL wio_PaletteServe (LRESULT *, HWND, UINT, WPARAM, HPALETTE);
int wio_DesktopInfo (int);
void wio_Window2Parent (HWND hWnd, POINT *pPt);
POINT wio_GetWindowSize (HWND hWnd);
POINT wio_GetWindowPos (HWND hWnd);
void wio_SetSafeRect (HWND hWnd, RECT *pR);

 #define wio_VDU_COLORS (wio_DesktopInfo (BITSPIXEL) + wio_DesktopInfo (PLANES) - 1)

 #define WIO_NO_COLOR ((COLORREF) -1L)
 #define WIO_PRINTALL 1
 #define WIO_NOSHADOW 2
void wio_TextOutRefresh (HDC,short,short,char *,char *,short,short,short,COLORREF);
ULONG wio_MaxRam ();

//---------------------------------------------------------------
// MODULE:snd_ Sound play functions..
//---------------------------------------------------------------

void snd_Init (char *szSndFiles);
void snd_Play (short sound);

//---------------------------------------------------------------
// MODULE:ctl_  For adding std controls on a non-dlg window..
//---------------------------------------------------------------

#define CTL_IDD 0x1000L	    // Internal Ctl ids start here..
#define CTL_IDD_AUTO (CTL_IDD+0x1000)
#define CTL_AUTOCALC (0x4000L)

#define CTL_TyTEXT     1
#define CTL_TyBUTTON   2
#define CTL_TyCHECKBOX 3
#define CTL_TyRADIOBOX 4
#define CTL_TyEDIT     5

#define CTL_TyGROUPBOX 0x100
#define CTL_TyCENTER   0x200

typedef struct {
  HWND hWnd;
  long id;      // Sub-item id..
} CTL_SUBITEM;

typedef struct {
  char *str;		// string of button txts, null term.
  long type;		// Type of control..
  long val;		// Initial and Resultant value..
  MYPOINT top; 		// top left to start buttons
  MYPOINT len;		// x/y size in pixels. ==0 for autocalc..
  MYPOINT add;		// Spc between if series of ctls..
  short num;		// No of ctls if multi..
  long id;		// Ctrl id # start..
  short nwnd;
  MYPOINT bot;         // Computed bottom..
  CTL_SUBITEM *pSubItem;        // Ptr to list of individual windows to do with ctl..
} CTL_ITEM;

typedef struct {	// Data Struct for Button routine..
  WORD status;		// 
  HWND hOwner;		// Window with buttons. NULL=just repos..
  CTL_ITEM *pItem;	// Malloced mem for items..
  int nitems;
} CTL_INFO;

  // Macros for setting/extracting check-flag bits..
#define ctl_AddFlag(pI,flag,bit) \
  {(pI)->val <<=1; if((flag)&(bit)) (pI)->val|=1;}
#define ctl_GetFlag(val,flag,bit) \
  {(flag)=(val&1) ? (flag)|(bit) : (flag)&~(bit); \
  val >>=1;}

void ctl_Init (CTL_INFO *,HWND);
void ctl_Close (CTL_INFO *);
void ctl_Reset ();
int ctl_AddItem (CTL_INFO *, CTL_ITEM *);
void ctl_ChangeText (CTL_INFO *pCtl, long cID,char *pTxt);
BOOL ctl_Service (CTL_INFO *pCtl,HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam);
long ctl_GetVal (CTL_INFO *, long);
BOOL ctl_GetStr (CTL_INFO *pCtl, long cID, char *pTxt, long size);

//---------------------------------------------------------------
// MODULE:con_ Generic Console style I/O routines..
//---------------------------------------------------------------
		// Some local variables..
#define WM_CON_INPUT (WM_USER + 4242)	// Unique message id for input response..

short con_open (HWND, char *);
void con_close ();
char con_getch ();
short con_printf (char *, ...);

//---------------------------------------------------------------
// MODULE: menu_ MENU handle & strings allocation routines..
//---------------------------------------------------------------

typedef struct {
  HMENU hMenu;          // Menu handle
  WORD *pIdm;           // array IDM codes..
  long *pGreyBits;      // Array Menu Graying bits.. (bit 0 set if hide, not grey..)
  int nmenu;            // # entries in above arrays
  int nMI;		// #menus defined.. array of MENU_INFO structs supplied if >1
} MENU_INFO;

int menu_Init (MENU_INFO *, char *);
void menu_Close (MENU_INFO *);
void menu_Set1Tick (MENU_INFO *, short, short);
char * menu_GetString (MENU_INFO *, int);
void menu_Greying (MENU_INFO *, long);
long menu_GetGreyBits (MENU_INFO *, long);
#define MENU_NOT_FOUND -1
//---------------------------------------------------------------
// MODULE: lang_ LANGUAGE strings allocation routines..
//---------------------------------------------------------------

extern char lang_szError [128];
int lang_Init (char *szParFile, char **szLang, int nLang);

//---------------------------------------------------------------
// MODULE:tool_ Toolbar support defines
//---------------------------------------------------------------

  // Toolbutton status..
#define TOOL_IS_NORMAL         0
#define TOOL_IS_CHECKED        1
#define TOOL_IS_PRESSED        2
#define TOOL_IS_DISABLED       3
#define TOOL_IS_HIDDEN         4

  // Toolbutton styles..
#define TOOL_STY_BUTTON        0
#define TOOL_STY_SEP           1
#define TOOL_STY_CHECK         2
#define TOOL_STY_WRAP          4
#define TOOL_STY_END           8

#define TOOL_STYLE_SEP {0,0,0,TOOL_STY_SEP}
#define TOOL_STYLE_WRAP {0,0,0,TOOL_STY_WRAP}
#define TOOL_STYLE_END {0,0,0,TOOL_STY_END}

  // Toolbar mode-types..  
#define TOOL_TYPE_FLOAT        1	// Toolbar is floating win, not fixed
#define TOOL_TYPE_CHILD        2	// Toolbar is child, not popup/overlapped
#define TOOL_TYPE_RESIZE       4	// Toolbar resizes right border to parent width..
#define TOOL_TYPE_REPEAT       8	// Toolbar buttons repeat..
#define TOOL_TYPE_RMOUSE      16	// Enable Right-mouse buttons..

// TTN_NEEDTEXT equivalent message id.. (posted to parent to get msg..)
#define TOOL_NEEDTEXT (WM_USER + 1827)

#define TOOLSERV_WM_COMMAND 1
#define TOOLSERV_NEEDTEXT 2
#define TOOLSERV_CLOSING 3	// Sent when toolbar win closes

typedef struct {
  int idCommand;	// Command..
  BYTE nrep;		// #nth repeat?
  BYTE rmouse;		// Right mouse button hit..
} TOOL_BUTTONHIT;

typedef struct {  // Individual tool-bar buttons...(similar TBBUTTON)
  int idCommand;  // Command identifier associated with the button. 
		  // This identifier is used in a WM_COMMAND msg
		  // when the button is chosen. If fsStyle == TBSTYLE_SEP 
		  // value, this member must be zero.
  WORD iIndex;	  // Zero-based index of button image/text.. (indexed into  TOOL_ITEMS)
  BYTE fsState;	  // Button state flags. This member can be a combination 
		  // of the values listed in Toolbar Button States. 
  BYTE fsStyle;	  // Button style. This member can be a combination 
		  // of values listed in Toolbar Button Styles 
} TOOL_BUTTON;

typedef struct {  // Descriptor of a bmp/txt available on a Toolbar
  int topx,topy;	// Top x/y pos of button picture in bmp file..
  char *pStr;		// If not null, ptr to string for text-button..
} TOOL_ITEMS;
  
  // Marcos fetch palette/bmpdc for toolbar (uses default if none available)
#define TOOL_HPAL(pTool) ((pTool)->hPal ? (pTool)->hPal : tool_dat.hPal)
#define TOOL_HBMPDC(pTool) ((pTool)->hBmpDC ? (pTool)->hBmpDC : tool_dat.hBmpDC)

typedef long (*TOOLSERV_PROC) (int, void *);  // For front end service function..

typedef struct {	// Data for a tool-bar..
  MYPOINT but;		// Size of each button..
  MYPOINT bmp;		// Size of each bitmap..
  int nTbut;		// No of tool-bar buttons to add..
  TOOL_BUTTON *pTbut;	// Array of toolbar buttons.
  int nItems;		// Absolute max items available
  TOOL_ITEMS *pItems;	// Ptr to descriptor for all possible button item (NULL=Simple default bmp index)
  MYPOINT autopos;	// Start of bmp images in tool-bmp, if pItems is NULL
  MYPOINT ttop;		// Top X/y position 
  MYPOINT tlen;		// Size of toolbar (0,0 = default) (EXCLUDES any win borders)
  MYPOINT calclen;	// Computed size of toolbar buttons..
  short sepsize;	// size of TOOL_STY_SEP item (0 for 1/3 normal button size)
  short tborder;	// Size of border, in pixels..
  short tooltype;	// TOOL_TYPE_FLOAT:  bit 0 clr = borderless child win, docked top.
  			//  set=floating window. (Will autosize if docked top)
  			// bit 1 set if floating window is a CHILD (clr=OVERLAPPED)
  			// bit 2 set = resize len to parent.
  			// bit 3 set for auto-repeat..
  char *szTitle;	// Title-bar message (None=normal captionless)
  HWND hParent;		// Window handle of parent
  HWND hWndMsg;		// Window to recieve WM_COMMAND and TOOL_NEEDTEXT messages.. (NULL for hParent default)
  HWND hWnd;		// Window handle of toolbar.
  //HBITMAP *hBmp;	// Bitmap to get toolbar images..
  HDC *hBmpDC;		// Or "compatible" DC with 256 col bmp in it..(NULL=use global default)
  HPALETTE *hPal;	// Palette for toolbar-redraw..(NULL=use global default)
  TOOLSERV_PROC pfnServiceTool;	// Ptr to front-end misc service routine..
} TOOL_BAR;

#define TOOL_BAR_MAX 40		// Max # toolbars

typedef struct {
  char szText [80];	// Buffer to recieve tool-tip text..
			// Other members not normally used by client..
  HWND hWnd;		// Current Tool-tips drawing window handle (NULL=none)
  int idCommand;	// Current command id..
  TOOL_BAR *pBar;	// Cur tool-tip toolbar..
  int iBut;		// Cur tool-tip button..
  MYPOINT itop;		// Top pos of window..
  MYPOINT ilen;		// Size of window
  HDC hMemDC;		// Compatible mem DC for screen capture
  HBITMAP hBitmap;	// Bmp to keep graphics under tip..
} TOOL_TIPTEXT;

typedef struct {	// Just one of these local-data holders..
  char *szClass;	// Toolbar Window class name
  HFONT hFont;		// Default font for texts & tooltips
  int nTbars;		// no of toolbars
  TOOL_BAR *pTbars [TOOL_BAR_MAX];  // Pointers to a list of toolbars
  TOOL_BAR *pPressedBar;	// Cur toolbar with button pressed + 0x8000 (0=NONE)
  short PressedBut;	// Cur button pressed..
  BYTE PressedRepeat;	// # repeats for auto-repeat feature..
  BYTE rmouse;		// Set if right-mouse hit..
  COLORREF colBack;	// Color of main backdrop (192)
  COLORREF colLow;	// Color of low-lite (128)
  HBRUSH hBrushBack;	// Brush for main background
  HPEN hPenBack;	// Pen for background
  HPEN hPenLow;		// Pen for lowlite..
  UINT timerid;		// ID of timer used by toolbar for tool-help text
  //char *szTipClass;	// ToolTips Window class name
  TOOL_TIPTEXT tip;	// Current tool-tip text window info..
  HDC *hBmpDC;		// Or "compatible" DC with 256 col bmp in it..(NULL=use above Bmp)
  HPALETTE *hPal;	// Palette for toolbar-redraw..
  MYPOINT vdu;		// Screen size..
} TOOL_DATA;

void tool_Reset (HINSTANCE, HPALETTE *, HDC *);
void tool_Kill ();
BOOL tool_Create (TOOL_BAR *);
long tool_FindPos (TOOL_BAR *, int, int, short);
void tool_Resize (TOOL_BAR *, int, int, int);
void tool_Close (TOOL_BAR *);
void tool_RedrawAll ();
BOOL tool_Load (TOOL_BAR *, char *, char *, int);

//---------------------------------------------------------------
// MODULE:rtf_ Rich Text Format display box contols..
//---------------------------------------------------------------

typedef VOID (*RTF_PROC) (void *, int);  // Callback service procedure (mouse hit, etc)

typedef struct {
  char *pTxt;		// Ptr to RTF data..
  int topx,topy;	// Top X/y position 
  int lenx,leny;	// Size of RTF window (0,0 = default)
  int rtftype;		// 

  char *szTitle;	// Title-bar message (None=normal captionless)
  DWORD dwStyle;	// Style of window to create (0=default)
  HWND hParent;		// Window handle of parent
  HWND hWnd;		// Window handle of rtf-display window..
  HPALETTE hPal;	// Palette for RTF-redraw..
  HFONT *phFont;	// Ptr to fonts for texts
  int nFonts;		// No of fonts..
  COLORREF *pColFonts;  // Ptr to font colors..
  long startpixel;	// Start-position of window Vertical view-port..
			// Vars computed by rtf_ routines..
  long npixels;		// Total # vert pixel len of RTF file..
  long startpos,endpos;	// Start/end vert pos of display viewport window
			// (Note - due to line-rounding startpos != startpixel..)
  long nlines;		// Line-count
  long startline,endline; // Start/end line of display viewport window
  long linefwd,lineback;  // Size of 1st line in view & prev line in view..
  long spcsize;
  int markPos;	// cursor (CHR_MARK) vertical position.. (-1 == NOT FOUND)
  WRECT rect;		// Drawing area within HDC..
  MYPOINT mousehit;
  long mouse_charpos;	// If RTF_MOUSEHIT callback, calc pos of mousehit as char index & call fn..
  int mousemsg;
  RTF_PROC pfnServiceRtf;  // Frontend callback service function.. NULL=None..
} RTF_WIN;

#define RTF_MARK_BEFORE_WIN 0x40000000L
#define RTF_MARK_IN_WIN     0x20000000L
#define RTF_MARK_AFTER_WIN  0x10000000L
#define RTF_MARK_MASK       0x0FFFFFFFL

void rtf_Reset (HINSTANCE);
BOOL rtf_WinCreate (RTF_WIN *);
void rtf_Close (RTF_WIN *);
void rtf_Resize (RTF_WIN *, int, int, int, int);

#define RTF_REDRAW      3
#define RTF_REDRAWALL   2
#define RTF_REDRAWTEXT  1
#define RTF_NODRAW      0
#define RTF_NOSCROLLBAR 4	// Disable scrollbar pas refresh..
#define RTF_MOUSEHIT    8	// Search for pixel pos of mouse- hit..
#define RTF_KEEP_CUR   16	// Keep cursor pos in view window..

#define RTF_FORCE 0x8000
#define RTF_FONT_MAX 10		// Max # fonts that can be used..

void rtf_SelectFont (RTF_WIN *pRtf, HDC hDC, int cflag);
void rtf_SelectColour (RTF_WIN *pRtf, HDC hDC, int icol);
void rtf_DrawText (RTF_WIN *, HDC, int);
void rtf_Draw (RTF_WIN *, HDC, int);

#define RTF_SERV_MOUSEHIT 1	// Callback service # for mouse..

//---------------------------------------------------------------
// MODULE:lbox_ User List-Box with 3d effect headers
//---------------------------------------------------------------

#define LBOX_MAX_HEAD 30

typedef long (*LBOXSERV_PROC) (int, void *);  // For front end service function..

#define LBOXSERV_ACCESS_START  1   // Send to indicate start of access of lbox data
#define LBOXSERV_ACCESS_END    2   // Sent to indicate end of access..
#define LBOXSERV_NEEDFIELD     3   // Request data for a given field..
#define LBOXSERV_STARTLINE     4   // Start a new line.. (read in any data for that line, clr colours, etc) (1..n)
#define LBOXSERV_ITEM_SELECTED 5   // Sent if mouse-click on item.. 
	// (then rline=1..n,or 0=title,rfield=1-n)

typedef struct {	// Object for data transfer for list box field..
  char *pTxt;		// Ptr to text field (Default=use szTxt)
  long rline;		// Line # requested:1..max
  short rfield;		// Field # requested:1..max
  BYTE lineColour;	// Colour index of cur line (0=default);
  UINT mouseCmd;	// Mouse command - WM_LBUTTONDOWN, etc..
  char szTxt[256];	// Text for field. (if field-data request)
} LBOX_FIELD;

typedef struct {
  LBOXSERV_PROC pfnServiceLbox;	// Ptr to front-end get-field info routine..
  char *pHeadTxt;	// Header Title text data (null sep)..
  int nFields;	// # Header items..
  long totLines;	// Total # lines..
  short headx [LBOX_MAX_HEAD];	// width of each field, +ve=pixels, -ve=(av char)*2
  WORD ftype [LBOX_MAX_HEAD];  // Type for each field
    #define LBOX_TYPE_NUM 0x8000	// Numeric field (0=ascii)
    #define LBOX_TYPE_RJUST 0x4000	// Right-justified
  char *pTxt;		// Ptr to LISTBOX data..
  MYPOINT ltop;		// Top X/y position 
  MYPOINT llen;		// Size of LISTBOX window (0,0 = default)
  int lboxtype;		// Params specify type of list box..
    #define LBOX_TYPE_NOTITLE 0x8000	// Kill title bar..
    #define LBOX_TYPE_VERTSCROLL 0x4000	// Vertical scroll bar..
    #define LBOX_TYPE_SELECTABLE 0x2000	// A true "Listbox", item selectable with mouse..
    #define LBOX_TYPE_ELASTIC 0x1000	// The fields can be moved by the mouse..
    #define LBOX_TYPE_INVERT 0x0800	// The box is "inverted", with line 1 at bottom..
  long SelectedLine;	// "selected" line, 1-n, 0=none selected.. (if Selectable, item is drawn reversed)
  char *szTitle;	// Window Title-bar message (None=normal captionless)
  DWORD dwStyle;	// Style of window to create (0=default)
  HWND hParent;		// Window handle of parent
  HWND hWnd;		// Window handle of lbox-display window..
  HPALETTE *hPal;	// Ptr to Palette for LISTBOX-redraw..
  HFONT *phFont;	// Ptr to fonts handle for text..
			// Misc colors 
     #define LBOX_COL_TITLE 0	// Color of Title backdrop (192)
     #define LBOX_COL_HI 1	// Color 3d hilite (255)
     #define LBOX_COL_LO 2	// Color lo-lite (128)
     #define LBOX_COL_MAIN 3	// Color main box background (255)
     #define LBOX_COL_TEXT 4	// Color for default text (0)
     #define LBOX_COL_TEXT_SEL 5 // Color for selected text (255)
     #define LBOX_COL_BACK_SEL 6 // Color for selected text background (0)
     #define LBOX_COL_TEXT_RED 7
     #define LBOX_COL_TEXT_BLUE 8
     #define LBOX_COL_TEXT_GREY 9
     #define LBOX_COL_MAX 10
     #define LBOX_COL_DEFAULT  RGB(192,192,192),RGB(255,255,255),RGB(128,128,128),RGB(255,255,255),RGB(0,0,0),RGB(255,255,255),RGB(128,128,128),RGB(255,0,0),RGB(0,0,255),RGB(128,128,128)
  COLORREF color[LBOX_COL_MAX];	// Color table
  HPEN hPen[LBOX_COL_MAX];	// List of pens..
  HBRUSH hBrush[LBOX_COL_MAX];	// List of brushes
  BOOL setcolours;		// FALSE to reset colors to defaults..
		// Both below can be filled by user proc, to ID msgs returning..
  long id;			// User-def ID for front-end proc..
  void *pId;			// User-def ID for front-end proc..

			// Vars computed by lbox_ routines..
  long StartOffset;	// Top-line to use in redraw (Pos of scrollbar) 0..n-1
  MYPOINT sfont;	// Average size of font
  WRECT rect;		// Drawing area within HDC..
  LBOX_FIELD *pField;	// Ptr to "current" field, used in callback msgs..
} LBOX_WIN;

#define LBOX_REDRAWALL   0x70000000L	// Set modes for repaint all
#define LBOX_REDRAWBACK  0x40000000L	// Set modes for repaint all
#define LBOX_REDRAWTEXT  0x20000000L	// Redraw text body
#define LBOX_REDRAWTITLE 0x10000000L	// Redraw title bar
#define LBOX_REDRAWLINE  0x080000000L	// Redraw just 1 line..(in low bits)

void lbox_Reset (HINSTANCE);
BOOL lbox_WinCreate (LBOX_WIN *);
void lbox_Close (LBOX_WIN *);
void lbox_Resize (LBOX_WIN *pRtf, int, int, int, int);
void lbox_Draw (LBOX_WIN *, HDC, int);

//---------------------------------------------------------------
// MODULE: thread_ Controls Thread functions..
//---------------------------------------------------------------

void thread_Faster ();
void thread_Normal ();

//---------------------------------------------------------------
// MODULE: task_ Run an intensive task, show Cancel/% window..
//---------------------------------------------------------------

typedef void (*TASK_PROC) (void *);  // Task routine..

typedef struct {
  HINSTANCE hInstance;
  char *szClass;
  HFONT hFont;
  MYPOINT fontsize;	// Ave char height/width
  long threadID;
  BOOL isRunning;
  BOOL isStopped;
  char szProgress[256];
  long starttime;
  RECT wrect;		// Client area window size 
  HWND hTaskWnd;
  HWND hButWnd;
  HWND hParentWnd;	
  int percent;		// % done in 1000ths 
  char szText[512];	//  series of string delim by ASC 1 codes, thus..
			// "Title \1 TxtLine1 \1 TxtLine2 \1 Cancel \1 Time %s \0\0"
  TASK_PROC pfnTask;	// Task procedure..
  void *pParams;	// Initial parameters..
} TASK_DATA;

extern TASK_DATA task_dat;

void task_Reset (HINSTANCE);
BOOL task_Init ();
void task_Redraw (HDC);
BOOL task_IsRunning ();
void task_ThreadEnd ();
void task_Close ();

//---------------------------------------------------------------
// MODULE: msg_ Post "delayed" messages..
//---------------------------------------------------------------

BOOL msg_PostDelayed (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, int sleeptime);

//---------------------------------------------------------------
// MODULE: accel_ Accelerator fns..
//---------------------------------------------------------------

HACCEL accel_Load (char *szParFile, char *szBlock);

//---------------------------------------------------------------
// MODULE: ini_ .INI Profile file read/writes..
//---------------------------------------------------------------

void ini_Init (char *, char *);
void ini_WrtStr (char *, char *);
void ini_WrtInt (char *, int *, short);
void ini_ReadStr (char *, char *);
void ini_ReadInt (char *, int *, short);
void ini_ReadChar (char *, int *);


//---------------------------------------------------------------
// MODULE: bmp_ BMP loading/initialisation
//---------------------------------------------------------------

#define bmpNITEMS 20
#define RGBF(r,g,b,f)     ((COLORREF) ( ((BYTE)(r) | ((WORD)(g)<<8)) | (((DWORD)(BYTE)(b))<<16)) | (((DWORD)(BYTE)(f))<<24) )
#define GetFValue(rgb)	    ((BYTE)((rgb)>>24))

typedef struct {		// Individual bitmap item..
  short mode;			// Mixed flags, 
   #define BMPI_KEEPRAW      1	// bit 0 =keep raw bmp data
   #define BMPI_MAKEMASK     2	// bit 1 =create mono bmp. 
   #define BMPI_TOPLEFT_BACK 4	// bit 2=use topleft pixel as background
   #define BMPI_NO_HI_PACK   8 	// bit 3=dont compress high-empty entries..
   #define BMPI_USE_RGB_TINT 16	// bit 4=Scale RGB values of bitmaps by RGBtint
   #define BMPI_FORCE    0x8000 // bit 15=new bitmap, force load regardless
  HBITMAP hBmp;			// Handle for bitmap.. NULL=none loaded.
  HDC hDC;			// Handle of "compatible" DC..
  HBITMAP hMaskBmp;		// Handle of MASK mono-bitmap
  HDC hMaskDC;			// Handle of MASK mono-DC..
  COLORREF RGBtint;		// Val to colourise all entries..(0-100)
  short lenx,leny;		// Bitmap size
  WORD sPal;			// Index into Palette-start of entries.
  WORD nPal;			// # palette entries..
  WORD darkest;			// Darkest palette entry..
  WORD xscale,yscale;		// Scaling factor: 0=disabled..
  LPBITMAPINFOHEADER head;	// Pointer to raw bitmap data (NULL=not kept)
  char *fname;			// File name of bitmap, to load..
} BMPITEM;

typedef struct {
  HDC hOrigDC;			// DC to use for creating "compatible" DC..
  HPALETTE hPal;		// Palette for bitmaps..
  LOGPALETTE far *lpPal;	// Ptr to raw palette data (NULL=NONE)
  WORD nExtraPal;		// No of "special" entries in PAL table..
  COLORREF *pExtraPal;		// Pointer to "Extra" palette entries..
  BMPITEM i [bmpNITEMS];	// List of loaded bmp items..
} BMPHEAD;

#define spr_MAXSETS 4	// max # of different "sets" within any one bmp.. (2D only)
#define spr_MAXPIECES 16

typedef struct {	// Object describing a sprite..
  BMPHEAD *bm;		// Ptr to graphics/palette data object (mast have MonoMask)
  WORD cbmp;		// Index of bitmap to use in that object
  WORD lx,ly;		// Max size of sprite.
  short cspr;		// Current sprite to use..
  short base3d;		// Offset from bottom so that 3d piece "sits" on sqr..
  MYPOINT ppos[spr_MAXPIECES]; // Array of pos of piece-graphics within that BMP
  short animate;		// 0=none,1..n=#animation step bytes..
  BYTE animStep[16];	// Animation stages for sliding piece..
			//  Indexs from normal piece pos to right of it..
} spr_SPRITE;	
	// Convert piece val to index offset
//#define spr_PIECE2OFF(pspr,cp) ((WORD) (cp) % (pspr->nspr))
#define spr_PIECE2OFF(pspr,cp) ((WORD) (cp) & (spr_MAXPIECES - 1))

#define brd_CURRENT 0x8000	// PutAt:piece val=use cur board contents
#define brd_SETUP_POS 0x4000	// OR in val to indicate "setup" box selection..

typedef struct {	// 2d board drawing data
  char far *board;	// Ptr to board
  short sqrx,sqry;	// X/Y size of board (ie. 8,8)
  short pixx,pixy;	// Size of each sqr pixels
  short offx,offy;	// Pixel-offset from top-left corner.
  BOOL flip;		// TRUE if board display inverted
  BMPHEAD *bm;		// Ptr to graphics data obj with lt/dark sqr bitmaps
  short lt_bmp,dk_bmp;	// Light/Dark sqr bitmap indexes
  spr_SPRITE *pSp;	// Ptr to Piece-graphics data object..
  short movflag;	// 1==piece "held" by mouse
  short movpiece;	// (sliding) Piece in motion..
  short movfrom,movto;	// Source/dest sqrs on board..
  BYTE far *pHi;	// Ptr to list of sqrs to be hilited (0xff term)
  short hipal;		// Colour to use for hilite..
  BYTE outline;		// Draw outline frame around board..
  BYTE su_nrows;	// No of rows to add for setup piece display 0=NO SETUP BOX
  char *conv_pc;	// Conversion array from "normal" piece order to internal order
  short npieces;	// # possible pieces, listed in above array 
} brdHEAD;

  // FUNCTION prototypes..
	// DIB lib prototypes  
short bmp_LoadAll (BMPHEAD *, short);
 #define BMP_LOAD_CLR    1  // Set bit 0 to wipe old first
 #define BMP_LOAD_MAKEDC 2  // Set bit 1 to create a temp DC for bmp-loading..
BOOL bmp_Reset (BMPHEAD *, short);
 #define BMP_RST_DEL_OLD 1   // Mode bit 0 to Delete old objs/DCs/Bmp handles etc
 #define BMP_RST_INIT    2   // Set  bit 1 to Init first palette alloc
 #define BMP_RST_WIPE    4   // Set  bit 2 for absolute wipe..
 #define BMP_RST_RAW     8   // Set  bit 3 to wipe kept 'raw' bitmaps..
short bmp_Load (BMPHEAD *, short);
BOOL bmp_Rescale (BMPITEM *, short , short);
BOOL bmp_Add (BMPHEAD *, short , char *, COLORREF, short, short,short );

//---------------------------------------------------------------
// MODULE: d2d_ 2D drawing/sprite/animation routines
//---------------------------------------------------------------

void d2d_EndMove ();
void d2d_InitMove (spr_SPRITE *);
void d2d_PutAt (HDC, spr_SPRITE *, short, short);
void d2d_Slide (HDC, spr_SPRITE *, short, short, short, short, short, short, void (*)());
void d2d_SpriteRescale (spr_SPRITE *, WORD , WORD );
void d2d_PiecePickUp (HDC, spr_SPRITE *, short , short );
void d2d_PieceMove (HDC, spr_SPRITE *, short, short);
void d2d_PieceDrop (HDC, spr_SPRITE *, short, short);

//--------------------------------------------------------------
// MODULE: title_  Generic title screen routines..
//--------------------------------------------------------------

typedef struct {
  BOOL UseBmp;
  char *szBmpFile;
  char *szClass;
  BMPHEAD *phBmp;	// Ptr to Local Bitmap data..
  char *szProgName;
  PROC_VOID pfnDialog;	// Ptr to dialog routine.. (returns int..)
  HINSTANCE hInst;	// Instance of main prog
} TITLE_DATA;

int title_Screen (TITLE_DATA *);

