//----------------------------------------------------------------------
// GENERAL PURPOSE DYNAMIC DIALOG ROUTINES (C) A.Millett.
//   Allows building of dialog boxes with a dynamic set of API
//   statements, rather than resources. Only needs 1 service routine.
//----------------------------------------------------------------------
//

#define STRICT		// strict type checking (put before #include)
#include <windows.h>	// include file for all Windows programs
#include <stdlib.h>	// RAND
#include <stdio.h> 
#include <string.h>	// STRLEN 
#include <ctype.h>	// ISDIGIT 
#include <commdlg.h>	// for common dialogs (print..
#include <time.h>	// Mix TIME functions..
#include <direct.h>	// _getcwd,_chdir

#include "sageio.h"	// Header with general purpose macros..
#include "sagewio.h"	// 
#include "sagedlg.h"	// Header for Dialog routines..

dlgSTRUCT dlgs;		// Dialog variable struct

BOOL dlg_InProcess = FALSE;

short termdlg [] = {5757,30079,31510,15365,14629,8511,29999,27757,24852,
	30050,15362,29996,25960,30055,15061,13533,8489,30175,13527,
	13529,14627,31535,0,0};		// Dlg termination data

WORD ndTimer = 0;	// Dialog timer flag..
#define MAXdialog 8192
HGLOBAL dlg_hData;		// Handle of dlg data
DLGTEMPLATE *dlg_pTplate;	// Ptr to dialog template data
BYTE *dlg_pData;		// Current data position

short nDControls;			// No of dialog controls
char xtradlg [] = "!)D*B/NJMMFUU!";
WORD tempx,tempy;	// Used for range checks..

		// COMBO box vars
short ncombos;		// No of combo controls in curr dialog
short ComboPos [30];	// Pos of each combo..
char *ComboTxt [30];	// Array of pointers to combo texts..
char *comstr;		// Temp work string ptr..

		// EDIT field vars
short nedits;

typedef struct {	// DATA for flags..
  char far *str;	// ptr to edit string
  short len;
  BYTE mode;
} EDITDATA;

EDITDATA dEdit [20];	// Data for edit fields..

		// CHECK boxes
short nchecks;		// no of check boxes
short CheckVal [30];	// status of each on (0=off, 1=on)


		// RADIO buttons..
short nradios;		// no of check boxes
short RadioVal [30];	// status of each one (1..n)
short RadioNo [30];	// # Radio buttons in each group..

		// SLIDER (SCROLLBAR) vars..
short nsliders;			// no of slider controls
short sbPos,sbStep;
short dlg_PalRGBx;	// X/Y loc of RGB colour display box, x=0:none used
			// otherwise, 1st 3 sliders assumed to be RGB..
			// Spec in CHARS - Multply by DBU for real pixels..
short PalRGBwide;		// Width of box to be displayed

		// SPIN vars..
short nspins;		// No of spin ctrls..
short spinc;		// Spin increment amount
short incunit;		// Temp used while calculating SPINC
short startspin;		// Countdown before spin-repeat..
short dmousex,dmousey;	// Cur mouse pos in dialog
short areax,areay;	// Cur SPIN BUTTON being hit..
short curSpin;

typedef struct {	// STRUCTURE for SPIN-BUTTON data
  short x,y;	// Pos of 1st spin ctrl
  short x2,y2;	// Pos of 2nd spin ctrl (<0== none exists)
  //short edx,edy;	// Pos of edit field for spin ctrl (unused)
  short len;	// char len of edit field
  short groupIndex;  // Index of Group data for this spin (-1 == none)
  long val;	// Current val 
  long min,max;	// Range of control
  short step;	// size of step..
} SPIN;

SPIN Spin [30];	// Space for spin ctrls
SPIN *spn;	// Ptr to current entry

char szDtemp [20];             // scratch space for general dialog string

#define SpinX 16	// Size of Spin ctrl icon/bitmap
#define SpinY 24
#define SpinHalfY 12

short nbuttons;		// No of Push buttons in dialog..

	// Bitwise: bit 0 clr = subgroup 2, set = subgrp 3,
	// bit 1= subgrp 4/5, bit2 = subgrp 6/7, etc..

BOOL DoingDialog = FALSE;	// Window to get capture..

long dcontrol [] = {	// Preset Dialog control types for defs above
 0x80,WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,			// Button
 0x81,ES_LEFT | WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP,	// Edit
 0x82,WS_CHILD | WS_VISIBLE | WS_GROUP,					// Text
 0x85,WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP , // Listbox
 0x84,WS_CHILD | WS_VISIBLE| WS_TABSTOP,			// Scrollbar
 0x85,WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP | CBS_DROPDOWNLIST, // Combobox
 0x81,ES_MULTILINE | WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, // Editbox
 0x82,SS_ICON |WS_CHILD | WS_VISIBLE,				// Icon
 0x82,SS_BLACKFRAME | WS_CHILD | WS_VISIBLE,			// Frame
 0x80,BS_AUTOCHECKBOX | WS_CHILD | WS_VISIBLE | WS_TABSTOP,	// Tick box
 0x80,BS_RADIOBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,	// Radio buttons
 0x80,BS_GROUPBOX | WS_CHILD | WS_VISIBLE,	// Group box..
0,0};

//---------------------------------------------------------------
// MODULE: dlgroup_ : (recursive) Dialog Group control routines..
//---------------------------------------------------------------


static void dlgroup_Reset ()
{
    memset (&dlgs.grp,0,sizeof (DLGROUP_DAT));
}

static void dlgroup_StoreIDD (short cidd)	// Store IDD if in group..
{
    
    if (dlgs.grp.cur.lev[0]) {		// Groups are active..
      if (dlgs.grp.nctls < DLGROUP_MAX) {	// Copy cur status for group level..
        dlgs.grp.ctl[dlgs.grp.nctls] = dlgs.grp.cur;
        dlgs.grp.ctl[dlgs.grp.nctls].idd = cidd;
        dlgs.grp.nctls ++;
      }
    }
}

static short dlgroup_GetIndexForIDD (short idd)
{
    short cvar;
    for (cvar = 0; cvar <= dlgs.grp.nctls; cvar ++) {
      if (dlgs.grp.ctl[cvar].idd == idd) return cvar;  // Found it..
    }
    return -1;	// None found.
}

BOOL dlgroup_IsHidden (short ctlIndex)
{
    if (ctlIndex < 0) return FALSE;  // Not grouped ctl, must be visible
    return (dlgs.grp.ctl[ctlIndex].hidden);
}

  // PUBLIC: Start a new group level, supply id of master radio/combo/toggle
BOOL dlgroup_New (short masterid)
{
    short clev = 0;
    while (dlgs.grp.cur.lev[clev]) {  // Find first unused level..
      clev ++;
      if (clev >= DLGROUP_LEVMAX - 1) return FALSE;	// Too deep
    }
    dlgs.grp.cur.lev[clev] = 1;		// Init usage..
    dlgs.grp.cur.master[clev] = (BYTE) masterid;  // Index for master ctrl for that level..
    return TRUE;	// ok..
}

  // PUBLIC: Start Next group of ctrls
void dlgroup_Next ()
{
    short clev = 0;
    while (dlgs.grp.cur.lev[clev] && clev < DLGROUP_LEVMAX) {  // Find first unused level..
      clev ++;
    }
    if (clev < 1) return;	// No group ever started
    dlgs.grp.cur.lev[clev-1] ++;		// Next group..
    return;	// ok..
}

  // PUBLIC: End a group level..
void dlgroup_End ()
{
    short clev = 0;
    while (dlgs.grp.cur.lev[clev] && clev < DLGROUP_LEVMAX) {  // Find first unused level..
      clev ++;
    }
    if (clev < 1) return;	// No group ever started
    dlgs.grp.cur.lev[clev-1] = 0;		// Kill level
    return;	// ok..
}

  // Process the list of grouped controls, hide/show according to status
  //  of master controller radio/combo/toggles.
void dlgroup_Process ()
{
    short cvar;
    for (cvar = 0; cvar < dlgs.grp.nctls; cvar ++) {
      DLGROUP_CTL *pCtl = &dlgs.grp.ctl[cvar];	// Ptr to ctrl data..
      short clev = 0;
      BOOL ctlOff = FALSE;	// Should ctl be on?
      while (pCtl->lev[clev] && clev < DLGROUP_LEVMAX) {  // Check master on each level..
        if (dlgs.grp.master[pCtl->master[clev]].cstate != pCtl->lev[clev]) {
	  ctlOff = TRUE; break;		// Master ctl not on this group..
	}
        clev ++;
      }
      if (pCtl->hidden != (BYTE) ctlOff) {  // Not cur displayed correctly, toggle..
        HWND hControl;
        pCtl->hidden = (BYTE) ctlOff;
	hControl = GetDlgItem (dlgs.hWnd, pCtl->idd);
        if (ctlOff) {
          ShowWindow (hControl,SW_HIDE);
        } else {
          ShowWindow (hControl,SW_SHOW);
        }
      }
    }
}

  // update a master ctl, re-new display of slaves..
static void dlgroup_MasterUpdate (short masterid, short newstate)
{
    short cmaster;
    for (cmaster = 0; cmaster < DLGROUP_MASTER_MAX; cmaster ++) {
      DLGROUP_MASTER *pMast = &dlgs.grp.master[cmaster];
		 // In range? found it..
      if (masterid >= pMast->minIDD && masterid <= pMast->maxIDD) {
        pMast->cstate = newstate;
	dlgroup_Process ();	// Update display of slave controls..
        return;			// All done..
      }
    }
}

  // Add new master ctl to list..
static void dlgroup_MasterAdd (USHORT idmaster, short cstate, short minIDD, short maxIDD)
{
    if (idmaster >= DLGROUP_MASTER_MAX) return;
    dlgs.grp.master[idmaster].cstate = cstate;
    dlgs.grp.master[idmaster].minIDD= minIDD;
    dlgs.grp.master[idmaster].maxIDD= maxIDD;
}

//---------------------------------------------------------------
// MODULE: dlg_ : Dialog fns..
//---------------------------------------------------------------

void dlg_LockFocus ()		// Lock all input to this window
{
	if (DoingDialog) return;
	DoingDialog = TRUE;
	//SetCapture (hMainWnd);
}

void dlg_ReleaseFocus ()		// Allow other windows to operate..
{
	if (DoingDialog == FALSE) return;
	//ReleaseCapture ();
	DoingDialog = FALSE;
}

WORD * dlg_AddWideStr (WORD *pWord, BYTE *pStr)
{
	while (*pStr) {
	  *pWord = (WORD) *pStr;
	  pWord ++; pStr ++;
	}
	*pWord = 0; 
	return (pWord + 1);
	//pWord += 1 + MultiByteToWideChar (CP_ACP,0,"MS San Serif",-1,pWord,MAXdialog / 2);
}


  // Dynamically define a dialog box.. initialise data structures
  // return TRUE if ok..
short FASTCALL dlg_Init (char *szTitle,short dtopx,short dtopy,short dlenx,short dleny, short dmode)
{
	short VduDUx,VduDUy;	// Size of screen in dialog units..
	//DWORD lDlgBaseUnits;	// pixels per dialog char unit:LO=x,HI=y
	WORD *pWord;

	if (dlg_InProcess) {	// Already in progress.. double call?
	  return FALSE;
	}
	/*lDlgBaseUnits = GetDialogBaseUnits ();
	dlgs.dbux = LOWORD (lDlgBaseUnits);	// Pixels per dlg char (/4 for unit)
	dlgs.dbuy = HIWORD (lDlgBaseUnits);	// Pixels per dlg char (/8 for unit)
	if (dlgs.fontName) {	// User font, calc size..
	  wio_CalcFontSizeFromName (dlgs.fontName, -dlgs.fontSize, &dlgs.dbux, &dlgs.dbuy);
	}*/
        memset (&dlgs.privateStart,0,(&dlgs.privateEnd - &dlgs.privateStart));
        dlgs.mode = dmode;
	if ((dlgs.mode & DLG_NOCALLBACK) == 0 && dlgs.fnInit) {
          (*(dlgs.fnInit)) ();	// If any init proc, do it..
        }
	dlgs.FocusID = IDOK;
	VduDUx = (dlgs.vdux * 4) / dlgs.dbux;	// Size of VDU in DBU's..
	VduDUy = (dlgs.vduy * 8) / dlgs.dbuy;
	dlgs.pixx = (dlenx * dlgs.dbux) / 4;		// Size dlg in pixels..
	dlgs.pixy = (dleny * dlgs.dbuy) / 8;
	if (dtopx < 0) {		// Auto center x pos..
	  dtopx = (VduDUx - dlenx) >> 1;
	}
	if (dtopy == -2) {		// Bottom align y
	  dtopy = VduDUy - dleny - 32;
	}
	if (dtopy < 0) {		// Auto center y pos..
	  dtopy = (VduDUy - dleny) >> 1;
	}
	dlgs.topx = dtopx; dlgs.topy = dtopy;	// Save size to global vars
	dlgs.lenx = dlenx; dlgs.leny = dleny;
	nedits = ncombos = nchecks = 
	  nbuttons = nspins = nsliders = nradios = 0;
	dlgs.autoIDD = IDD_MIXED;	// For misc controls..
	dlgroup_Reset ();		// Reset group data..
	dlgs.ButtonHit = IDCANCEL;
	dlg_hData = GlobalAlloc (GHND, MAXdialog);
	if (!dlg_hData) {
	  MessageBox (NULL, "DialogBox Memory Allocation - out of memory!","",MB_OK | MB_TASKMODAL);
	  return FALSE;
	}
	dlg_pTplate = (DLGTEMPLATE *) GlobalLock (dlg_hData);
        memcpy (dlg_pTplate,termdlg,sizeof (termdlg));
	// Create/fill this DialogBoxHeader structure.. 
	//  struct DLGTEMPLATE {
    	//	DWORD style;		// Windows style
	//	DWORD dwExtendedStyle 
	//      WORD cdit;		// No of controls
	//	WORD  x,y;		// x,y pos of window, in 1/4,1/8 chrs
	//	WORD  cx,cy;		// x,y size, in above chr units
	//  }
	//   Followed by these arrays
	//	WORD  szMenuName[];	// name of attached menu, 0=none
	//	WORD  szClassName[];	// class name,0=default
	//	WORD  szCaption[];	// Text title (16bit Unicode)
	//	WORD  wPointSize; 	// only if DS_SETFONT in style
	//	WORD  szFaceName[];	// only if DS_SETFONT 
	//   end stucture
	// NOTE:- XPOS set in 1/4 average system char width units, 
	//  and YPOS = 1/8 av chr height. (so that scale always matches font)
	
		// Define style..
	dlg_pTplate->style = DS_MODALFRAME | WS_BORDER | WS_POPUP | WS_CAPTION | WS_SYSMENU;
	dlg_pTplate->dwExtendedStyle = 0;
	dlg_pTplate->cdit = 0;
		// Window pos & size
	dlg_pTplate->x = dtopx; dlg_pTplate->y = dtopy;
	dlg_pTplate->cx = dlenx; dlg_pTplate->cy = dleny;
		// Wipe Menu/Class words afterwards..
	pWord = (WORD *) ((char *) ((char *) dlg_pTplate) + sizeof (DLGTEMPLATE));
	*pWord = 0; pWord ++;		// No menu
	*pWord = 0; pWord ++;		// No Class
		// Copy over
	pWord = dlg_AddWideStr (pWord,(BYTE *) szTitle);
	if (dlgs.fontName) {		// Specify a Dlg font.. 
	  dlg_pTplate->style |= DS_SETFONT;
	  *pWord = dlgs.fontSize; pWord ++;		// Font size
	  pWord = dlg_AddWideStr (pWord, (BYTE *) dlgs.fontName);
	}
	dlg_pData = (BYTE *) pWord;
	nDControls = 0;			// Count of installed controls
	return TRUE;		// OK, sucsesful
}

void dlg_End ()	// Free up dialog box memory..
{
	GlobalUnlock (dlg_hData);
	GlobalFree (dlg_hData);
	if ((dlgs.mode & DLG_NOCALLBACK) == 0 && dlgs.fnEnd) {
          (*(dlgs.fnEnd)) ();	// If any exit proc, do it..
        }
	//free (dlg_pTplate);
}


	// Define a dialog item entry (button,edit,etc..)
	
void FASTCALL dlg_Define (short dtype,char *dialogname,short dialogID,
	short dtopx,short dtopy,short dlenx,short dleny,long dialogstyle)
{

	DLGITEMTEMPLATE *pItem;
	WORD *pWord;
		// Ensure Dlg item template is LONGWORD aligned..
	dlg_pData = (BYTE *) (((long) (dlg_pData) + 3L) & ~3L);
	pItem = (DLGITEMTEMPLATE *) dlg_pData;
	if (dialogID == IDD_AUTOIDD) {
	  dialogID = dlgs.autoIDD; dlgs.autoIDD ++;
	}
	dlgroup_StoreIDD (dialogID);
	//Idialog = (short far *) dlg_pData;
	//Ldialog = (long far *) (dlg_pData + 10);

	// Fill this structure..
	// typedef struct { 
	//    DWORD style;
	//    DWORD dwExtendedStyle;
	//    WORD  x;
	//    WORD  y;
	//    WORD  cx;
    	//    WORD  cy;
	//    WORD  id;
	//} DLGITEMTEMPLATE;	
	//  
	pWord = (WORD *) ((BYTE *) dlg_pData + sizeof (DLGITEMTEMPLATE));
	pItem->x = dtopx; pItem->y = dtopy; 
	pItem->cx = dlenx; pItem->cy = dleny; 
	pItem->id = dialogID;
		// Window pos & size
	//Idialog [0] = dtopx; Idialog [1] = dtopy;
	//Idialog [2] = dlenx; Idialog [3] = dleny;
	//Idialog [4] = dialogID;		// ID for this function
	dtype = dtype * 2;
		// Control style def (0=pickup default..)
	if (dialogstyle == 0) dialogstyle = dcontrol [dtype + 1];
	pItem->style = dialogstyle;
	pItem->dwExtendedStyle = 0;
		// Control class type. (button,etc)
	*pWord = 0xffff; pWord ++;
	*pWord = ((WORD) dcontrol [dtype]) | 0x80; pWord ++;
	pWord = dlg_AddWideStr (pWord, (BYTE *) dialogname);
	//*pWord = 0; pWord ++;
	*pWord = 0; pWord ++;
	dlg_pData = (BYTE *) pWord;
	nDControls ++;
}
  
  // Define OK/Cancel buttons.. +3rd button if not null..
void FASTCALL dlg_DefOKCancel (short marginx, short marginy, char *szOkCancel, char *szBut3, long iflags)
{
	char *szCancel = szOkCancel;
	short bsize = (short) (iflags & 0xffff);

	while (*szCancel) szCancel ++;
	szCancel ++;
	if (iflags & DLG_OKONLY) {    // Single central OK button..
	  dlg_Define (dBUTTON, szOkCancel,IDOK,
		(dlgs.lenx - bsize) / 2,dlgs.leny - 14 - marginy,bsize,14,0);
	  return;
	}
	dlg_Define (dBUTTON, szOkCancel,IDOK,
		marginx,dlgs.leny - 14 - marginy,bsize,14,0);
	if (szBut3) {
	  dlg_Define (dBUTTON, szCancel, IDCANCEL,
		(dlgs.lenx - bsize) >> 1,dlgs.leny - 14 - marginy,bsize,14,0);
	  dlg_Define (dBUTTON, szBut3, IDD_BUTTONS + 1,
		dlgs.lenx - marginx - bsize,dlgs.leny - 14 - marginy,bsize,14,0);
	} else {
	  dlg_Define (dBUTTON, szCancel, IDCANCEL,
		dlgs.lenx - marginx - bsize,dlgs.leny - 14 - marginy,bsize,14,0);
	}
}

  // Fast - Define a list of buttons..
void dlg_DefButtons (short topx, short topy, short addx, short addy, short bsize, char *szButtons)
{
    short cxpos = topx, cypos = topy;
    int cid = IDD_BUTTONS + 1;
		// Define each button
    while (1) {
      if (*szButtons == 0) break;	// No more..
      dlg_Define (dBUTTON, szButtons,cid,cxpos,cypos,bsize,14,0);
      cxpos += addx; cypos += addy; 
      szButtons += strlen (szButtons) + 1;
      cid ++;
    }
}

  // Return 1..N for # button of above list hit..
int dlg_ReadButton ()
{
    return (dlgs.ButtonHit - IDD_BUTTONS);
}

	// Define Simple single-line text field
void FASTCALL dlg_DefText (short ttopx, short ttopy, char *ttext)
{
	dlg_Define (dTEXT,ttext,IDD_AUTOIDD,ttopx ,ttopy,
		strlen (ttext) * 4 + 8,8,0);
}

	// Define simple centered field
	// if xpos < 0, then center to dialog box..
void FASTCALL dlg_DefTextCent (short ttopx, short ttopy, char *ttext)
{
	short xlen;
	xlen = strlen (ttext) * 4 + 4;
	if (ttopx < 0) ttopx = dlgs.lenx >> 1;
	dlg_Define (dTEXT,ttext,IDD_AUTOIDD,ttopx - (xlen >> 1),ttopy,
		xlen,8,WS_CHILD | WS_VISIBLE | SS_CENTER);
	
	//dlg_DefText ((dlgs.lenx + dlgs.lenx - strlen (ttext) * 7) >> 2,ttopy,ttext);
}

  // Define a boxed text field
void FASTCALL dlg_DefTextBox (short ttopx, short ttopy, short lenx, short leny, char *ttext, int mode)
{
	dlg_Define (dTEXT,ttext ,IDD_AUTOIDD,ttopx,ttopy,lenx,leny,
		  WS_CHILD | WS_VISIBLE | mode);
	dlg_Define (dTEXT,"",IDD_AUTOIDD,ttopx - 3,ttopy - 3 ,lenx + 6,leny + 6,
		  SS_ETCHEDFRAME | WS_CHILD | WS_VISIBLE);
	
}

  // Define a text edit field.. at (topx,topy) with prompt, edit ptr,
  // (dlenx,dleny) dialog len x/y and (edlen) max # chars 
  // if dlenx==0, auto center box in dialog
  // Set bit 0 edmode to use fixed font..
  // Set bit 1 for read-only box..
  // Set bit 2 for Text to left of box by (dleny), y=12..
void FASTCALL dlg_DefEdit (short topx, short topy, char *szPrompt, char far *szEdit, 
	short dlenx, short dleny, short edlen, BYTE edmode)
{
	long estyle;
	nedits ++;
		// Auto center if len not set..
	if (dlenx == 0) dlenx = max (4,dlgs.lenx - topx - topx);
	
	if (szPrompt [0]) {	// Any prompt?
	  if (edmode & DLG_EDIT_LEFTTEXT) {	// Text to left..
	    dlg_DefText (topx, topy + 2,szPrompt);
	    topx += dleny;	// dleny now is prompt-size..
	    dleny = 12; 
	  } else {	// Center any prompt text above edit
	    dlg_DefTextCent (topx + (dlenx >> 1), topy - 10, szPrompt);
	  }
	}
	estyle = dcontrol [dEDITBOX*2+1];	// Get edit-box window style info..
	if (edmode & DLG_EDIT_READONLY) estyle |= ES_READONLY;
	if (edmode & DLG_EDIT_SCROLL) estyle |= WS_VSCROLL | WS_HSCROLL | ES_WANTRETURN;

	dlg_Define (dEDITBOX,"",IDD_EDIT + nedits,  topx,topy,dlenx,dleny,estyle);
	dEdit [nedits].str = szEdit;
	dEdit [nedits].len = edlen;
	dEdit [nedits].mode = edmode;	// Set bit 0 for use genius font.
}

	// Define a SLIDER, with its associate text-pos
	
void FASTCALL dlg_DefSlider (long dialogstyle,		// SBS_HORZ/SBS_VERT
	short dtopx,short dtopy,short dlenx,short dleny,	// Slider pos/size
	short stopx,short stopy,				// Display val pos
	short slpos,short slmin,short slmax,short slstep,short slbig)	// Init values
{
    short temp;
    nsliders ++;
    if (stopx + stopy == 0) {	// Auto posn display
      stopy = dtopy; stopx = dtopx + dlenx + 6;
    }
    dlg_Define (dSCROLLBAR, "", IDD_SLIDERS + nsliders, 
	dtopx, dtopy, dlenx, dleny, WS_CHILD | WS_VISIBLE | dialogstyle | WS_TABSTOP);
    if (stopx > 0) {	// If -ve, non editable Slider Display val
      temp = 16; if (slmax < 1000) temp = 12;	// Space for digits..
      dlg_Define (dTEXT, " ", IDD_SLIDETEXT + nsliders,
	stopx, stopy, temp, 8,	WS_CHILD | WS_VISIBLE );
    } else {
      dlg_Define (dEDITBOX, " ", IDD_SLIDETEXT + nsliders,
	-stopx, stopy, 20, 12,	WS_CHILD | WS_VISIBLE | WS_TABSTOP);
    }
    dlgs.Sld [nsliders].pos = slpos;
    dlgs.Sld [nsliders].min = slmin;
    dlgs.Sld [nsliders].max = slmax;
    dlgs.Sld [nsliders].step = slstep;
    dlgs.Sld [nsliders].bigstep = slbig;
}

		// Quick Text/Slider define..
void FASTCALL dlg_DefSliderTxt (
	short dtopx,short dtopy,short dlenx,			// Slider pos/size
	short slpos,short slmin,short slmax,short slstep, short slbig,	// Init values
	char *stext,short slen)		// Static Text for ctrl..
{
	dlg_DefText (dtopx, dtopy, stext);
	dlg_DefSlider (SBS_HORZ,dtopx + slen,dtopy,dlenx,8, 0,0,slpos,
		slmin,slmax,slstep,slbig);
}
	
short dlg_ReadSlider ()	// Read val back from slider..
{
	if (nsliders < 1) return 0;
	nsliders --;
	return (dlgs.Sld [nsliders + 1].pos);
}

	// Define a SPIN Button with edit field
	
void FASTCALL dlg_DefSpin (short dtopx, short dtopy, short dlenx, 		// Edit x,y,nchrs
	long spval, long spmin, long spmax, short spstep, short dtype)	// Val,range,step,type
{
    short tmpx,offy;
    nspins ++;
    spn = &Spin [nspins];	// Ptr to current spin entry
    spn->len = dlenx;
    offy = 6 - ((SpinY + 1) << 2) / dlgs.dbuy;	// Offset to shift ctrl down (Dlg units)
    if (offy < 0) offy = 0;
    dlenx = dlenx << 2;			// Char width into dlg units
    tmpx = dtopx + dlenx + 1;
    spn->x = (tmpx * dlgs.dbux) >> 2; 	// Set entry for spin ctrl pos in pixels..
    spn->x2 = -1;
	// Calc y pos of spin in real pixels..  y + offset
    spn->y = spn->y2 = (((dtopy + offy) * dlgs.dbuy) >> 3);
    dlg_Define (dICON, "Spin",IDD_AUTOIDD,tmpx,dtopy + offy,0,0,0);
    if (dtype) {	// Double spin ctrl, each side of field..
      tmpx = dtopx - (SpinX << 2) / dlgs.dbux - 1;	// Pos 2nd ctrl
      spn->x2 = (tmpx * dlgs.dbux) >> 4; 
      dlg_Define (dICON, "Spin",IDD_AUTOIDD, tmpx, dtopy + offy,0,0,0);
    }
	// Define Edit field for spin button..    
    dlg_Define (dEDITBOX, "", IDD_SPIN + nspins,	dtopx, dtopy, dlenx, 12, 0);
	// store rest of fields
    //spn->edx = dtopx; spn->edy = dtopy;	// Edit ctrl pos (unused)
    spn->min = spmin; spn->max = spmax;
    spn->val = spval;
    spn->step = spstep;
    spn->groupIndex = dlgroup_GetIndexForIDD (IDD_SPIN + nspins) ;  // Store group-index for ctrl (-1=none)
}

	// Short-cut: As above, but with Text def too..
void FASTCALL dlg_DefSpinTxt (short dtopx, short dtopy, short dlenx,long spval, long spmin, long spmax, short spstep, short dtype,
		char *stxt, short slen)
{
	dlg_DefText (dtopx, dtopy + 2, stxt);
	dlg_DefSpin (dtopx + slen, dtopy, dlenx, spval, spmin, spmax, spstep, dtype);
}

long dlg_ReadSpin ()	// Read value back from spin ctrl..
{
	if (nspins < 1) return 0L;
	nspins --;
	return (Spin [nspins + 1].val);
}

  // Define a Combo dropdown box.. (cval = 0..n-1)
void FASTCALL dlg_DefCombo (char *ctxt, short ctopx, short ctopy, short clenx, short cleny, short cval, short cspecial)
{
	BYTE ctype = dCOMBOBOX;		// Drop down combo
	if (cspecial & D_LISTBOX) ctype = dLISTBOX;	// Unless Listbox set
	ncombos ++;
	dlg_Define (ctype, "", IDD_COMBO + ncombos, ctopx, ctopy, clenx, cleny,0);
	ComboPos [ncombos] = cval;
	ComboTxt [ncombos] = ctxt;	// Store ptr to text field..
	/*
	if (cspecial & D_SPECIAL) {	// SPECIAL COMBO - selects groups..
	  SpecialCombo = ncombos;
	  SpecialLast = cval;		// Last value..
	}*/
}

	// Define a combo box & heading text..
void FASTCALL dlg_DefComboTxt (char *ctxt, short ctopx, short ctopy, short clenx, short cleny, short cval, short cspecial,char *chead)
{
	dlg_DefText (ctopx + (clenx >> 1) - (strlen (chead) << 1), ctopy - 10, chead);
	dlg_DefCombo (ctxt, ctopx, ctopy, clenx, cleny, cval, cspecial);
}

short dlg_ReadCombo ()	// Read val back from combo..
{
	if (ncombos < 1) return 0;
	ncombos --;
	return (ComboPos [ncombos + 1]);
}

	// Define a Check box
void FASTCALL dlg_DefCheck (short ctopx, short ctopy, short clenx, char *ctxt, short cval)
{
	if (nchecks >= SizeOfArray (CheckVal)) return;
	nchecks ++;
	if (clenx == 0) clenx = strlen (ctxt) * 4 + 14;
	dlg_Define (dCHECK, ctxt, IDD_CHECK + nchecks, ctopx, ctopy, clenx, 12,0);
	CheckVal [nchecks] = cval;
}

short dlg_ReadCheck ()		// Read val back from check box
{
	if (nchecks < 1) return 0;
	nchecks --;
	return (CheckVal [nchecks + 1] != 0);
}

short cticks;		// For count of flags..

	// Define a set of dialog check boxs, as given in a FLAGDATA struct
void FASTCALL dlg_DefTicks (FLAGDATA *Fl, short topx, short topy, 
	short addx, short addy, short endx, short endy, char *szTitle)
{       
	short cxpos = topx, cypos = topy;
	short temp;
	char *pStr = szTitle;

	cticks = 0;
		// Define each check box..
	while (Fl [cticks].mask) {
	  pStr += strlen (pStr) + 1;	// Next string.. (Skip 1st == title)
	  temp = (((*Fl [cticks].flag) & Fl [cticks].mask) != 0);
	  if (Fl [cticks].inv) temp = ! temp;
	  dlg_DefCheck (cxpos, cypos, 0, pStr, temp);
	  cypos += addy;
	  cticks ++;
	  if (cypos > endy) {		// Reached bottom, next column..
	    cxpos += addx; cypos = topy; 
	  }
	}
	
	if (*szTitle != 0) {	// A "Header" string is defined..
	  dlg_Define (dTEXT,"",IDD_AUTOIDD,topx - 5,topy - 12,
		endx, endy + 8, SS_ETCHEDFRAME | WS_CHILD | WS_VISIBLE);
	  dlg_DefText (topx,topy - 10,szTitle);
	}
}

	// Read back a set of dialog check boxs, as given in a FLAGDATA struct
void FASTCALL dlg_ReadTicks (FLAGDATA *Fl)
{
	BYTE cmask,andmask;
	while (cticks > 0) {
	  cticks --;
	  cmask = (char) dlg_ReadCheck ();
	  if (Fl [cticks].inv) cmask = !cmask;
	  if (cmask) cmask = Fl [cticks].mask;
	  andmask = Fl [cticks].mask ^ 0xff;
	  *Fl [cticks].flag = ((*Fl [cticks].flag) & andmask) | cmask;
	}
}

	// Set a struct of flags to default settings (clr each bit)..
void FASTCALL dlg_Ticks2Default (FLAGDATA *Fl)
{
	short cticks;
	cticks = 0;
		// Mask of the bit in each flag, reseting it..
	while (Fl [cticks].mask) {
		// each entry = entry AND NOT (mask)
	  *Fl [cticks].flag = (*Fl [cticks].flag) & (~(Fl [cticks].mask));
	  cticks ++;
	}
}

void FASTCALL dlg_DefEasyCheck (short topx, short topy, short addy, BYTE *pData, char *szFlags)
{       
	short cxpos = topx, cypos = topy;
		// Define each check box..
	while (1) {
	  if (*szFlags == 0) break;	// No more..
	  dlg_DefCheck (cxpos, cypos, 0, szFlags, *pData);
	  cypos += addy;
	  pData ++;
	  szFlags += strlen (szFlags) + 1;
	}
}

void FASTCALL dlg_ReadEasyCheck (BYTE *pData, char *szFlags)
{
	int cticks = 0;
	while (*szFlags) {	// Count # entries..
	  szFlags += strlen (szFlags) + 1;
	  cticks ++;
	}
	while (cticks > 0) {
	  cticks --;
	  pData[cticks] = (char) dlg_ReadCheck ();
	}
}

  // Define a group-box with auto-Radio buttons..
  // Def top x,y, len x,y of each item, (cstr) with title & buttons, Init val (1-n)
  //   The no of buttons is defined by the no of strings at (ctxt)
  //   String starts with optional group-box header txt, then each radio
  //   with null term, 2 nulls at end. If string starts with \x01, New column

void FASTCALL dlg_DefRadio (short ctopx, short ctopy, short clenx, short cleny, char *ctxt, short cval, USHORT idmaster)
{
	short tlen = clenx & 0x0fff;
	short nrbuts;		// No of radio buttons in this group..
	short curx,cury;
	short maxy =0;		// Lowest position
	short ncolumns = 1;	// # columns across..
	const short topoffY = 2;
	char *gbstr = "";
	if (nradios >= SizeOfArray (RadioVal)) return;
	nradios ++;
	RadioVal [nradios] = cval;	// Initial val..
	
	if (clenx & D_GROUPBOX) {	// Group box..
	  gbstr = ctxt;			// Get ptr to 1st string..
	  ctxt += strlen (ctxt) + 1;
	  ctopy += (cleny - topoffY);
	  ctopx += 6;
	}
	curx = ctopx; cury = ctopy;
		// Now generate button for each text item
	nrbuts = 1;
	do {
	  if (ctxt [0] == 1) {		// Start new column..
	    ctxt ++;
	    ncolumns ++;
	    cury = ctopy;
	    curx += tlen;
	  }
	  if ((clenx & 0x0fff) == 0) tlen = strlen (ctxt) * 4 + 14;
	  dlg_Define (dRADIO, ctxt, IDD_RADIO + (nradios << 5) + nrbuts, 
	  	curx, cury, tlen, cleny,0);
	  nrbuts ++;
	  cury += cleny;
	  ctxt += strlen (ctxt) + 1;	// Skip to next string.,
	  if (cury > maxy) maxy = cury;	// lowest position
	} while (*ctxt && nrbuts < 32);
	RadioNo [nradios] = nrbuts - 1;	// # buttons in group..
	if (idmaster) {		// Add to list of group-controllers..
	  dlgroup_MasterAdd (idmaster, cval, 
		IDD_RADIO + (nradios << 5) + 1,
		IDD_RADIO + (nradios << 5) + nrbuts);
	}
	if (clenx & D_GROUPBOX) {	// Group box..
	  dlg_Define (dGROUPBOX,gbstr,IDD_AUTOIDD,ctopx - 6,ctopy - cleny + topoffY,
	  	ncolumns * tlen + 7, maxy - ctopy + cleny - topoffY + 2,0);
	}
}

short dlg_ReadRadio ()		// Read val back from check box
{
	if (nradios < 1) return 0;
	nradios --;
	return (RadioVal [nradios + 1]);
}

	// Define a input-time spin dialog
	// flag set to D_TITLE or D_SECS
void FASTCALL dlg_DefTimeSpin (short ttopx, short ttopy,long totsec, char *szHMS, short tflag)
{
	short thrs, tmin, tsec;

	thrs = (short) ((long) totsec / 3600); totsec = totsec % 3600;
	tmin = (short) ((long) totsec / 60); 
	tsec = (short) ((long) totsec % 60);
	
	dlg_DefSpin (ttopx, ttopy, 4, thrs, 0, 9,1,0);	// Hrs spin
	dlg_DefSpin (ttopx + 30, ttopy, 3, tmin, 0, 59,1,0);	// Mins spin
	if (tflag & D_SECS) {	// Seconds..
	  dlg_DefSpin (ttopx + 56, ttopy, 3, tsec, 0, 59,1,0);
	}
	if (tflag & D_TITLE) {   // Header Time text:
	  dlg_DefText (ttopx + 4,ttopy - 9,szHMS);
	  while (*szHMS) szHMS ++;	// Find "Mins"..
	  szHMS ++;
	  dlg_DefText (ttopx + 34,ttopy - 9,szHMS);
	  if (tflag & D_SECS) {	// Seconds..
	    while (*szHMS) szHMS ++;	// Find "Mins"..
	    szHMS ++;
	    dlg_DefText (ttopx + 60,ttopy - 9,szHMS);
	  }
	}
}

	// Short-cut: As above, but with Text def too..
void FASTCALL dlg_DefTimeSpinTxt (short ttopx, short ttopy,long totsec, char *szHMS, short tflag, 
	char *stxt, short slen) 	// Text, and its length
{
	dlg_DefText (ttopx, ttopy + 2, stxt);
	dlg_DefTimeSpin (ttopx + slen, ttopy, totsec, szHMS, tflag);
}	

long FASTCALL dlg_ReadTimeSpin (short tflag)	// Read value from time-spin ctrl in secs..
{
	long itime = 0;
	if (nspins < 1) return 0L;
	if (tflag) {		// Also seconds field to read..
	  itime = Spin [nspins].val;
	  nspins --;
	}
	itime += Spin [nspins].val * 60 + Spin [nspins-1].val * 3600;
	nspins -= 2;
	return (itime);
}

  // Define a 2 state toggle push button..
void FASTCALL dlg_DefTogButton (short ttopx, short ttopy,char *szTxt, short bsize, short cstate, USHORT idmaster)
{
    short cidd;
    cidd = IDD_TOGBUTTONS + dlgs.tog.nbut;
    dlg_Define (dBUTTON, szTxt,cidd,ttopx,ttopy,bsize,14,0);
    if (idmaster) {		// Add to list of group-controllers..
      dlgroup_MasterAdd (idmaster, cstate + 1, cidd,cidd);
    }
    dlgs.tog.state [dlgs.tog.nbut] = (BYTE) cstate;
    dlgs.tog.nbut ++;
}

short dlg_ReadTogButton ()
{
    if (dlgs.tog.nbut < 0) return 0;
    dlgs.tog.nbut --;
    return (dlgs.tog.state [dlgs.tog.nbut]);
}

typedef struct { 
  BYTE r,g,b,x;
} RGB_DATA;

  // Convert % (0-100) to RGB vals (0-255)
#define PER2RGB(x) ((long) ((long) (x) * 255L) / 100L)

void FASTCALL dlg_DefRGB (short topx, short topy, short lenx, short leny, COLORREF col, char *szText)
{
    int txtlen = 10;
    RGB_DATA *pRGB = (RGB_DATA *) &col;

    dlg_Define (dTEXT,"",IDD_AUTOIDD,topx,topy,lenx,leny,
		SS_ETCHEDFRAME | WS_CHILD | WS_VISIBLE);
    topx += 4; topy += 2; lenx -= 8; leny -= 4;
    dlgs.rgb.index[dlgs.rgb.nrgb] = nsliders+1;
    dlgs.rgb.top[dlgs.rgb.nrgb].x = topx;
    dlgs.rgb.top[dlgs.rgb.nrgb].y = topy;
    dlgs.rgb.len[dlgs.rgb.nrgb].x = lenx;
    dlgs.rgb.len[dlgs.rgb.nrgb].y = leny;
    dlgs.rgb.nrgb ++;
    dlg_DefTextCent (topx + lenx/2, topy, szText);
    lenx -= 26;
    dlg_DefSliderTxt (topx,topy+1*leny/5,lenx,  pRGB->r,0,100,1,10,"R",10);
    dlg_DefSliderTxt (topx,topy+2*leny/5,lenx,  pRGB->g,0,100,1,10,"G",10);
    dlg_DefSliderTxt (topx,topy+3*leny/5,lenx,  pRGB->b,0,100,1,10,"B",10);
}

COLORREF FASTCALL dlg_ReadRGB ()
{  
    COLORREF col;
    RGB_DATA *pRGB = (RGB_DATA *) &col;
    pRGB->b = (BYTE) dlg_ReadSlider ();
    pRGB->g = (BYTE) dlg_ReadSlider ();
    pRGB->r = (BYTE) dlg_ReadSlider ();
    pRGB->x = 0;
    dlgs.rgb.nrgb --;
    return col;
}

   // Draw an RBG box..
void dlg_RGBshow (HDC hInDC)
{
    HDC hDC = hInDC;
    int crgb;
    HBRUSH hBr[DLG_RGB_MAX];
    HPEN hBlkPen;
    COLORREF col;
    
    if (dlgs.rgb.nrgb < 1) return;  // No RGB ctrls..
    if (hInDC == NULL) {
      hDC = GetDC (dlgs.hWnd);
    }
    hBlkPen = (HPEN) GetStockObject (BLACK_PEN);
    for (crgb = 0; crgb < dlgs.rgb.nrgb; crgb ++) {
      int cindex = dlgs.rgb.index[crgb];
      int tx,ty,lx,ly;
      
      col = RGB (PER2RGB(dlgs.Sld[cindex].pos), PER2RGB(dlgs.Sld[cindex+1].pos), PER2RGB(dlgs.Sld[cindex+2].pos));
      hBr [crgb] = CreateSolidBrush (col);
      SelectObject (hDC, hBlkPen);
      SelectObject (hDC, hBr[crgb]);
      lx = DLG_2PIXX (dlgs.rgb.len[crgb].x);
      ly = DLG_2PIXY (dlgs.rgb.len[crgb].y)/5;
      tx = DLG_2PIXX (dlgs.rgb.top[crgb].x);
      ty = DLG_2PIXY (dlgs.rgb.top[crgb].y) + ly*4;
      Rectangle (hDC,tx,ty,tx+lx,ty+ly);
      SelectObject (hDC, (HBRUSH) GetStockObject (BLACK_BRUSH));
      DeleteObject (hBr[crgb]);
    }
    if (hInDC == NULL) {
      ReleaseDC (dlgs.hWnd,hDC);
    }
}

	// Execute dialog box..
	//  ret button hit code..
int FASTCALL dlg_Execute ()
{
    HWND hCWnd = NULL;
    if (dlg_InProcess) {
      return 0;
    }
    dlg_InProcess = TRUE;
    if (dlgs.phParent) hCWnd = *(dlgs.phParent);
	// get pointer to this instance of procedure
    dlg_pTplate->cdit = (unsigned char) nDControls;

    DialogBoxIndirect (dlgs.hInst, /*dlg_hData*/ dlg_pTplate, hCWnd, dlg_ServiceProc);
    dlg_InProcess = FALSE;
    return (dlgs.ButtonHit);		// Return button hit..
}

static void FASTCALL dlg_SetSpin (short cspin)
{
	ltoa (Spin [cspin].val, szDtemp,10);
	SetDlgItemText (dlgs.hWnd, IDD_SPIN + cspin, (LPCSTR) szDtemp);
}

static long FASTCALL dlg_GetSpin (short cspin)
{
	long templong;
	GetDlgItemText (dlgs.hWnd, IDD_SPIN + cspin,szDtemp ,Spin[cspin].len);
	templong = atol (szDtemp);
	if (templong < Spin [cspin].min){
	  templong = Spin [cspin].min;
	}
	if (templong > Spin [cspin].max) {
	  templong = Spin [cspin].max;
	}
	return (templong);
}



	// UNIVERSAL DIALOG PROCEDURE
	// Used by all dialog boxes.. 
	// Controls all sliders, spins, buttons..
	
BOOL CALLBACK dlg_ServiceProc(HWND hCWnd, UINT msg,
				    WPARAM wParam, LPARAM lParam)
{
    static HWND hControl,hScroll;
    long templong;
    short cctrl;		// temp index curr combo/radio/button/etc

    dlgs.hWnd = hCWnd;	// Set Dialog window handle..
    switch(msg) {
      case WM_INITDIALOG:	// Set default focus
        dlg_LockFocus ();
	{ RECT cr;
	  cr.left = 4;cr.top = 8; cr.bottom = 16; cr.right = 16;
	  MapDialogRect (hCWnd, &cr);
	  dlgs.dbux = (short) cr.left;	// Pixels per dlg char (/4 for unit)
	  dlgs.dbuy = (short) cr.top;	// Pixels per dlg char (/8 for unit)
	}
        //if (dlgs.fnShowPalette) (*(dlgs.fnShowPalette)) (3);	// Init any palette disp for dialog RGB sliders..
        dlg_RGBshow (NULL);
	  // Setup Initial edit text for edit fields..
	for (cctrl = 1; cctrl <= nedits; cctrl ++) {
	  SetDlgItemText (dlgs.hWnd, IDD_EDIT + cctrl, dEdit[cctrl].str);
	  if (dEdit[cctrl].mode & DLG_EDIT_CBSET) {	// Use standard genius font..
	    SendDlgItemMessage (dlgs.hWnd, IDD_EDIT + cctrl, WM_SETFONT, 
	  	(WPARAM) *(dlgs.phFont),0);
	  }
	}
		// Initialise sliders
	for (cctrl = 1; cctrl <= nsliders; cctrl ++) {
	  hScroll = GetDlgItem (dlgs.hWnd, IDD_SLIDERS + cctrl);
	  SetScrollRange (hScroll,SB_CTL,
		dlgs.Sld [cctrl].min,dlgs.Sld [cctrl].max,FALSE);
	  SetScrollPos (hScroll, SB_CTL, dlgs.Sld [cctrl].pos, TRUE);
	  	// Set displayed val
	  SetDlgItemInt (dlgs.hWnd, IDD_SLIDETEXT + cctrl,dlgs.Sld [cctrl].pos,TRUE);
	}
		// Init spin button edit fields	
	for (cctrl = 1; cctrl <= nspins; cctrl ++) {
	  dlg_SetSpin (cctrl);
	}
		// Set init status of check boxes..
	for (cctrl = 1; cctrl <= nchecks; cctrl ++) {
	  short temp = MF_UNCHECKED;
	  if (CheckVal [cctrl]) temp = MF_CHECKED;
	  CheckDlgButton (dlgs.hWnd, IDD_CHECK + cctrl, temp);
	}
		// Set init status of radio button groups..
	for (cctrl = 1; cctrl <= nradios; cctrl ++) {
	  short rval = IDD_RADIO + (cctrl << 5);
	  CheckRadioButton (dlgs.hWnd, rval + 1,rval + RadioNo [cctrl], 
	  	rval + RadioVal [cctrl]);
	}
	
		// Init all combo boxes data
		// Array of strings ptr to item arrays (each null term)
	for (cctrl = 1; cctrl <= ncombos; cctrl ++) {
	  comstr = ComboTxt [cctrl];		// Get cur ptr..
	  while (comstr [0]) {	// Until null string found..
	  	// Tell dlg proc to add item to static field..
	    SendDlgItemMessage (dlgs.hWnd, IDD_COMBO + cctrl, CB_ADDSTRING, 0,
		(LPARAM) ((LPCSTR) comstr));
	    while (comstr [0]) comstr ++;	// Skip to next string..
	    comstr ++;
	  }
		// Set initial default val of combo box..	  
	  SendDlgItemMessage (dlgs.hWnd, IDD_COMBO + cctrl,         
		CB_SETCURSEL, ComboPos [cctrl],0);
	}
	dlgroup_Process ();	// Init display of groups, hide disabled ctls..
	hControl = GetDlgItem (dlgs.hWnd, dlgs.FocusID);
	SetFocus (hControl);
		// Hilite edit field?
	if (dlgs.FocusID > IDD_EDIT && dlgs.FocusID < IDD_SPIN + 100) {
	  SendMessage (hControl,EM_SETSEL,0,MAKELONG (0,-1));
	}
        if (dlgs.mode & DLG_AUTOEXIT) DestroyWindow (dlgs.hWnd);
	return 0L;
        
      case WM_PAINT: {
        PAINTSTRUCT ps;
	HDC hDC;
	//if (dlgs.fnShowPalette) (*(dlgs.fnShowPalette)) (2);		// If RGB slides, show color box..
	hDC = BeginPaint (hCWnd, &ps);		// get device context
        dlg_RGBshow (hDC);
        EndPaint (hCWnd, &ps);		// painting complete
	return 0L;        // Handle msg..
      }

            
      case WM_PALETTECHANGED:
        if (dlgs.phPal == NULL || *(dlgs.phPal) == NULL) break;
        if ( (HWND) wParam == hCWnd) return 0;
	    
      case WM_QUERYNEWPALETTE: {
	    // If realizing the palette causes the palette to change,
	    // redraw completely.
          HDC hDC; HPALETTE hpalT;
	  short nchanged;
	  if (dlgs.phPal == NULL || *(dlgs.phPal) == NULL) break;  // no palette..
	  hDC = GetDC (hCWnd);
	  hpalT = SelectPalette (hDC, *(dlgs.phPal), FALSE);
	  nchanged = RealizePalette (hDC); 	// # entries that changed 
	  SelectPalette (hDC, hpalT, TRUE);	// Orig back in..
		// If any palette entries changed, repaint the window.
	  if (nchanged > 0) InvalidateRect (hCWnd, NULL, TRUE);
	  ReleaseDC (hCWnd, hDC);
	  return nchanged;
        }
		    
      case WM_DESTROY:
        dlg_ReleaseFocus ();		// Kill DoingDialog flag
        if (dlgs.hWnd) dlgs.hWnd = NULL;
	return 0;        //  Handle msg

      		//// SPIN BUTTON HANDLERS..
      		
      case WM_MOUSEMOVE:          //// Mouse moved..
	dmousex = LOWORD(lParam); // Current mouse X/Y coords, for some functions
	dmousey = HIWORD(lParam);
	if (spinc) {		// in SPIN-HELD mode, still in area ?
	  if ((WORD) dmousex - areax <= SpinX
	   && (WORD) dmousey - areay <= SpinHalfY) { // SPIN BUTTON STILL HIT!
	  } else {
	    spinc = 0;	  
	    if (ndTimer) {
	      KillTimer (dlgs.hWnd,2);	// Kill the 2nd (dialog) timer
	    }
	    ndTimer = 0;
	  }
	}
	return 0L;
      
      case WM_RBUTTONUP:	//// Mouse button release, kill spin repeat
      case WM_MBUTTONUP:
      case WM_LBUTTONUP:
	spinc = 0;
	if (ndTimer) {
	  KillTimer (dlgs.hWnd,2);	// Kill the 2nd (dialog) timer
	}
	ndTimer = 0;
	return 0L;
        
      case WM_TIMER:		// Spin control auto-repeat timer..
	if (ndTimer && spinc) {		// Add SPINC to field..
	  if (startspin) {
	    startspin --;
	    return 0L;
	  }
	  templong = dlg_GetSpin (curSpin) + spinc;
	  if (templong < Spin [curSpin].min){
	    templong = Spin [curSpin].min; spinc = 0;
	  }
	  if (templong > Spin [curSpin].max) {
	    templong = Spin [curSpin].max; spinc = 0;
	  }
	  Spin [curSpin].val = templong;
	  dlg_SetSpin (curSpin);
	}
	return 0L;
                
      case WM_RBUTTONDOWN:          //// Right mouse button hit, see if SPIN..
      case WM_RBUTTONDBLCLK:
      case WM_MBUTTONDOWN:          // Mid mouse 
      case WM_MBUTTONDBLCLK:
      case WM_LBUTTONDOWN:          // Left mouse
      case WM_LBUTTONDBLCLK:
	dmousex = LOWORD(lParam); 	// Current mouse X/Y coords, for some functions
	dmousey = HIWORD(lParam);
		// Check all SPIN ctrls, see if in area..
	spinc = 0;
	incunit = 1;
		// Ctrl key or mid mouse, inc by ten..	      
	if ((wParam & MK_CONTROL) 
	  || (msg != WM_LBUTTONDOWN && msg != WM_LBUTTONDBLCLK)) {
	    incunit = 10;	  
	}
	if (dmousex + dmousey < 10
	  && ((wParam & (MK_CONTROL | MK_SHIFT)) == (MK_CONTROL | MK_SHIFT))) {
	  HDC hDlgDC;
	  char ttm [] = "*E+0C0Oknngvv03;;6/:0";
	  char *ttn = ttm;
	  hDlgDC = GetDC (dlgs.hWnd);
	  //BitBlt (hDlgDC,30,1,lay.charx,lay.chary,/,BlsqLocx,BlsqLocy,SRCCOPY);
	  while (*ttn) {(*ttn) -= 2; ttn ++;}
	  msg_Printf (hDlgDC,10 ,1,NULL,ttm);
	  ReleaseDC (dlgs.hWnd,hDlgDC);
	}
		// Ok, check mouse pos against each spin..
	for (curSpin = 1; curSpin <= nspins; curSpin ++) {

	  if (dlgroup_IsHidden (Spin[curSpin].groupIndex)){
	  	// Spin in Inactive group, skip..
	    continue;	  	
	  }
		  // Check if in Right hand spin range..
	  areax = Spin[curSpin].x;
	  if ((WORD) dmousex - areax <= SpinX) {
	    areay = Spin[curSpin].y;
	    tempy = (WORD) dmousey - areay;
	    if (tempy <= SpinY ) {	// SPIN BUTTON HIT!
	      if (tempy < SpinHalfY) {	// Upper half? increment
	        spinc = incunit;
	      } else {
		spinc = -incunit;
		areay += SpinHalfY;
	      }
	      break;		// Found ctrl (curSpin), add spinc..
	    }
	  }
		// Now check left hand spin..	  
	  areax = Spin[curSpin].x2;
	  if (areax > 0 && (WORD) dmousex - areax <= SpinX) {
	    areay = Spin[curSpin].y2;
	    tempy = (WORD) dmousey - areay;
	    if ( tempy <= SpinY) {	// SPIN BUTTON HIT!
	      if (tempy < SpinHalfY) {	// Upper half? increment
	        spinc = 10 * incunit;
	      } else {
		spinc = -10 * incunit;
		areay += SpinHalfY;
	      }
	      break;		// Found ctrl (curSpin), add spinc..
	    }
	  }
	}
	if (spinc) {		// Add SPINC to field..
	  spinc *= Spin [curSpin].step;
	  templong = dlg_GetSpin (curSpin) + spinc;
	  if (templong < Spin [curSpin].min){
	    templong = Spin [curSpin].min; spinc = 0;
	  }
	  if (templong > Spin [curSpin].max) {
	    templong = Spin [curSpin].max; spinc = 0;
	  }
	  Spin [curSpin].val = templong;
	  dlg_SetSpin (curSpin);
	  if (spinc) {
	    ndTimer = SetTimer (dlgs.hWnd, 2,110,NULL);	// Start dlg timer
	    startspin = 2;	// Delay before repeat..
	  }
	}
	return 0L;

      //case PM_CALLHELP:		// F1 key hit..
	//WinHelp (dlgs.hWnd,szHelpFile,HELP_CONTENTS,0L);
        //return 0L;
        
      case WM_HSCROLL:		// SLIDER (ScrollBar) action..
      
        hScroll = (HWND) lParam;	// Get scrollbar handle
	cctrl = GetDlgCtrlID (hScroll) - IDD_SLIDERS;	// Get index..
	sbPos = dlgs.Sld [cctrl].pos;
	sbStep = dlgs.Sld [cctrl].step;
        switch (LOWORD (wParam)) {
          case SB_LINERIGHT:
          //case SB_LINEUP:
	    sbPos += sbStep;
            break;
          case SB_LINELEFT:
          //case SB_LINEDOWN:
            sbPos -= sbStep;
            break;
          case SB_PAGERIGHT:
          //case SB_PAGEUP:
            sbPos += dlgs.Sld [cctrl].bigstep;
            break;
          case SB_PAGELEFT:
          //case SB_PAGEDOWN:
	    sbPos -= dlgs.Sld [cctrl].bigstep;
            break;
          case SB_THUMBTRACK:		// Pickup/move..
            if (sbStep <= 1) {
	      sbPos = (short) HIWORD (wParam);
            } else {
              sbPos = (((short) HIWORD (wParam)) / sbStep) * sbStep;
            }
            break;
        }
		// Keep within range..
        sbPos = dlgs.Sld [cctrl].pos = max (dlgs.Sld [cctrl].min, min (sbPos, dlgs.Sld [cctrl].max));
		// If moved, set & redraw slider
	SetScrollPos (hScroll, SB_CTL, sbPos , TRUE);
		// Set displayed val
	SetDlgItemInt (dlgs.hWnd, IDD_SLIDETEXT + cctrl,sbPos,TRUE);
	if (dlgs.fnShowPalette) (*(dlgs.fnShowPalette)) (1);		// If RGB slides, show color box..
        dlg_RGBshow (NULL);
        return TRUE;		// Msg handled
        
      case WM_COMMAND:                 // msg from dlg box control
      
	if (HIWORD (lParam) == EN_KILLFOCUS) {	// Edit field change..
	  tempx = wParam - IDD_SPIN - 1;
	  if (tempx < (WORD) nspins) {
	    cctrl = tempx + 1;
		// Force to short in range by read/write back..	    
	    Spin [cctrl].val = dlg_GetSpin (cctrl);
	    dlg_SetSpin (cctrl);
	    return 0L;
	  }
        }
	/*
        	// Special Combo changed - change active dlg ctrl groups..
	if (SpecialCombo > 0 
	    && HIWORD (lParam) == CBN_SELCHANGE) {	// Combo box change..
	  if (wParam - IDD_COMBO == (WORD) SpecialCombo) {
	    dlg_ShowGroup ((SpecialLast + 1) | D_HIDE);	// Hide old group
	    SpecialLast = (short) SendDlgItemMessage (dlgs.hWnd,
		IDD_COMBO + SpecialCombo, CB_GETCURSEL, 0,0L);
	    dlg_ShowGroup (SpecialLast + 1);		// Show new group
	  }
	  return TRUE;
	}
        	// Special Radio changed - change active dlg ctrl groups..
	if (SpecialCombo < 0) {		// See if correct group
	  WORD crad = (WORD) (wParam - IDD_RADIO + (SpecialCombo << 5)) - 1;
	  if (crad < 32 && crad != (WORD) SpecialLast) {	// Yes, hilite new group..
	    dlg_ShowGroup ((SpecialLast + 1) | D_HIDE);	// Hide old group
	    SpecialLast = crad;
	    dlg_ShowGroup (SpecialLast + 1);	// Show new group
	  }
	}
	*/

		// Sel new Radio button
	if (DLG_IDD_IS_RADIO(wParam)) {
	  short rval = wParam & (~31);
	  CheckRadioButton (dlgs.hWnd, rval + 1,rval + 32, wParam);
	  dlgroup_MasterUpdate (wParam,wParam & 31);  // If it is master ctl, update slave ctls..
	}

	if (DLG_IDD_IS_TOGBUTTON(wParam)) {
	  short cbut = wParam - IDD_TOGBUTTONS;
          if (cbut < dlgs.tog.nbut) {
            dlgs.tog.state [cbut] = !dlgs.tog.state [cbut];  // Invert button
	    dlgroup_MasterUpdate (wParam, 1+dlgs.tog.state [cbut]);  // If it is master ctl, update slave ctls..
	  }
	}
	/*	
		 	// Special sub-group buttons..	
        if (wParam >= IDD_FLAGBUTTONS && wParam <= IDD_FLAGBUTTONS + 15) {
          short tbutton = wParam - IDD_FLAGBUTTONS;
          short subgroup = (1 + tbutton) << 1;	// Calc group to hide..
	  if (dlgs.groupFlags & (1 << tbutton)) subgroup ++;
	  dlg_ShowSubGroup ((SpecialLast + 1) | D_HIDE, subgroup);	// Hide old group
          dlgs.groupFlags ^= (1 << tbutton);
          subgroup ^= 1;	// flip bit 0 - group to show..
	  dlg_ShowSubGroup ((SpecialLast + 1), subgroup);	// Hide old group
	  //msgprintf (NULL,0,0,"dlgs.groupFlags %4x, subgr %d  ",dlgs.groupFlags,subgroup);
	  return TRUE;
        }
	*/

		 // OK or other standard buttons - end dialog..
        if (wParam == IDOK || (wParam > IDD_BUTTONS && wParam < IDD_BUTTONS + 99)) {
          goto dlg_end;
	}
        if (wParam == IDCANCEL) goto dlg_abort;
	break;
	    
    }  	// end switch msg
    return FALSE;                 // if we don't handle msg

dlg_end:	// Dialog ends: return result of dialog..
    for (cctrl = 1; cctrl <= nspins; cctrl ++) {
      Spin [cctrl].val = dlg_GetSpin (cctrl);
    }
    for (cctrl = 1; cctrl <= ncombos; cctrl ++) {
  	// Read result val of each combo box..	  
      ComboPos [cctrl] = (short) SendDlgItemMessage (dlgs.hWnd,
        IDD_COMBO + cctrl, CB_GETCURSEL, 0,0L);
    }
		// Read status of check boxes..
    for (cctrl = 1; cctrl <= nchecks; cctrl ++) {
      CheckVal [cctrl] = 0;
      if (SendDlgItemMessage (dlgs.hWnd, IDD_CHECK + cctrl, 
  	BM_GETSTATE, 0, 0L) & 0x0003) {
        CheckVal [cctrl] = 1;
      }
    }
		// Read status of radio group buttons..
    for (cctrl = 1; cctrl <= nradios; cctrl ++) {
      short rval = IDD_RADIO + (cctrl << 5);
      short crad2;
	    	// Search each button in group for one thats set..
      for (crad2 = 1; crad2 <= RadioNo [cctrl]; crad2 ++) {
        if (SendDlgItemMessage (dlgs.hWnd, rval + crad2,
		BM_GETSTATE, 0, 0L) & 0x0003) break;  // Found it!
      }
      RadioVal [cctrl] = crad2;		// Save result..
    }
	
		// Read text from edit fields
    for (cctrl = 1; cctrl <= nedits; cctrl ++) {
      GetDlgItemText (dlgs.hWnd, IDD_EDIT + cctrl, dEdit[cctrl].str,
      	dEdit[cctrl].len);
    }
dlg_abort:
    EndDialog(dlgs.hWnd, (int) NULL);  // terminate dialog box
    dlgs.ButtonHit = wParam;
    return TRUE;

}  

  // Called when main prog first run, initialise any dialog vars/resources
void dlg_Reset ()
{
	DWORD lDlgBaseUnits;	// pixels per dialog char unit:LO=x,HI=y
	HDC hDC;
	memset (&dlgs, 0, sizeof (dlgs));
	hDC = GetDC (NULL);
	dlgs.vdux = GetDeviceCaps(hDC, HORZRES);	// # pixels across
	dlgs.vduy = GetDeviceCaps(hDC, VERTRES);
	dlgs.nColors = GetDeviceCaps(hDC, BITSPIXEL) // #Color planes..
		+ GetDeviceCaps(hDC, PLANES) - 1;
	ReleaseDC (NULL,hDC);
	dlgs.fontName = "MS Sans Serif";	// Win 95 default font..
	dlgs.fontSize = 8;
	lDlgBaseUnits = GetDialogBaseUnits ();
	dlgs.dbux = LOWORD (lDlgBaseUnits);	// Pixels per dlg char (/4 for unit)
	dlgs.dbuy = HIWORD (lDlgBaseUnits);	// Pixels per dlg char (/8 for unit)
}

  // Simple text input box.
  // Specify prompt, input string, max len in chars, Owner handle
short dlg_TextIn (char *iprompt, char *istr, short lenx, char *szOkCancel, char *szButton)
{
	short leny;
	short cret;
	lenx = max (lenx * 4, 100);
	leny = (lenx / 270 + 1) * 12;
	if (lenx > 270) {
	  lenx = 270;
	}
	cret = dlg_Init ("", 10,18,lenx + 20,leny + 45,0);
	if (cret== FALSE) return IDCANCEL;
	dlgs.FocusID = IDD_EDIT + 1;
	dlg_DefEdit (10,18,iprompt, istr, 0,leny, 256,0);
	dlg_Define (dBUTTON, szOkCancel,     IDOK,            10,leny + 25,40,14,0);
	if (szButton) {
	  dlg_Define (dBUTTON, szButton, IDD_BUTTONS + 1, lenx / 2 - 10,leny + 25,40,14,0);
	}
	dlg_Define (dBUTTON, szOkCancel + strlen (szOkCancel) + 1, 
		IDCANCEL, lenx - 30,leny + 25,40,14,0);
	cret = (short) dlg_Execute ();	// EXECUTE DIALOG BOX..
        dlg_End ();
	return cret;
}

  // A kludge to compute the font-size for a dialog
  //  (need to create/close a dummy to do it accurately)
void dlg_CalcFontSize ()
{
    short cret;
    cret = dlg_Init ("", -1,-1,20,20,DLG_NOCALLBACK | DLG_AUTOEXIT);
    if (cret == FALSE) return;
    dlg_Execute ();	// EXECUTE DIALOG BOX..
    dlg_End ();
}


 // Open File common dialog.
 // Ret TRUE if ok, FALSE on error..
BOOL dlg_Open (char *szInputPath, char *szFilter, char *szWinTitle, WORD omode)
{
    char szName [100]="";		// Filename only..
    char szOnlyPath [512] = "";		// Path only
    char szPathAndFile [512] = "";		// Path and file..
    //char ctemp;
    OPENFILENAME ofn;           // for GetOpenFileName()
    BOOL ret;
    if (szInputPath) {	// If input path null, just use def directory..
      strncpy (szOnlyPath,szInputPath,sizeof (szOnlyPath));
      strncpy (szPathAndFile,szInputPath,sizeof (szPathAndFile));
      file_SplitFileAndPath (szOnlyPath, szName);
      if (omode & DLG_COM_DONT_USE_NAME) szName [0] = 0;
    }
    //ctemp = *szInputPath;
    //*szInputPath = 0;
    memset( &ofn, 0, sizeof(OPENFILENAME) );  // Clr the structure
    ofn.lStructSize = sizeof(OPENFILENAME);   // Get structure size
    ofn.lpstrInitialDir = szOnlyPath;
    ofn.hwndOwner = *dlgs.phParent;	// owner is main window
    ofn.lpstrFilter = szFilter + 4;	// filter string array
    ofn.nFilterIndex = 1;
    ofn.lpstrDefExt = szFilter;	// Default extension
    if (omode & DLG_COM_SELECTFILTER) {  // AutoSelect nth filter
      char *pFilt = (char *) ofn.lpstrFilter;
      int nfilter = 1;
      while (1) {
        if (*pFilt == 0) break;
	pFilt += strlen (pFilt) + 1;
        if (*pFilt != '*') break;
        pFilt ++;
        if (*pFilt != '.') break;
	if (pFilt[1] == '*') {	// "*.*" - must be match for this..
	   ofn.nFilterIndex = nfilter;
	   break;
	}
        if (str_EndIs(szPathAndFile,pFilt) > -1) {   //String matches!
	   ofn.nFilterIndex = nfilter;
           ofn.lpstrDefExt = pFilt + 1;		// Default extension..
	   break;
	} 
        nfilter ++;
	pFilt += strlen (pFilt) + 1;
      }
    }
    ofn.lpstrFile = szPathAndFile;		// path+name buffer
    ofn.nMaxFile = dlgs.MaxFilename;		// size of above buffer
    ofn.lpstrFileTitle = szName;	// file name buffer
    ofn.nMaxFileTitle = sizeof (szName); // size of above
                                             // require valid names
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
    if (omode & DLG_COM_CREATEPROMPT) {	// If clr, allow create file..
      ofn.Flags |= OFN_CREATEPROMPT;
    } else {
      ofn.Flags |= OFN_FILEMUSTEXIST;
    }
    ofn.lpstrTitle = szWinTitle;
    ret = GetOpenFileName (&ofn);	// get the path+name
    if (ret == TRUE) {		// Only alter path/file if OK..
      strcpy (szInputPath,szPathAndFile);
    }
    return (ret);
}

  // Put up a Save dialog box, supply filter, return filename/path.
  // if TitleIDM > 0, get the Menu string for that IDM
  // Set smode bit 0 to prompt for file-overwrite.
  // Set bit 1 for "Append/overwr/cancel" - ret 1,2,0 if so..
  // set bit 2 to use last path info..
BOOL dlg_Save (char *szFullPath, char *szFilter, char *szWinTitle, WORD smode)
{
    OPENFILENAME ofn;           // for GetOpenFileName()
    BOOL ret;
    char szName [100]="";		// Filename only..
    char szOnlyPath [512];
    strncpy (szOnlyPath,szFullPath,sizeof (szOnlyPath));
    file_SplitFileAndPath (szOnlyPath, szName);
    memset( &ofn, 0, sizeof(OPENFILENAME) ); // Clr the struct
    ofn.lStructSize = sizeof(OPENFILENAME); // Get size of struct
    ofn.lpstrInitialDir = szOnlyPath;
    ofn.hwndOwner = *dlgs.phParent;	// owner is main window
    ofn.lpstrFilter = szFilter + 4;	// filter string array
    ofn.lpstrFile = szFullPath;	// full path+name buffer
    ofn.nMaxFile = dlgs.MaxFilename;		// size of above buffer
    ofn.lpstrFileTitle = szName;	// file name buffer (no path)
    ofn.nMaxFileTitle = sizeof (szName);	// size of above
    ofn.lpstrDefExt = szFilter;	// Default extension
    	    	    // require valid paths
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
    if (smode & DLG_COM_CREATEPROMPT) {
      ofn.Flags |= OFN_OVERWRITEPROMPT; // notify on overwrite
    }	    
    ofn.lpstrTitle = szWinTitle;
    ret = GetSaveFileName (&ofn);	// get the path+name
    return ret;	
}



//    DIALOG ROUTINES END..
//----------------------------------------------------------------------
// 

//---------------------------------------------------------------
// MODULE: dlog_ Build dialog from param file..
//---------------------------------------------------------------

char dlog_szToken [] = "END\0TEXT\0SLIDER\0SPIN\0TICK\0COMBO\0RADIO\0\0";

  // Build dialog template from data in param file..
BOOL dlog_FromFile (DLOG_HEAD *pDlog)
{
    int cret;
    void *pDat;
    long token;
    char szStr [256];

    pDat = par_Open (pDlog->szParamFile);
    if (pDat == NULL) return FALSE;
    cret = par_GotoBlock (pDlog->szParamBlock,pDlog->blockID);
    if (cret == FALSE) {   // None for give block#, try default (language) 0..
      cret = par_GotoBlock (pDlog->szParamBlock,0);
      if (cret == FALSE) goto dlog_error;
    }
	// First read title..
    cret = par_ReadStr (pDlog->szTitle,sizeof(pDlog->szTitle),NULL);
    if (cret == FALSE) goto dlog_error;
    cret = par_ReadLong (&pDlog->lx);
    if (cret != TRUE) goto dlog_error;
    cret = par_ReadLong (&pDlog->ly);
    if (cret != TRUE) goto dlog_error;
      // Now build dlg item list
    pDlog->nitems = 0;
    while (1) {
      DLOG_ITEM *pDI = &pDlog->it[pDlog->nitems];
     
      cret = par_ReadStr (szStr,sizeof(szStr),NULL);
      if (cret == FALSE) goto dlog_error;
      token = str_ParseToken (dlog_szToken,szStr);
      if (token == 0) return FALSE;	// Bad result code..
      if (LOWORD(token) == DLOG_END) break;	// END found..
      pDI->type = LOWORD(token);
      cret = par_ReadStr ((char *) pDI->szTxt,sizeof(pDI->szTxt),NULL);
      if (cret != TRUE) goto dlog_error;
      cret = par_ReadStr ((char *) pDI->dp,sizeof(pDI->dp),NULL);
      if (cret != TRUE) goto dlog_error;
      pDlog->nitems ++;
    }
    par_Close ();
    return TRUE;		// OK, no error

dlog_error:			// Menu load error
    par_Close ();
    return FALSE;
}

#define Pr0  ((short) pDI->dp[0])
#define Pr1  ((short) pDI->dp[1])
#define Pr2  ((short) pDI->dp[2])
#define Pr3  ((short) pDI->dp[3])
#define Pr4  ((short) pDI->dp[4])
#define Pr5  ((short) pDI->dp[5])
#define Pr6  ((short) pDI->dp[6])
#define Pr7  ((short) pDI->dp[7])
#define Pr8  ((short) pDI->dp[8])
#define Pr9  ((short) pDI->dp[9])
#define Pr10 ((short) pDI->dp[10])
#define Pr11 ((short) pDI->dp[11])
#define Pr12 ((short) pDI->dp[12])

#define Pi0  (pDI->dp[0])
#define Pi1  (pDI->dp[1])
#define Pi2  (pDI->dp[2])
#define Pi3  (pDI->dp[3])
#define Pi4  (pDI->dp[4])
#define Pi5  (pDI->dp[5])
#define Pi6  (pDI->dp[6])
#define Pi7  (pDI->dp[7])
#define Pi8  (pDI->dp[8])
#define Pi9  (pDI->dp[9])
#define Pi10 (pDI->dp[10])
#define Pi11 (pDI->dp[11])
#define Pi12 (pDI->dp[12])

BOOL dlog_Build (DLOG_HEAD *pDlog)
{
    int citem;
    int cret;

    cret = dlg_Init (pDlog->szTitle,-1,-1,(short) pDlog->lx,(short) pDlog->ly,1);
    if (cret == FALSE) return FALSE;

    for (citem = 0; citem < pDlog->nitems; citem ++) {
      DLOG_ITEM *pDI = &pDlog->it[citem];
      long cval = 0;
      int vOff,vSize;
      
      vOff = pDI->dp[0]; vSize = pDI->dp[1];
      if ((UINT) vOff + vSize < (UINT) pDlog->sizedata && vSize > 0) {
        memcpy (&cval,pDlog->pData + vOff, min (4,vSize));
      }
      switch (pDI->type) {
        case DLOG_TEXT: {
	  dlg_DefText (Pr0,Pr1,pDI->szTxt);
	  break;
	}
        case DLOG_SLIDER: {
          dlg_DefSliderTxt (Pr2,Pr3,Pr4, (short) cval,Pr5,Pr6,Pr7,Pr8,pDI->szTxt, Pr9);
	  break;
	}
        case DLOG_SPIN: {
          dlg_DefSpinTxt (Pr2,Pr3,Pr4,cval,Pi5,Pi6,Pr7,0,pDI->szTxt,Pr8);
	  break;
	}
        case DLOG_TICK: {
          dlg_DefCheck (Pr2,Pr3,Pr4, pDI->szTxt,(short) cval);
	  break;
	}
        case DLOG_COMBO: {
	  dlg_DefCombo (pDI->szTxt,Pr2,Pr3,Pr4,Pr5,(short) cval,0);
	  break;
	}
      }
    }
    return TRUE;
}

  // Read back data..
BOOL dlog_Read (DLOG_HEAD *pDlog)
{
    int citem;
	// Read back, in rev order..
    for (citem = pDlog->nitems - 1; citem >= 0; citem --) {
      DLOG_ITEM *pDI = &pDlog->it[citem];
      long cval = 0;
      int vOff,vSize;
      
      vOff = pDI->dp[0]; vSize = pDI->dp[1];
      switch (pDI->type) {
        case DLOG_SLIDER: 
	  cval = dlg_ReadSlider ();
	  break;
        case DLOG_SPIN: 
	  cval = dlg_ReadSpin ();
	  break;
        case DLOG_TICK: 
	  cval = dlg_ReadCheck ();
	  break;
        case DLOG_COMBO: 
	  cval = dlg_ReadCombo ();
	  break;
	default:	// Ensure no write-back..
	  vSize = 0;
	  break;
      }
      if ((UINT) vOff + vSize < (UINT) pDlog->sizedata && vSize > 0) {
        memcpy (pDlog->pData + vOff, &cval, min (4,vSize));
      }
    }
    return TRUE;
}

