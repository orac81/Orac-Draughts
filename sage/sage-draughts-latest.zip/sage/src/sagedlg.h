//----------------------------------------------------------------------
// GENERAL PURPOSE DYNAMIC DIALOG ROUTINES (C) A.Millett.
//   .H Declarations for these..
//----------------------------------------------------------------------

#define IDD_EDIT 1010		// IDD_s start for edit fields
#define IDD_SPIN 1400		// IDD_s start for spin fields
#define IDD_SLIDERS 1500	// IDD_s start for sliders..
#define IDD_SLIDETEXT 1550	// IDD_s start for slider text
#define IDD_BUTTONS 1600	
#define IDD_COMBO 1700
#define IDD_CHECK 1750		// IDD for check boxes
#define IDD_AUTOIDD 1800	// Tells dlg_Define to auto gen one..
#define IDD_MIXED 1801		// IDDs for auto gen IDD ctrls..
#define IDD_RADIO 2048		// IDD for radio buttons..(..2400)
#define IDD_TOGBUTTONS 3000	// Toggle-buttons..

#define DLG_IDD_IS_RADIO(x) ((UINT) ((x) - IDD_RADIO) < 0x160)
#define DLG_IDD_IS_TOGBUTTON(x) ((UINT) ((x) - IDD_TOGBUTTONS) < 100)

		// Misc dialog flags defines..
#define D_HIDE ((short) 0x8000)
#define D_SECS 1		
#define D_TITLE 2
#define D_SPECIAL 0x8000 // Bit means special group-select combo
#define D_LISTBOX 2	 // Bit means permanant (non drop-down)
#define D_OFF 0
#define D_GROUPBOX 0x4000	// Means buttons have group box about them..


//#define PM_INIT_SPECIAL_GROUPS  WM_USER+1234   // Initialise "Special" groups..

	// Some preset dialog control types..
	// Used by (dcontrol) array.
#define dBUTTON 0
#define dEDIT 1
#define dTEXT 2
#define dLISTBOX 3
#define dSCROLLBAR 4
#define dCOMBOBOX 5
#define dEDITBOX 6
#define dICON 7
#define dFRAME 8
#define dCHECK 9
#define dRADIO 10
#define dGROUPBOX 11

#define DLG_EDIT_CBSET    1
#define DLG_EDIT_READONLY 2
#define DLG_EDIT_LEFTTEXT 4
#define DLG_EDIT_SCROLL 8

typedef struct {	// DATA for flags (check-boxes)..
  BYTE *flag;		// ptr to char flag
  BYTE mask;		// Bit to use..
  char inv;		// nz if inverted flag (set if on by default..)
} FLAGDATA;

extern BOOL DoingDialog;	// Window to get capture..
extern short PalRGBwide;		// Width of box to be displayed
extern BYTE saveclock;		// temp used to save clock status
extern OFSTRUCT ofBuf;		// Struct for open file..

typedef struct {	// Structure for SLIDER data
 short pos;	// Cur pos of slider
 short min,max;	// range
 short step;	// step for incr/decr
 short bigstep;	// step for big inc/dec
} SLIDER;

//---------------------------------------------------------------
// MODULE: dlgroup_ : Dialog Group control routines..
//---------------------------------------------------------------

typedef struct {
  #define DLGROUP_LEVMAX 4
  short idd;		// ID of ctrl..
  BYTE lev[DLGROUP_LEVMAX];	// Group ctrl belongs to (upto 4 levels..)
  BYTE master[DLGROUP_LEVMAX];	// Index of controlling master for given level..
  BYTE hidden;		// TRUE if ctrl is currently hidden..
} DLGROUP_CTL;

typedef struct {
  short cstate;		// Current state
  short minIDD,maxIDD;	// idd for ctrl (min/max range if radios..)
} DLGROUP_MASTER;

	// A combo box can be set to select groups on ctrls to be active
	// These are Vars for handling variable control groups..
typedef struct {
  #define DLGROUP_MAX 100
  #define DLGROUP_MASTER_MAX 20
  short nctls;		// no of variable controls in array..
  DLGROUP_CTL ctl[DLGROUP_MAX];	// data for each grouped ctrl..
  DLGROUP_CTL cur;	// Current group-level status.. (next idd, cur group)
  DLGROUP_MASTER master[DLGROUP_MASTER_MAX];	// data for each master controller..
} DLGROUP_DAT;

#define DLG_SPECIAL(x) (x) // Bit means special group-select combo

BOOL dlgroup_New (short);
void dlgroup_Next ();
void dlgroup_End ();

typedef struct {
  #define DLG_TOGBUT_MAX 20
  BYTE state[DLG_TOGBUT_MAX];
  short nbut;
} DLG_TOGBUT;

typedef struct {
  #define DLG_RGB_MAX 12
  short index[DLG_RGB_MAX];
  POINT top[DLG_RGB_MAX];
  POINT len[DLG_RGB_MAX];
  short nrgb;
} DLG_RGB;

typedef struct {	// DIALOG VARIABLES..
  short FocusID;	// IDD_ no for Focus field
  short ButtonHit;		// IDD_ Val of button pushed
  void (*fnInit)();	// External routine called every time dialog starts
  void (*fnEnd)();	// Ext called on dlg ending..
  void (*fnShowPalette)(short);	// Ext called on showing palette display..
  HWND *phParent;	// Ptr to parent window which dlg is attached..
  short dbux;		// Pixels per char width (/4 for dlg unit)
  short dbuy;		// Pixels per char height(/8 for dlg unit)
  short vdux,vduy;	// Size of ourput screen
  short nColors;	// color depth in bits..
  short topx,topy;	// Top left in Dialog units..
  short lenx,leny;	// Size in Dlg units
  short pixx,pixy;	// Size in pixels
  short MaxFilename;	// Max len of Filename in common dialog open/save..
  HINSTANCE hInst;	// Program instance handle.
  HFONT *phFont;	// Ptr to 2nd font..
  HPALETTE *phPal;	// Ptr to palette..
  char *fontName;	// Font to use for dialog, also for computing size of dlg base units..
  short fontSize;	// Size in points..
	// PRIVATE VARS for (g32dlg.cpp)
  BYTE privateStart;
  WORD mode;
  HWND hWnd;		// Handle of current dialog window..
	// Slider group data..
  SLIDER Sld [30];	// Space for slider controls..
  DLG_TOGBUT tog;	// Toggle-button data group..
  DLG_RGB rgb;
  DLGROUP_DAT grp;	// Data for switchable groups of controls..
  short autoIDD;	// Auto-inc id for generic ctrls..
  BYTE privateEnd;
} dlgSTRUCT;


extern dlgSTRUCT dlgs;		// Dialog variable struct

  // Macros convert Dialog Base Units to pixels..
#define DLG_2PIXX(x) (((x)*dlgs.dbux)/4)
#define DLG_2PIXY(y) (((y)*dlgs.dbuy)/8)

	// PCS DIALOG API Function declarations..
  #define DLG_NOCALLBACK 4  // mode - do not use call-backs to freeze comp, etc..
  #define DLG_AUTOEXIT   8  // Exit immediately (for sizeing fonts..)

short FASTCALL dlg_Init (char *,short,short,short,short, short);
void dlg_End ();
void FASTCALL dlg_Define (short,char *,short,short,short,short ,short ,long );
void FASTCALL dlg_DefOKCancel (short, short,char *,char *,long);
 #define DLG_OKONLY 0x10000L   // Only display single OK button
void dlg_DefButtons (short, short, short, short, short, char *);
int dlg_ReadButton ();
void FASTCALL dlg_DefText (short , short , char *);
void FASTCALL dlg_DefTextCent (short, short, char *);
void FASTCALL dlg_DefTextBox (short, short, short, short, char *,int);
void FASTCALL dlg_DefEdit (short,short,char *,char far *,short,short,short,BYTE);
void FASTCALL dlg_DefSlider (long,short,short,short,short,short,short,short,short,short,short,short);
void FASTCALL dlg_DefSliderTxt (short,short,short,short,short,short,short,short,char *,short);
short dlg_ReadSlider ();
void FASTCALL dlg_DefSpin (short,short,short,long,long,long,short,short);
void FASTCALL dlg_DefSpinTxt (short,short,short,long,long,long,short,short,char *,short);
long dlg_ReadSpin ();
void FASTCALL dlg_DefCombo (char *,short,short,short,short,short,short);
void FASTCALL dlg_DefComboTxt (char *,short,short,short,short,short,short,char *);
short dlg_ReadCombo ();
void FASTCALL dlg_DefCheck (short,short,short,char *,short);
short dlg_ReadCheck ();
void FASTCALL dlg_DefTicks (FLAGDATA *,short,short,short,short,short,short,char *);
void FASTCALL dlg_ReadTicks (FLAGDATA *);
void FASTCALL dlg_Ticks2Default (FLAGDATA *);
void FASTCALL dlg_DefEasyCheck (short topx, short topy, short addy, BYTE *pData, char *szFlags);
void FASTCALL dlg_ReadEasyCheck (BYTE *pData, char *szFlags);
void FASTCALL dlg_DefRadio (short,short,short,short,char *,short,USHORT);
short dlg_ReadRadio ();
void FASTCALL dlg_DefTimeSpin (short,short,long,char *,short);
void FASTCALL dlg_DefTimeSpinTxt (short,short,long,char *,short,char *,short);
long FASTCALL dlg_ReadTimeSpin (short);
void FASTCALL dlg_DefTogButton (short,short,char *,short,short,USHORT);
short dlg_ReadTogButton ();
void FASTCALL dlg_DefRGB (short, short, short, short, COLORREF, char *);
COLORREF FASTCALL dlg_ReadRGB ();
int  FASTCALL dlg_Execute ();
BOOL CALLBACK dlg_ServiceProc(HWND, UINT, WPARAM, LPARAM);
void dlg_LockFocus ();
void dlg_ReleaseFocus ();
void dlg_Reset ();
short dlg_TextIn (char *, char *, short , char *, char *);
void dlg_CalcFontSize ();
 #define DLG_COM_CREATEPROMPT 1	// If file non-existant, show "create" text,,
 #define DLG_COM_NOSPLIT      2
 #define DLG_COM_SELECTFILTER 4	// Enables auto-selection of filters..
 #define DLG_COM_DONT_USE_NAME 8 // Uses supplied path but not name..
BOOL dlg_Open (char *, char *, char *, WORD);
BOOL dlg_Save (char *, char *, char *, WORD);

//---------------------------------------------------------------
// MODULE: dlog_ Build dialog from param file..
//---------------------------------------------------------------

#define DLOG_NPAR 16

typedef struct {
  int type;
  char szTxt[256];	// Var len txt..
  long dp[DLOG_NPAR];		// Parameters..0=offset,1=sizeofvar,2=data...
} DLOG_ITEM;

typedef struct {
  char szTitle[128];
  long lx,ly;
  int nitems;
  DLOG_ITEM it[128];	// List of items..
  char *szParamFile;
  char *szParamBlock;
  short blockID;        // ID-language # id..
  BYTE *pData;
  int sizedata;
} DLOG_HEAD;


#define DLOG_END    1
#define DLOG_TEXT   2
#define DLOG_SLIDER 3
#define DLOG_SPIN   4 
#define DLOG_TICK   5
#define DLOG_COMBO  6

BOOL dlog_FromFile (DLOG_HEAD *);
BOOL dlog_Build (DLOG_HEAD *);
BOOL dlog_Read (DLOG_HEAD *);

