/*  SAGE DRAUGHTS ENGINE - Copyright A.Millett 1989-2025
*/
  
#define STRICT		// strict type checking (put before #include)
#include <windows.h>	// include file for all Windows programs
#include <stdlib.h>	// RAND
#include <stdio.h> 
#include <string.h>	// STRLEN 
#include <ctype.h>	// ISDIGIT 

#include <time.h>	// Mix TIME functions..
#include <mmsystem.h>	// Multimedia inc (SOUND..)
#include <commdlg.h>	// for common dialogs (print..
#include <io.h>		// open/write/close
#include <fcntl.h>	// open/write/close
#include <sys\stat.h>	// open/write/close

#include "sageio.h"	// Generic IO code..
#include "genio.h"
#include "sagemain.h"
#include "chengine.h"
#include "chdbase.h"	// Header with info on Checker DataBase subroutines..
#include "dbend.h"

#define hashENABLE 1
#define Italian 0

ENG_VAR eng;	// Engine vars..

#define STLONG static long
#define STINT static short
#define STUINT static unsigned short
#define STBYTE static unsigned char
#define STFUNC static

STFUNC void listpos (short );
STFUNC void miniboard (short , short , short );
STFUNC void scanmoves ();
STFUNC void FASTCALL gen1blkmove (short);
STFUNC void FASTCALL gen1whtmove (short);
STFUNC void initmvptrs (void);
STFUNC void GameBuildIndex (void);
STFUNC void bokBuildBookList (BYTE);
STFUNC short FASTCALL bokLoad (BYTE , BYTE);
STFUNC void edbInitGame ();
STFUNC void InitMoves (short);

#define BOARD8x8 FALSE
#if BOARD8x8
  #define ENG_BOARDX 8
  #define ENG_BOARDY 8
#else 
  #define ENG_BOARDX eng.boardx
  #define ENG_BOARDY eng.boardy
#endif

#define SetBrd(x,y,p) eng.checker_board [(x) + (y) * ENG_BOARDX] = p;


#define schDebug 1		// Enable debugging..

long schBegTime,schEndTime,schCurTime;
extern int eng_touse;

#define CWHITE 4		// Side to play vals..
#define CBLACK 2
#define FLIPWB 6		// to flip sides side=FLIPWB-side

	// Get color for any given move..(0=Start,or mvnum..)
#define GetColorForMove(MvNo) \
	(((MvNo ^ VarInitCol) & BitInitCol) ? CWHITE : CBLACK)

int cb_2play = FALSE;  // TRUE if external cb engine plays cur move...

//////////////////////////////////////////////////
//						//
//      CONVERSION OF ORIG BLITZ/SAGE ENGINE..	//
//						//
//////////////////////////////////////////////////

        // Mixed weights for engine, read from ini.."weights=100,100,100.."
short schIniWeights [20] =
 {100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100};

#define iniScale(v,index) ((short) ((long) (((long) v) * (long) schIniWeights [index]) / 100L))

#define iniWEIGHT   0   // Overall weighting of static board-map TIME values 
#define iniBACKROW  1   // Weighting for keeping men on back if no kings
#define iniEDGEVAL  2   // Weighting against going to side of board
#define iniCROWNRUN 3   // Weighting against going to side of board
#define iniBRIDGE   4   // Weighting for Bridge Sqr(1,3)
#define iniTRI      5   // Weighting for Triangles (1,2,6 & 2,3,7)
#define iniDOGVAL1  6   // Weighting against 1st Dogholes (1,5)
#define iniDOGVAL2  7   // Weighting against 2nd Dogholes (3,12)
#define iniCLAMPVAL 8   // Weighting for side-clamps
#define iniKHOLD    9   // Weighting for King holding 1/2 men
#define iniFWDPRUNE 10   // Weighting for King holding 1/2 men

// Global variables

short bmult = 10;		// Width multiplier
short schNsqrs = 32;	// No of squares..
short schIsMultiJump;	// Set if we are in middle of Multiple-jump..

GAMESTORE far *CheckerMoveInfo;	// Pointer to extra checker move info
UINT CheckerNParts;		// And count of # jumps in sequence..

// Local module variables..

STINT schRNDflag = 0;	// enable randomisation
STINT schMode = 0;	// -1=calc,0=No think,1=think opp,2=hint
#define schThinkHint 2
#define schThinkOpp 1
#define schThinkComp -1
#define schThinkNone 0
short schHintFrom = -1;		// Last comp move, kept for best-reply..(-1=none)
short schHintTo;

short oppKeepHash = 0;	// Set to keep hash tables (=# seconds for last calc)
short oppOverTime = 0;	// 0=normal compute, 1=overtime mode..

STINT schColor;		// Cur search colour CWHITE = 4, CBLACK = 2 
STUINT schMove;		// Cur search move (1..schNmoves)
STINT schSrc;		// Cur search source loc on board..
STINT schDest;		// Cur search dest loc..
STINT schDir;		// Cur Direction offset of move..
STINT schPiece;		// Piece being moved
STINT schCapPc;		// Piece being captured
STINT schPickVal;
STUINT schPly;		// current search ply..
STINT schCapSq;		// Capture square
STINT schScore;		// score going up tree..
STINT schBestEval;	// score coming back down
		// Lo 2 bits:= 00:"==" Accurate score, 01: "<=", 02: ">="
#define schEVALTRUE(x) ((x) & (~3))
#define schEVALLESS(x) (((x) & (~3)) | 1)
#define schEVALMORE(x) (((x) & (~3)) | 2)
#define schEVAL_IS_TRUE(x) (((x) & 3) == 0)
#define schEVAL_IS_LESS(x) (((x) & 3) == 1)
#define schEVAL_IS_MORE(x) (((x) & 3) == 2)

STINT schBestSoFar;	// Current actual best score
STINT schLastEval;	// Eval of previous iteration
STINT schLast2Eval;	// Eval of prev to last iteration
STINT schIQcut = 30;	// IQ cut off - for search end..
STINT schCut;		// Running current IQ level, cuts when IQ reached
STINT schNextBest = 0;	// Set to move from-to of move to ignore, if
STINT schPossibleNextBest = 0;	// Set to move from-to of move to ignore, if

STINT schNGame;		// No of index-entries
	// Index ptrs into Game-Store array (0..n-1)
	// Points to eng.game_store array, 1..n, 0=terminate
STBYTE schGameIndex [MAX_GAME_STORE + 2];
	// Access eng.game_store move from/to bytes as word..
#define schGAMEWORD(Pos) *((USHORT *) (&eng.game_store[Pos].src))
	// Get a game-store move word ..
#define schGetGAMEMOVE(Mov) schGAMEWORD (Mov + schGameIndex[Mov])

STINT schNmoves;		// No of moves in current mvgen..
STINT schItereval;	// Val of last iteration
STINT schNewIter;	// Flag indicates start new iteration..
int schIterMode;	// Mode for search, as below..
#define sch_NEWITER 1
#define sch_NEWSCH  2
#define sch_FAILALL 3
#define sch_FAILLO  4
#define sch_FAILHI  5

STINT xpos,ypos;		// General pos 
STINT temp,temp2;

const short schGamemode = 0;		// 0=norm, 1=play-lose,2=Krace
STINT schGameStage;		// % schBoard filled   

STLONG schTargetTime;	// Norm Target time in secs for cur search
STLONG schMaxTime;		// Max Target time in secs for cur search
STLONG schCurTargTime;	// Current target time (between above 2)
static short schTargetLevel;	// Used for fixed/infinite search levels

			//** SAGE BITS **  
STINT multijump;	// Set when search in middle of multi-jump seq..
STINT schKnockDown;
STINT qcrowned;
STINT knockflag = 1;
STINT schCapPc;


STBYTE jumpflag;
STINT dirul,dirur,dirdl,dirdr;		// Dirs Up-left..   
STINT dir2ul,dir2ur,dir2dl,dir2dr;
STBYTE schType8x8 = 0;		// Board type - set if normal english 8x8
STBYTE schType8x8inv = 0;	// Set if Inverted 8x8 (italian,spanish)
STBYTE schType10x10 = 0;		// Board type - set if international 10x10
STBYTE schItalFlag;		// Set if italian rules..

			//*** SAGE VARIABLES (IMPORT) ***  
#define EVAL_LOWEST -32760
#define EVAL_HIGHEST 32760
#define EVAL_DRAW 32764		// All scores >= this score are draws..
#define EVAL_DRAWSCH 32765	// Draw during search..

const short killerflag = 1;	// Indicates killer mode   
STBYTE prefflag = 1;	// Deep scan prefered moves on 1st ply   
STINT schWinLo = EVAL_LOWEST;  // Norm limits to alpha-beta window   
STINT schWinHi =  EVAL_HIGHEST;
STINT schWinSize = 500;		// Width of window (s5000 == 550), try 380?
STINT schStartLo,schStartHi;	// Win lo/hi at iteration start..
STINT schShortDepth = 30;	// Flag sets short look ahead and sort depth   
STBYTE schDoingShort = 0;	// Global flag tells deeper plys short in process   
STINT materialdif;	// Difference in material + for wh   
STUINT schStartPly = 1;	// No cuts on this ply

const short trimflag = 1;	// Trim window bounds as we look   
const short pvsflag = 0;	// Do PVS search after 1st move.. 

STINT xflag = 0;		// Double mvgen   
//STINT fwdflag = hashENABLE;	// Fwd prune   
STBYTE fwdflag = 1;	// Fwd prune   

STINT offrand = 7;	// Rnd offset   

STLONG schNodes;	// Overall Count of terminal nodes   
unsigned short  nalphas = 0;	// Count of alpha cuts   
STBYTE schDeepestPly;			// Deepest ply hit   

STINT protMode = 0;	// Protection mode, if ==2, then can crash..
STINT protSec = 0;	// Protection clock, when > 180 can crash
short schMixedFlags = 0;	// Mixed testing flags..
short schMixedFlagsVar = 0;	// ver for front end to change (not const)
short schDrawByRep = 50;	// # moves before draw by rep..
  // bit 0=hash-no win adj. bit 1=true hash vals only. bit 2=no draw hashs
  // bit 3=spool search to debug file.
			// Some flags..
const short testflag = 0;	// Test FILTERGEN   
const short bestflag = 15;	// Disp Best-line flag/depth   
STINT nowhite,noblack;
const short usedbflag = 0;
const short gen2flag = 0;

#define Mply 70		// Absolute max ply depth   
#define Mlist 1000	// Size of move lists   
#define MAXBRD 270

STINT schBoard [MAXBRD + 4];	// Playing area   
//  schBoard [] for english - white at top.. (sq1==87,sq32==12) (bm=2,bk=3,wm=4,wk=5)
// --  12  --  14  --  16  --  18  
// 21  --  23  --  25  --  27  --  
// --  32  --  34  --  36  --  38  
// 41  --  43  --  45  --  47  --  
// --  52  --  54  --  56  --  58  
// 61  --  63  --  65  --  67  --  
// --  72  --  74  --  76  --  78  
// 81  --  83  --  85  --  87  --  

STBYTE schCrown [MAXBRD + 4];	// Flag any crowning sqrs   
	// Sqr weight maps (also used for BOOK search..
short blmanweights [MAXBRD + 4] ;  // Weight squares for CBLACK MAN moves   
short whmanweights [MAXBRD + 4] ;
short blkingweights [MAXBRD + 4] ; // Weight squares for CBLACK KING moves   
short whkingweights [MAXBRD + 4] ;
STBYTE bokBoard [MAXBRD*2 + 4];	// Play board for book
STBYTE bokMatch [MAXBRD*2 + 4];	// Match to search for 
STBYTE bokRevMatch [MAXBRD*2 + 4];	// Match rev colours

STINT schDrawStat;	// Draw-status during search
#define DRAW_REP 1	// Possible bit values..
#define DRAW_50MOVE 2
STINT schManMoved;	// Has a man moved?
#define WMAN_MOVED 1	// True if wht man has moved in search..
#define BMAN_MOVED 2
#define MAN_TAKEN  4    // True if capture has occured..

STINT tnomoves  [Mply];	// No of moves at given ply   
STINT tcmove    [Mply];	// Move under examination at g. ply   
STINT tccut     [Mply];	// Accumulated cut off val at g. ply   
STINT tcolor    [Mply];	// Color who moves at g. ply   
STINT toldpiece [Mply]; // Value of moved piece at g. ply   
STINT ttaken    [Mply];	// Value of taken piece at g. ply   
STBYTE tjumpflag [Mply];// Stash for jump flag   
STINT tweight   [Mply];	// Storage for running weight val at g. ply   
STINT tbestmove [Mply];	// Best move so far at g. ply   
STINT tbestdir  [Mply];	// Best dir so far at g. ply   
STINT tbesteval [Mply];	// Best eval so far at g. ply   
STINT twindlo   [Mply];	// Window low value   
STINT twindhi   [Mply];	// Window high value   
STINT tnblkmen  [Mply];	// No of CBLACK men on schBoard at g. ply.   
STINT tnwhtmen  [Mply];	// No of CWHITE men on schBoard at g. ply.   
STINT tnblkking [Mply];   // No of CBLACK kings on schBoard at g. ply.   
STINT tnwhtking [Mply];   // No of CWHITE kings on schBoard at g. ply.   
STINT tdrawstat [Mply]; // Draw-status during search
STINT tmanmoved [Mply]; // Draw-status during search
STLONG thashdraw[Mply]; // Address of hash entry to wipe going back down..
STINT tpvs      [Mply]; // Principle var sch..
STINT tpvsset   [Mply];

STINT *mvbrd, *mvdir, *mveval, *mvtot, *mvindex;

typedef struct {
  short brd [Mlist];	// Move list - co-ord of each movable piece   
  short dir [Mlist];	// Dir for each move (+/-/7/9/14/18)   
  short eval [Mlist];	// Spot eval, for short look   
  short index [Mlist];	// Pointer to WH/BL pos index table..   
  short tot [Mlist];	// Max-move for 'take the most' move-scan..(Ital)
  short extra [2];	// Overflow safety buffer
} MOVETREE;

MOVETREE xmv;	// Structure for above tree..
	// Following are updated by engine always..
UINT schLegalIndex;	// Index into above for start of legal move list
UINT schNLegalMoves;	// No of moves in that list..
BYTE schLegalJump;	// Set if jumpflag set
	
STINT piececount [10] ; 	// Running count for pieces - [2] for Bman, etc   
STINT kingvals [35] ;	// Value of 1 king, 2 kings, etc..   
STINT manvals [35] ;	// Value of 1 man, 2 men, etc..   
STUINT bestline [300];	// Best-line storage..   
#define Bestline(Ply,Deep) bestline [((Ply) << 4) + Deep]

unsigned char far *besthash;	// Hashtable of best moves   
unsigned char HUGE_ *hbesthash;
STINT mhash = 1000;
STINT hashply = 4;
STINT hashele = 7;
unsigned short chash;

#define Vone 10
#define Vtwo 20
#define Vten 100
#define Vl(Eval) ((Eval) * Vone)

#define OREOVAL 140      // Oreo triangle 2,3,7   
#define BACKVAL 140      // Triangle 1,2,6   
#define BRIDGEVAL 120    // Bridge 1,3   
#define DOGVAL1 150      // Dog-Hole cramps (1,5)   
#define DOGVAL2 150      // 2nd Dog-Hole cramps (3,12)   
#define CLAMPVAL 100    // Side men hold other men clamp
#define KHOLD 200        // King holds 1/2 men
#define FWDPRUNE 3      // Fwd prune factor

short schOreoval = OREOVAL;
short schBackval = BACKVAL;
short schBridgeval = BRIDGEVAL;
short schDogval1 = DOGVAL1;
short schDogval2 = DOGVAL2;
short schClampval = CLAMPVAL;
short schKhold = KHOLD;
short schFwdPrune = FWDPRUNE;
               
#define FLIPWB 6

#define Nblkmen piececount[2]	// Alt for No of black men..   
#define Nblkking piececount[3]	
#define Nwhtmen piececount[4]   
#define Nwhtking piececount[5]  
#define Nmen piececount[2]+piececount[4]
#define Nkings piececount[3]+piececount[5]

	// Conv X,Y pos to Search-Board index..
#define schPosOf(Xpos,Ypos) ((Xpos) + (Ypos) * bmult)


			// Macro to Swap 2 moves in move table   
#define Swapmoves(Move1,Move2,regv) \
	regv = mvindex [Move1];\
	mvindex [Move1] = mvindex [Move2];\
	mvindex [Move2] = regv;\
	regv = mvbrd [Move1];\
	mvbrd [Move1] = mvbrd [Move2];\
	mvbrd [Move2] = regv;\
	regv = mveval [Move1];\
	mveval [Move1] = mveval [Move2];\
	mveval [Move2] = regv;\
	regv = mvdir [Move1];\
	mvdir [Move1] = mvdir [Move2];\
	mvdir [Move2] = regv;


	// Set X/Y pos of checker schBoard (1..N)
STFUNC void SetChessBrd (short x, short y, short a)
{
	eng.checker_board [(x-1) + (y-1) * ENG_BOARDX] = (char) a;
}

short sch2cg (short csq)		// Conv schBoard coord to Chess Gen coord
{
	return (csq - ((csq / bmult) << 1) - ENG_BOARDX - 1);
}

short cg2sch (short csq)		// Conv CG coord to search brd..
{
	return (csq + ((csq / ENG_BOARDX) << 1) + bmult + 1);
}

STFUNC void cgbrd2sch ()		// Move eng.checker_board to search-engine brd
{
	short xpos,ypos;
	short cpos;
	cpos = 0;
	for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	  for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	    schBoard[schPosOf (xpos, ypos)] = eng.checker_board [cpos]; 
	    cpos ++;
	  }
	}
}

  // Move search-engine format board (with edge-surround) to eng.checker_board..
STFUNC void sch2cgbrd (char far *chboard, short far *schBrd)
{
	short xpos,ypos;
	short cpos;
	cpos = 0;
	for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	  for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	    chboard [cpos] = (char) schBrd [schPosOf (xpos, ypos)];
	    cpos ++;
	  }
	}
}

//-------------------------------------------------------------------------
//		
// 		PIECE LIST BUILDING CODE
//
 
STINT blpos  [40];	// Pos of each piece, in order 0=King..15=Man   
STINT whpos  [40];	
STINT bltype [40];	// Type of each piece   
STINT whtype [40];
STINT tcapindex [Mply];	// Index of Capt.piece   
STINT nblack;
STINT nwhite;
STINT nwhpos;		// # entries in xxPOS tables   
STINT nblpos;
STINT piecepos [8];	// Start pos for given piece   

STINT xindex;		// Current indexed piece   
STINT capindex;		// Index Captured piece   
STINT xtakeloc;
unsigned tindex;

	// Find a piece on board, set index to new position (0=kill)
#define Updateblpos(Cbrd,Cpiece,Cval) \
	temp = findblindex (Cbrd,Cpiece);\
	blpos [temp] = Cval;

#define Updatewhpos(Cbrd,Cpiece,Cval) \
	temp = findwhindex (Cbrd,Cpiece);\
	whpos [temp] = Cval;

STFUNC void buildpos ()	// Build wh/blpos [] tables   
{
	short cbrd,xpiece;
	short maxbrd = schPosOf (ENG_BOARDX,ENG_BOARDY);
	nblack = 0;
	nwhite = 0;
	for (xpiece = Wking; xpiece >= Bman; xpiece --) {	// Kings..Pawns   
	  if (xpiece & CBLACK) {
	    piecepos [xpiece] = nblack;	// Save start for piece   
	  } else {
	    piecepos [xpiece] = nwhite;
	  }
	  for (cbrd = schPosOf (1,1); cbrd <= maxbrd; cbrd ++) {
	    if ( schBoard [cbrd] == xpiece) {
	      if (xpiece & CBLACK) {
		blpos [nblack] = cbrd;
		bltype [nblack] = xpiece;
		nblack ++;
	      } else {
		whpos [nwhite] = cbrd;
		whtype [nwhite] = xpiece;
		nwhite ++;
	      }
	    }
	  }
	}
	whpos [nwhite] = blpos [nblack] = 0;
	nblpos = nblack;
	nwhpos = nwhite;
}

STFUNC short FASTCALL findwhindex (short cbrd, short cpiece)	// Find index of white piece   
{
	register short cpos;
	cpos = piecepos [cpiece];
	if (whpos [cpos] == cbrd) {
	  return (cpos);
	}
	cpos ++;
	while (cpos < nwhpos) {
	  if (whpos [cpos] == cbrd) {
	    return (cpos);
	  }
	  cpos ++;
	}
	printsi ("W!",cbrd); printsi (",",cpiece); listpos (0);
	{ short xx = 1;
	  if (xx == 1) {
	    exit (0);
	  }
	}
	return 0;
}

STFUNC short FASTCALL findblindex (short cbrd, short cpiece)	// Find index of black piece   
{
	register short cpos;
	if (blpos [(cpos = piecepos [cpiece])] == cbrd) {
	  return (cpos);
	}
	cpos ++;
	while (cpos < nblpos) {
	  if (blpos [cpos] == cbrd) {
	    return (cpos);
	  }
	  cpos ++;
	}
	printsi ("B!",cbrd); printsi (",",cpiece); 
	listpos (0);
	{ short xx = 1;
	  if (xx == 1) {
	    exit (0);
	  }
	}
        return (0);
}

STFUNC void printlist ()
{
	short lmove;
	for (lmove = 1; lmove <= schNmoves; lmove ++) {
	  nprint = 0;
	  printsi ("Mov:",lmove);
	  printsi (",Brd:",mvbrd [lmove]);
	  printsi (",Dir:",mvdir [lmove]);
	  printsi (",Inx:",mvindex [lmove]);
          //rjust (40);
	}
	prints ("\n");
}

STFUNC void listpos (short mode)
{
	short zindex,temp;
	if (mode == 0) {
	  prints ("LISTPOS!");
	  miniboard (1,10,0);
	}
	gotoxy (1,3);
	printsi ("Cmove ",schMove); printsi ("/",schNmoves);
	printsi (",color ",schColor);
	printsi (", Cply ",schPly); printsi (", Xindex ",xindex);
	printsi (", Xbrd ",schSrc); prints ("   \n");
	nprint = 0;
	for (zindex = 0; zindex < nwhite; zindex ++) {
	  printsi ("  W:",zindex); printsi (",",whpos [zindex]);
	  printsi (",",whtype [zindex]);
	  temp = findwhindex (whpos [zindex],whtype [zindex]);
	  if ( temp != zindex) printsi ("!!",temp);
	  prints ("  ");
	  if (nprint > 67) {
            nprint = 0; prints ("\n");
	  } 
	}
	prints ("... \n");
	nprint = 0;
	for (zindex = 0; zindex < nblack; zindex ++) {
	  printsi ("  B:",zindex); printsi (",",blpos [zindex]);
	  printsi (",",bltype [zindex]);
	  temp = findblindex (blpos [zindex],bltype [zindex]);
	  if ( temp != zindex) printsi ("!!",temp);
	  prints ("  ");
	  if (nprint > 67) {
            nprint = 0; prints ("\n");
	  } 
	}
	prints ("... \n");
	#if schDebug
	  printlist ();
	#endif
        if (mode) return;
        DoMessage ("SEARCH PROBLEM - HIT SPACE TO RETRY..");
}

STFUNC void updateplay () {}	// Update eng.checker_board..

static short *keyrb,*keylb;	// Key left/right bridge sqrs   
static short *orr2b,*orr3b,*orl2b,*orl3b;	// 2nd/3rd OREO sqrs   
static short *dogrb,*doglb;
static short *keyrw,*keylw;
static short *orr2w,*orr3w,*orl2w,*orl3w;
static short *dogrw,*doglw;
static short *corn1w,*corn2w;
static short *corn1b,*corn2b;

	// Setup schBoard & Crowning sqrs.. (1=Setup pieces)
STFUNC void schNewBoard (short far *ibrd, short clrp)
{
	register short cpos;
	short fb;
	BYTE cmen;
	bmult = ENG_BOARDX + 2;
	fb = (ENG_BOARDX + 2) * (ENG_BOARDY + 2) - 1;	// Flip Board   
		// Fill schBoard with EDGE chars
	for (cpos = 0; cpos < MAXBRD; cpos ++) {
	  ibrd [cpos] = EdgeSq;
	}
		// Etch out play area..
	for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	  for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	    cpos = schPosOf (xpos,ypos);
	    if (((ypos + xpos) & 1) != (FlagCornMode != 0)) {
	      ibrd [cpos] = 0;
	    }
	  }
	}

	if (clrp == 1) {	// NEW-BOARD - set up pieces
	  cmen = eng.menperside;
	  cpos = 1;
	  while (cpos < fb / 2 && cmen) {
	    if (ibrd [cpos] == 0) {
	      ibrd [cpos] = Wman;
	      cmen --;
	    }
	    cpos ++;
	  }
	  cmen = eng.menperside;
	  cpos = bmult * ENG_BOARDY + ENG_BOARDX;
	  while (cpos > fb / 2 && cmen) {
	    if (ibrd [cpos] == 0) {
	      ibrd [cpos] = Bman;
	      cmen --;
	    }
	    cpos --;
	  }
	}
}

	// Define flags/data for Game rules..
typedef struct {
  short x,y;		// Board size
  BYTE rules;		// 0=eng..
  BYTE invert;		// Invert brd
  BYTE men;		// men per side
  short mval,kval;	// Man & king vals
  BYTE flags;		// eng.gamflags..
} GAME_RULES;

short manval = 1220, kingval = 1800;
static GAME_RULES const schGameRules [] = {
  8,8,0,0,12,1250,1650,0,  	// English
  8,8,1,1,12,1100,1850,0x19,	// Italian
  8,8,0,0,12,0};

#define ScaleVal(Xval,Ind) \
  (short) ((long) ((long) ((long) eng.piece_value[Ind] * 5L + 100L) * ((long) Xval))/100L)

  // Initialise varisize parameters
  // Called after newboard, or when re-spooling after load.
STFUNC void schInitParams (void)
{
	schHintFrom = -1;
	Phint_move->from = Phint_move->to = 0;	// Clr engine hint..
	manval = 1200; kingval = 1600;
	if (eng.gamtype < 15) {	// Get Pre-set rules/board size..
	  #if (BOARD8x8 == 0)
	    ENG_BOARDX = schGameRules [eng.gamtype].x;
	    ENG_BOARDY = schGameRules [eng.gamtype].y;
	  #endif
	  eng.gamrules = schGameRules [eng.gamtype].rules;
	  eng.menperside = schGameRules [eng.gamtype].men;
	  eng.gamflags = schGameRules [eng.gamtype].flags;
	  manval = schGameRules [eng.gamtype].mval;
	  kingval = schGameRules [eng.gamtype].kval;
	  if (schGameRules [eng.gamtype].invert) {	// Board orientation..
	    VarInvert |= BitInvert;
	  } else {
	    VarInvert &= (~ BitInvert);
	  }
	}
	bokLoad (eng.gamtype,0);		// If book changed from last time, reload..
	manval = ScaleVal (manval,0);	// Scale to % stored in piece_value..
	kingval = ScaleVal (kingval,1);	// Scale to % stored in piece_value..
	schWinSize = ScaleVal (550L,2);	// Scale to % stored in piece_value..
		// Out of range error? normalise to English..
	if (eng.menperside < 1 || ENG_BOARDX < 4 || ENG_BOARDY < 4 
		|| ENG_BOARDX > 16 || ENG_BOARDY > 16) {
	  #if (BOARD8x8 == 0)
	    ENG_BOARDX = ENG_BOARDY = 8; 
	  #endif
	  eng.menperside = 12;
	  eng.gamrules = 0; eng.gamflags = 0;
	}
		// Calc no of sqrs on board..
	schNsqrs = ((ENG_BOARDX * ENG_BOARDY) + (FlagCornMode != 0)) >> 1;
	bmult = ENG_BOARDX + 2;
	schType8x8 = schType8x8inv = 0;
	if (ENG_BOARDX == 8 && ENG_BOARDY == 8) {
	  if (FlagCornMode == 0) {
	    schType8x8 = 1;
	  } else {
	    schType8x8inv = 1;
	  }
	}
	schItalFlag = (eng.gamrules == 1);	// Italian game rules..
	GameBuildIndex ();
		// Init move directions
	dirul = - bmult - 1; dirur = - bmult + 1;
	dirdl = bmult - 1; dirdr = bmult + 1;
	dir2ul = dirul + dirul; dir2ur = dirur + dirur;
	dir2dl = dirdl + dirdl; dir2dr = dirdr + dirdr;

		// Build crowning flag map
	for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	  for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	    schCrown [schPosOf (xpos,ypos)] =  (ypos == 1 || ypos == ENG_BOARDY);
	  }
	}
	#if ENDGAMEDB
	  edbInitGame ();	// Init brd->bitbrd converters..
	#endif
		// FIND Bridges/Oreo/Dogholes 
	corn1w = corn2w = corn1b = corn2b = schBoard;
	temp = 2 + bmult;
	if (schBoard [temp] == EdgeSq) {
	  temp ++;
	  doglw = schBoard + temp - 2 + bmult + bmult;
	} else {
	  corn1w = schBoard + temp;
	  corn2w = doglw = schBoard + temp - 1 + bmult;
	}
	keylw = schBoard + temp;
	orl2w = keylw + 2; orl3w = keylw + 1 + bmult;
	temp = ENG_BOARDX - 1 + bmult;
	if (schBoard [temp] == EdgeSq) {
	  temp --;
	  dogrw = schBoard + temp + 2 + bmult + bmult;
	} else {
	  corn1w = schBoard + temp;
	  corn2w = dogrw = schBoard + temp + 1 + bmult;
	}
	keyrw = schBoard + temp;
	orr2w = keyrw - 2; orr3w = keyrw - 1 + bmult;
	temp = 2 + (bmult * ENG_BOARDY);
	if (schBoard [temp] == EdgeSq) {
	  temp ++;
	  doglb = schBoard + temp - 2 - bmult - bmult;
	} else {
	  corn1b = schBoard + temp;
	  corn2b = doglb = schBoard + temp - 1 - bmult;
	}
	keylb = schBoard + temp;
	orl2b = keylb + 2; orl3b = keylb + 1 - bmult;
	temp = ENG_BOARDX - 1 + (bmult * ENG_BOARDY);
	if (schBoard [temp] == EdgeSq) {
	  temp --;
	  dogrb = schBoard + temp + 2 - bmult - bmult;
	} else {
	  corn1b = schBoard + temp;
	  corn2b = dogrb = schBoard + temp + 1 - bmult;
	}
	keyrb = schBoard + temp;
	orr2b = keyrb - 2; orr3b = keyrb - 1 - bmult;
}


	// Rebuild game index - ptr list into eng.game_store for each move..
STFUNC void GameBuildIndex ()
{
	short cpos;
	schNGame = 0;
	cpos = 1;
	schGAMEWORD(0) = 0xffff;	// Never matches next move..
	while (schGAMEWORD (cpos)) {
		// Is this move not part of multijump?
	  if (cpos == 1 || eng.game_store [cpos].src != eng.game_store [cpos - 1].dest) {
	    schGameIndex [schNGame] = (BYTE) ((UINT) cpos - schNGame);
	    schNGame ++;	// Next move..
	  }
	  cpos ++;		// Next (part) move..
	}
			// Next entry pos..
	schGameIndex [schNGame] = (BYTE) ((UINT) cpos - schNGame);
	schGameIndex [schNGame + 1] = 0;	// Add terminator..
}

STFUNC void GameClr ()		// Clr game storage..
{
	eng.game_status = 0;
	eng.move_number = 0;		// Current move index..
	eng.init_moven = 0;			// Start move..
	schGAMEWORD(0) = 0xffff;	// Never matches next move..
	schGAMEWORD(1) = 0;
	schGameIndex [0] = 1;		// Ptr to 1st move in..
	schGameIndex [1] = 0;		// Add null terminator
	schNGame = 0;
}

	// Add a move (or part of move-jump) to game storage,
STFUNC short FASTCALL GameAdd (BYTE msrc, BYTE mdest, BYTE mflag)
{
	short cpos = eng.move_number - (eng.init_moven & 0x07ff);
	short cstore = cpos + (short) ((BYTE) schGameIndex [cpos]);
	if ((UINT) cpos >= MAX_GAME_STORE) return -1;
	  // If unterminated multijump, append, else replace with new move..
	  // Scan to find how far along multijump we currently are..
	  // Remember-move we are adding already done on brd..
	while (schGAMEWORD (cstore) 
	  	&& eng.checker_board [eng.game_store [cstore].dest] == 0 
	  	&& (eng.game_store [cstore].flag & 1)) {
	  cstore ++;
	}
	if ((UINT) cstore >= MAX_GAME_STORE) return -1;
	#if Debug
	  if (cstore - cpos > 40) {	// Temp break point..
	    mflag |= 80;
	  }
	#endif
		// Save move..
	eng.game_store [cstore].src = msrc;
	eng.game_store [cstore].dest = mdest;
	eng.game_store [cstore].flag = mflag;
	schGAMEWORD (cstore + 1) = 0;		// Add null terminator..
		// Add multi-jump part..
	if (mflag & 0x01) {
	  schGameIndex [cpos + 1] = 0;	// Add null terminator..
	} else {	// Normal move/Multijump end, incr index..
	  schGameIndex [cpos + 1] = cstore - cpos;
	  schGameIndex [cpos + 2] = 0;
	  eng.move_number ++;
	  schNGame = cpos + 1;
	}
	return 0;
}

  // Quick Test if multi-jump possible for this sqr.. (jumpflag) set if so
  //  NOTE because no buildpos done, do not use this mvgen in real search..
STFUNC void TestMulti (short csqr)
{
	cgbrd2sch ();	// Copy eng.checker_board to engine-schBoard..
	initmvptrs ();	// Initialise Move list pointers   
	jumpflag = 0;
	schNmoves = 0;
	schColor = schBoard [csqr] & FLIPWB;
	if (schColor == 0) return;
	tindex = 0;		// NOTE - not real index!
	if (schColor == CBLACK) {
	  gen1blkmove (csqr);
	} else {
	  gen1whtmove (csqr);
	}
}

  // Quick - get ptr to move #..
STFUNC GAMESTORE far * FASTCALL schPtrToMove (UINT cmov)
{
	short cpos;
        if (cmov > (UINT) eng.move_number) return 0;
        cpos = cmov - (eng.init_moven & 0x07ff);
        cpos += schGameIndex [cpos];	// Calc index into game-store..
	return (eng.game_store + cpos);		// Ptr to full info
}

  // Quick do-move. If illegal, ret 0, else ret 0x8000 + flags..
  // Set bit 15 src for extra fast - no multijump check..
  //  flags are 0x40==capture, 0x04=promo..0x01=multijump after this..
  //   0x02=piece moved=K, 0x08=Capture piece =K
STFUNC short FASTCALL qDoMove (short isrc, short mdest)
{
	char cpiece,mvpiece;
	short cdir,absdir;
	short cflag = (short) (0x8000L);
	short msrc = isrc & 0x0fff;
	UINT maxbrd = ENG_BOARDX * ENG_BOARDY;
	if (msrc == mdest) return 0;
	if ((UINT) msrc > maxbrd || (UINT) mdest > maxbrd) return 0;
	mvpiece = eng.checker_board [msrc];
	if ((mvpiece & FLIPWB) == 0) return 0;
	cdir = mdest - msrc;
	absdir = abs(cdir);
	if (absdir != ENG_BOARDX + 1 && absdir != ENG_BOARDX - 1) {	// Jump?
	  short cbrd;
	  short ccap;
	  #if 1		// ENGLISH/ITALIAN 1-step moves..
	    if ((absdir >> 1) != ENG_BOARDX + 1 && (absdir >> 1) != ENG_BOARDX - 1) {
	      return 0;		// Not a legal single-step-jump
	    }
	  #endif
	  cflag |= 0x40;		// Set capture flag bit..
	  cdir = ENG_BOARDX - 1;		// Try 1 dir..
	  if (absdir % cdir) {
	    cdir = ENG_BOARDX + 1;		// Try another
	    if (absdir % cdir) {
	      return 0;		// neither, error..
	    }
	  }
	  if (mdest < msrc) cdir = -cdir;
	  cbrd = msrc; ccap = 0;
	  do {
	    cbrd += cdir;
	    	// Error if no capture piece found!
	    if (cbrd == mdest || (UINT) cbrd > maxbrd) return 0;
	    cpiece = eng.checker_board [cbrd];
	    if (cpiece & FLIPWB) {
	      if (cpiece & FLIPWB & mvpiece) return 0;	// Cannot jump same color
	      if (ccap) return 0;	// Already found, Cannot capture 2!
	      ccap = cbrd;
	    }
	  } while (cpiece == 0);
	  if (cpiece & 1) cflag |= 8;	// Capt piece is K flag bit..
	  eng.checker_board [ccap] = 0;	// Erase captured
	}
	if (mvpiece & 1) cflag |= 2;	// Moved piece is K flag-bit..
	if (schCrown [cg2sch (mdest)]) {  // Crown man?
          if (mvpiece == Bman) {
            mvpiece = Bking;
	    cflag |= 0x04;		// Set promotion flag bit..
          }
          if (mvpiece == Wman) {
            mvpiece = Wking;
	    cflag |= 0x04;		// Set promotion flag bit..
	  }
        }
	eng.checker_board [mdest] = mvpiece;
	eng.checker_board [msrc] = 0;
	if (((cflag & 0x44) == 0x40) && (isrc & 0x8000) == 0) {	// Multijump check..
	  TestMulti (cg2sch (mdest));
	  if (jumpflag) cflag |= 1;	// bit 0=multijump possible..
	}
	return cflag;
}


	// GAME-SEARCH FUNCTIONS

STFUNC void CountPieces()		// Count no of pieces - b/w/men/kings   
{
	short xpos,ypos,cpiece;
	Nblkmen = Nwhtmen = Nblkking = Nwhtking = 0;	// Clr counts   
	for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	  for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	    cpiece = schBoard [schPosOf(xpos, ypos)];
	    if (cpiece >= Bman && cpiece <= Wking) piececount [cpiece] ++;
	  }
	}
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkmen + Nblkking;
}

	// Initialise value of pieces in various quantitys
	// ie. the value of 2 men is manvals[2] 
STFUNC void setvalpieces ()
{
	short ccount;
	kingvals [0] = Vl(-4); manvals [0] = Vl(-1000);
	kingvals [1] = kingval - manval;	// Advantage for 1st king   
	manvals [1] = manval;
	for ( ccount = 2; ccount < 33; ccount++) {
	  manvals  [ccount] = ccount * manval;
	  kingvals [ccount] = ccount * (kingval - manval - Vl(7)) + Vl(7);
	}
	if (nowhite > noblack) {  // Depress last man val, encourage xch..  
	  manvals [nowhite] -= Vl(11);
	  kingvals [nowhite] -= Vl(11);
	}
	if (noblack > nowhite) {
	  manvals [noblack] -= Vl(11);
	  manvals [noblack] -= Vl(11);
	}
}


STFUNC void kwadd (short pos, short add)
{
	whkingweights [pos] += add; blkingweights [pos] += add;
}

//  schBoard [] for english - white at top.. (sq1==87,sq32==12) (bm=2,bk=3,wm=4,wk=5)
// --  12  --  14  --  16  --  18  
// 21  --  23  --  25  --  27  --  
// --  32  --  34  --  36  --  38  
// 41  --  43  --  45  --  47  --  
// --  52  --  54  --  56  --  58  
// 61  --  63  --  65  --  67  --  
// --  72  --  74  --  76  --  78  
// 81  --  83  --  85  --  87  --  


STFUNC void initweights ()	// Pre-select weight tables for men and kings.   
{
	#define WVal(x) ((x) * unit)
	short unit = iniScale (Vone,iniWEIGHT);
	short backrow = iniScale (Vl(6),iniBACKROW);
	short edgeval = iniScale (Vl(1),iniEDGEVAL);
	short crownrun = iniScale (Vl(8),iniCROWNRUN);
	STINT wManWt,bManWt,wkwt,bkwt;	// Wh/bl/man/K weights   
	short cpos;
	short xpos,ypos;
	short temp,temp2;
	STINT centx,centy;
	short nkings;
	schGameStage = (50 * (Nmen + Nkings)) / eng.menperside;
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	nkings = Nwhtking + Nblkking;
	materialdif = nowhite - noblack;
		// TermNode evals..
	schDogval1 = iniScale (DOGVAL1,iniDOGVAL1);
	schDogval2 = iniScale (DOGVAL2,iniDOGVAL2);
	schBridgeval = iniScale (BRIDGEVAL,iniBRIDGE);
	schOreoval = iniScale (OREOVAL,iniTRI);
	schBackval = iniScale (BACKVAL,iniTRI);
	schClampval = iniScale (CLAMPVAL,iniCLAMPVAL);
	schKhold = iniScale (KHOLD,iniKHOLD);
	schFwdPrune = iniScale (FWDPRUNE,iniFWDPRUNE);
	
	for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	  centy = abs (ypos + ypos - ENG_BOARDY - 1) >> 1;
	  for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	   centx = abs (xpos + xpos - ENG_BOARDX - 1) >> 1;
	   cpos = schPosOf (xpos,ypos);
	   if (schBoard [cpos] != EdgeSq) {
	    wManWt = WVal ((1 + ENG_BOARDY - ypos) * 2);
	    bManWt = WVal (ypos * 2);
	    temp = centx;
	    if (centy > centx) temp = centy;
	    bkwt = wkwt = 20 - temp * 4;
	    if (temp == 0) {wkwt -= 3; bkwt -= 3;}
	    if (schGameStage < 67) {			// Flip Time   
	      temp = wManWt; wManWt = bManWt; bManWt = temp;
	    } else {
	      if (ypos + ypos > ENG_BOARDY) {	// Decrease 5/6th rank   
		wManWt -= WVal (1);
	      } else {
		bManWt -= WVal (1);
	      }
	    }
	    if (xpos == 1 || xpos == ENG_BOARDX) {		// EdgeSq   
	      if (schBoard [cpos] == 0) {
		wManWt -= edgeval; bManWt -= edgeval;
	      }
	      if (ypos == 1 || ypos == ENG_BOARDY) {
		wManWt -= edgeval; bManWt -= edgeval;
	      }
	    }
	    if (centx + centy == 0) {
	      wManWt += WVal (1); bManWt += WVal (1);
	    }
	    if (ypos <= 2) bManWt += crownrun;
	    if (ypos >= ENG_BOARDY - 1) wManWt += crownrun;
	    temp = schBoard [cpos] | schBoard [cpos + dirul] | schBoard [cpos + dirur]
		 | schBoard [cpos + dirdl] | schBoard [cpos + dirdr]
		 | schBoard [cpos + dirdl +dirul] | schBoard [cpos + dirdr +dirur];
            if (ypos > 1) temp |= schBoard [cpos + dirul + dirur];
            if (ypos < ENG_BOARDY) temp |= schBoard [cpos + dirdl + dirdr];
	    if (materialdif > 0 && (temp & CBLACK)) {	// Attack weak side  
	      wkwt += 5;
	    }
	    if (materialdif < 0 && (temp & CWHITE)) {
	      bkwt += 5;
	    }
	   } else {
	    wManWt = bManWt = wkwt = bkwt = 0;
	   }
	   if (nkings == 0 && xpos > 1 && xpos < ENG_BOARDX) {  // Inc backrow defence..
	     if (ypos == 1) {		// wht backrow
	       wManWt += backrow;
	     }
	     if (ypos == ENG_BOARDY) {	// blk backrow
	       bManWt += backrow;
	     }
	   }
	   whmanweights [cpos] = wManWt;
	   blmanweights [cpos] = bManWt;
	   whkingweights [cpos] = WVal(wkwt);
	   blkingweights [cpos] = WVal(bkwt);
	  }
	}
	if (schItalFlag) {
	  temp = schPosOf (1,1); temp2 = schPosOf (2,2);
	} else {
	  temp = schPosOf (ENG_BOARDX,1); temp2 = schPosOf (ENG_BOARDX - 1, 2);
	}

	if (schBoard [temp] != EdgeSq) {
	  whmanweights [temp] -= WVal(6); whmanweights [temp2] -= WVal(2);
	  blmanweights [temp] -= WVal(6); blmanweights [temp2] -= WVal(2);
	  kwadd (temp,WVal(-6)); kwadd (temp2,WVal(-3));
	}
	if (schType8x8) {  // English..
	   blmanweights [18] -= WVal(30);   // Dont crown in single corner unless u can escape!
	   blkingweights [18] -= WVal(30);
	   whmanweights [81] -= WVal(30);
	   whkingweights [81] -= WVal(30);
	}
	if (schItalFlag) {
	  temp = schPosOf (ENG_BOARDX,ENG_BOARDY); temp2 = schPosOf (ENG_BOARDX - 1,ENG_BOARDY - 1);
	} else {
	  temp = schPosOf (1,ENG_BOARDY); temp2 = schPosOf (2,ENG_BOARDY - 1);
	}

	if (schBoard [temp] != EdgeSq) {
	  whmanweights [temp] -= WVal(6); whmanweights [temp2] -= WVal(2);
	  blmanweights [temp] -= WVal(6); blmanweights [temp2] -= WVal(2);
	  kwadd (temp,WVal(-6)); kwadd (temp2,WVal(-3));
	}
	if (schItalFlag) {
	  if (schType8x8inv) {
	    kwadd (13,WVal(-2)); kwadd (31,WVal(-2)); kwadd (68,WVal(-2)); kwadd (86,WVal(-2));
	    kwadd (17,WVal(4)); kwadd (28,WVal(4)); kwadd (71,WVal(4)); kwadd (82,WVal(4)); //Dcorn  
	  }
	}
}

  // Dump & view weight tables..
void DumpWeights (short tab)
{
	short *tptr;
	short xpos,ypos;
	char *cstr;
	switch (tab & 15) {
	  case 1:
	    tptr = whmanweights; cstr = "wht men"; break;
	  case 2:
	    tptr = blmanweights; cstr = "blk men"; break;
	  case 3:
	    tptr = whkingweights; cstr = "wht king"; break;
	  case 4:
	    tptr = blkingweights; cstr = "blk king"; break;
	  case 5:
	    tptr = schBoard; cstr = "board"; break;
	  case 6:
	    tptr = schBoard; cstr = "sqrpos"; break;
	  default:
	    return;
	}
	// hDC=hMainDC;
	//SelectObject (hDC,hFont);
	//SelectObject (hDC,(HPEN) GetStockObject(BLACK_PEN));
	//SetBkMode (hDC,OPAQUE);
	Dink ();
	con_printf ("%s table, white at top\x0d\x0a",(LPSTR) cstr);
	for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	  for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	    int cval = (int) tptr [schPosOf (xpos,ypos)];
	    if ((tab & 15) == 6) {
	      cval = schPosOf (xpos,ypos);
	    }
	    if (tab & 16) {	// hex..
	      con_printf ("%04x  ",cval);
	    } else {
	      con_printf ("%05d  ",cval);
	    }
	  }
          con_printf ("\x0d\x0a");
	}
}

//-------------------------------------------------------------------------
//		
// 		MOVE GENERATORS   
//

#define GenerateMoves \
	buildpos ();\
	jumpflag = 0;\
	if (schColor == CBLACK) {\
	  genblackmoves ();\
	} else {\
          genwhitemoves ();\
	}

#define FastGenerateMoves \
	jumpflag = 0;\
	if (schColor == CBLACK) {\
	  genblackmoves ();\
	} else {\
	  genwhitemoves ();\
	}

#define FastGenerateJumps \
	if (schColor == CBLACK) {\
	  genblackjumps ();\
	} else {\
	  genwhitejumps ();\
	}

	// Add a move to MOVE-TREE..
#define Addmove(Xdir) \
	  schNmoves ++; listptr ++;\
	  listptr [0] = cbrd; listptr += Mlist;\
	  listptr [0] = Xdir; listptr += Mlist;\
	  listptr [0] = 0; listptr += Mlist;\
	  listptr [0] = tindex; listptr -= (Mlist + Mlist + Mlist);

#define Gen1jmp(Cdir,C2dir,Opcolor) \
	if ( (brdptr [Cdir] & Opcolor) && (brdptr [C2dir] == 0)) {\
	  Addmove (C2dir) \
	}

#define Genijmp(Cdir,C2dir,Opcolor) \
	if ( (brdptr [Cdir] == Opcolor) && (brdptr [C2dir] == 0)) {\
	  Addmove (C2dir) \
	}

#define Gen1dir(Cdir,C2dir,Opcolor) \
	if ( (cdest = schBoard [cbrd + Cdir]) == 0 && jumpflag == 0) { \
	  Addmove (Cdir) \
	} else if ( (cdest & Opcolor) && (schBoard [cbrd + C2dir] == 0)) {\
	  if (jumpflag == 0) {\
	    jumpflag = 1;\
	    schNmoves = 0; listptr = mvbrd;\
	  }\
	  Addmove (C2dir) \
	}

	// Gen dir for Italian man   

#define Genidir(Cdir,C2dir,Opcolor)\
	if ( (cdest = schBoard [cbrd + Cdir]) == 0 && jumpflag == 0) { \
	  Addmove (Cdir) \
	} else if ( (cdest == Opcolor) && (schBoard [cbrd + C2dir] == 0)) {\
	  if (jumpflag == 0) {\
	    jumpflag = 1;\
	    schNmoves = 0; listptr = mvbrd;\
	  }\
	  Addmove (C2dir) \
	}

STFUNC void FASTCALL gen1blkmove (short cbrd)
{
	short cdest;
	register short *listptr = mvbrd;
	if (schBoard [cbrd] == Bman) {
	  if (schItalFlag) {
	    Genidir (dirul, dir2ul, CWHITE)
	    Genidir (dirur, dir2ur, CWHITE)
	  } else {
	    Gen1dir (dirul, dir2ul, CWHITE)
	    Gen1dir (dirur, dir2ur, CWHITE)
	  }
	  return;
	} else {
	  Gen1dir (dirul, dir2ul, CWHITE)
	  Gen1dir (dirur, dir2ur, CWHITE)
	  Gen1dir (dirdl, dir2dl, CWHITE)
	  Gen1dir (dirdr, dir2dr, CWHITE)
	}
}

static short cbrd,pcount;

STFUNC void genblackmoves ()	// Gen legal BLACK moves, ret NMOVES 
{
	static unsigned cbrd;
	register short cdest ;
	register short *listptr = mvbrd;
	//register short *brdptr;  
	schNmoves = 0 ;
	if (schItalFlag) goto GenBlkItal;
	for (tindex = 0; tindex < (unsigned) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (schBoard [cbrd] == Bman) {
	      Gen1dir (dirul, dir2ul, CWHITE)
	      Gen1dir (dirur, dir2ur, CWHITE)
	    } else {
	      Gen1dir (dirul, dir2ul, CWHITE)
	      Gen1dir (dirur, dir2ur, CWHITE)
	      Gen1dir (dirdl, dir2dl, CWHITE)
	      Gen1dir (dirdr, dir2dr, CWHITE)
	    }
	  }
	}
	return;
GenBlkItal:		// Gen moves for italian rules.
	for (tindex = 0; tindex < (unsigned) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    if (schBoard [cbrd] == Bman) {
	      Genidir (dirul, dir2ul, CWHITE)
	      Genidir (dirur, dir2ur, CWHITE)
	    } else {
	      Gen1dir (dirul, dir2ul, CWHITE)
	      Gen1dir (dirur, dir2ur, CWHITE)
	      Gen1dir (dirdl, dir2dl, CWHITE)
	      Gen1dir (dirdr, dir2dr, CWHITE)
	    }
	  }
	}
}

STFUNC void genblackjumps ()	// JUMP ONLY GEN...
{
	static unsigned cbrd;
	register short *brdptr;
	register short *listptr = mvbrd;
	jumpflag = 1;
	schNmoves = 0 ;
	if (schItalFlag) goto GenBlkItal;
	for (tindex = 0; tindex < (unsigned) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    brdptr = schBoard + cbrd;
	    if (brdptr [0] == Bman) {
	      Gen1jmp (dirul, dir2ul, CWHITE)
	      Gen1jmp (dirur, dir2ur, CWHITE)
	    } else {
	      Gen1jmp (dirul, dir2ul, CWHITE)
	      Gen1jmp (dirur, dir2ur, CWHITE)
	      Gen1jmp (dirdl, dir2dl, CWHITE)
	      Gen1jmp (dirdr, dir2dr, CWHITE)
	    }
	  }
	}
	return;
GenBlkItal:		// Gen jumps for italian rules.
	for (tindex = 0; tindex < (unsigned) nblpos; tindex ++ ) {
	  if ((cbrd = blpos [tindex]) != 0) {
	    brdptr = schBoard + cbrd;
	    if (brdptr [0] == Bman) {
	      Genijmp (dirul, dir2ul, CWHITE)
	      Genijmp (dirur, dir2ur, CWHITE)
	    } else {
	      Gen1jmp (dirul, dir2ul, CWHITE)
	      Gen1jmp (dirur, dir2ur, CWHITE)
	      Gen1jmp (dirdl, dir2dl, CWHITE)
	      Gen1jmp (dirdr, dir2dr, CWHITE)
	    }
	  }
	}
}

STFUNC void FASTCALL gen1whtmove (short cbrd)
{
	static short cdest;
	register short *listptr = mvbrd;
	if (schBoard [cbrd] == Wman) {
	  if (schItalFlag) {
	    Genidir (dirdl, dir2dl, CBLACK)
	    Genidir (dirdr, dir2dr, CBLACK)
	  } else {
	    Gen1dir (dirdl, dir2dl, CBLACK)
	    Gen1dir (dirdr, dir2dr, CBLACK)
	  }
	} else {
	  Gen1dir (dirdl, dir2dl, CBLACK)
	  Gen1dir (dirdr, dir2dr, CBLACK)
	  Gen1dir (dirul, dir2ul, CBLACK)
	  Gen1dir (dirur, dir2ur, CBLACK)
	}
}

STFUNC void genwhitemoves ()	// Gen legal WHITE moves, ret NMOVES   
{
	static unsigned cbrd;
	register short cdest ;
	register short *listptr = mvbrd;
	//register short *brdptr;  
	schNmoves = 0 ;
	if (schItalFlag) goto GenWhtItal;
	for (tindex = 0; tindex < (unsigned) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    if (schBoard [cbrd] == Wman) {
	      Gen1dir (dirdl, dir2dl, CBLACK)
	      Gen1dir (dirdr, dir2dr, CBLACK)
	    } else {
	      Gen1dir (dirdl, dir2dl, CBLACK)
	      Gen1dir (dirdr, dir2dr, CBLACK)
	      Gen1dir (dirul, dir2ul, CBLACK)
	      Gen1dir (dirur, dir2ur, CBLACK)
	    }
	  }
	}
	return;
GenWhtItal:		// Gen moves for italian rules.
	for (tindex = 0; tindex < (unsigned) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    if (schBoard [cbrd] == Wman) {
	      Genidir (dirdl, dir2dl, CBLACK)
	      Genidir (dirdr, dir2dr, CBLACK)
	    } else {
	      Gen1dir (dirdl, dir2dl, CBLACK)
	      Gen1dir (dirdr, dir2dr, CBLACK)
	      Gen1dir (dirul, dir2ul, CBLACK)
	      Gen1dir (dirur, dir2ur, CBLACK)
	    }
	  }
	}
}

STFUNC void genwhitejumps ()	// JUMP ONLY GEN..   
{
	static unsigned cbrd;
	register short *brdptr;
	register short *listptr = mvbrd;
	jumpflag = 1;
	schNmoves = 0 ;
	if (schItalFlag) goto GenWhtItal;
	for (tindex = 0; tindex < (unsigned) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    brdptr = schBoard + cbrd;
	    if (brdptr [0] == Wman) {
	      Gen1jmp (dirdl, dir2dl, CBLACK)
	      Gen1jmp (dirdr, dir2dr, CBLACK)
	    } else {
	      Gen1jmp (dirdl, dir2dl, CBLACK)
	      Gen1jmp (dirdr, dir2dr, CBLACK)
	      Gen1jmp (dirul, dir2ul, CBLACK)
	      Gen1jmp (dirur, dir2ur, CBLACK)
	    }
	  }
	}
	return;
GenWhtItal:		// Gen moves for italian rules.
	for (tindex = 0; tindex < (unsigned) nwhpos; tindex ++ ) {
	  if ((cbrd = whpos [tindex]) != 0) {
	    brdptr = schBoard + cbrd;
	    if (brdptr [0] == Wman) {
	      Genijmp (dirdl, dir2dl, CBLACK)
	      Genijmp (dirdr, dir2dr, CBLACK)
	    } else {
	      Gen1jmp (dirdl, dir2dl, CBLACK)
	      Gen1jmp (dirdr, dir2dr, CBLACK)
	      Gen1jmp (dirul, dir2ul, CBLACK)
	      Gen1jmp (dirur, dir2ur, CBLACK)
	    }
	  }
	}
}

STFUNC void FASTCALL genforsq (short csqr)	// Gen mvs for 1 sqr   
{
	jumpflag = 0;
	schNmoves = 0;
	if ((schBoard [csqr] & schColor) == 0) return;
	if (schColor == CBLACK) {
	  tindex = findblindex (csqr, schBoard [csqr]);
	  gen1blkmove (csqr);
	} else {
	  tindex = findwhindex (csqr, schBoard [csqr]);
	  gen1whtmove (csqr);
	}
}

//#if Italian

STINT tmostjumps [Mply];	// Max jmp score for recurgen   
STINT tcurjumps  [Mply];	// Cur jump score for recurgen   
STINT jumpcount;
STINT curjumps;

STUINT startply;

STFUNC void recurgen ()		// Recursively gen moves, do JUMPCOUNT   
{
	UINT cmove;
	tnomoves  [schPly] = schNmoves;	// Save move table size   
	tmostjumps [schPly] = 0;
	tcurjumps [schPly] = curjumps;
	for (cmove = 1; cmove <= (UINT) schNmoves; cmove ++) {
	  schSrc = mvbrd [cmove];
	  schDir = mvdir [cmove];
	  schDest = schSrc + schDir;
	  schPiece = schBoard [schSrc];	// Piece to be moved   
	  toldpiece [schPly] = schPiece;	// Stash its val on stack   
	  schCapSq = schSrc + (schDir >> 1);
	  schCapPc = schBoard [schCapSq];
	  if (schCapPc & 1) {
	    curjumps += 42;
	  } else {
	    curjumps += 40;
	  }
	  if (schPly == startply) {
	    if (schPiece & 1) curjumps += 20;
	    if (schCapPc & 1) curjumps ++;
	  }
	  schBoard [schSrc] = 0;
	  schBoard [schCapSq] = EdgeSq;
	  schBoard [schDest] = schPiece;
	  ttaken [schPly] = schCapPc;		// Save vars on stack   

	  mvbrd += schNmoves;	// Inc move list ptrs   
	  mvdir += schNmoves;
	  mveval += schNmoves;
	  mvtot += schNmoves;
	  mvindex += schNmoves;

	  jumpflag = 1;		// Flag indicates that gen moves are jumps   
	  schNmoves = 0;
	  // tindex = xindex;  
	  if (schColor == CBLACK) {		// Whose go is it?   
	    gen1blkmove (schDest);	// Gen legal black moves for XDEST  
	  } else {
	    gen1whtmove (schDest);	// Gen legal white moves for XDEST   
	  }
	  if (schNmoves && (schCrown [schDest] & schColor) == 0) {	// More Jumps?   
	    schPly ++;
	    if (schPly > Mply - 3) {
	      DoMessage ("RECUR Ply overflow!");
	      exit (0);
	    }
	    recurgen ();
	    schPly --;
	  } else {		// No more jumps, ret jump-score   
	    jumpcount = curjumps;
	  }
	  schPiece = toldpiece [schPly] ;
	  schCapPc = ttaken [schPly] ;
	  schNmoves = tnomoves [schPly] ;

	  mvbrd -= schNmoves;	// Dec move list ptrs   
	  mvdir -= schNmoves;
	  mveval -= schNmoves;
	  mvtot -= schNmoves;
	  mvindex -= schNmoves;
					// UNDO move   
	  schSrc = mvbrd [cmove];
	  schDir = mvdir [cmove];
	  schBoard [schSrc + schDir] = 0;	// Wipe moved piece   
	  schBoard [schSrc] = schPiece;	// Restore old piece   
	  schCapSq = schSrc + (schDir >> 1) ;
	  schBoard [schCapSq] = schCapPc;
	  curjumps = tcurjumps [schPly];
					// Save score   
	  mvtot [cmove] = jumpcount;
	  if (jumpcount > tmostjumps [schPly]) {
	    tmostjumps [schPly] = jumpcount;
	  }
	}
	jumpcount = tmostjumps [schPly];		// Return best score   
}

STFUNC void filtergen ()		// Scan jumps, del illegal   
{
	UINT tmove,cmove;
	if (schNmoves < 2) return;
	mvtot = xmv.tot;
	startply = curjumps = schPly;
 	recurgen ();
	jumpflag = 1;
	tmove = 0;
	for (cmove = 1; cmove <= (unsigned) schNmoves; cmove ++) {
	  if (mvtot [cmove] == jumpcount) {	// Only the max jumps   
	    tmove ++;
	    mvbrd [tmove] = mvbrd [cmove];
	    mvdir [tmove] = mvdir [cmove];
	    mveval [tmove] = mveval [cmove];
	    mvindex [tmove] = mvindex [cmove];
	  }
	}
	schNmoves = tmove;
}

STFUNC void filtergensq (short csqr)		// Filter-Moves for 1 sqr   
{
	UINT tmove,cmove;
	mvtot = xmv.tot;
	startply = curjumps = schPly;
 	recurgen ();
	jumpflag = 1;
	tmove = 0;
	for (cmove = 1; cmove <= (unsigned) schNmoves; cmove ++) {
	  if (mvtot [cmove] == jumpcount) {
	    if (mvbrd [cmove] == csqr) {
	      tmove ++;
	      mvbrd [tmove] = mvbrd [cmove];
	      mvdir [tmove] = mvdir [cmove];
	      mveval [tmove] = mveval [cmove];
	      mvindex [tmove] = mvindex [cmove];
	    }
	  }
	}
	schNmoves = tmove;
}
//#endif		// Italian   

#define schSIZE_RAND 255
static short randeval [schSIZE_RAND + 3];
STFUNC void initrnd ()		// Fill random evaluator array..   
{
	short crnd,temp;
	short xoff = abs (offrand);
	if (xoff == 0) xoff = 1;
	for (crnd = 0; crnd <= schSIZE_RAND; crnd ++) {
	  temp = (myRand () % xoff);
	  if (offrand > 0) temp = temp * (myRand () % xoff);
	  if (myRand () & 1) temp = -temp;
	  randeval [crnd] = temp;
	}
}

STFUNC void initmvptrs ()
{
	mvbrd = xmv.brd;		// Initialise Move list pointers   
	mvdir = xmv.dir;
	mveval = xmv.eval;
	mvindex = xmv.index;
	mvtot = xmv.tot;
}

//-------------------------------------------------------------------------
//		
// 		HASH TABLE FUNCTIONS..   
//
 
#if hashENABLE


static short hashFlag = 20;	// Depth to stop trans-looks   
static short hashSchFlag = 20;	// During search..
ULONG hashBoard [MAXBRD + 4];
ULONG hashBrdLong [MAXBRD + 4];
static short HUGE_ *hashPtr;	// Pointer to current element in trans   
long HUGE_ *hashLPtr;		// Long pointer to cur element..
long hashNoEle;
long hashHit,hashAccess;
short hashBestMove = 0;
short hashBestDir = 0;

ULONG hashVal;
ULONG hashLVal;
HGLOBAL hashhGlob = NULL;	// Handle on hash mem
static short HUGE_ *hashStart = NULL;	// Pointer to Transposition table in FAR heap.   

typedef struct {	// Hash-table entry structure..
  short iq;	// IQ depth val searched (bigger==deeper,0=unused
  short bestMove;
  long hash;		// 32bit hash val
  short eval;		// Eval of node
  short bestDir;
  long spare;
} hashDATA;

#define hashALTMETHOD 0		// Set to enable alt-method..

long hashBytesAlloc = 0L;	// total # mem allocated..

long hashIgnore = 1;
long hashIgnoreMask = 0;

void schIgnore (char *hstr)
{
	if (*hstr == 0) return;
	hashIgnoreMask = str2val (hstr,16,8);
	while (*hstr >= '0') hstr ++;
	if (*hstr != ',') return;
	hstr ++; 
	hashIgnore = str2val (hstr,16,8);
}

  // Initialise hash table memory, (call when program starts)
short ext_hash_init (long hashbytes)
{
	short hprimes [] = {5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,
		67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149};
		// First, fill hash-board positions with lookup codes..
	mySrand (149);
	srand (100);
	for (xpos = 1; xpos < MAXBRD; xpos ++) {
	  hashBrdLong [xpos] = (ULONG) myRand () + ((long) rand () << 8) 
	  	+ ((long) (myRand () ^ (long) hprimes [(xpos + 10) & 31]) << 17);
	  hashBrdLong [xpos] &= (ULONG) (~1L);	// Kill off lo bit..
	}
	for (xpos = 1; xpos < MAXBRD; xpos ++) {
	  hashBoard [xpos] = (ULONG) (myRand () + (0x1a50L * (long) rand ()) 
		+ hprimes [xpos & 31]) * 2;	// Note - bit0 always=0..
	}
	hashBoard [0] = 0;		// Lowest always zero..
	hashBrdLong [0] = 0;
	mySrand ((short) clock ());
		// Now alloc hash memory
	if (hashhGlob) {	// Dealloc old first..
	  GlobalUnlock (hashhGlob);
	  GlobalFree (hashhGlob);
	}
	hashBytesAlloc = 0L;
	hashhGlob = GlobalAlloc (GMEM_MOVEABLE | GMEM_ZEROINIT, hashbytes);
	if (hashhGlob == NULL) {
          hashFlag = 0;
          return -1;	// Error
	}
	hashBytesAlloc = hashbytes;
		// Calc # elements (round down nearest 128)
	hashNoEle = ((hashbytes - 1000) / (sizeof (hashDATA) * 128)) * 128;
 	hashStart = GlobalLock (hashhGlob);  // Allocate FAR hash INT array 
	return 0;	// OK..
}

  // Release mem taken by hash tables..
void hashFinish ()
{
	if (hashhGlob) {
	  GlobalUnlock (hashhGlob);
	  GlobalFree (hashhGlob);
	}
	hashhGlob = NULL;
	hashStart = NULL;
	hashFlag = 0;
}

  // ALT: Calc (hashVal) and (hashLVal) for given board pos..
  // (hashVal) is mod table size.
STFUNC void hashAltGetVal (BYTE far *cbrd, short ccolor)
{
	register short temp,temp2;
	short cpos;
	short bsize = ENG_BOARDX * ENG_BOARDY;
	hashVal = 0; hashLVal = 0;
	for (cpos = 0; cpos < bsize; cpos ++) {
	  temp2 = cbrd [cpos];
	  if (temp2 & (CWHITE | CBLACK)) {
	    temp = cg2sch (cpos);
	    hashVal += hashBoard [temp] - (ULONG) temp2;
	    hashLVal += hashBrdLong [temp + temp2];
	  }
	}
	hashVal = (hashVal % (ULONG) hashNoEle) | 1;
	if (ccolor == CBLACK) hashVal --;
}

  // Calc (hashVal) and (hashLVal) for current piece-list..   
  // (hashVal) is modulus table-size- ie. position of entry..
STFUNC void hashGetVal ()
{
	register unsigned cindex;
	register short temp,temp2;
	hashVal = 0; hashLVal = 0;
	for (cindex = 0; cindex < (unsigned) nwhpos; cindex ++ ) {
	  temp = whpos [cindex];
	  if (temp) {
	    temp2 = whtype [cindex];
	    hashVal += hashBoard [temp] - (ULONG) temp2;
	    hashLVal += hashBrdLong [temp + temp2];
	  }
	}
	for (cindex = 0; cindex <  (unsigned) nblpos; cindex ++ ) {
	  temp = blpos [cindex] ;
	  if (temp) {
	    temp2 = bltype [cindex];
	    hashVal += hashBoard [temp] - (ULONG) temp2;
	    hashLVal += hashBrdLong [temp + temp2];
	  }
	}
	hashVal = (hashVal % (ULONG) hashNoEle) | 1;
	if (schColor == CBLACK) hashVal --;
}

STFUNC void FASTCALL hashSaveTran (short ceval, short ciq, short bestmove, short bestdir)	// Save BOARD as transposition table entry   
{
	hashDATA HUGE_ *hPtr;	// Pointer to current entry..
	hashGetVal ();		// Encode BOARD [] to BITBRD [], HASHCODE   
	   // Get Ptr to cur element   
	hPtr = ((hashDATA HUGE_ *) hashStart) + hashVal;
		// Deeper one already stored?
	if (ciq < hPtr->iq + 2)  {
	  if (hPtr->hash == hashLVal) return;	// Was cur pos, dont try for 2nd slot..
	  hPtr += 2;	// Try next slot..
	  if (ciq < hPtr->iq + 2)  return;	// Also not vacant..
	}
	hPtr->iq = (unsigned) ciq;
	hPtr->eval = ceval;
	hPtr->hash = hashLVal;
	hPtr->bestMove = bestmove;
	hPtr->bestDir = bestdir;
}

STFUNC void FASTCALL hashSaveDrawTran ()	// Save BOARD as transposition table entry   
{
	hashDATA HUGE_ *hPtr;	// Pointer to current entry..
	hashGetVal ();		// Encode BOARD [] to BITBRD [], HASHCODE   
	   // Get Ptr to cur element   
	hPtr = ((hashDATA HUGE_ *) hashStart) + hashVal;
		// HASHOP one already stored?
	if (hPtr->iq > 500)  return ;
	hPtr->iq = (unsigned) 1;
	hPtr->eval = EVAL_DRAWSCH;
	hPtr->hash = hashLVal;
	hPtr->bestMove = 0;
	hPtr->bestDir = 0;
        thashdraw [schPly] = (long) hashVal;
}

STFUNC short hashCheckTran ()	// Check BOARD against transposition table   
{
	hashDATA HUGE_ *hPtr;	// Pointer to current entry..
	short ceval;
	short ciq;
	hashGetVal ();		// Encode BOARD [] to BITBRD [], HASHCODE   
	  // Get Ptr to cur element   
	hPtr = ((hashDATA HUGE_ *) hashStart) + hashVal;
	hashAccess ++;
	if (hPtr->hash != hashLVal) {
	  hPtr += 2;	// Try next slot..
	  if (hPtr->hash != hashLVal) return 0;// Long hash val fails check
	}
	ciq = hPtr->iq;
	if (ciq == 0) return (0);	// No hash stored..
	ceval = hPtr->eval;
	if ((schMixedFlags & 4096) == 0) {
	  hashBestMove = hPtr->bestMove;
	  hashBestDir = hPtr->bestDir;
	}
	if (ceval >= EVAL_DRAW) {		// Draw by repetition.
	  if (schDrawStat == 0) schCut += 10;	// Shallower search..
	  schDrawStat |= DRAW_REP;
	  return 0;				// cont search..
	}
		// Allow 5 iq points because IQ stored AFTER adding plys IQ factor.
	if ((schIQcut - schCut - 5) > ciq) return (0);
	hashHit ++;
	if (schEVAL_IS_TRUE (ceval)) {	// True eval, return it..
	  schBestEval = ceval;
	  return (1);
	}
	if (schMixedFlags & 2) return 0;	// short-circuit hash..
	if (schEVAL_IS_MORE(ceval)) {		// score >= eval, set win..
	  if ((schMixedFlags & 1) == 0 && schColor == CBLACK) return 0;
	  schWinLo = max (schWinLo,schEVALTRUE (ceval));
	  return 0;
	}
		// score <= eval, set win..
	if ((schMixedFlags & 1) == 0 && schColor == CWHITE) return 0;
	schWinHi = min (schWinHi,schEVALTRUE (ceval));
	return 0;
}

typedef struct {
  short flag;
  long hash1,hash2;
} hashDRAWS;

#define hashMAXDRAWS 64		// Must be power of 2..
hashDRAWS hashDraw [hashMAXDRAWS + 2];	// For draw-by-rep values..

void hashClrDraws ()
{
	short cpos;
	for (cpos = 0; cpos < hashMAXDRAWS; cpos ++) {
	  hashDraw [cpos].flag = 0;
	}
}

  // Add current pos as draw-entry
void hashAddDraw ()
{
	short cpos;
	cgbrd2sch ();
	schColor = GetColorForMove (eng.move_number);
	buildpos ();		// Build piece list
	hashGetVal ();		// Get hash values..
	cpos = eng.move_number & (hashMAXDRAWS - 1);
	hashDraw [cpos].flag = 1;
	hashDraw [cpos].hash1 = (long) hashVal;
	hashDraw [cpos].hash2 = (long) hashLVal;
}

int drawbyrep = 0;

  // Move "hashDraw" info into real hash table
MYINLINE void hashReadDraws ()
{
	short cpos;
	hashDATA HUGE_ *hPtr;	// Pointer to current entry..
	drawbyrep = 0;
	if (schMixedFlags & 4) return;		// Dont use draw values..
	for (cpos = 0; cpos < hashMAXDRAWS; cpos ++) {
	  if (hashDraw [cpos].flag) {
	    hPtr = ((hashDATA HUGE_ *) hashStart) + hashDraw[cpos].hash1;
	    if (hPtr->iq && hPtr->eval == EVAL_DRAW) drawbyrep ++;
	    hPtr->iq = 511;
	    hPtr->eval = EVAL_DRAW;	// Draw eval..
	    hPtr->hash = hashDraw [cpos].hash2;
	  }
	}
}

  // Clear Hash tables, except for draw-values..
STFUNC void hashClr ()
{
	long ctran;
	if (hashFlag == 0) return;
	for (ctran = 0; ctran <= hashNoEle + 1; ctran ++) {
	  ((hashDATA HUGE_ *) hashStart) [ctran].iq = 0;
  	  ((hashDATA HUGE_ *) hashStart) [ctran].bestMove = 0;

	}
	hashReadDraws ();	// Read in draw data..
}

short hashCountDraws ()	// Debuging function - count draws in hash..
{
	long ctran;
	short ndr = 0;
	hashDATA HUGE_ *hPtr = (hashDATA HUGE_ *) hashStart;
	if (hashFlag == 0) return 0;
	for (ctran = 0; ctran <= hashNoEle + 1; ctran ++) {
	  hPtr ++;
	  if (hPtr->iq && hPtr->eval == EVAL_DRAWSCH) ndr++;
	}
	return ndr;
}

//---------------------------------------------------------------
// MODULE: autol_ Autolearn functions
//---------------------------------------------------------------

typedef struct {
  long id;	// Always 1234
  long nauto;
  long cauto;
  long hashNoEle;	// hashNoEle when table was created
  hashDATA thash[0];
} AUTOL_HASH;

AUTOL_HASH *autol_pDat = NULL;
char autol_szFile [] = "autolrn.bin\0(C) A.Millett, PC Solutions.";

  // New search, load autolearn values into hash table..
void autol_Init ()
{
    int auSize;
    int cauto;
    if (eng.autolearn == 0) return;
    auSize = eng.autolearn * 1024;
    if (autol_pDat == NULL) {
      int flen,mlen;
      flen = file_Length (autol_szFile);
      if (flen >= 0) {  // Check id
        AUTOL_HASH head;
        file_Load (autol_szFile,&head,0,sizeof(head));
	if (head.id != 1234) flen = -1;   // Bad file, overwrite..
        if (head.hashNoEle != hashNoEle) flen =-1;	// no of hash entries changed, restart..
      }
      mlen = sizeof (AUTOL_HASH) + sizeof (hashDATA) * auSize;
      if (flen == -1) {   // Never used before, create new file..
        autol_pDat = (AUTOL_HASH *) malloc (mlen+1024);
	memset (autol_pDat,0,mlen);
        autol_pDat->id = 1234;
        autol_pDat->nauto = auSize;
	autol_pDat->hashNoEle = hashNoEle;
	file_Save (autol_szFile,autol_pDat,mlen,0);
      } else {		// Load existing file..
        if (flen != mlen) {   // File exists, but dif size, resize..
          autol_pDat = (AUTOL_HASH *) malloc (max (mlen,flen)+1024);
	  memset (autol_pDat,0,mlen);
	  file_Load (autol_szFile,autol_pDat,0,flen);
	  autol_pDat->cauto = autol_pDat->nauto;
          autol_pDat->nauto = auSize;
          if (autol_pDat->cauto >= auSize) autol_pDat->cauto = 0;
	} else {	// Simple load..
          autol_pDat = (AUTOL_HASH *) malloc (mlen+1024);
	  memset (autol_pDat,0,mlen);
	  file_Load (autol_szFile,autol_pDat,0,mlen);
	}
      }
    }
	// OK data is checked/loaded, put into real hash table..
		// Load into real hash table..
    for (cauto = 0; cauto < autol_pDat->nauto; cauto ++) {
      hashDATA *pAuto;	// move From autolearn table
      hashDATA *pHash;  // To real hash table
      pAuto = &autol_pDat->thash[cauto];
      if (pAuto->iq) {
        pHash = ((hashDATA *) hashStart) + pAuto->spare;
	if (Debug && pAuto->spare == 258707) {
	  temp = temp + 1;
	}
	if (pAuto->iq >= pHash->iq-40) {   // Dont overwrite very deep existing hash..
	  *pHash = *pAuto;	
	}
      }
    }
    return;
}

long autol_LastHash = 0;

  // Check autolearning params each new iteration..
void autol_SaveScore (short ceval, short ciq, short bestmove, short bestdir)
{
    static int earlyscore;
    hashDATA *pAuto;	// To autolearn table
    hashDATA *pHash;  // From real hash table
    if (eng.autolearn == 0) return;
    if (schPly > 1) {// Save ply2/3 scores in a mini table ahead of normal ptr..
      static int minirot;
      int pos = autol_pDat->cauto + 64;
      if (schIQcut < 110) return;
      if (pos >= autol_pDat->nauto - 64) pos = 0;   // Ensure wrap ok..
      pos += (minirot & 63);	// Store 63 misc scores..
      minirot ++;
      pAuto = &autol_pDat->thash[pos];
      pAuto = &autol_pDat->thash[autol_pDat->cauto];
      pHash = ((hashDATA *) hashStart) + hashVal;
      *pAuto = *pHash;
      pAuto->spare = (long) hashVal;
      if (pAuto->eval >= EVAL_DRAW) {	// Stored was draw, so ensure a real eval is stored..
        pAuto->eval = schBestEval;
        pAuto->iq = ciq;
	pAuto->bestMove = bestmove;
	pAuto->bestDir = bestdir;
      }
      return;
    }
    //if (schIQcut < 50) {
    //  earlyscore = schBestEval; return;
    //}
    if (schIQcut < 110) return;
	if (Debug && hashVal == 258707) {
	  temp = temp + 1;
	}
    //if (abs(earlyscore - schBestEval) < 128) return;   // No big change in score, so dont store..
    if (autol_LastHash != (long) hashVal) {  // Goto next slot..
      autol_LastHash = (long) hashVal;
      autol_pDat->cauto ++;
      if (autol_pDat->cauto >= autol_pDat->nauto) autol_pDat->cauto = 0;
      
    }
    pAuto = &autol_pDat->thash[autol_pDat->cauto];
    pHash = ((hashDATA *) hashStart) + hashVal;
    *pAuto = *pHash;
    pAuto->spare = (long) hashVal;
    if (pAuto->eval >= EVAL_DRAW) {	// Stored was draw, so ensure a real eval is stored..
      pAuto->eval = schEVALTRUE (schBestEval);
      pAuto->iq = ciq;
      pAuto->bestMove = bestmove;
      pAuto->bestDir = bestdir;
    }

}

  // Prog ends, save & free autolearn data..
void autol_Quit ()
{
    int auSize,mlen;
    if (eng.autolearn == 0) return;
    auSize = eng.autolearn * 1024;
    mlen = sizeof (AUTOL_HASH) + sizeof (hashDATA) * auSize;
    file_Save (autol_szFile,autol_pDat,mlen,0);
    free (autol_pDat);
    autol_pDat = NULL;
}

//------------------------------------------------------------
//  Hash preset loaded values
//

typedef struct {
  long hash1;
  long hash2;
  short eval;
} HASH_PRESET;

HGLOBAL prehGlob = NULL;
HASH_PRESET HUGE_ *preStart = NULL;
long preCount = 0;
long preLastSize = -1;	// When hash size changes, reload..
short preGameType = -1;
#define preSIZE 0x80000L	// 512K entries max..
extern gamINITBRD EPD;		// EPD Board position, side to move, castling..

char szPreFile [] = "hashop1.dpd";

  // Release preset hash table mem
void hashClrPreset ()
{
	  if (prehGlob) {
	    GlobalUnlock (prehGlob);
	    GlobalFree (prehGlob);
	  }
	  prehGlob = NULL;
	  preGameType = -1;
	  preLastSize = -1;
	  preStart = NULL;
	  preCount = 0;
}

  // First use of search with HASHOP tables..
BOOL preReload ()
{
	HFILE hEPDfile = NO_FILE;	// handle to input file..
	short nread;
	char *cstr;
	long ceval;
	if (prehGlob) {
	  GlobalUnlock (prehGlob);
	  GlobalFree (prehGlob);
	}
	prehGlob = GlobalAlloc (GMEM_MOVEABLE, preSIZE * sizeof (HASH_PRESET) + 32);
	if (prehGlob == NULL) return FALSE;
	preStart = (HASH_PRESET HUGE_ *) GlobalLock (prehGlob);
	hEPDfile = _lopen (szPreFile, OF_READ);
	if (hEPDfile == HFILE_ERROR) return FALSE;
	BufReset ();
	preCount = 0;
	do {
	  if (LineInput (hEPDfile, szTemp, SIZEszTemp,1) < 0) break;
	  cstr = szTemp;
	  while (*cstr == 32 || *cstr == 9) cstr ++;
	  if (cstr [0] == 0) break;	// Blank line..
		// Try to parse asc EPD line into a position at EPD.brd..
	  nread = ConvertAsc2Pos (cstr, &EPD);
	  if (nread == 0) break;	// Parse error, bad position..
	  cstr = szTemp + nread;
	  do {
	    if (*cstr < 32) goto badl;
	    if (cstr [0] == 'c' && cstr [1] == 'e') {
	      cstr += 2;        
	      while (*cstr == 32) cstr ++;
	      ceval = (long) atoi (cstr);
	      ceval = (ceval * (long) manval) / 100L;	// Convert to SAGE score..
	      break;
	    }
	    cstr ++;
	  } while (1);
	  hashAltGetVal (EPD.brd,(short) (EPD.side ? CBLACK : CWHITE));
	  preStart [preCount].hash1 = (long) hashVal;
	  preStart [preCount].hash2 = hashLVal;
	  preStart [preCount].eval = schEVALTRUE ((short) ceval);
	  preCount ++;
	} while (preCount < preSIZE - 1);
	_lclose (hEPDfile);	// Close read file
	return TRUE;
badl:
	_lclose (hEPDfile);	// Close read file
	return FALSE;
}


  // Called when a new search starts..
  // Load Preset hash table
void hashLoadPreset ()
{
	long cpos;
	hashDATA HUGE_ *hPtr;	// Pointer to current entry..
	if (schMixedFlags & 512) return;	// Dont use hash presets
	szPreFile [6] = 49 + eng.gamtype;	// Hash Book to load..
	if (FileExists (szPreFile) == FALSE) goto prekill;
		// Type/Size changes, load in DPD file?
	if (preGameType != eng.gamtype || preLastSize != hashNoEle) {		// Changed/new, load it in..
	  preGameType == eng.gamtype;
	  preLastSize = hashNoEle;
	  if (preReload () == FALSE) goto prekill;
	}
	if (prehGlob == NULL) return;
	if (preCount == 0) return;
		// Load into real hash table..
	for (cpos = 0; cpos < preCount; cpos ++) {
	  hPtr = ((hashDATA HUGE_ *) hashStart) + preStart [cpos].hash1;
	  hPtr->iq = 511;
	  hPtr->eval = preStart [cpos].eval;
	  hPtr->hash = preStart [cpos].hash2;
	}
	return;
prekill:
	hashClrPreset ();
}

//#else   // hashENABLE
// STINT tranflag = 0;		// No transpositions..
#endif	// hashENABLE..   

//-------------------------------------------------------------------------
//		
// 		ENDGAME DATABASE FUNCTIONS..   
//


char edbFile [100] = "db6";	// Name of default endgame db file. NOTE - LEAVE SPACE for IDX letters at end
short edbMaxPieces = 6;		// # pieces in that db
short edbBuffSize = 8000;		// # K mem to alloc for buffers.
short edbGameType = 0;
short edbType = 6;		// Type of db + (gametype * 10)

#if ENDGAMEDB

typedef struct {
  BYTE result;
    #define EDB_DRAW 0
    #define EDB_WWIN 1
    #define EDB_BWIN 2
    #define EDB_UNKNOWN 3
    #define EDB_NOT_QUIET 4
  BYTE nmen;
  BYTE manmoved;
  BYTE spare;
} EDB_RES;

EDB_RES schEndDB;		// Current endgame db result.. (EDB_WIN/DRAW/LOSS/UNKNOWN)
EDB_RES tenddb    [Mply];	// Current endgame db status
EDB_RES schDBStatusAtStart;

#define EDB_USE_ALT (schEndDB.result >= EDB_UNKNOWN)	// Use alt endgame eval..

STBYTE edbBrd2Bit [90];
STINT edbDisabled = -1;		// =0 when dbase is enabled...
short edbDepth = 0;		// Depth after 1/2 way to start using databases..
short edbStartDepth = 1;
  // Init Board->BitBrd converters..
STFUNC void edbInitGame ()
{
	BYTE csqr;
	short cpos;
	char lookupEng [] = {0, 7,15,23,31, 3,11,19,27, 6,14,22,30, 2,10,18,26,
		5,13,21,29, 1,9,17,25, 4,12,20,28, 0,8,16,24};
	char lookupIt [] = {0, 31,23,15,7, 27,19,11,3, 30,22,14,6, 26,18,10,2,
		29,21,13,5, 25,17,9,1, 28,20,12,4, 24,16,8,0};
	char *lookup;
	//memset (edbBrd2Bit,0,sizeof (edbBrd2Bit));
	for (cpos = 0; cpos < sizeof (edbBrd2Bit); cpos++) {
	  edbBrd2Bit [cpos] = 0;
	}
	if (eng.gamtype == 0) {
	  lookup = lookupEng;
	} else if (eng.gamtype == 1) {
	  lookup = lookupIt;
	} else {
	  return;	// Not 8x8 game..
	}
	for (csqr = 1; csqr <= (BYTE) schNsqrs; csqr ++) {
	  cpos = ext_num2pos (csqr);
	  cpos = cg2sch (cpos);
	  edbBrd2Bit [cpos] = lookup [csqr];
	}
}

long edbBitBrd [3];	// Bit-board rep of pieces:W,B,K.

  // Convert move-list to bitboard and get DB result..
short edbGetResult ()
{
	register short cpos;
	long cmask;
	short cbit;
	short cloc;
	edbBitBrd [0] = edbBitBrd [1] = edbBitBrd [2] = 0;	// Clr bitboard
		// Scan piece lists, build bits..
	cpos = 0;			// White piece list..
	while (cpos < nwhpos) {
	  cloc = whpos [cpos];
	  if (cloc) {
	    cmask = 1L;
	    cbit = edbBrd2Bit [cloc];
	    cmask <<= cbit;
	    edbBitBrd [0] |= cmask;
	    if (whtype [cpos] & 1) {	// King..
	      edbBitBrd [2] |= cmask;
	    }
	  }
	  cpos ++;
	}
	cpos = 0;			// Black piece list..
	while (cpos < nblpos) {
	  cloc = blpos [cpos];
	  if (cloc) {
	    cmask = 1L;
	    cbit = edbBrd2Bit [cloc];
	    cmask <<= cbit;
	    edbBitBrd [1] |= cmask;
	    if (bltype [cpos] & 1) {	// King..
	      edbBitBrd [2] |= cmask;
	    }
	  }
	  cpos ++;
	}
	
	if (edbBitBrd [0] == 0 || edbBitBrd [1] == 0) { // Illegal pos..
	  return -9999;
	}
	cloc = (short) DBLookup (edbBitBrd,(short) (schColor == CBLACK));
	return (cloc);
}

  // EVAL Endgame DB for search..
short MYINLINE edbUpdate ()
{
	short origNmoves = schNmoves;
	short oppcapt;
	if (nowhite + noblack > edbMaxPieces) return EDB_UNKNOWN;
	if (eng.gamtype != edbGameType) return EDB_UNKNOWN;
	//if (schPly == 1) return EDB_UNKNOWN;
	if (jumpflag) return EDB_NOT_QUIET;

	//if (schCut <= edbStartDepth) return EDB_UNKNOWN;
	  	// Now look at opp moves, chack no pieces en-prise..
	mvbrd += origNmoves; 
	mvdir += origNmoves;
	mveval += origNmoves;
	mvindex += origNmoves;
	schColor = FLIPWB - schColor;	// Toggle color   
	FastGenerateJumps
	oppcapt = schNmoves;
	mvbrd -= origNmoves;   // Adv. move list pointers to new stack   
	mvdir -= origNmoves;
	mveval -= origNmoves;
	mvindex -= origNmoves;
	schColor = FLIPWB - schColor;	// Toggle color   
	schNmoves = origNmoves;
	jumpflag = 0;	
	if (oppcapt == 0) {		// OK no capture moves for opp..
	  short res;
	  res = edbGetResult ();	// +1600=side to move wins..
	  if (schColor == CBLACK) res = -res;	// Invert for black..
	  switch (res) {
	    case DB_TIE:		// DRAW..
	      return EDB_DRAW;
	    case DB_WIN:	// W.WIN/B.LOSS..
	      return EDB_WWIN;
	    case DB_LOSS:	// B.WIN/W.LOSS..
	      return EDB_BWIN;
	  }
	  return EDB_UNKNOWN;
	}
	return EDB_NOT_QUIET;
}
	
#if Debug	// Misc debug-test key services..
void edbTest ()
{
	short res;
	InitMoves (0);	// Generate legal move list, initialise misc vars
			// Also reset white/eng.black_move_time = 0;

	res = edbGetResult ();
	msgprintf (NULL,0,0,"End-game Result = %d\n(BitBoards W:%0.8lx B:%0.8lx K:%0.8lx) ",
		res,edbBitBrd [0],edbBitBrd [1],edbBitBrd [2]);
}
#endif

#else		// ENDGAMEDB
 #define EDB_USE_ALT 1		// Always Use alt endgame eval..
#endif		// end-game database..

//-------------------------------------------------------------------------
//		
// 		DEBUGGING FUNCTIONS..
//

#define dbug_SPOOL _DEBUG

#if dbug_SPOOL		// Tree printing features.

#define dbug_DUMP_FLAG (schMixedFlags & 8)	// Dump whole tree..

short dbugFile = -1;

BYTE dbugFrom [Mply];		// Stored tree-info..
BYTE dbugDest [Mply];
BYTE dbugLast [Mply];		// Prev mv checksum..
short dbugNLines;
STFUNC void dbugPrintIter ();

  // Open debug spool file (if not already open)..
STFUNC void dbugOpen ()
{
	if ((schMixedFlags & 8) == 0) return;
	if (dbugFile == -1) {
	  dbugFile = open ("sgdebug.txt",_O_TRUNC | _O_BINARY | _O_WRONLY | _O_CREAT,_S_IREAD | _S_IWRITE);
	}
	dbugNLines = 0;
}

  // Close debug spool file..
void dbugClose ()
{
	if (dbugFile != -1) {
	  if (schMixedFlags & 8) {	// Print final info..
	    dbugPrintIter ();
	  }
	  close (dbugFile);
	  dbugFile = -1;
	}
}

  // Terminal reached, print current line to debug spool text..
STFUNC void dbugPrintLine (short dmode)
{
	char dbugText [350];		// Line to print..
	char *cstr = dbugText;
	short cfr,cto;
	short cret;
	BYTE isdif;
	UINT cply;
	dbugNLines ++;
	if (dbugFile == -1) return;
	if (dmode) {		// Hash pick-up..
	  ADDCHAR (cstr,'#');
	} else {
	  ADDCHAR (cstr,' ');
	}
	int2asc (cstr,schNodes,6);
	cstr += 6;
	if (schBestEval < 0) {
	  ADDCHAR (cstr,'-');
	} else {
	  ADDCHAR (cstr,'+');
	}
	int2asc (cstr,(short) abs (schBestEval),5);
	cstr += 5;
	if (schDoingShort) {
	  ADDCHAR (cstr,'s');
	} else {
	  ADDCHAR (cstr,' ');
	}
	ADDCHAR (cstr,'i');
	int2asc (cstr,schCut,3);
	cstr += 3;
	ADDCHAR (cstr,':');
		// Now print moves up to terminal node.
	isdif = 0;
	for (cply = 1; cply < schPly; cply ++) {
	  cfr = ext_pos2num ((BYTE) sch2cg (dbugFrom [cply]));
	  cto = ext_pos2num ((BYTE) sch2cg (dbugDest [cply]));
	  if (LOBYTE (cfr + cto + cto) != dbugLast [cply]) {
	    dbugLast [cply] = LOBYTE (cfr + cto + cto);
	    isdif = 1;
	  }
	  
	  if (isdif) {
	    ADDCHAR (cstr,'.');
	  } else {
	    ADDCHAR (cstr,' ');
	  }
	  INT2ASC2 (cstr,cfr);
	  INT2ASC2 (cstr,cto);
	}
	if (dmode) {		// Hash pick-up..
	  cstr += wsprintf (cstr," #%0.4x,%0.8lx",hashVal,hashLVal);
	}
	ADDCHAR (cstr,10);
	*cstr = 0;
	cret = write (dbugFile,dbugText,(short) (cstr - dbugText));
	if (cret == -1) {	// Disk write error (disk full?);
	  Dink ();
	  close (dbugFile);
	  dbugFile = -1;
	}
}

  // New iteration - print out info line..
STFUNC void dbugPrintIter ()
{
	char dbugText [350];		// Line to print..
	char *cstr = dbugText;
	short cret;
	if (dbugFile == -1) return;
	cret = wsprintf (dbugText, "ITER: IQ:%d BestEval:%d Nodes:%d HashHit:%d HashLook:%d\n",
		(int) schIQcut,(int) schBestSoFar,(int) schNodes, hashHit,hashAccess);
	cret = write (dbugFile,dbugText,(short) cret);
	
	if (cret == -1) {	// Disk write error (disk full?);
	  Dink ();
	  close (dbugFile);
	  dbugFile = -1;
	}
}

void dbugNewBest ()
{
	char dbugText [50];		// Line to print..
	int cfr,cto;
	short npr;
	if (dbugFile == -1) return;
	if (schPly > 3) {
	  return;
	}
	cfr = ext_pos2num ((BYTE) sch2cg (schSrc));
	cto = ext_pos2num ((BYTE) sch2cg (schSrc + schDir));
	npr = wsprintf (dbugText,"NewBest@Ply%d Move:%d-%d Eval:%d\n",(int) schPly,cfr,cto,(int) schBestEval);
	write (dbugFile,dbugText,npr);
}
#else 	// dbug_SPOOL
 #define dbug_DUMP_FLAG 0	// Disable Dump whole tree..
#endif 	// dbug_SPOOL


STFUNC void miniboard (short xtop, short ytop, short hisqr)	// Disp mini-schBoard   
{
	short cpiece,cpos;
	const short TinySq = 9;
	static short xpos,ypos;
	STBYTE tinypos[] = {36,1, 36,1, 1,1, 10,1, 19,1, 28,1, 44,1};
	xtop = (xtop * (ENG_BOARDX + 1) * TinySq);
	ytop *= 16;
	for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	  for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	    cpos = schPosOf(xpos,ypos);
	    cpiece = min (6,schBoard [schPosOf(xpos,ypos)]) << 1;
	    if (cpos == hisqr) cpiece = 12;
	    BitBlt (hWDC, xpos * TinySq + xtop, ypos * TinySq + ytop, 
	    	TinySq,TinySq,
	    	hTinyDC, tinypos [cpiece],tinypos [cpiece + 1] ,SRCCOPY);
	    
	  }
	}
}

#if schDebug
STFUNC void debugit (char *istr, short hisqr)
{
	short tabpos = schPly * (ENG_BOARDX + 2);
        if (schPly > 8) return;
        SetBkMode (hMainDC,OPAQUE);
	miniboard (schPly,0,hisqr);
	gotoxy (tabpos,ENG_BOARDY + 1);
	prints (istr);
	gotoxy (tabpos,ENG_BOARDY + 2);
	printi (schNmoves);printsi (",",schScore);prints (".");
	prints ("\n\n\n\n\n\n\n\n\n");
	if (debugflag == 2) listpos (1);
	if (DoYesNo ("Debug: More ?") == IDNO) {
	  debugflag = 0;
        }
	gotoxy (tabpos,ENG_BOARDY + 1);
	prints ("      "); 
}
#endif

BOOL histFlag = 1;
#define histSize 4095
short MYSEG histTable [histSize + 16];	// History lookup table..
	// Convert brd/dir/color to lookup pos..
#define Move2Hist(pos,dir,col) \
 ( ( ( ((pos) << 5) ^ ((col) << 3) ) ^ ((BYTE) (((dir) + 32) ^ 1) % 14) ) & histSize)
 
//  ALT:more efficient size, slower..	
//	( ( (((pos) % 50) << 5) ^ ((col) << 4) ) | ((((dir) + 32) ^ 1) % 14) )
	
  // Find simple killer move & history move..
MYINLINE void schHistoryKiller (BOOL dohist) 
{
	UINT cmove;
	short killermove;
	short killerdir;
	short cbrd,cdir;
	if (histFlag == FALSE) dohist = FALSE;
	killermove = tbestmove [schPly];
	killerdir = tbestdir  [schPly];
	if (schColor == CWHITE) {	// WHITE move..
	  for (cmove = 1; cmove <=  (unsigned) schNmoves; cmove ++) {	// Find Killer   
	    cbrd = mvbrd [cmove]; cdir = mvdir [cmove];
	    if (hashBestMove ==  cbrd && hashBestDir == cdir) {
	      mveval [cmove] = 16000;		// Force to top   
	    } else if (killermove ==  cbrd && killerdir == cdir) {
	      mveval [cmove] = 15000;		// Force to top   
	    } else if (dohist) {
	      mveval [cmove] += histTable [Move2Hist (cbrd,cdir,schColor)];
	    }
	  }
	} else {	// BLACK move..
	  for (cmove = 1; cmove <=  (unsigned) schNmoves; cmove ++) {	// Find Killer   
	    cbrd = mvbrd [cmove]; cdir = mvdir [cmove];
	    if (hashBestMove ==  cbrd && hashBestDir == cdir) {
	      mveval [cmove] = -16000;		// Force to top   
	    } else if (killermove ==  cbrd && killerdir == cdir) {
	      mveval [cmove] = -15000;		// Force to top   
	    } else if (dohist) {
	      mveval [cmove] -= histTable [Move2Hist (cbrd,cdir,schColor)];
	    }
	  }
	}
}

  // Calc "The move" factor..
MYINLINE short TheMove ()
{
	register short cpos;
	short movecount = 0;
	short cret;
	const short meval = Vl(32);	// "the move" factor weight..(was 32)
	cpos = 0;			// White piece list..
	while (cpos < nwhpos) {		// If on "Odd sqr" system..
	  if (whpos [cpos] & 1) {
	    movecount ++;
	  }
	  cpos ++;
	}
	cpos = 0;			// Black piece list
	while (cpos < nblpos) {		// If on "Odd sqr" system..
	  if (blpos [cpos] & 1) {
	    movecount ++;
	  }
	  cpos ++;
	}
		// Return +/- eval dependant on move-status.
	cret = (schColor == CBLACK ? meval : -meval);
	if (movecount & 1) return -cret;
	return cret;
}


//  schBoard [] for english - white at top.. (sq1==87,sq32==12) (bm=2,bk=3,wm=4,wk=5)
// --  12  --  14  --  16  --  18  
// 21  --  23  --  25  --  27  --  
// --  32  --  34  --  36  --  38  
// 41  --  43  --  45  --  47  --  
// --  52  --  54  --  56  --  58  
// 61  --  63  --  65  --  67  --  
// --  72  --  74  --  76  --  78  
// 81  --  83  --  85  --  87  --  

 // Return (schBestEval) for curr pos.   
void FASTCALL TerminalNode ()
{
	short nwht = Nwhtmen + Nwhtking;
	short nblk = Nblkmen + Nblkking;
	short matbal;
	schNodes ++;	// Increment terminal node count   

	matbal = manvals [nwht] - manvals [nblk]
		+ kingvals [Nwhtking] - kingvals [Nblkking];
        
	schBestEval = matbal + schScore ;
	/*
        if (Nwhtking && Nblkmen) {   // Any Wht kings behind Blk men?
	  short cpos,bpos;
	  for (cpos = 0; cpos < nwhpos; cpos ++) {
	    if (whtype [cpos] == Wking) {
	      bpos = whpos [cpos];
	      if (schBoard [bpos + dirdl] == Bman) {
	        if (schBoard [bpos + dir2dl] != EdgeSq) schBestEval -= Vl(8);
	      }
	      if (schBoard [bpos + dirdr] == Bman) {
	        if (schBoard [bpos + dir2dr] != EdgeSq) schBestEval -= Vl(8);
	      }
	    }
	  }
	}		
        if (Nblkking && Nwhtmen) {   // Any Blk kings behind Wht men?
	  short cpos,bpos;
	  for (cpos = 0; cpos < nblpos; cpos ++) {
	    if (bltype [cpos] == Bking) {
	      bpos = blpos [cpos];
	      if (schBoard [bpos + dirul] == Wman) {
	        if (schBoard [bpos + dir2ul] != EdgeSq) schBestEval += Vl(8);
	      }
	      if (schBoard [bpos + dirur] == Wman) {
	        if (schBoard [bpos + dir2ur] != EdgeSq) schBestEval += Vl(8);
	      }
	    }
	  }
	} */
			
        	// Even # pieces, look for move..
        if (nwht == nblk && ((ENG_BOARDX | ENG_BOARDY) & 1) == 0) {
	  if (nwht < 5) {		// When 4 or less a side..
	    schBestEval += (TheMove () >> ((nwht + 1)/2));
          }
        } 
	if (Nwhtking + Nblkking) {	// King parameters..   
	  if (matbal > Vl(20)) {	// If black is lesser   
	    if ((*corn1b) + (*corn2b) == 3) {
	      schBestEval -= Vl(21);		// Encourage B.King in D corner   
            } else if ((*corn2w) + (*corn1w) == 3) {
	      schBestEval -= Vl(21);
	    }	
	  }

	  if (matbal < Vl(-20)) {	// If WHITE is lesser   
	    if (((*corn1b) ^ (*corn2b)) == 5) {
	      schBestEval += Vl(21);		// Encourage W.King in D corner   
	    } else if (((*corn2w) ^ (*corn1w)) == 5) {
	      schBestEval += Vl(21);
	    }
	  }      	      
	}

	if (*keyrb == Bman) {	   // BLACK back defence   
	  if (*dogrb == Wman)      	// Dog hole ?   
	    schBestEval -= schDogval1;
	  if (*keylb == Bman)		// Bridge factor   
	    schBestEval -= schBackval;
	  if (*orr2b == Bman && *orr3b == Bman)	// Dcorn tri ?   
	    schBestEval -= schBackval;
	}
	if (*keylb == Bman) {
	  if (*orl2b == Bman && *orl3b == Bman)	// Oreo ?   
	    schBestEval -= schOreoval;
	  if (*doglb == Wman)		// 2nd dog hole ?   
	    schBestEval -= schDogval2;
	}

	if (*keylw == Wman) {		// WHITE defence   
	  if (*doglw == Bman)		// Dog hole ?   
	    schBestEval += schDogval1;
	  if (*keyrw == Wman)		// Bridge factor   
	    schBestEval += schBackval;
	  if (*orl2w == Wman && *orl3w == Wman)
	    schBestEval += schBackval;
	}
	if (*keyrw == Wman) {
	  if (*orr2w == Wman && *orr3w == Wman)	// Oreo ?   
	    schBestEval += schOreoval;
	  if (*dogrw == Bman)		// 2nd dog hole ?   
	    schBestEval += schDogval2;
	}
	if (schItalFlag) {
	  if (schType8x8inv) {
	  	// 1K holds 2 men..
	    if (schBoard [31] == Bman && schBoard [33] == Wking
		&& ((schBoard [13] | schBoard [11]) & CWHITE) == 0) {
	      schBestEval += schDogval2 + Vl(6);
	    }
	    if (schBoard [68] == Wman && schBoard [66] == Bking
		&& ((schBoard [86] | schBoard [88]) & CBLACK) == 0) {
	      schBestEval -= (schDogval2 + Vl(6));
	    }
		// CBLACK clamp on w..   
	    if (schBoard [48] == Bman && schBoard [37] == Wman && schBoard [28] == 0) schBestEval -= Vl(5);
	    if (schBoard [51] == Bman && schBoard [42] == Wman) schBestEval -= Vl(7);
	    if (schBoard [57] == Wman && schBoard [68] == Bman) schBestEval -= Vl(7);
	    if (schBoard [62] == Wman && schBoard [71] == Bman) schBestEval -= Vl(7);
		// CWHITE clamp on b..  
	    if (schBoard [51] == Wman && schBoard [62] == Bman && schBoard [71] == 0) schBestEval += Vl(5);
	    if (schBoard [48] == Wman && schBoard [57] == Bman) schBestEval += Vl(7);
	    if (schBoard [42] == Bman && schBoard [31] == Wman) schBestEval += Vl(7);
	    if (schBoard [37] == Bman && schBoard [28] == Wman) schBestEval += Vl(7);
	  }
	} else {
	  if (schType8x8) {		// English..
	    if (matbal < Vl(-20)) {	// If white is lesser   
	      if (schBoard [18] == Wman) {
	        if ((schBoard [16] ^ schBoard [27] ^ schBoard [38]) == Wking) schBestEval += Vl(7);
	      }
	    }
		// BLACK clamp on w..   
	    if (schBoard [41] == Bman && schBoard [32] == Wman) {
	      schBestEval -= Vl(2);
	      if (schBoard [21] == 0) schBestEval -= Vl(3);
	    }
	    if ((schBoard [58] & Bman) && schBoard [47] == Wman) schBestEval -= schClampval;
	    if (schBoard [52] == Wman && (schBoard [61] & Bman)) schBestEval -= schClampval;
	    if (schBoard [67] == Wman && (schBoard [78] & Bman)) schBestEval -= schClampval;
		// WHITE clamp on b..  
	    if (schBoard [58] == Wman && schBoard [67] == Bman) {
	      schBestEval += Vl(2);
	      if (schBoard [78] == 0) schBestEval += Vl(3);
	    }
	    if ((schBoard [41] & Wman) && schBoard [52] == Bman) schBestEval += schClampval;
	    if (schBoard [47] == Bman && (schBoard [38] & Wman)) schBestEval += schClampval;
	    if (schBoard [32] == Bman && (schBoard [21] & Wman)) schBestEval += schClampval;
	    if (Nwhtking || Nblkking) {
	    	// WK@22 holds 2BM..
	      if (schBoard [36] == Wking && schBoard [38] == Bman) {
	        if (schBoard [58] == Bman) schBestEval += schKhold;
	        if (schBoard [16] != Wman) schBestEval += schDogval2;
	      }
	    	// WK@14 holds 2BM..
	      if (schBoard [56] == Wking && schBoard [58] == Bman) {
	        if (schBoard [78] == Bman) schBestEval += schKhold;
	      }
	    	// WK@19 holds 2BM..
	      if (schBoard [43] == Wking && schBoard [61] == Bman) {
	        if (schBoard [41] == Bman) schBestEval += schKhold;
	      }
	    	// BK@11 holds 2WM..
	      if (schBoard [63] == Bking && schBoard [61] == Wman) {
	        if (schBoard [41] == Wman) schBestEval -= schKhold;
	        if (schBoard [83] != Bman) schBestEval -= schDogval2;
	      }
	    	// BK@19 holds 2WM..
	      if (schBoard [43] == Bking && schBoard [41] == Wman) {
	        if (schBoard [21] == Wman) schBestEval -= schKhold;
	      }
	    	// BK@14 holds 2WM..
	      if (schBoard [56] == Bking && schBoard [58] == Wman) {
	        if (schBoard [38] == Wman) schBestEval -= schKhold;
	      }
	    }
	  }
	}

	if (schGamemode == 1) {		// Play-to-lose Mode   
	  schBestEval = - schBestEval;
	  if (nwht == 1) {
	    schBestEval -= Vl(300);
	  }
	  if (nblk == 1) {
	    schBestEval += Vl(300);
	  }
	}
	if (Nwhtking && Nblkking) {	// Dilute eval if both sides have Kings
	  schBestEval = schBestEval - (schBestEval >> 3);
	}
	if (schRNDflag) schBestEval += randeval [((short) schNodes) & schSIZE_RAND];
	if ((BYTE) schPly > schDeepestPly) {		// Stash schDeepestPly term node   
	  schDeepestPly = (BYTE) schPly;
	}
	#if ENDGAMEDB
	 switch (schEndDB.result) {			// Add in endgame result?
	   case EDB_DRAW:
	    schBestEval = schBestEval / 4;
	    break;
	   case EDB_WWIN:
	    schBestEval = schBestEval + (12000 - ((schEndDB.nmen) / 2) * 1024);
	    if (schEndDB.manmoved) {
	      schBestEval += 300;
	    }
	    break;
	   case EDB_BWIN:
	    schBestEval = schBestEval - (12000 - ((schEndDB.nmen) / 2) * 1024);
	    if (schEndDB.manmoved) {
	      schBestEval -= 300;
	    }
	    break;
	   default:
	    /*
	    if (nwht + nwht < edbMaxPieces && nblk - nwht > 1) {	// 4+B v 2-W .. Psedo DB
	      schBestEval -= 10000; break;
	    }
	    if (nblk + nblk < edbMaxPieces && nwht - nblk > 1) {	// 4+W v 2-B .. Psedo DB
	      schBestEval += 10000; break;
	    }
	    */
	    break;
	 }
	#endif
	if (schDrawStat) {	// Possible Draw detected
	  //if (schBestEval > 0) {
	  //  schBestEval = max (0,schBestEval - Vl(30));
	  //} else {
	  //  schBestEval = min (0,schBestEval + Vl(30));
	  //}
	  schBestEval = schBestEval / 2;
	}
		// This should be last line..
	schBestEval = schEVALTRUE(schBestEval);
	#if dbug_SPOOL		// Tree printing features.
	  if (dbug_DUMP_FLAG) {	// Any debug-spool?
	    dbugPrintLine (0);		// Print line to text spool file.
	  }
	#endif
}

MYINLINE void picknextmove ()		// Scan for next best EVAL..   
{
	short bmove,beval;	// Best mv/eval   
	register short tmove;
	if (schMove >=  (unsigned) schNmoves ) return;
	bmove = schMove;
	beval = mveval [bmove];
	if (schColor == CBLACK) {
	  for (tmove = schMove + 1; tmove <= schNmoves; tmove ++) {
	    if (mveval [tmove] < beval) {
	      beval = mveval [tmove];
	      bmove = tmove;
	    }
	  }
	} else {			// CWHITE move ..   
	  for (tmove = schMove + 1; tmove <= schNmoves; tmove ++) {
	    if (mveval [tmove] > beval) {
	      beval = mveval [tmove];
	      bmove = tmove;
	    }
	  }
	}
	Swapmoves (schMove,bmove,tmove);	// Put best at top..   
}

  // Recursive call for building move tables   
  // Search for (schNodeCount) before return. Bit0=Skip MvGen (New iteration)
  // ret 0=still going, 1=iteration done.
STFUNC short FASTCALL SearchDo (UINT schNodeCount)
{
	static unsigned short inflag;
	short trueEval;		// Eval with lo hash-bits stripped out.
	short lastCut;		// prev ply cut..
	inflag = schNodeCount;
	schNodeCount = schNodeCount & 0xfff0;
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	materialdif = nowhite - noblack;
	if (inflag & 1) {   // New iteration, skip mvgen..
	  goto SkipMvGen;
	}
	if (inflag & 2) {   // New iteration, skip to scan moves..
	  goto ScanMoves;
	}
	
UpTree:			// Recursive loop point..
	if (schNodeCount > 0xf000) return 0;		// Halt search..
	schNodeCount --;
	nowhite = Nwhtmen + Nwhtking; noblack = Nblkking + Nblkmen;
	materialdif = nowhite - noblack;
	if (schPly <=  (unsigned) bestflag) {
	  Bestline (schPly,schPly) = 0;
	}
	if (schPly > Mply - 3 || schCut > 300) {	// Overflow!
	  TerminalNode ();
	  goto DownTree;		// Go back down search tree..
	}
	if (multijump == 0) {	// Has prev. ply gen MULTI-JUMP moves ?   
	  if (schCut > schIQcut && schPly > 1 && schPly > ((UINT) schIQcut >> 4)) {	// End search ?   
	    FastGenerateJumps		// Quiesence search
	    if (schNmoves == 0) {	// No more jumps, terminate..
	      /*#if ENDGAMEDB
	        if (edbDepth) {
		  jumpflag = 0;
	          schEndDB = edbUpdate ();
	          if (schEndDB == EDB_NOT_QUIET) {  // Pieces are en-prise..
		    goto NormMvGen;
		  }
		}
	      #endif
	      */
	      TerminalNode ();
	      goto DownTree;		// Go back down search tree..
	    }
	  } else {		// Normal move gen   
            #if hashENABLE
	    if (schCut < schIQcut - hashSchFlag && hashSchFlag && schDrawStat == 0) {
	      if (hashCheckTran () && schPly > 1) {	// Transposition hit ?   
		#if dbug_SPOOL		// Tree printing features.
		  if (dbug_DUMP_FLAG) {	// Any debug-spool?
		    dbugPrintLine (1);		// Print line to text spool file.
		  }
		#endif
		if (schPly <  (unsigned) bestflag && schDoingShort == 0) {		// Bestline ?   
		  Bestline (schPly,schPly) = ((hashBestMove + hashBestDir) << 8) + hashBestMove;
		  Bestline (schPly,schPly+1) = 0;
		}
		tbestmove [schPly] = hashBestMove;	// Clr next plys response   
		tbestdir [schPly] = hashBestDir;
		tbestmove [schPly+1] = 0;	// Clr next plys response   
		tbestdir [schPly+1] = 0;
		//tbestmove [schPly] = 0;	// Clr next plys response   
		//tbestdir [schPly] = 0;
	        goto DownTree;		// Go back down search tree..
	      }
	    }
            #endif
NormMvGen:
	    FastGenerateMoves		// Gen blk/wht move list   
	    #if schDebug
	      if (gen2flag & 1) {
	        FastGenerateMoves
	      }
	    #endif
	  }	// Jmpgen if..   
	} else {	// Multijump..   
	  jumpflag = 1;
	}
	if (schItalFlag) {
	  if (jumpflag && testflag == 0) {   // Scan jumps, del illegal   
	    filtergen ();
	  }
	}
SkipMvGen:			// When 1st called, go to this point..
	#if schDebug
	 if (debugflag) { debugit ("Up..",0);}
	#endif
	if (jumpflag && schPly > 1) {		// Last man capt, game end   
	  if (nowhite == 1 && schColor == CBLACK) {
	    schNodes ++;
	    schBestEval = schEVALTRUE(-32000 + schPly * 4);
	    goto DownTree;		// Go back down search tree..
	  }
	  if (noblack == 1 && schColor == CWHITE) {
	    schNodes ++;
	    schBestEval = schEVALTRUE(32000 - schPly * 4);
	    goto DownTree;		// Go back down search tree..
	  }
	}

	if (schGamemode == 2) {	// King race   
	  if (Nwhtking) {
	    schBestEval = 32000 - (schPly << 2);
	    goto DownTree;		// Go back down search tree..
	  }
	  if (Nblkking) {
	    schBestEval = -32000 + (schPly << 2);
	    goto DownTree;		// Go back down search tree..
	  }
	}

	if (schNmoves == 0) {      // No moves, so side is lost   
	  schNodes ++;
	  if (schColor == CBLACK) {
	    schBestEval = schEVALTRUE(32000 - (schPly << 2));	// +ve bad for black   
	  } else {
	    schBestEval = schEVALTRUE(-32000 + (schPly << 2));
	  }
	  if (schGamemode == 1) schBestEval = - schBestEval;	// Play to lose !   

	  goto DownTree;		// Go back down search tree..
	}
	#if ENDGAMEDB
	  if (schCut < edbDepth) {
	    short newDB;
	    newDB = edbUpdate ();
	    if (newDB < EDB_UNKNOWN) {  // If new score is definate, use for later eval..
	      schEndDB.result = (BYTE) newDB;
	      schEndDB.nmen = (BYTE) nowhite + noblack;
	      schEndDB.manmoved = (BYTE) schManMoved;
	    }
	    if (schPly == 1) {
	      schDBStatusAtStart = schEndDB;
	      schDBStatusAtStart.result = newDB;
	    } else {
			// If not started in DB & sch hits DB, terminate search..
	      if (schEndDB.result < EDB_UNKNOWN) {
	        if (schManMoved || (schDBStatusAtStart.result != schEndDB.result && schDBStatusAtStart.result != EDB_NOT_QUIET)) {   // Change in end db status..
	          schCut += 8;    // Terminate this branch more quickly..
		}
	        //if (schDBStatusAtStart < EDB_UNKNOWN) {   // Sch started from dbase score..
	        //   schCut += 4;    // Terminate this branch more quickly..
	        //} else {
	        //  TerminalNode ();    // Found DB score from nonDB-start sch, terminate..
	        //  goto DownTree;	
		//}
	      }
	    }
	  }
	#endif
		// Hard-wired endgame db..
	if (EDB_USE_ALT && nowhite == 1 && Nblkking > 1 && schColor == CBLACK) {
	  if (usedbflag && jumpflag == 0 && schCut + schCut > schIQcut) {  // Pseudo Dbase ?   
	    if (Nblkking > 2) {		// 3Bk+ v 1W   
	      TerminalNode ();
	      schBestEval -= 10000;
	      goto DownTree;		// Go back down search tree..
	    }
	    if (Nwhtmen) {		// 2Bk+ v 1Wm   
	      TerminalNode ();
	      schBestEval -= 10000;
	      goto DownTree;		// Go back down search tree..
	    }
	    if (schCut + schCut + schCut > schIQcut + schIQcut) {
	      TerminalNode ();
	      schBestEval -= Vl(32);
	      goto DownTree;		// Go back down search tree..
	    }
	  }
	} else if (EDB_USE_ALT && noblack == 1 && Nwhtking > 1 && schColor == CWHITE) {
	  if (usedbflag && jumpflag == 0 && schCut + schCut > schIQcut) {  // Pseudo Dbase ?   
	    if (Nwhtking > 2) {		// 3Wk+ v 1B   
	      TerminalNode ();
	      schBestEval += 10000;
	      goto DownTree;		// Go back down search tree..
	    }
	    if (Nblkmen) {		// 2Wk+ v 1Bm   
	      TerminalNode ();
	      schBestEval += 10000;
	      goto DownTree;		// Go back down search tree..
	    }
	    if (schCut + schCut + schCut > schIQcut + schIQcut) {
	      TerminalNode ();
	      schBestEval += Vl(32);
	      goto DownTree;		// Go back down search tree..
	    }
	  }
	}  
	#if hashENABLE		// Save a transposition draw going up tree..
	  thashdraw [schPly] = 0;
	  if (schCut + schCut + 5 < schIQcut && (schMixedFlags & 16) == 0) {
	    if (hashSchFlag
	       && schDoingShort == 0 && schWinHi - schWinLo > 0 
	       && schDrawStat == 0 && Nwhtking && Nblkking) {
	        hashSaveDrawTran ();
	    }
          }
	#endif
	
	if (schPly > 1 && killerflag && schNmoves > 2 && tbestmove [schPly]) { // Killer move ?   
	  schHistoryKiller (schCut + 15 < schIQcut);
	}

	
				// Calc new cutoff val   
	if (fwdflag) {	// was fwdflag
	  short temp;
	  BYTE lastjump = tjumpflag [schPly - 1];	// Last move jump?
	  short iqadd = 9;
	  if (jumpflag) {
	    iqadd = 7;
	    if (schNmoves == 1) iqadd = 1;
	    /* iqadd = 9;
	    temp = materialdif + 1;		// mat dif AFTER jump..
	    if (schColor == CBLACK) temp -= 2;
	    if (temp < 0) temp = -temp;		// ABS   
	    if (schNmoves == 1) iqadd -= 3;
	    if (tcolor [schPly - 1] == schColor) {	// Multijump?   
	      iqadd -= 3;
	      if (temp < 2) iqadd -= 2;
	    } else {
	      if (temp == 0 || materialdif == 0) {
		iqadd -= 4;
	      } else {
		if (temp == 1) iqadd -= 2;
	      }
	    }*/
	  } else {	// Non jump   
	    iqadd = (schNmoves / 8) + 9;
	    if (materialdif) {
	      //iqadd ++;
	      if (materialdif < -1 || materialdif > 1) iqadd += schFwdPrune;
	      if (materialdif < -2 || materialdif > 2) iqadd += schFwdPrune;
	      //if (lastjump == 0) iqadd ++;
	    }
	  }
	  schCut += min (15,max (iqadd,1));	// Ensure min/max add..
	  if (schColor == CBLACK) {	// Add in mobility..
	    schScore -= schNmoves;
	  } else {
	    schScore += schNmoves;
	  }
	} else {	// Original - deep scan   
	  if (schNmoves > 1) {
	    if (schNmoves < 8) {
	      schCut += (schNmoves >> 1) + 8;	// was nm + 5   
	    } else {
	      schCut += (schNmoves >> 2) + 10;
	    }
	  }
	}
        #if ENDGAMEDB
         tenddb    [schPly] = schEndDB;	// Save endgame DB status..
        #endif
	if (pvsflag) tpvsset[schPly] = FALSE;
        tdrawstat [schPly] = schDrawStat;	// Draw-status
        tmanmoved [schPly] = schManMoved;
	tcolor    [schPly] = schColor;	// Save color   
	tnomoves  [schPly] = schNmoves;	// Save move table size   
	tccut     [schPly] = schCut;	// Save running cutoff total   
	tweight   [schPly] = schScore;	// Save running weight/time value   
	tjumpflag [schPly] = jumpflag ;	// Save jump status   
	
	tnblkmen  [schPly] = Nblkmen ;	// Stash piece counts   
	tnblkking [schPly] = Nblkking ;
	tnwhtmen  [schPly] = Nwhtmen ;
	tnwhtking [schPly] = Nwhtking ;

	schKnockDown = 0;
	
		// Short look ahead? Do quick search to order moves,
		// if we are low in the tree..
	if (schShortDepth && schShortDepth + schCut < schIQcut
		      && schDoingShort == 0 && schNmoves > 1 && schPly > 1) {
	  short templo,temphi,tempiq,nodec;
	  UINT tempply;
	  templo = schWinLo; temphi = schWinHi;
	  tempply = schPly;
	  schWinLo = EVAL_LOWEST; schWinHi = EVAL_HIGHEST;	// Full width short 
	  tempiq = schIQcut;
	  schDoingShort = 1;
	  schIQcut = min ((schIQcut >> 1),schCut + 40); // Depth of ordering sch..
	  // schIQcut = (schIQcut + schCut) / 2; // Depth of ordering sch..
	  schStartPly = schPly;	// No cuts at this ply 
	  nodec = 0x7ff2;	// Node-count+skip to scan-moves..
	  while (SearchDo (nodec) == 0) { // Search all moves, return best 
	    nodec &= 0xfff0;		// Mask out skip-init bit..
	  }
	  schIQcut = tempiq;
	  schWinLo = templo; schWinHi = temphi;
	  #if Debug
	    if (schPly != tempply) {
	      exit (0);
	    }
	  #endif
	  schDoingShort = 0;	// Enable deeper looks 
	  schStartPly = 1;
	  if (0 && schCut * 2 > schIQcut) {   // PROBCUT style extension..
	    if (schColor == CBLACK) {		// See if better CBLACK move found   
	      if (schBestEval < schWinLo) {
	        schBestEval = schWinLo;
	        goto DownTree;		// Go back down search tree..
	      }
	    } else {
	      if (schBestEval > schWinHi) {
	        schBestEval = schWinHi;
	        goto DownTree;		// Go back down search tree..
	      }
	    }
	  }
	  schKnockDown = 0;	// Deeper on 1st move.. 
	  if (jumpflag == 0) {
	    if (schCut + schCut - 20 < schIQcut) {
	      if (schPly > 4 && tcmove [schPly - 2] == 1 && tnomoves [schPly - 2] > 1) {
	        schKnockDown += 2;
	        if (tcmove [schPly - 4] == 1 && tnomoves [schPly - 4] > 1) schKnockDown += 2;
	      }
	    }
	  }
	}
		// SCAN-MOVES - Evaluate move list, ret best   
ScanMoves:
	tbestmove [schPly] = 0;   	// Init best move   
	tbestdir  [schPly] = 0;
	if (schColor == CBLACK) {		// Init best eval counter to lowest   
	  tbesteval [schPly] = EVAL_HIGHEST;
	} else {
	  // tbesteval [schPly] = schWinLo;	 -ve bad for white   
	  tbesteval [schPly] = EVAL_LOWEST;
	}
	schMove = 1;	// For schMove = 1 to schNmoves..
schNextMove:	

	  picknextmove ();		// PICK NEXT BEST EVAL   
schRedoMove:
	  qcrowned = 0;			// Flag indicates crowning   
	  schSrc = mvbrd [schMove];		// Get coord of piece, & dir   
	  schDir = mvdir [schMove];
	  schPiece = schBoard [schSrc];	// Piece to be moved   
	  toldpiece [schPly] = schPiece;	// Stash its val on stack   
	  schDest = schSrc + schDir;
	  #if dbug_SPOOL		// Tree printing features.
	    if (dbug_DUMP_FLAG) {		// Add mv to debug spool text
	      dbugFrom [schPly] = (BYTE) schSrc;
	      dbugDest [schPly] = (BYTE) schDest;
	    }
	  #endif

	  xindex = mvindex [schMove];
	  if (schColor == CBLACK) {
	    if (schSrc != blpos [xindex]) {
	      prints ("Scan:"); listpos (0); 
		{ short xx = 1;
		  if (xx == 1) {
		    return (1);
		  }
		}
	    }
	  } else {
	    if (schSrc != whpos [xindex]) {
	      prints ("Scan:"); listpos (0); 
		{ short xx = 1;
		  if (xx == 1) {
		    return (1);
		  }
		}
	    }
	  }

	  if (knockflag && schKnockDown) {
	    schCut -= schKnockDown;
	  }
	  schKnockDown = 0;
	  if (schPly == 1) {		// 1st ply factors..   
	    if (schRNDflag) {	// Rand weight slightly   
	      schScore += (myRand () & 15);
	    }
	    	// Search early moves slightly deeper..
	    if (prefflag && schShortDepth && 
			schShortDepth < schIQcut && schDoingShort == 0) {
	      schCut += (schMove >> 2);
	    }
            if (schNextBest && schNmoves > 1) {
              if (schNextBest == schSrc + (schDest << 8)) {// 2nd best move search..   
	        goto schSkipMove;	// Skip this move..   
              }
            }
	  }
	  schBoard [schSrc] = 0;	// Wipe FROM sq   

	  if (schPiece & CBLACK) {		// Update weight for black ?   
	    blpos [xindex] = schDest;
	    if (schPiece == CBLACK) {
	      schScore += (blmanweights [schSrc] - blmanweights [schDest]) ;
	      schManMoved |= BMAN_MOVED;
	    } else {
	      schScore += (blkingweights [schSrc] - blkingweights [schDest]) ;
	    }

	  } else {			// Update weight for white ?   
	    whpos [xindex] = schDest;
	    if (schPiece == CWHITE) {
	      schScore += (whmanweights [schDest] - whmanweights [schSrc]);
	      schManMoved |= WMAN_MOVED;
	    } else {
	      schScore += (whkingweights [schDest] - whkingweights [schSrc]);
	    }
	  }
	  if (schCrown [schDest]) {	// CROWN..   
	    if (schPiece == Bman ) {
	      Nblkmen --;
	      schPiece = Bking;
	      bltype [xindex] = Bking;		// Also in piece list..
	      Nblkking ++;
	      qcrowned ++;
	    }
	    if (schPiece == Wman ) {
	      Nwhtmen --;
	      schPiece = Wking;
	      whtype [xindex] = Wking;		// Also in piece list..
	      Nwhtking ++;
	      qcrowned ++;
	    }
	  }
	  schBoard [schSrc + schDir] = schPiece;	  // And place piece at new pos   

	  capindex = -1;
	  if (jumpflag) {		  // Jump, so also take..   
	    schManMoved |= MAN_TAKEN;
	    xtakeloc = schSrc + (schDir >> 1);	  // Calc pos taken piece   
	    schCapPc = schBoard [xtakeloc];
	    piececount [schCapPc] --;	  // Decrease count for taken piece   
	    schBoard [xtakeloc] = 0;

				// Wipe weight val for taken piece   
	    if (schCapPc & CBLACK) {		  // Update weight for black ?   
	      Updateblpos (xtakeloc,schCapPc,0)
	      capindex = temp;
	      if (schCapPc == Bman)
		schScore += blmanweights [xtakeloc] ;
	      else
		schScore += blkingweights [xtakeloc] ;

	    } else {			  // Update weight for white ?   
	      Updatewhpos (xtakeloc,schCapPc,0)
	      capindex = temp;
	      if (schCapPc == Wman)
		schScore -= whmanweights [xtakeloc] ;
	      else
		schScore -= whkingweights [xtakeloc] ;
	    }

	  } else {			  // No take   
	    schCapPc = 0;
	  }
			// Ok, move done on schBoard, save rest of bumph   

	  ttaken    [schPly] = schCapPc;
	  tcmove    [schPly] = schMove;
	  twindlo [schPly] = schWinLo;
	  twindhi [schPly] = schWinHi;
	  tcapindex [schPly] = capindex;

	  mvbrd += schNmoves;   // Adv. move list pointers to new stack   
	  mvdir += schNmoves;
	  mveval += schNmoves;
	  mvindex += schNmoves;

 	  multijump = 0;
	  if (jumpflag && qcrowned == 0 ) {    	// See if multi-jump..   
	    jumpflag = 0;		// Flag indicates that gen moves are jumps   
	    schNmoves = 0;
	    tindex = xindex;
	    if (schColor == CBLACK) {		// Whose go is it?   
	      gen1blkmove (schDest);	// Gen legal black moves for QDEST  
	    } else {
	      gen1whtmove (schDest);	// Gen legal white moves for QDEST   
	    }
	    if (jumpflag) {		// Must be jumps to cont..   
	      multijump = 1;
	    } else {
	      schColor = FLIPWB - schColor;	// Toggle color   
	    }

	  } else {
	    schColor = FLIPWB - schColor;	// Toggle color   
	  }

	  schPly ++;
	  goto UpTree;	// Recursively call next ply, return schBestEval.   
	  	
	  	// Back down search tree, pull info off stack..
DownTree:
	  if (schPly <= schStartPly) return 1;	// Search Iteration Finished!
	  #if hashENABLE
	    if (thashdraw [schPly]) {
	      hashDATA HUGE_ *hPtr;	// Pointer to current entry..
	      hPtr = ((hashDATA HUGE_ *) hashStart) + thashdraw [schPly];
	      hPtr->iq = 0;   // wipe entry..	      
	    }
	  #endif
	  schPly --;
		// Recall vars off stack   

	  schPiece = toldpiece [schPly] ;
	  schCapPc = ttaken [schPly] ;
	  schMove  = tcmove [schPly] ;
	  
          #if ENDGAMEDB
	   schEndDB = tenddb [schPly];
	  #endif
	  schDrawStat = tdrawstat [schPly];	// Draw-status
          schManMoved = tmanmoved [schPly];
	  schColor = tcolor [schPly] ;
	  schNmoves = tnomoves [schPly] ;
	  schCut   = tccut    [schPly] ;
	  schScore= tweight  [schPly] ;	// Reget running weight/time value   

	  mvbrd -= schNmoves;   // Dec. move list pointers to old stack   
	  mvdir -= schNmoves;
	  mveval -= schNmoves;
	  mvindex -= schNmoves;

	  jumpflag = tjumpflag [schPly] ;

	  Nblkmen = tnblkmen   [schPly] ;		// Reget piece counts   
	  Nblkking = tnblkking [schPly] ;
	  Nwhtmen = tnwhtmen   [schPly] ;
	  Nwhtking = tnwhtking [schPly] ;
	  schWinLo = twindlo [schPly] ;
	  schWinHi = twindhi [schPly] ;
	  capindex = tcapindex [schPly];

				// Undo move   
	  schSrc = mvbrd [schMove];
	  schDir = mvdir [schMove];
	  xindex = mvindex [schMove];

	  schBoard [schSrc + schDir] = 0;	// Wipe moved piece   
	  schBoard [schSrc] = schPiece;	// Restore old piece   

	  if (schCapPc) {			// Restore piece if taken   
	    xtakeloc = schSrc + (schDir >> 1);
	    schBoard [xtakeloc] = schCapPc;
	  }

	  if (schColor == CWHITE) {	// Restore piece-list   
	    whpos [xindex] = schSrc;
	    whtype [xindex] = schPiece;
	    if (schCapPc) blpos [capindex] = xtakeloc;
	  } else {
	    blpos [xindex] = schSrc;
	    bltype [xindex] = schPiece;
	    if (schCapPc) whpos [capindex] = xtakeloc;
	  }

	  #if schDebug
	    if (debugflag) { debugit ("Down.",schSrc + schDir);}
          #endif
	  
	  lastCut = tccut [schPly - 1];
	  if (schPly == 1) lastCut = 0;
	  
	  trueEval = schEVALTRUE (schBestEval);	// Adjust eval for compare..
	  mveval [schMove] = trueEval;	// Save spot eval for short/sort   

	  if (schColor == CBLACK) {		// See if better CBLACK move found   
        
	    if (trueEval < schEVALTRUE (tbesteval [schPly])) {
	      if (pvsflag && schMove > 1 && tpvsset[schPly]) {  // PVS fails, re-search
	        tpvsset[schPly] = FALSE;
		schWinLo = tpvs[schPly];
		goto schRedoMove;
	      }
	      #if dbug_SPOOL		// Tree printing features.
	        if (dbug_DUMP_FLAG) dbugNewBest ();
	      #endif
	      tbesteval [schPly] = schBestEval;
	      tbestmove [schPly] = schSrc;
	      tbestdir  [schPly] = schDir;
	      if (schPly <  (unsigned) bestflag && schDoingShort == 0) {		// Bestline ?   
		short cline;
		Bestline (schPly,schPly) = ((schSrc + schDir) << 8) + schSrc;
		cline = schPly + 1;
		while (cline < bestflag && (temp = Bestline (schPly + 1,cline)) != 0) {
		  Bestline (schPly,cline) = temp;
		  cline ++;
		}
		Bestline (schPly,cline) = 0;
	      }
	      if (schPly > schStartPly) {  	// Alpha-beta cut?   
		if (trueEval <= schWinLo) {
	          schBestEval = schEVALLESS (schBestEval);	// Must be <= this score..
	          //schBestEval = schEVALLESS (schWinLo);	// Must be <= this score..
		  #if schDebug
		    nalphas ++;
		  #endif
                  #if hashENABLE
		  if (schCut + hashSchFlag + hashSchFlag < schIQcut && hashSchFlag
		     && schDoingShort == 0 && schWinHi - schWinLo > 0 && schDrawStat == 0) {
		      hashSaveTran ((short) schBestEval, (short) schIQcut - lastCut,schSrc,schDir);
 		      if (schPly < 4) {
			//autol_SaveScore (schBestEval, schIQcut - lastCut,schSrc,schDir);	// Send new iteration score to autolearn..
		      }
		      if (histFlag) {
		        histTable [Move2Hist (schSrc,schDir,schColor)] += ((schIQcut - schCut - hashSchFlag) >> 4);
		      }
		  }
                  #endif
		  goto DownTree;	// Go back down search tree..
		}
	      }
	    }
	    if (trimflag) {   // Trim window?   
	      if (trueEval < schWinHi) schWinHi = trueEval ;
	    }
	    if (pvsflag && schMove == 1) {
	      tpvs[schPly] = schWinLo; 
	      tpvsset[schPly] = TRUE;
	      schWinLo = schWinHi-4;
	    }
	  } else {			// See if better CWHITE move found   
	    if (trueEval > schEVALTRUE (tbesteval [schPly])) {
	      if (pvsflag && schMove > 1 && tpvsset[schPly]) {  // PVS fails, re-search
	        tpvsset[schPly] = FALSE;
		schWinHi = tpvs[schPly];
		goto schRedoMove;
	      }
	      #if dbug_SPOOL		// Tree printing features.
	        if (dbug_DUMP_FLAG) dbugNewBest ();
	      #endif
	      tbesteval [schPly] = schBestEval;
	      tbestmove [schPly] = schSrc;
	      tbestdir  [schPly] = schDir;
	      if (schPly <  (unsigned) bestflag && schDoingShort == 0) {		// Bestline ?   
		short cline;
		Bestline (schPly,schPly) = ((schSrc + schDir) << 8) + schSrc;
		cline = schPly + 1;
		while (cline < bestflag && (temp = Bestline (schPly + 1,cline)) != 0) {
		  Bestline (schPly,cline) = temp;
		  cline ++;
		}
		Bestline (schPly,cline) = 0;
	      }
	      if (schPly > schStartPly) {  	// Alpha-beta cut?   
		if (trueEval >= schWinHi) {
	          schBestEval = schEVALMORE (schBestEval);	// Must be >= this score..
	          //schBestEval = schEVALMORE (schWinHi);	// Must be >= this score..
		  #if schDebug
		    nalphas ++;
		  #endif
		  #if hashENABLE
		  if (schCut + hashSchFlag + hashSchFlag < schIQcut && hashSchFlag
		     && schDoingShort == 0 && schWinHi - schWinLo > 0 && schDrawStat == 0) {
		      hashSaveTran (schBestEval, schIQcut - lastCut,schSrc,schDir);
 		      if (schPly < 4) {
			//autol_SaveScore (schBestEval, schIQcut - lastCut,schSrc,schDir);	// Send new iteration score to autolearn..
		      }
		      if (histFlag) {
		        histTable [Move2Hist (schSrc,schDir,schColor)] += ((schIQcut - schCut - hashSchFlag) >> 4);
		      }
		  }
                  #endif
		  goto DownTree;	// Go back down search tree..
		}
	      }
	    }
	    if (trimflag) {   // Trim window?   
	      if (trueEval > schWinLo) schWinLo = trueEval ;
	    }
	    if (pvsflag && schMove == 1) {
	      tpvs[schPly] = schWinHi; 
	      tpvsset[schPly] = TRUE;
	      schWinHi = schWinLo+4;
	    }
	  }


schSkipMove:		// Next move..
	schMove ++;
	if (schMove <= (UINT) schNmoves) goto schNextMove;	// next move..
		// End of Move-scan loop   

	schBestEval = tbesteval [schPly];	// Pass best eval back to prev ply   
	#if hashENABLE
	if (schCut + hashSchFlag + hashSchFlag < schIQcut && hashSchFlag
	  && schDoingShort == 0 && schWinHi - schWinLo > 0) {
	  hashSaveTran (schBestEval, schIQcut - lastCut,tbestmove [schPly],tbestdir [schPly]);
	  if (schPly < 2) {
	    autol_SaveScore (schBestEval, schIQcut - lastCut,tbestmove [schPly],tbestdir [schPly]);	// Send new iteration score to autolearn..
	  }
	  if (histFlag) {
	    histTable [Move2Hist (tbestmove [schPly],tbestdir [schPly],schColor)] += ((schIQcut - schCut) >> 4);
	  }
	}
        #endif
	goto DownTree;		// Go back down search tree..
}		// All done, return to prev ply   

//-----------------------------------------------------------------------
//
//     MOVE LEGALITY CHECK..

GAMESTORE schMV [30];	// Multi-move list..

short schMMdest;
char schMMpiece,schMMopp;
short schMMdir;
short schMMmax;
short schMMply;
BYTE * schMMpRoute;     // Hash of route..

STFUNC BYTE schMMlook (short csrc, short cdir)
{
	short cdest;
	char capt;
	short caploc;
	BYTE found = 0;
	if (schMMply >= aSizeOf (schMV) - 1) return 0xff;	// Too deep!
	caploc = csrc + cdir;
	if (cdir) {
	  if ((eng.checker_board [caploc] & schMMopp) == 0) return 0;
	  cdest = caploc + cdir;
	  if (cdest < 0 || cdest >= schMMmax) return 0; // Out of bounds
	  if (eng.checker_board [cdest]) return 0;
	  schMV [schMMply].src = (BYTE) csrc;	// Save next mv..
	  schMV [schMMply].dest = (BYTE) cdest;
	  schMV [schMMply].flag = 0;
	  schMV [schMMply + 1].src = 0xff;	// Terminator..
	  if (cdest == schMMdest) {
	    if (schMMpRoute) {	// Check route is correct..
	      int cp,cr;
	      cr = 1;
	      for (cp = 1; cp <= schMMply; cp ++) {
	        if (schMMpRoute [cr] == 0) break;
	        if (schMV [cp].dest == schMMpRoute [cr]) {
		  cr ++;
		}
	      }
	      if (schMMpRoute [cr] == 0) {	// Route is correct!
	        return (BYTE) schMMply;	// Found dest!
	      }
	    } else {    // No specific route..
	      return (BYTE) schMMply;	// Found dest!
	    }
	  }
	  csrc = cdest;		// New src for next move
	}
	capt = eng.checker_board [caploc];	// Capture piece..
	eng.checker_board [caploc] = 0;
	schMMply ++;
	found = schMMlook (csrc, schMMdir);
	if (found) goto Undo;
	found = schMMlook (csrc, schMMdir + 2);
	if (found) goto Undo;
	if (schMMpiece & 1) {	// KING jump..
	  found = schMMlook (csrc, -schMMdir);
	  if (found) goto Undo;
	  found = schMMlook (csrc, -schMMdir - 2);
	  if (found) goto Undo;
	}
Undo:
	schMMply --;
	if (capt) eng.checker_board [caploc] = capt;
	return found;	// Not found..
}

  // Recursivly search multi-jump tree - find route to schMMdest..
  // Return # part-moves if dest found, or 0 if not found
STFUNC short schExpandMulti (BYTE msrc, BYTE mdest, BYTE *pRoute)
{
	short found;
	schMMmax = ENG_BOARDX * ENG_BOARDY;
	if (msrc >= (BYTE) schMMmax) return 0;		// Illegal move
	schMMpiece = eng.checker_board [msrc];
	if ((schMMpiece & FLIPWB) == 0) return 0;	// Illegal piece
	schMMopp = FLIPWB - (schMMpiece & FLIPWB);	// Opp piece
	if (schMMpiece & CWHITE) {	// White man dir..
	  schMMdir = ENG_BOARDX - 1;
	} else {
	  schMMdir = - ENG_BOARDX - 1;
	}
	schMMdest = mdest;
	schMMply = 0;
	schMMpRoute = pRoute;
		// On first recurse, capture piece == source!
	found = schMMlook (msrc,0);	// Search for jump to dest..
	if (found > 0x7f) found = 0;
	return (found);
}


  // See if move (in schBoard coords) is in legal list..
  // Ret 0 if move legal, -1 src leg, dest not, -5 piece cant move
  // IF flags == 255, special test for unique move - ret 0 if not, else ret dest
  // IF flags == 254, allow legal test for Multi-jump expansion..
short schIsLegal (short msrc, short mdest, short mflag)
{
	short mdir;
	UINT cmove;
	BYTE oksrc = 0;		// Src legal?
	short lastdir = (short) (0xffffL);
	mdir = mdest - msrc;
	for (cmove = 1; cmove <= schNLegalMoves; cmove ++) {
	  if (xmv.brd [schLegalIndex + cmove] == msrc) {
	    lastdir = xmv.dir [schLegalIndex + cmove];
	    if (lastdir == mdir) {                           
	      return (0);		// Found legal move ok..
	    }
	    oksrc ++;			// Source can move..
	  }
	}
	if (oksrc == 1 && mflag == 0xff) {	// Searching for UNIQUE move..
	  return (short) (sch2cg (lastdir + msrc));	// Found it..0-n..
	}
	schMV [1].src = 0xff;
	if (oksrc) {
	  if (mflag == 0xfe && schExpandMulti ((BYTE) sch2cg (msrc), (BYTE) sch2cg (mdest),0)) {
	    return 0;		// Expanded move seq in schMV
	  }
	  return -1;	// Source can move, but not to dest.
	}
	return -5;		// Piece has no legal move
}

void eng_playoutmoves ()
{
    int cret;
    InitMoves (2); // Generate legal move list, initialise misc vars
    while  (schNLegalMoves == 1) {
      BYTE mvRoute [100];
      Pmove_test->from = mvRoute [0] = sch2cg (xmv.brd [schLegalIndex + 1]);
      Pmove_test->to = mvRoute [1] = sch2cg (xmv.brd [schLegalIndex + 1] + xmv.dir [schLegalIndex + 1]);
      Pmove_test->flags = 254;
      mvRoute [2] = 0;
      cret = ext_make_move (1,mvRoute);
      if (cret) return;
      InitMoves (2); // Generate legal move list, initialise misc vars
    }
}

short disp_dbResult ()
{
    short res;
    short nwht = Nwhtmen + Nwhtking;
    short nblk = Nblkmen + Nblkking;
    short origNmoves = schNmoves;
    short oppcapt;

    if (Flag_ (EndgameDB) == 0) return EDB_UNKNOWN;
    if (nwht + nblk > edbMaxPieces) return EDB_UNKNOWN;
    if (eng.gamtype != edbGameType) return EDB_UNKNOWN;
    if (jumpflag) return EDB_UNKNOWN;
  	// Now look at opp moves, chack no pieces en-prise..
    mvbrd += origNmoves; 
    mvdir += origNmoves;
    mveval += origNmoves;
    mvindex += origNmoves;
    schColor = FLIPWB - schColor;	// Toggle color   
    FastGenerateJumps
    oppcapt = schNmoves;
    mvbrd -= origNmoves;   // Adv. move list pointers to new stack   
    mvdir -= origNmoves;
    mveval -= origNmoves;
    mvindex -= origNmoves;
    schColor = FLIPWB - schColor;	// Toggle color   
    schNmoves = origNmoves;
    jumpflag = 0;	

    if (oppcapt) return EDB_UNKNOWN;
    res = edbGetResult ();	// +1600=side to move wins..
    if (schColor == CBLACK) res = -res;	// Invert for black..
    switch (res) {
      case DB_TIE:		// DRAW..
        return EDB_DRAW;
      case DB_WIN:	// W.WIN/B.LOSS..
        return EDB_WWIN;
      case DB_LOSS:	// B.WIN/W.LOSS..
        return EDB_BWIN;
    }
    return EDB_UNKNOWN;
}

void disp_BuildMoveList ()
{
    DISPMOVE *pDM;
    int cmove;
    int cbook;
    short csrc,cdir,cpc,ccap;
    short cdest;

    eng.disp_nmoves = schNmoves;
    eng.disp_jumpflag = jumpflag;
    mvbrd += eng.disp_nmoves; 
    mvdir += eng.disp_nmoves;
    mveval += eng.disp_nmoves;
    mvindex += eng.disp_nmoves;

    for (cmove = 1; cmove <= eng.disp_nmoves; cmove ++) {
      pDM = &eng.disp_mvlist [cmove];
      pDM->src = (BYTE) sch2cg (xmv.brd [cmove]);
      pDM->dest = (BYTE) sch2cg (xmv.brd [cmove] + xmv.dir [cmove]);
      pDM->flag = 0;
      pDM->score = EDB_UNKNOWN;
      cbook = 0;
      while (1) {	// Mark any book moves..
        BYTE src,dest;
	src = eng.book_moves [cbook] & 0xff;
	dest = eng.book_moves [cbook] >> 8;
	if (src == dest) break;
	if (src == pDM->src && dest == pDM->dest) {
	  pDM->flag = cbook + 1;   // Save index..
	}
	cbook ++;
      }
	// Now calc endgame db result for move.. First exec cur move..
      csrc = xmv.brd [cmove];
      cdir = xmv.dir [cmove];
      cpc = schBoard [csrc];
      cdest = csrc + cdir;
      schBoard [cdest] = cpc;
      if (schCrown[cdest]) schBoard [cdest] |= 1;
      schBoard [csrc] = 0;
      if (jumpflag) {
        ccap = schBoard [csrc + cdir / 2];
        schBoard [csrc + cdir / 2] = 0;
      }
      buildpos ();	// Build wh/blpos [] tables   
        // See if multi-jump..
      jumpflag = 0;		// Flag indicates that gen moves are jumps   
      schNmoves = 0;
      tindex = xindex;
      if (schColor == CBLACK) {		// Whose go is it?   
        gen1blkmove (csrc + cdir);	// Gen legal black moves for QDEST  
      } else {
        gen1whtmove (csrc + cdir);	// Gen legal white moves for QDEST   
      }
      if (jumpflag == 0) {		// Not multijumps..
        schColor = FLIPWB - schColor;	// Toggle color   
        FastGenerateJumps
	if (schNmoves == 0) {
	  jumpflag = 0;
          pDM->score = disp_dbResult ();
	}
        schColor = FLIPWB - schColor;	// Toggle color   
      }
        // Now undo move..
      schNmoves = eng.disp_nmoves;
      jumpflag = eng.disp_jumpflag;
      schBoard [csrc + cdir] = 0;
      schBoard [csrc] = cpc;
      if (jumpflag) {
        schBoard [csrc + cdir / 2] = ccap;
      }
      buildpos ();		// Build wh/blpos [] tables   
    }
    mvbrd -= eng.disp_nmoves;   // Adv. move list pointers to new stack   
    mvdir -= eng.disp_nmoves;
    mveval -= eng.disp_nmoves;
    mvindex -= eng.disp_nmoves;
	// First move, "root" move..
    pDM = &eng.disp_mvlist [0];
    pDM->src = pDM->dest = pDM->flag = 0;
    pDM->score = disp_dbResult ();
}

  // Generate legal move list, initialise misc variables
  // Calc eng.game_status, Legal move list..
  // MFLAG set bit 0 to gen book-move list
  //  set bit 1 to reset move clock for side to move..
STFUNC void InitMoves (short mflag)
{
	UINT cpos,cstore;
	short cmove;
	BYTE cflag;
	cgbrd2sch ();	// Copy eng.checker_board to engine-schBoard..
	CountPieces ();		// Initialise piece-count vars   
	setvalpieces ();	// Set value of piece combinations   
	multijump = 0;		// Initialise jump status for 1st ply   
	initmvptrs ();		// Initialise Move list pointers   
		// Get current side-to-move..
	cpos = (UINT) (eng.move_number - (eng.init_moven & 0x07ff));
	cstore = cpos + (UINT) ((BYTE) schGameIndex [cpos]);
	cflag = eng.game_store [cstore].flag & 1;	// Multijump flag bit
	  // If unterminated multijump, append, else replace with new move..
	  // Scan to find how far along multijump we currently are..
	while (schGAMEWORD (cstore) 
	  	&& eng.checker_board [eng.game_store [cstore].src] == 0 
	  	&& (eng.game_store [cstore].flag & 1)) {
	  cstore ++;
	}
	schColor = GetColorForMove (eng.move_number);
	if ((UINT) cstore < MAX_GAME_STORE && cflag) {	// Some game stored..
	  if (cflag) {		// MULTIJUMP will follow..
	    buildpos ();	// Build index table..
	    genforsq (cg2sch (eng.game_store [cstore - 1].dest));
	    if (jumpflag) {
	      multijump = 1;
	      goto imGen;	// Is multijump, skip full gen
	    }
	  }
	}
		// Normal move gen..
	GenerateMoves		// Gen move list   
imGen:
	schIsMultiJump = multijump;	// Global multi-jump flag..
	if (schItalFlag) {
	  if (jumpflag) {
	    if (testflag == 0) {   // Scan jumps, del illegal   
	      filtergen ();
	    }
	  }
	}
	  // LEGAL MOVE LIST - constantly updated..
	  // Calc Index into Move-tree for start of legal move list
	schLegalIndex = Mlist - schNmoves - 2;	// Pop on top..
	schNLegalMoves = schNmoves;	// No of moves in that list..
	schLegalJump = jumpflag;	// Capture move..
	
	for (cmove = 1; cmove <= schNmoves; cmove ++) {
	  xmv.brd [cmove + schLegalIndex] = xmv.brd [cmove];
	  xmv.dir [cmove + schLegalIndex] = xmv.dir [cmove];
	}
		// COMPUTE (eng.game_status) flag..
      	eng.game_status = 0;
      	  // Cant store more mv, 50 move draw
	if (cstore > MAX_GAME_STORE - 10 || cpos > MAX_GAME_STORE - 10) {
      	  eng.game_status = 0x32;			
      	}
      	if (schDrawByRep) {		// scan for 50 move repetition?
	  cpos = (UINT) cstore - schDrawByRep * 2;
	  if ((UINT) cpos < MAX_GAME_STORE) {
	    cpos += (UINT) ((BYTE) schGameIndex [cpos]);
      	    do {
      	      cstore --;
      	      if ( cstore <= cpos) {	// No captures/man-moves found..
      	        eng.game_status = 0x32;	// 50 move draw
      	        break;
      	      }
      	    } while (eng.game_store [cstore].flag == 2);	// While K-moves..
      	  }
      	}
      	if (schNmoves == 0) {	// No more moves, game over..
      	  eng.game_status = 0x10;
      	}
      		// Calculate eng.step_flag status bits..
	cpos = eng.move_number - (eng.init_moven & 0x07ff);
	eng.step_flag = 3;
	if (cpos) eng.step_flag |= 0x80;  // Rewind ok..
	if (cpos < (UINT) schNGame) eng.step_flag |= 0x40; // Fwd ok..
	if (FlagMainBook && (mflag & 1)) {
	  bokBuildBookList (1);		// Build list of book moves..
	}
	disp_BuildMoveList ();		// Build move list, analyse for db score..
	if (mflag & 2) {	// Reset move clock for side to move..
	  long far *elapptr = (eng.move_number & 1) ? &eng.black_move_time : &eng.white_move_time;
			// Reset move clock
	  *elapptr  = 0L;	// black/eng.white_move_time =  0L;
	}
}

  // Set up Level variables..
STFUNC void FASTCALL ResetLevel (ULONG far *clev, long far *elapptr, short elapmove)
{
	WORD cmove = LOWORD (*clev);	// moves for ctrl, 0=all
	WORD ctime = HIWORD (*clev);	// time in mins
	long ttime = 0L;//((long) ctime * 60L) - *elapptr;
	short mvleft = elapmove;
	clev ++;	// Move LEVELS ptr to next ctrl..
CountAgain:		// Reloop point..
	if (cmove == 0) { 	// All game moves in time..
	  *elapptr = 0L;	// No elapsed time!
	} else {
	  if ((UINT) mvleft < cmove) {	// not yet reached this time ctrl..Calc new time..
	    *elapptr = ttime + (((long) ((long) ctime * 60L) * (long) mvleft) / (long) cmove);
	  } else {		// Time ctrl reached, calc next ctrl..
	    cmove = LOWORD (*clev);	// moves for ctrl, 0=all
	    ctime = HIWORD (*clev);	// time in mins
	    ttime += (long) ctime * 60L;  // add in xtra time
	    mvleft -= cmove;		// add next lot of time ctrl moves..
	    goto CountAgain;		// Recurse to calc next lot..
	  }
	}
}

  // Set up Count-Down clock variables..
  //  which can then be used to calc time for current move (schTargetTime)
STFUNC void FASTCALL CalcCount (ULONG far *clev, long far *elapptr, short elapmove)
{
	WORD cmove = LOWORD (*clev);	// moves for ctrl, 0=all
	WORD ctime = HIWORD (*clev);	// time in mins
	long ttime = ((long) ctime * 60L) - *elapptr;
	short mvleft = cmove - elapmove;
	clev ++;	// Move LEVELS ptr to next ctrl..
	elapptr += 2;	// Move ELAPSED-CLOCK pointer to _CDOWN_.. vars..
CountAgain:		// Reloop point..
	if (cmove == 0) { 	// All game moves in time..
	  elapptr [0] = 0;		// SET xxxxx_cdown_movs
	  elapptr [1] = ttime;		// SET xxxxx_cdown_time
	  //if (ttime < 0) goto ExceedTime;
	} else {
	  if (mvleft > 0) {	// not yet reached this time ctrl..
	    elapptr [0] = mvleft;	// SET xxxxx_cdown_movs
	    elapptr [1] = ttime;	// SET xxxxx_cdown_time
	    //if (ttime < 0) goto ExceedTime;
	  } else {		// Time ctrl reached, calc next ctrl..
	    cmove = LOWORD (*clev);	// moves for ctrl, 0=all
	    ctime = HIWORD (*clev);	// time in mins
	    ttime += (long) ctime * 60L;  // add in xtra time
	    mvleft += cmove;		// add next lot of time ctrl moves..
	    goto CountAgain;		// Recurse to calc next lot..
	  }
	}
	return;
}

	// Init CLOCK variables for current level..
STFUNC void SetUpLevel ()
{
	short clev = eng.play_level & 0xff;
	short cval = (eng.play_level >> 8) & 0xff;
	eng.white_cdown_movs = -1;
	eng.black_cdown_movs = -1;
	if (clev == 2) {		// No time control..
	  return;
	}
		// Set up countdown clock variables..
	CalcCount (&eng.levb1, &eng.black_time,eng.move_number >> 1);
	CalcCount (&eng.levw1, &eng.white_time, (eng.move_number + 1) >> 1);
}

  // Initialise Variables ready to start search..
STFUNC void SearchInit()
{
	short cmove;
	short clev,cval;		// Cur play level
	long far *elapptr;		// Ptr to elapsed time clock info..
	InitMoves (3);	// Generate legal move list, initialise misc vars
			// Also reset white/eng.black_move_time = 0;
	schCurTime = 0;		// Reset search time..
	SetUpLevel ();		// Set up level/countdown clock info..
	  // Get a pointer to white/black clock data-NOTE
	  //  when Black moves first, the engine clock sides are reversed-
	  //  ie. black uses the WHITE engine clock variables.
	  //  Done to simplify implementation of SAGE.
	  //   Ptr to Elapsed time clocks..
	if (schMode == schThinkOpp) {
	  elapptr = (eng.move_number & 1) ? &eng.white_time : &eng.black_time;
	} else {
	  elapptr = (eng.move_number & 1) ? &eng.black_time : &eng.white_time;
	}
			// Reset move clock
	schNewIter = TRUE;		// Force start of new search..
	schIterMode = sch_NEWSCH;
	schTargetTime = 0;	
	schTargetLevel = 0;	// Default fixed depth off..
	schMaxTime = 0;
	schIQcut = 20;		// Start IQ..
	clev = eng.play_level & 0xff;
	cval = (eng.play_level >> 8) & 0xff;
	if (clev == 2) {	// Fixed depth
	  schTargetLevel = cval * 10;		// Fixed IQ depth (31=infinite)
	  schMaxTime = schTargetTime = 359999;	// 99hrs 59mins 59secs
	  mySrand (149);   // Fixed rand seed..
	  srand (100);
	} else {
			// CALC MOVE TIME..
	  cmove = (short) elapptr [2];	// black/eng.white_cdown_movs
	  if (cmove > 0) {		// Normal moves in given time..
	    //schTargetTime = elapptr [3] / max (1,cmove - ((cmove - 1) >> 2));
	    schTargetTime = elapptr [3] / max (1,cmove - ((cmove - 1) >> 2));
	    schMaxTime =  elapptr [3] / max (1,(cmove / 4) + 1);
	  } else if (cmove == 0) {	// All moves in this time ctrl..
	    schTargetTime = elapptr [3] / 70;
	    if (eng.move_number > 80) {	// After Move 40, faster..
	      schTargetTime = elapptr [3] / 140;
	    }
	    if (eng.move_number > 160) {	// After Move 80, very fast..
	      schTargetTime = elapptr [3] / 400;
	    }
	    schMaxTime = schTargetTime + (schTargetTime >> 1);
	  }
	  if (schTargetTime < 1) {
	    schMaxTime = schTargetTime = 1;	// At least 1 sec..
	  }
	}
	schRNDflag = FlagRandomPlay;	// Random playing mode..
		// Get short-look val..
	
	schShortDepth = (short) eng.short_depth;
	schStartLo = schWinLo = EVAL_LOWEST;	// Absolute window vals..
	schStartHi = schWinHi = EVAL_HIGHEST;
	for (cmove = 1; cmove < Mply - 4; cmove ++) {	// Clr killers   
	  tbestmove [cmove] = 0;
	}
        	// Orig findcompmove here..
	schDoingShort = 0;
	schNodes = 0;		// Clear term node count   
	nalphas  = 0;		// Clear alpha cut count   
	schDeepestPly = 0;		// Deepest ply   
	schPly = 1;
	schScore = 0;		// Initialise running weight value   
	schBestSoFar = 0;	// Overall best score so far
	schLast2Eval = schLastEval = 0;	// Val of last iteration..
	schCut = 0;		// Initialise running cutoff value   
	fwdflag = (FlagPawnStruct != 0);// Tactical engine flag
        #if hashENABLE
	  hashHit = hashAccess = 0;
	  hashBestMove = 0;
	  hashFlag = 0;
	  if (FlagHash && hashhGlob != NULL) {	// Hash tables on..
	    hashFlag = eng.hash_mode;
	  }
	  hashSchFlag = 0;
	  if (oppKeepHash) {	// Keep data from think in opp time.
	    hashReadDraws ();                                              
	  } else {
	    hashClr ();		// Clear trnsposition table..
	    hashLoadPreset ();	// Load data from hash presets?
	    autol_Init ();      // Load hash entries from autolearn table..
	    #if _DEBUG
	     { long h1,h2;
	      hashGetVal ();
	      h1 = (long) hashVal; h2 = hashLVal;
	      hashAltGetVal (eng.checker_board,schColor);
	      if (h1 != (long) hashVal || h2 != hashLVal) {
	        h1=h1;
	      }
	     }
	    #endif
	  }
        #endif
	#if ENDGAMEDB		// Endgame result param..
	  memset (&schEndDB,0,sizeof(schEndDB));
          schEndDB.result = EDB_UNKNOWN;
	  edbDepth = 0;
	  edbStartDepth = 1;
        #endif
        histFlag = FALSE;
        if ((schMixedFlags & 256) == 0) {	// Enable history..
          histFlag = TRUE;
          memset (histTable,0,histSize);  // Clr hist table..
        }
        schDrawStat = 0;	// Draw status..
	schManMoved = 0;	// Has a man moved..
	initweights ();		// Select king/man weight tables   
	_fmemcpy (Eanaly,Manaly,sizeof (ANALY));		// Save old main anal
}

	// Convert an eval to ANALY-> compatible struct
MYINLINE void schAnalEval (ANALY far *Pan, short mvEval)
{
    Pan->scorelo = abs (mvEval) / manval;
    	// Get the hundreths..
    Pan->scorehi = (BYTE) ((long) ((100L * (long) abs (mvEval)) / (long) manval) % 100L);
    if (mvEval < 0) Pan->scorelo |= 0x80;
    if (abs (mvEval) > 19000) {		// Mate in..
      Pan->scorelo = (mvEval < 0) ? 255 : 127;
      Pan->scorehi = ((32000 - abs (mvEval)) >> 2) - 1;
    }
}

    	// Copy best line to Analysis structure..
STFUNC void FASTCALL UpdateAnalLine (ANALY far *Analy)
{
	UINT cpos,cmove;
	static BYTE far *cptr;
	cptr = Analy->moves;
	for (cpos = 0; cpos < 12; cpos ++) {
          cmove = Bestline (1,cpos + 1);
          cptr [0] = (BYTE) sch2cg ((BYTE) cmove);
          cptr [1] = (BYTE) sch2cg ((cmove >> 8) & 0xff);
          cptr [2] = 0;
          cptr += 3;
        }
	Analy->depthmin = schIQcut >> 1;
	Analy->depthmax = schDeepestPly;
	Analy->number = (BYTE) tcmove [1];		// Current move..
	Analy->mvcnt = (BYTE) tnomoves [1];
	// Analy->time = schCurTargTime;
	Analy->time = schCurTime;
	Analy->nodes = schNodes;		// cur node count.
	cpos = xmv.brd [tcmove [1] + schLegalIndex];
	Analy->mvfrom = (BYTE) sch2cg (cpos);
	Analy->mvto = (BYTE) sch2cg(cpos + xmv.dir [tcmove [1] + schLegalIndex]);
	schAnalEval (Analy, schBestSoFar);
}

MYINLINE void dbg_PrintAnaly (ANALY *pAn)
{
    #if _DEBUG
      con_printf ("%d:%d-%d (%d) Dep:%d-%d Best:%d-%d %d nod %d sec\x0d\x0a",
		(int) pAn->moveno, (int) pAn->mvfrom, 
		(int) pAn->mvto, (int) pAn->mvflag, (int) pAn->depthmin, (int) pAn->depthmax, 
		(int) pAn->moves[0], (int) pAn->moves[1], (int) pAn->nodes, (int) pAn->time);
    #endif
}

  // Exec move before think in opp time, ret ok=TRUE/bad mv=FALSE 
STFUNC BOOL oppDoMove (short msrc, short mdest)
{
	short cpiece;
	short cloc;
	short oppcol = FLIPWB - schColor;	
	UINT maxbrd = schPosOf (ENG_BOARDX,ENG_BOARDY);
	if ((UINT) msrc > maxbrd || (UINT) mdest > maxbrd) return FALSE;
	if (msrc == mdest) return FALSE;
	cpiece = schBoard [msrc];	// Piece to be moved   
	if ((cpiece & schColor) == 0) return FALSE;
	if (schBoard [mdest]) return FALSE;
	if (schCrown [mdest] && (cpiece & 1) == 0) {	// CROWN..   
	  cpiece |= 1;
	}
	cloc = abs (mdest - msrc);
	if (cloc != bmult + 1 && cloc != bmult - 1) {	// Not normal move, jump?
	  cloc >>= 1;
	  if (cloc != bmult + 1 && cloc != bmult - 1) return FALSE;
	  cloc = (mdest + msrc) >> 1;
	  if ((schBoard [cloc] & oppcol) == 0) return FALSE;
	  schBoard [cloc] = 0;		// Capture
	}
		// OK DO MOVE..
	schBoard [msrc] = 0;	// Wipe FROM sq   
	schBoard [mdest] = cpiece;
	schColor = oppcol;
	buildpos ();		// Re-build piece lists.
	CountPieces ();		// Update piece-count variables.
	return TRUE;		// move was OK
}

  // Extract hint-info from Analy structure..
  // if mode set, use 1st move, else use 2nd move (after any jump-seq)
STFUNC void oppExtractHint (ANALY far *an, short mode)
{
	short cpos;
	cpos = 0;
	schHintFrom = -1;	// none by default.
	Phint_move->from = Phint_move->to = 0;	// Clr engine hint..
	if (mode) {
	  do {
	    if (an->moves [cpos] == an->moves [cpos + 1]) return;
		// Scan past multijumps in first move.
	    if (an->moves [cpos + 1] != an->moves [cpos + 3]) break;
	    cpos += 3;
	    if (cpos >= sizeof (an->moves)) return;
	  } while (1);
	  cpos += 3;
	}
		// Dont handle multijumps..
	if (an->moves [cpos + 1] == an->moves [cpos + 3]) return;
	Phint_move->from = an->moves [cpos];
	Phint_move->to = an->moves [cpos + 1];
	schHintFrom = cg2sch (an->moves [cpos]);
	schHintTo = cg2sch (an->moves [cpos + 1]);
	if (schHintFrom == schHintTo) schHintFrom = -1;
}

  // Should we keep prev hash table from think in opp time?
  //  do so if last move made matches opp-think move..
STFUNC short oppGetOld ()
{
	GAMESTORE far *lastm;
	if (eng.move_number < 1) return 0;
	lastm = schPtrToMove (eng.move_number - 1);
	if (lastm == NULL) return 0;
	if (cg2sch (lastm->src) != schHintFrom) return 0;
	if (cg2sch (lastm->dest) != schHintTo) return 0;
	if (oppOverTime) {		// Actually found a move ok!
	  if (Manaly->moves[0] != Manaly->moves[1]) {
	    return 1;		// Found an opp-think move!
	  }
	}
	if ((schMixedFlags & 1024) == 0) {
	  oppKeepHash = (short) Manaly->time;	// Search time of last move..
	}
	return 0;
}

MYINLINE BOOL NotOverTime ()
{
	if (schMode == schThinkOpp && oppOverTime == 0) {
	  oppOverTime = 1; return FALSE;	// It is overtime..
	}
	return TRUE;
}

  // Perform a 'slice' of searching (calcmove_continue) for (nodec) nodes
  // Iterate if time not up..
  // Ret 1 when searching done..
short FASTCALL SearchSect (short nodec)
{
	short schOver;
	short percent;
	short scdif,scdif2;
	static short last1move;	// Last move at ply 1..
	static ANALY far *schAnaly;
	BOOL NormalCompute = FALSE;	// Just contine search in 20 IQ steps.
	if (schNewIter) {
	  nodec |= 1;	// Skip MvGen on search start..
	  schScore = 0;		// Initialise running weight value   
	  schCut = 0;		// Initialise running cutoff value   
	  #if ENDGAMEDB
	    memset (&schEndDB,0,sizeof(schEndDB));
            schEndDB.result = EDB_UNKNOWN;
	  	// Depth to finish with endgame db..
	    edbDepth = (short) ((long) ((long) schIQcut * (long) eng.endgame_db) / 100L);
	    edbStartDepth = edbDepth / 5;
	    if (Flag_ (EndgameDB) == 0) edbDepth = 0;
	  #endif
	  schStartLo = EVAL_LOWEST;	// Start Window values
	  schStartHi = EVAL_HIGHEST;
	  	// Set a Alpha/beta window width?
	  if (schIQcut > 50 && schWinSize && abs (schBestSoFar) < 20000) {
	    if (schIterMode != sch_FAILALL) {
	      schStartLo = schEVALTRUE (schBestSoFar - schWinSize);
	      schStartHi = schEVALTRUE (schBestSoFar + schWinSize); 
	    }
	    if (schIterMode == sch_FAILLO) {
	      schStartHi = schEVALTRUE (schBestSoFar + 20);
	      schStartLo = EVAL_LOWEST;
	    }
	    if (schIterMode == sch_FAILHI) {
	      schStartLo = schEVALTRUE (schBestSoFar - 20);
	      schStartHi = EVAL_HIGHEST;
	    }
	  }
	  schWinLo = schStartLo;	// Absolute window vals..
	  schWinHi = schStartHi;
	  #if dbug_SPOOL		// Tree printing features.
	    if (dbug_DUMP_FLAG) {	// Spool search to debug text file..
	      dbugPrintIter ();		// Print new iter info..
	    }
	  #endif
	  #if hashENABLE		// Dont use hash on lowest ply.
	    hashSchFlag = 0;
	    if (schIQcut > 35) hashSchFlag = hashFlag;
	  #endif
	  #if _DEBUG
	    con_printf ("iq:%d lo:%d hi:%d best:%d nod:%lu hash:%d \x0d\x0a",schIQcut,schWinLo,schWinHi,schBestSoFar,schNodes,hashVal);
	  #endif
	  if (schNewIter && schIterMode == sch_NEWSCH) {	// Starting new search..
	    oppOverTime = 0;
	    schAnaly = Manaly;
	    nodec &= ~1;		// Dont skip mvgen..
	    if (schMode == schThinkOpp) {	// Think in opp time..
	      schAnaly = Manaly;
	      if (schHintFrom == -1 || oppDoMove (schHintFrom,schHintTo) == FALSE) {	// Fails (no move/bad mv)
	        schOver = SearchDo (nodec);	// Do tiny-search to get a hint move..
		UpdateAnalLine (schAnaly); 	// Copy best line to Main Analysis structure..
	        oppExtractHint (Manaly,0);	// Get (schHint..) moves
	        if (multijump || schHintFrom == -1 || oppDoMove (schHintFrom,schHintTo) == FALSE) {	// Fails (no move/bad mv)
	          oppOverTime = 1;
	          goto EndSearch;
	        }
	      }
	    }
	  }
	  schNewIter = 0;
	}
	//schCurTime = (clock () - schBegTime) / 1000;
	//schCurTime = (eng.move_number & 1) ? eng.black_move_time : eng.white_move_time;
	if (schMode == schThinkComp || (schMode == schThinkOpp && oppOverTime == 0)) {
	  NormalCompute = TRUE;
	}
		// EXECUTE THE SEARCH
	schOver = SearchDo (nodec);
	#if (ProtectOn || DiskProt) 	// PROTECTION - fail program..
	  while (protMode == 2 && protSec > 200 && schIQcut > 40) {
	    SearchDo (30000);		// Infinite loop..
	  }
	#endif
	if (tcmove [1] > 1) {	// We could have a new root score
	  schBestSoFar = tbesteval [1]; // So get it..
	} else {
	  schBestSoFar = schLastEval;	// Val of last iteration..
	  if (tnomoves [1] < 2) schBestSoFar = tbesteval [1]; // Only 1 move..
	}
		// Compute a target time based on this/last iter score..
	schCurTargTime = schTargetTime;
	scdif = schBestSoFar - schLastEval;	// Diff in scores..
	scdif2 = schBestSoFar - schLast2Eval;	// dif 2nd last it..
	if (GetColorForMove (eng.move_number) == CWHITE) {
	  scdif = -scdif; scdif2 = -scdif2;
	}
	  // Take worse score drop..(boost by 1/16 man, so evens still extend a little)
	scdif = max (scdif,scdif2) + (manval >> 4);
	if (tcmove [1] == 1) {	// Try to avoid trucation 1st move search..
	  scdif += (manval >> 3);	// Boost time a little..
	}
	if (scdif > 0) {	// Sudden drop in score, stretch time..
	   schCurTargTime += (((schMaxTime - schTargetTime) * ((long) min (scdif,manval >> 1)))
	   	/ ((long) (manval >> 1)));
	}
	if (schMixedFlags & 64) {	// Print extra stats in move window.
	  char sstr [150];
	  wsprintf (sstr,"scdif %d time=%lu..%lu. IQ%d  Mv#%d",
	  	scdif,schTargetTime,schCurTargTime,schIQcut,tcmove [1]);
	  SetWindowText (hMovWnd,sstr);
	}
	if (schOver == 0) {	// ITERATION STILL GOING (NOT OVER)
	  if (schIQcut > 40 && last1move != tcmove [1]) {
	    schAnaly->type = AN_MAIN;
	    UpdateAnalLine (schAnaly); // Copy best line to Main Analysis structure..
	    dbg_PrintAnaly (schAnaly);
	    eng.anal_flag |= 0xa0;	// Main anal line/root changed..
	  }
	  if (schCurTime < schCurTargTime || (!NormalCompute)) { // Search not over yet..
	    last1move = tcmove [1];
	    return 0;
	  }  // Otherwise drop thro, time over..
	  if (schMode == schThinkOpp && oppOverTime == 0) {  // If think in opp, go to OverTime mode..
	    oppOverTime = 1; 	// Switch to Overtime mode..
	    last1move = tcmove [1];
	    NormalCompute = FALSE;	// Now in think-opp Overtime.. IQ step 20..
	    return 0;
	  }
	}
	last1move = tcmove [1];
	schAnaly->type = AN_MAIN;
	UpdateAnalLine (schAnaly); // Copy best line to Main Analysis structure..
        dbg_PrintAnaly (schAnaly);
	eng.anal_flag |= 0xa0;	// Main anal line/root changed..
		// Search finished? Or re-iterate..
	if (schTargetTime < 1 && NormalCompute) {
	  if (NotOverTime ()) goto EndSearch;
	  NormalCompute = FALSE;	// Now in think-opp Overtime.. IQ step 20..
	}
	if (schCurTime >= schCurTargTime && schTargetLevel == 0 && NormalCompute) {
	  if (NotOverTime ()) goto EndSearch;
	  NormalCompute = FALSE;	// Now in think-opp Overtime.. IQ step 20..
	}
	//percent = (short) ((long) (schCurTime * 100) / schCurTargTime);
	percent = (short) ((long) (schCurTime * 100) / schCurTargTime);
	if (percent > 75 && NormalCompute) {
	  if (NotOverTime ()) goto EndSearch;	// Cannot start new iteration
	  NormalCompute = FALSE;	// Now in think-opp Overtime.. IQ step 20..
	}
	percent = (short) ((long) (schCurTime * 200) / (schCurTargTime + schTargetTime));
	if (schMixedFlags & 64) {	// Print extra stats in move window.
	  char sstr [200];
	  short clen;
	  static short tpos;
	  clen = wsprintf (sstr,"Targ %lu IQ %d Eval %d Window %d/%d #hit %lu #look %lu opp %d, #pre %d, mixf %d",
	  	schCurTargTime,schIQcut,schBestSoFar,schStartLo,schStartHi,
	  	hashHit,hashAccess,oppKeepHash,preCount,schMixedFlags);
	    clen += wsprintf (sstr + clen,"#Draw %d ",hashCountDraws ());
	  SetWindowText (hMainWnd,sstr);
	  tpos = (tpos + 1) & 7;
	  TextOut (hMainDC,0,50 + tpos * chrx,sstr,clen);
	}
	//autol_NewIter ();	// Send new iteration score to autolearn..
	if (abs (schBestSoFar) > 30000) {	// Game over..
	  goto EndSearch;
	}
	if (schWinSize) {	// See if AB win overflow..
	  if (schBestSoFar < schStartLo) {
	    schNewIter = TRUE;
	    if (schIterMode < sch_FAILALL) {
	      schIterMode = sch_FAILLO;	
	    } else {
	      schIterMode = sch_FAILALL;	// New iter, but no a/b window..
	    }
	    return 0;
	  }
	  if (schBestSoFar > schStartHi) {
	    schNewIter = TRUE;
	    if (schIterMode < sch_FAILALL) {
	      schIterMode = sch_FAILHI;
	    } else {
	      schIterMode = sch_FAILALL;	// New iter, but no a/b window..
	    }
	    return 0;
	  }
	}
	if (schMode == schThinkComp && schNLegalMoves < 2) {
	  if (tnomoves  [2] == 1) goto EndSearch;
          if (Manaly->moves[1] != Manaly->moves[3]) goto EndSearch;  // Not multijump, short analy..
	}
	if (schIQcut > 700) {
	  goto EndSearch;
	}
	if (!NormalCompute) {		// Either 2 player or opp think overtime..
	  schIQcut += 20;
	} else if (schTargetLevel) {	// Fixed depth/infinite search..
	  schIQcut += 20;
	  if (schIQcut > schTargetLevel) {
	    goto EndSearch;
	  }
	} else {		// Normal time-iteration
	  schIQcut += 10;
	  if (percent < 50) schIQcut += 2;
	  if (percent < 40) schIQcut += 2;
	  if (percent < 30) schIQcut += 2;
	  if (percent < 25) schIQcut += 1;
	  if (percent < 20) schIQcut += 2;
	  if (percent < 12) schIQcut += 2;
	  if (percent < 7) schIQcut += 2;
	  if (percent < 5) schIQcut += 1;
	}
	schNewIter = TRUE;
	schIterMode = sch_NEWITER;		// Force new iteration next time..
	schLast2Eval = schLastEval;	// Save prev to last score..
	schLastEval = schBestSoFar;	// Save Last iter score..
	return (0);		// Next iteration..
EndSearch:
	if (schMode == schThinkComp) {		// Keep best-reply as hint..
	  oppExtractHint (Manaly,1);		// Get (schHint..) moves
	  schPossibleNextBest = cg2sch (Manaly->moves[0]) + 
	  	(cg2sch (Manaly->moves[1]) << 8);  // For later next-best..
	}
	schMode = 0;
	return (1);	// Search finished
}

//////////////////////////////////////////////////
//						//
//      BOOK SERVICE ROUTINES..         	//
//						//
//////////////////////////////////////////////////

  // Book as long-words- MOVE BYTES:src,dest,flags,CMD
  // CMD==0 normal mov, ==1 for VAR start, ==2 for VAR end.
  // COMMENT: lo,mid,hi,2 (#=comment index # at end)
#define KMOV 0
#define KBEG 1
#define KEND 2
#define vMOV 0
#define vBEG 0x01000000
#define vEND 0x02000000
#define BOKCMD(x) (((long) x) >> 24)		// Strip out cmd byte
#define BOKFLAG(x) (((long) x) >> 16)
#define ISMOV(x) (((x) & 0xff000000) == vMOV)
#define ISBEG(x) (((x) & 0xff000000) == vBEG)
#define ISEND(x) (((x) & 0xff000000) == vEND)
#define ISPOS(x) (((x) & 0xffff0000) == (vBEG | 0xff0000))   // Setup pos..
#define mv_(x,y) (x) | (y<<8) | vMOV
#define mvB(x,y) (x) | (y<<8) | vBEG
	// Reverse colour of a move-word..
#define bokRevColOf(Cmov) \
	(((bokMaxBrd - 1) | ((bokMaxBrd - 1) << 8)) - (Cmov))

	// Must have "(C)PCSol" at start of book..

long bokEng [] = {0x50294328,0x6c6f5343,0x80000001,0x80000000,
/*  mvB(42,35),mvB(21,28),mv_(35,21),mv_(14,28),mv_(40,33),vEND,
             mvB(19,26),mv_(49,42),mv_(21,30),vEND,
             mvB(21,30),mv_(49,42),mv_(19,26),mv_(56,49),mv_(30,39),mv_(35,28),mv_(17,24),mv_(42,35),vEND,
    vEND,
  mvB(46,37),mvB(21,28),mv_(55,46),mv_(14,21),mv_(42,33),mv_(28,35),mv_(44,26),vEND,
             mvB(21,30),mv_(42,35),mv_(14,21),vEND,
    vEND,
*/   
vEND,vEND,vEND,vEND,vEND,0};

long bokItal [] = {0x50294328,0x6c6f5343,0x80000002,0x80000000,
		/*mvB(18,27),*/ vEND,vEND,vEND,0,0};

long bokVoid [] = {0x50294328,0x6c6f5343,0x80000000,0x80000000,
	vEND,vEND,0,0};

  // Array of Ptrs to internal book, by eng.gamtype:-0=eng,1=ital..
long *bokAll [] = {bokVoid,bokEng,bokItal,bokVoid,bokVoid,bokVoid,bokVoid,
	bokVoid,bokVoid,bokVoid,bokVoid,bokVoid,bokVoid,bokVoid,bokVoid};

BOOKTYPE *bokStart = bokEng;		// Start of book..
BOOKTYPE *bokPtr [MAX_BOOK_MOVES + 4];	// Array of ptrs to moves in eng.book_moves
BYTE bokFlags [MAX_BOOK_MOVES + 1];	// Array of flag bytes -!? move strength (bit set for rev col)
BYTE bokMvFlags [200]; 			// Temp Mv-flag store..
STINT bokColor;				// Current col during book scan
STINT bokMatchCol;			// Col of pos to find
STINT bokNlist;				// # moves in cur book list
STUINT far *bokList = eng.book_moves;	
BOOKTYPE *bokInsert;			// Point at which to insert moves..
BOOKTYPE *bokData;			// Cur ptr to book
STINT locrown,hicrown;
STINT bokMaxBrd;
STINT bokError;         
long bokSize;			// # entries in book (not just moves)
long bokMoveSize;		// # moves in book

HGLOBAL bokhGlobStack = NULL;	// Handle for temp book memory

char far *bokStartStack;	// Ptrs to mem for board-storage stack
char far *bokStack;
BYTE bokCurBook = 0xff;		// Current loaded book number..

HGLOBAL bokhGlobMem = NULL;	// Handle for main book memory
char bokName [] = "SBOOK0.BOK\0\0\0Sage Draughts is Copyright Adrian Millett 1989-95,"
		"All rights reseved, Duplication prohibited.";
long bokFileSize;
long bokMemSize;

  // Load a book for a given game type. set bokStart to point to start
  // Allocate/resize memory if necessary..
  // Ret 0 if book OK,nz if fails..
STFUNC short FASTCALL bokLoad (BYTE gametype, BYTE bmode)
{
	USHORT cbook;
	long *cptr;
	gametype ++;
	if (gametype > 20) return 0;
		// Book already loaded?
	if (bmode == 0 && gametype == bokCurBook) return 1;
	bokCurBook = gametype;
	bokName [5] = 48 + gametype;	// Book to load..
	if (gametype > 9) bokName [5] += 7;
	bokFileSize = GetFileLen (bokName);
	bokMemSize = bokFileSize + 0x4000;	// Alloc extra 16K..
	if (bokFileSize == HFILE_ERROR) {	// File dont exist..
	  bokMemSize = 0x4000;			// Alloc some mem anyway
	}
	if (bokhGlobMem == NULL) {	// No memory allocated, alloc some..
		// Grab some memory for book
	  bokhGlobMem = GlobalAlloc (GMEM_MOVEABLE, bokMemSize);
	} else {
	  GlobalUnlock (bokhGlobMem);
	  bokhGlobMem = GlobalReAlloc (bokhGlobMem, bokMemSize , 
	  	GMEM_MOVEABLE);
	}
	if (bokhGlobMem == NULL) {	// Unable to alloc mem..
	  return 0;
	}
	bokStart = GlobalLock (bokhGlobMem);
	if (bokFileSize == HFILE_ERROR) {	// File dont exist..
	  goto DefaultBook;
	}
	LoadHugeFile (bokName, (char HUGE_ *) bokStart,  0L, bokFileSize);
		// Incorrect header? If wrong, go to default books
	if (bokStart [0] != bokEng [0] || bokStart [1] != bokEng [1]) {
	  goto DefaultBook;
	}
	if ((bokStart [2] & 0x1f) != gametype) goto DefaultBook;
	return 1;
DefaultBook:
	cbook = 0;
	cptr = bokAll [gametype];
	while (cptr [cbook]) {			// Copy book to memory..
	  bokStart [cbook] = cptr [cbook];
	  cbook ++;
	}
	return 0;
}

STFUNC void bokUnLoad ()		// Free up any book memory
{
	if (bokhGlobMem) {
	  GlobalUnlock (bokhGlobMem);
	  GlobalFree (bokhGlobMem);
	}
	bokhGlobMem = NULL;
	bokStart = bokEng;
}

  // Save currently loaded book..
short bokSave ()
{
	bokBuildBookList (0);	// Build list of moves (& positions) for this pos..
				// & calc bokSize..
	SaveHugeFile (bokName,(char HUGE_ *) bokStart,(bokSize << 2) + 8); // (inc header len)
	return 0;
}

  // Compare 2 boards (uses INT size for speed..)
MYINLINE short bokCompare (char *mem1, char *mem2)
{
	USHORT cpos = bokMaxBrd >> 1;
	do {
	  cpos --;
	  if (((short *) mem1) [cpos] != ((short *) mem2) [cpos]) {
	    return 0;	// Fail
	  }
	} while (cpos > 0);
	if (bokMaxBrd & 1) {		// Test left-over byte, if odd size..
	  if (mem1 [bokMaxBrd - 1] != mem2 [bokMaxBrd - 1]) {
	    return 0;
	  }
	}
	return 1;		// Success!
}


  // Quick exec a book move, 
  // LOBYTE == from, HIBYTE = dest
  // bit 15 set if error
  // bit 0 set for wht captured, bit 1 if blk captured
MYINLINE short bokDoMove (USHORT cbook)
{
	char cpiece;
	char capt = 0;		// Captured piece
	short mdest,msrc;
	short cdir,absdir;
	short cret;
	mdest = cbook >> 8; msrc = (BYTE) cbook;
	cdir = mdest - msrc;
	absdir = abs(cdir);
	if (absdir != ENG_BOARDX + 1 && absdir != ENG_BOARDX - 1) {	// Jump?
	  short cbrd;
	  cdir = ENG_BOARDX - 1;		// Try 1 dir..
	  if (absdir % cdir) {
	    cdir = ENG_BOARDX + 1;		// Try another
	    if (absdir % cdir) {	// fails, bad move..
	      return (short) (0x8000L);
	    }
	  }
	  if (mdest < msrc) cdir = -cdir;
	  cbrd = msrc;
	  do {		// Scan to find captured piece..
	    cbrd += cdir;
		    // Error if no capture piece found!
	    if (cbrd == mdest || (USHORT) cbrd > MAX_CHECKER_BOARD) {
	      return (short) (0x8000L);
	    }
	    capt = bokBoard [cbrd];
	  } while (capt == 0);
	  bokBoard [cbrd] = 0;	// Erase captured
	}
	cpiece = bokBoard [msrc];	// Source
	if (cpiece < Bman || cpiece > Wking) {
	  return (short) (0x8000L);	// error..
	}
	if (mdest < locrown || mdest > hicrown) cpiece |= 1;
	bokBoard [mdest] = cpiece;	// Dest..
	bokBoard [msrc] = 0;		// Erase orig
	bokColor = (~cpiece) & FLIPWB;	// next move color..
	cret = 0;
	if (capt & CWHITE) cret = 1;
	if (capt & CBLACK) cret = 2;
	return cret;
}

	// Skip over a book-position entry..
#define bokSKIPPOS(x) x += ((((*x) & 0xff00) + 0x200) / 0x300) + 1;

  // Extract encoded set-up board position from book data,
  // set up on board position..
MYINLINE short bokExtractPos (BOOKTYPE *bkptr, BYTE *bkbrd, short *bkCol, BYTE *nw, BYTE *nb)
{
	//short plen = (*bkptr & 0xff00) >> 8;
	short cpos;
	BYTE bpos;
	BYTE HUGE_ *pptr;
	BYTE cpiece;
	*nw = 0;
	*nb = 0;
	*bkCol = GetColorForMove (*bkptr & 1);	// Side to move
		// Clear board pos..
	for (cpos = 0; cpos < bokMaxBrd; cpos ++) {
	  if (bkbrd [cpos] != EdgeSq) bkbrd [cpos] = 0;
	}
	bkptr ++;
	pptr = (BYTE HUGE_ *) bkptr;
	cpos = 0;
	cpiece = Bman;
	do {
	  if ((cpos & 3) == 3) cpos ++;		// Skip every 4th byte (CMD)
	  bpos = pptr [cpos];
	  if (bpos >= 0xfe) {
	    if (bpos == 0xfe) {
	      cpiece ++;
	    }
	    cpiece ++;
	  } else {
	    if (bpos > (BYTE) bokMaxBrd || bkbrd [bpos]) {	// Error..
	      return (short) (0x8000L);
	    }
	    bkbrd [bpos] = cpiece;
	    if (cpiece & CWHITE) {	// Count pieces..
	      nw[0] ++;
	    } else {
	      nb[0] ++;
	    }
	  }
	  cpos ++;
	} while (cpiece <= Wking);
	return 0;		// OK, done!
}

STBYTE bokSNwht,bokSNblk;	// piece count of pos to find..
STBYTE bokBuildMode;		// bit 1 set to disable rev color..

  // Recursivly examine book for matching lines..
STFUNC void FASTCALL bokRecurseSearch (BYTE bokNwht, BYTE bokNblk)
{
	BYTE ccmd;
	BYTE firsttime = 1;
	USHORT cbook;
	short ccolor = bokColor;		// Save cur pos on stack..
	_fmemcpy (bokStack,bokBoard,bokMaxBrd);
	bokStack += bokMaxBrd;
	do {		// Ok, now examine moves in this line..
		// If ADD-MOVES search, see if 1st matching pos?
	  if (bokInsert == NULL && bokColor == bokMatchCol) {
	    if (bokCompare (bokBoard, bokMatch)) {
	      bokInsert = bokData;	// Save pos of book entry
	    }
	  }
	  ccmd = (BYTE) (BOKCMD (*bokData));
	  if (ccmd == KEND) {	// Var ends, skip rest..
	    bokData ++;
	    goto ExitBook;
	  }
	  if (ccmd == KBEG && firsttime == 0) {	// Recursively look at sub-variation
	    bokRecurseSearch (bokNwht, bokNblk);
	  } else {			// Normal move, do it..
	    if (ISPOS (*bokData)) {	// Get set-up pos..
	      bokError = bokExtractPos (bokData, bokBoard, &bokColor, &bokNwht, &bokNblk); 
	      if (bokError) return;
	      bokSKIPPOS (bokData);	// Skip over a book pos;;
	      goto bokRecurseNext;	// Now reloop, scan this line..
	    } 
	    cbook = (USHORT) *bokData;
	    if (bokColor == bokMatchCol) {	// Found matching pos?
	      if (bokSNwht == bokNwht && bokSNblk == bokNblk 
	      	  && bokCompare (bokBoard, bokMatch) && bokNlist < MAX_BOOK_MOVES) {
	        bokList [bokNlist] = cbook;	// Yes, save it in list..
	        bokFlags [bokNlist] = (BYTE) (((long) *bokData) >> 16);
	        bokPtr [bokNlist] = bokData;	// Save pos of book entry
	        bokNlist ++;
	      }
	    } else { // Try for rev color match
	      if (bokSNwht == bokNblk && bokSNblk == bokNwht 
	          && (bokBuildMode & 2) == 0	// Rev-col mode on?
	      	  && bokCompare (bokBoard, bokRevMatch) && bokNlist < MAX_BOOK_MOVES) {
	        bokList [bokNlist] = bokRevColOf (cbook);	// Yes, save it in list..
			// Set bit 7 of flags== reversed colours..
	        bokFlags [bokNlist] = (BYTE) (((long) *bokData) >> 16) | 0x80;
	        bokPtr [bokNlist] = bokData;	// Save pos of book entry
	        bokNlist ++;
	      }
	    }
	    bokMoveSize ++;			// Move # count..
	    bokError = bokDoMove (cbook);	// Fast exec a move
	    bokData ++;
	    if (bokError & 3) {	// Captured piece?
	      if (bokError & 1) {
	        bokNwht --;
	      } else {
	        bokNblk --;
	      }
	      if (ISMOV(*bokData) && (BYTE) *bokData == HIBYTE (cbook)) {
		bokColor = (~bokColor) & FLIPWB; // Multijump, keep color..
	      }
	    }
	    bokError &= 0x8000;		// Now mask out all but error bit..
	  }
bokRecurseNext:
	  if (bokError) return ;
	  firsttime = 0;	// Clr for subsequent iterations
	  	// End if too few pieces on the board..
	} while (bokNwht + bokNblk >= bokSNwht + bokSNblk);
	cbook = 1;	// Nesting level..
	do {		// Skip past end, past any nested variants..
	  ccmd = (BYTE) BOKCMD (*bokData);
	  if (ccmd == KEND) cbook --;
	  if (ccmd == KBEG) cbook ++;
	  bokData ++;
	} while (cbook > 0);
ExitBook:
	bokStack -= bokMaxBrd;		// Pull orig pos off stack
	_fmemcpy (bokBoard,bokStack,bokMaxBrd);
	bokColor = ccolor;
}

STFUNC short FASTCALL bokPieceCount (char *pbrd)
{
	BYTE nw = 0;
	BYTE nb = 0;
	short cbrd;
	for (cbrd = 0; cbrd < bokMaxBrd; cbrd ++) {
	  if (pbrd [cbrd] & CWHITE) nw++;
	  if (pbrd [cbrd] & CBLACK) nb++;
	}
	return (nw << 8) + nb;
}

  // Build a list of allowable book moves at (blist)
  //  for given board position at (eng.checker_board), and (schColor)
  // Set mode bit 0 for AddLine search.. set bit 1 to disable rev-col moves
STFUNC void bokBuildBookList (BYTE bmode)
{
	short cret;
	bokBuildMode = bmode;	// save rev-color status bit to global
	bokList = eng.book_moves;
	bokData = bokStart + 4;
	bokInsert = bokData;
		// Force search for 1st match pos..
	if (bmode && !ISEND (*bokData)) bokInsert = NULL;
	bokNlist = 0;		// # moves found..
	bokError = 0;		// Set if internal error found..
	bokMoveSize = 0L;	// # moves in book
	bokSize = 0L;		// # entries in book
	bokMaxBrd = ENG_BOARDX * ENG_BOARDY;
	locrown = ENG_BOARDX ;	// Crown if less than this
	hicrown = bokMaxBrd - ENG_BOARDX - 1; // or more than this
		// Get a copy of current board..save as match..
	_fmemcpy (bokMatch,eng.checker_board,bokMaxBrd + 1);
	cret = bokPieceCount (bokMatch);
	bokSNwht = HIBYTE (cret);	// # pieces on search-board..
	bokSNblk = LOBYTE (cret);
	bokMatchCol = GetColorForMove (eng.move_number);	// col cur move
	{ short cpos;	// Make a Reversed-colours copy..
	  for (cpos = 0; cpos < bokMaxBrd; cpos ++) {
	    cret = bokMatch [cpos];
	    if (cret >= Bman && cret <= Wking) cret ^= 6; // Swap piece colours..
	    bokRevMatch [bokMaxBrd - 1 - cpos] = (BYTE) cret;
	  }
	}
	schNewBoard ((short *) bokBoard, 1);	// Start new game..
	sch2cgbrd (bokBoard,(short *) bokBoard);	// Convert to eng.checker_board format
	bokColor = GetColorForMove (0);	// color for book-replay start
		// Grab some memory for book-board storage stack..
	bokhGlobStack = GlobalAlloc (GMEM_MOVEABLE, 10000);
	if (bokhGlobStack == NULL) {	// Unable to alloc mem..
	  return ;
	}
	bokStartStack = bokStack = GlobalLock (bokhGlobStack);
	while (!ISEND (*bokData) && bokError == 0)  {	// Until all lines end..
	  cret = bokPieceCount (bokBoard);
	  bokRecurseSearch (HIBYTE (cret),LOBYTE (cret));	// SEARCH FOR MATCHES..
	}
	bokList [bokNlist] = 0;		// Null terminate list..
	bokSize = (long) ((BOOKTYPE *) bokData - bokStart);	// Abs Size of book
	GlobalUnlock (bokhGlobStack);
	GlobalFree (bokhGlobStack);
}

	// Insert data in book..
MYINLINE void InsertBook (BOOKTYPE *bIns, BOOKTYPE *bEnd, USHORT nadd)
{
	while (bEnd >= bIns) {	// Move it up by nadd..
	  bEnd [nadd] = bEnd [0];
	  bEnd --;
	}
}

  // Add 1 move to book..
  // (CheckerMoveInfo) points to eng.game_store move,
  // (bokList) points to list of moves (eng.book_moves), and bokPtr to their pos.
  // Ret 0 if add fails..
MYINLINE short bokAddMove (BYTE bokFlag)
{
    USHORT cbook;
    BYTE ccmd;
    USHORT nadd;
    USHORT cmove = *((short far *) CheckerMoveInfo);
    if (bokInsert == NULL) return 0;		// No matching pos, cannot add
    for (cbook = 0; bokList [cbook] && cbook < MAX_BOOK_MOVES; cbook++) {
      if (bokList [cbook] == cmove) return 0;	// move exists, dont add
    }
    	// Ok, insert point found - add move to book..
    	// Determine type of insertion:- depends on whats at insert point
    	//   ie. adding 1115,2218 thus:
    	// (1115) -> (1115,2218)   If ")", Simple insertion 2218
    	// (1115,(2319).. -> (1115,(2218),(2319).. If "(", insert (2218)
    	// (1115,2319) -> (1115,(2218),(2319)) If move, insert (2218) & add )
    ccmd = (BYTE) BOKCMD (*bokInsert);
    if (ccmd == KEND) {		// ")"    insert xxx
      nadd = CheckerNParts;
    } else if (ccmd == KBEG) {	// "("    insert (xxx)
      nadd = CheckerNParts + 1;
    } else {			// move.. insert (xxx) & )
      nadd = CheckerNParts + 2;
    }
    InsertBook (bokInsert,bokData + 2,nadd);	// Make space for new moves
    	// Now place moves in book
    for (cbook = 0; cbook < CheckerNParts; cbook ++) {
      GAMESTORE far *cgs = &CheckerMoveInfo [cbook];
      bokInsert [cbook] = *((short far *) cgs);
    }
    if (bokFlag) {	// If any flag, place in book..
      bokInsert [0] |= ((long) bokFlag) << 16;
    }
    if (ccmd != KEND) {		// Add brackets to move..
      bokInsert [0] |= vBEG;	// Or in open "("
      bokInsert [cbook] = vEND; // Add ")" to end
      if (ccmd == KMOV) {	// Also add ")" to next sequence
        short clev = 0;		// Parenthesis level
        long ibook = (long) cbook;		
	bokInsert [cbook + 2] |= vBEG;		// Add "(" to next line..
        do {			// Scan until end of this level found..
          ibook ++;
          bokInsert [ibook] = bokInsert [ibook + 1];
          if (BOKCMD (bokInsert [ibook]) == KBEG) clev ++;
          if (BOKCMD (bokInsert [ibook]) == KEND) clev --;
        } while (clev > 0);
		// a ")" is naturally left behind by move-down process..
      }
    }
    return 1;		// Move added ok..
}
         
  // Add a initial set-up position to book-tree..
MYINLINE short bokAddPos (BYTE far *cbrd)
{
	BOOKTYPE *bkptr = bokData;	// Cur ptr to book-end..
	BYTE pdat [100];	// Temp piece-list data..
	BYTE cpiece;
	short cpos,bpos;
	if (bokInsert != NULL) {  // Match exists, just add moves here..
	  return 0;
	}
	  // Otherwise add this position to the end of the book..
	  // First encode cur pos into piece-data
	cpos = 0;
	for (cpiece = Bman; cpiece <= Wking; cpiece ++) {
	  bpos = ENG_BOARDX * ENG_BOARDY;
	  do {		// Scan board..
	    bpos --;
	    if (cbrd [bpos] == cpiece) {
	      pdat [cpos] = (BYTE) bpos;	// Save piece-position
	      cpos ++;			// Next list
	    }
	  } while (bpos);
	  if (cpos > 0 && pdat [cpos-1] == 0xff) { // Compress a little..
	    pdat [cpos - 1] = 0xfe;	// Means 'skip 2 piece colours,,'
	  } else {
	    pdat [cpos] = 0xff;		// End of current piece list..
	    cpos ++;
	  }
	}
	if (cpos < 4) return -1;	// Cannot be legal pos..
	  // Build POSITION header book-entry long word..
	  // BEG,0xff,length,side-to-move (hi..lo)
	*bkptr = vBEG | 0xff0000 | (cpos << 8) | (eng.init_moven & 1);
	bkptr ++;
	bpos = 0;
	do {		// Now move data into real book..
	  long tmp;
	  tmp = pdat [bpos] | ((USHORT) pdat [bpos+1] << 8) | ((ULONG) pdat [bpos+2] << 16);
	  *bkptr = tmp;
	  bkptr ++;
	  bpos += 3;
	} while (bpos < cpos);
	*bkptr = vEND; bkptr ++;	// Add 2 END markers (+1 extra)
	*bkptr = vEND; bkptr ++;
	*bkptr = vEND;
}

  // Add current line to the book..
  // List of book flag-bytes in bFlags (if not NULL)
  // Start-move given in StartMove (0=from beginning)
  // Ret -1 if error/book corrupt, etc..
STFUNC short FASTCALL bokAddLine (BYTE *bFlags, short StartMove)
{
	short endmove = eng.move_number;
	BYTE cflag;
	//if (eng.init_moven) return -1;	// Error - must start from new pos..
	if ((bokSize << 2) + 4096 > bokMemSize) {	// Too big..
	  bokSave ();			// Save current book..
	  bokLoad (eng.gamtype,1);		// Force reload + realloc mem..
	}
	eng.param_ax_pass = -2;
	eng.param_pass = 0;		// Clr all old analysis
	ext_step_move ();	// Spool to game start..
	if (eng.init_moven) {	// Set-up position, add pos to book..
	  bokBuildBookList (3);	// Build list of moves (& positions) for this pos..
	  if (bokError) return -1;		// Error..
	  if (bokAddPos (eng.checker_board) == -1) return -1;	// Error..
	}
	if (StartMove) {
	  eng.param_ax_pass = 0x8000 | StartMove;
	  ext_step_move ();	// Spool to game start..
	}
		// Spool thro line 1 move at a time, add to book
	while (eng.move_number < endmove) {
	  bokBuildBookList (3);	// Build list of moves (& positions) for this pos..
	  if (bokError) return -1;		// Error..
	  eng.param_ax_pass = 0;
	  eng.param_pass = eng.move_number;
	  if (ext_misc_service () == -1) return -1;	// Error..
	  cflag = 0;
	  if (bFlags != NULL && eng.move_number < aSizeOf (bokMvFlags)) {
	    cflag = bokMvFlags [eng.move_number];
	  }
	  if (bokAddMove (cflag) == -1) return -1;		// Error..
	  eng.param_ax_pass = 1;	// Next move..	
	  eng.param_pass = 0;	
	  ext_step_move ();	// step forward..
	}
	return 0;		// Add line worked ok!
		// NOTE - caller should now perform book-save..
}

	// Conv ASC CHAR to.. 1 for White, 2 for Black, 0 for niether..
#define bokSIDECHR(x) (((x) == 'W') | (((x) == 'B') << 1)) 

  // Read in a position from ascii source into given board
  // return 0 if error, or (#chars read)*2 + side to move (bit 0)..
short ext_decode_asc_pos (char far *cstr, char far *cbrd)
{
	char cside;
	char cpiece;
	short cpos;
	short bpos;	// Brd pos
	short maxbrd = ENG_BOARDX * ENG_BOARDY;
	BYTE sidetomove = bokSIDECHR (cstr [0]) - 1;
	if (sidetomove > 1 || cstr [1] != ':' || cstr [2] != 'W') {
	  return 0;	// Illegal side-to-move..
	}
	//sidetomove = ((FlagInitCol == 0) ^ cside); // Set if 2nd side moves 1st
	  	// Wipe board clear..
	for (cpos = 0; cpos < maxbrd; cpos ++) {
	  cbrd [cpos] = EdgeSq;
	}
		// Etch out play area..
	for (cpos = 1; cpos <= schNsqrs; cpos++) {
	  cbrd [ext_num2pos ((BYTE) cpos) & 0xff] = 0;
	}
	cpos = 3;
	cside = Wman;	// Always start with white
	do {
	  cpiece = cside;
	  if (cstr [cpos] == 'K') {
	    cpos ++; cpiece ++;
	  }
	  if (isdigit (cstr [cpos]) == 0) {	// Must be number..
	    return 0;
	  }
	  bpos = (short) str2val (cstr + cpos, 10, 2); // Extract pos #
	  if (bpos == 0) {		// No pos, illegal..
	    return 0;	// Error
	  }
	  bpos = ext_num2pos ((BYTE) bpos);	// Convert..
	  if (bpos < 0 || bpos >= maxbrd || cbrd [bpos]) {
	    return 0;	// Error..
	  }
	  cbrd [bpos] = cpiece;		// Place piece..
	  do {		// Scan past number..
	    cpos ++;
	  } while (isdigit (cstr [cpos]));
	  if (cstr [cpos] == ',') cpos ++;
	  if (cstr [cpos] == ':') {	// Now black pieces..
	    cpos ++;
	    if (cstr [cpos] != 'B') return 0;
	    cpos ++;
	    cside = Bman;
	  }
	} while (cstr [cpos] != '.');	// Ends position..
	cpos ++;
	return ((cpos << 1) | sidetomove);
}

  // Turn current SAGE pos into an asc piece list.. 
  // FORMAT side:W#,K#:B#,#. (ie. W:W14,K7:BK31,28.)
short ext_encode_asc_pos (char *cstr, char far *cbrd, short cside)
{
	short csqr;
	short cpos;
	char ccol;
	char cpiece;
	char lastp;
	if (GetColorForMove (cside) == CWHITE) {	// Side to move
	  ADDCHAR (cstr,'W');
	} else {
	  ADDCHAR (cstr,'B');
	}
	ADDCHAR (cstr,':');
	ccol = CWHITE;
	ADDCHAR (cstr,'W');	// White pieces first
	do {			// Loop white then black..
	  lastp = 0;
	  for (csqr = 1; csqr <= schNsqrs; csqr++) {
	    cpos = ext_num2pos ((BYTE) csqr);
	    if (cpos < 0 || cpos >= (ENG_BOARDX * ENG_BOARDY)) break;
	    cpiece = cbrd [cpos];
	    if (cpiece & FLIPWB & ccol) {	// Correct piece col!
	      if (lastp) {	// If any prev, add comma
	        ADDCHAR (cstr,',');
	      }
	      lastp = cpiece;
	      if (cpiece & 1) {
		ADDCHAR (cstr,'K');
	      }
	      INT2ASC2 (cstr,csqr);
	    }
	  }
	  if (ccol == CBLACK) break;	// Both sides done..
	  ccol = FLIPWB - ccol;
	  ADDCHAR (cstr,':');
	  ADDCHAR (cstr,'B');
	} while (1);
	ADDCHAR (cstr,'.');
	ADDCHAR (cstr,' ');
	*cstr = 0;		// Null term
	return 0;
}

long bokLcount;		// Count of asc lines as they are read from file

short bokPrevGame [40]; // Previous game storage (up to 40 moves)
short bokLastNewMove;		// Point at which game differs..

void exAddExtraInfo (BYTE cflag, short movdat)
{
	  	// Temp Store move-flag..
	if (eng.move_number < aSizeOf (bokMvFlags)) {
	  bokMvFlags [eng.move_number] = cflag;
	}
		// Compare/save last game-move record
	if (eng.move_number < aSizeOf (bokPrevGame) - 1) {
	  	// Is the move same as in last game?
	  if (eng.move_number == bokLastNewMove) {
	    if (bokPrevGame [eng.move_number] == movdat) {
	      bokLastNewMove ++;
	    }
	  }
	  bokPrevGame [eng.move_number] = movdat;
	}
}

  // Load a single ascii-line from book file into engine..
STFUNC short bokLoadAscLine (short bindex)
{
	GAMESTORE pmov [3];
	short llen;
	char *cstr = szTemp;
	short cmove;
	BYTE cflag;
	do {
	  llen = bfLineRead (bindex, szTemp, sizeof (szTemp) - 100);
	  bokLcount ++;
	  if (llen == HFILE_ERROR) return -2;
	  	// End of book? (".end." , not ".egame..")
	  if (szTemp [0] == '.' && szTemp [2] != 'g') {
	    return -2;
	  }
	} while (szTemp [0] != '>' && isdigit (szTemp [0]) == 0);	// Ignore comment lines..
	ext_init_game ();
	
	if (szTemp[0] == '>') {		// Set up start position..
	  cmove = ext_decode_asc_pos (szTemp + 1, eng.checker_board);	// Ret length of pos..
	  if (cmove == 0) return (1);	// Error in position..
	  cstr += (cmove >> 1) + 1;		// Advance string..
	  eng.param_ax_pass = cmove & 1;
	  ext_set_board_pos ();
	}
	do {
		// Read in move..
	  if (isdigit (*cstr) == 0) break;	// Non move char, end..
	  cmove = (short) str2val (cstr,10,4);
	  while (isdigit (*cstr)) cstr ++;
	  	// Note - this ordering used, so that XOR with3= 1..5 linear ?<=>!
	  cflag = 0;
	  switch (*cstr) {
	    case '<' : cflag = 1; cstr ++; break;
	    case '?' : cflag = 2; cstr ++; break;
	    case '!' : cflag = 6; cstr ++; break;
	    case '>' : cflag = 7; cstr ++; break;
	  }
	  while (*cstr == ' ' || *cstr == ',') cstr ++;	// Skip white spc..
	  	// Ok, now make move on board..
	  Pmove_test->from = pmov[0].src = (BYTE) ext_num2pos ((BYTE) ((short) cmove / 100));
	  Pmove_test->to = pmov[0].dest = (BYTE) ext_num2pos ((BYTE) ((short) cmove % 100));
	  Pmove_test->flags = pmov[0].flag = 254;	// Allow multijump in 1 mv
	  pmov[1].src = pmov [1].dest = 0;
	  retv = ext_is_move_legal ();
	  if (retv) return (1);		// ret illegal move..
	  exAddExtraInfo (cflag, *((short *) pmov));  // Save flag/last game info
	  retv = ext_checker_move (pmov,0,NULL);	// Exec move..
	    	// Save in previous-line record..
	} while (1);
	return 0;		// All ok!
}

  // Import/Merge book data from orig-format book-file..
  // Ret non-zero on error..
short ext_book_import (char *ifile, long startgame)
{
	short bindex;
	short cstat = 0;
	char cstr [40];
	BYTE PgnMode = 0;
	int oldDBflag = VarEndgameDB;		// Disable endgame db look during build..
	LoadHugeFile (ifile,cstr,0,1);
	if (cstr [0] != '=') PgnMode = 1;	// No = at start, PGN file..
	bindex = bfFileOpen (ifile,-1,2048,READ);
	if (bindex == HFILE_ERROR) return HFILE_ERROR;
	memset (bokPrevGame, 0, sizeof (bokPrevGame)); // Clr prev game list
	bokLcount = 0;
	pdnResetFile (bindex);
	Clr_(EndgameDB);
	do {
	  bokLastNewMove = 0;	// Last move matching prev line
	  if (PgnMode) {	// Load a PGN file..
	    cstat = 0;
	    if (pdnReadGame (2) == 0) {	// Past end/error..
	      cstat = -1;
	      if (nLastRead < 10) cstat = -2;	// End of PGN file
	    }
	    bokLcount ++;
	  } else {		// Load old sbook.txt format file
	    cstat = bokLoadAscLine (bindex);
	  }
	  wsprintf (cstr,"HIT ESC TO STOP.. Line:%ld",bokLcount); 
	  SetWindowText (hSchWnd,cstr);
	  if (cstat) {
	    short opt = IDNO;
	    if (cstat == -2) {
	      cstat = 0;	// EOF, no error code..
	    } else {
	      opt = msgprintf (NULL,USEOPTIONS,MB_YESNO,
	      	"Book error at pos %ld, Continue?",bokLcount);
	    }
	    if (opt == IDYES) continue;		// Ignore error..
	    break;		// EOF or error..
	  }
	  if (bokLcount >= startgame) {
	    cstat = bokAddLine (bokMvFlags,bokLastNewMove);	// Add this line to book..
	  }
	  if (cstat) {
	    break;		// Encoding Error..
	  }
	} while (IsKeyHit (VK_ESCAPE) == 0);
	VarEndgameDB = oldDBflag;
	bfFileClose (bindex);
	bokSave ();		// Save new resultant book..
	return cstat;
}

  // Dump current book to file..
  // Ret HFILE_ERROR on error..
short FASTCALL bokPrintOld (char far *oname, short twide)
{
	char ctxt [30];
	HFILE hFile;
	BOOKTYPE *bptr;
	short csize;
	short xpos;
	short cerror = 0;
	hFile = _lcreat (oname,0);
	if (hFile == HFILE_ERROR) {
          return HFILE_ERROR;
	}
	bptr = bokStart + 4;
	xpos = 8;
	do {
	  BYTE ccmd;
	  short csrc,cdest;
	  ccmd = (BYTE) BOKCMD(*bptr);
	  csrc = ext_pos2num ((BYTE) *bptr);
	  cdest = ext_pos2num ((BYTE) (*bptr >> 8));
	  csize = 7;
	  if (ccmd != KEND && csrc && cdest && csrc != cdest) { // OK move..
	    wsprintf (ctxt," %2d-%2d ",csrc,cdest);
	    if (ccmd == KBEG) {
	      ctxt [0] = '(';
	    }
	  } else if (ccmd == KEND) {
	    wsprintf (ctxt,") ");
	    csize = 2;
	  } else { 	// Unrecognised, just print hex of long entry..
	    wsprintf (ctxt,"$%08lx ",*bptr);
	    csize = 10;
	  }
	  if (_lwrite (hFile, ctxt, csize) == HFILE_ERROR) {
	    cerror = HFILE_ERROR;
	    break;
	  }
	  xpos += csize;
	  bptr ++;
	  if (xpos >= twide) {
	    char crlf[] = "\x0d\x0a";
	    _lwrite (hFile, crlf, 2);		// Write cr/lf..
	    xpos = 0;
	  }
	} while (bptr <= bokStart + bokSize + 4);
	_lclose (hFile);
	return cerror;
}

  // Dump current book to file..
  // Ret HFILE_ERROR on error..
short FASTCALL bokPrint (char *oname)
{
	char szTxt [4096];
	int ctxt;
	HFILE hFile;
	BOOKTYPE *bptr;
	short csize;
	short cerror = 0;
	GAMESTORE oLine [1024];
	int nmove,cmove;
        int markers [512];
        int stack;
	int nlines;	// #lines outputed.
	BYTE lastcmd;
	BYTE ccmd = -1;
	char cchr;

	hFile = _lcreat (oname,0);
	if (hFile == HFILE_ERROR) {
          return HFILE_ERROR;
	}
	bptr = bokStart + 4;
	stack = 0; 
	nmove = 0;
	nlines = 0;
	do {
	  short csrc,cdest;
	  lastcmd = ccmd;
	  ccmd = (BYTE) BOKCMD(*bptr);
	  csrc = ext_pos2num ((BYTE) *bptr);
	  cdest = ext_pos2num ((BYTE) (*bptr >> 8));
	  if (ccmd == KEND) {   // End of Var, print & next..
	      // Print current line to PDN file..
	    if (nmove == 0) break;
	    if (lastcmd != KEND) {
	      nlines ++;
	      ctxt = wsprintf (szTxt, "[Event \x22%d\x22]\x0d\x0a",nlines);
              for (cmove = 0; cmove < nmove; cmove ++) {
	        if (ctxt > aSizeOf (szTxt) - 64) goto fin;
	        ctxt += wsprintf (szTxt+ctxt, " %d-%d", oLine [cmove].src, oLine [cmove].dest);
		cchr = 0;
		switch (oLine [cmove].flag) {
		  case 1: cchr = '<'; break;
		  case 2: cchr = '?'; break;
		  case 6: cchr = '!'; break;
		  case 7: cchr = '>'; break;
		}
		if (cchr) {szTxt[ctxt] = cchr; ctxt ++; szTxt[ctxt] =0;}
	      }
	      ctxt += wsprintf (szTxt+ctxt, " *\x0d\x0a");
	      if (_lwrite (hFile, szTxt, ctxt) == HFILE_ERROR) {
	        cerror = HFILE_ERROR;
	        break;
	      }
            }

	    if (stack <=0) break;
	    stack --;
	    nmove = markers [stack];
	    bptr ++;
	    continue;
	  }
	  if (ccmd == KBEG) {
            markers [stack] = nmove;
	    stack ++;
	  }
	  if (csrc == 0 || csrc == cdest) break;
	    // Save move, go to next..
	  if (nmove && csrc == oLine [nmove-1].dest) {   // Multi jump? append to prev..
	    oLine [nmove-1].dest = cdest;
	  } else {
	    oLine [nmove].src = csrc;
	    oLine [nmove].dest = cdest;
	    oLine [nmove].flag = (BYTE) BOKFLAG (*bptr);
	    nmove ++;
	  }
	  if (nmove > aSizeOf (oLine) - 4) break;
	  bptr ++;
	} while (bptr <= bokStart + bokSize + 4);
fin:
	_lclose (hFile);
	return cerror;
}

//////////////////////////////////////////////////
//						//
//      EXTERNALLY VISIBLE SERVICE ROUTINES..	//
//						//
//////////////////////////////////////////////////


short ext_initialize (void)	// Called once on prog-start..
{
	BYTE *cptr = (BYTE *) &eng.ioram_start;
	short cpos;
		// Clear mem from ioram_start to ioram_end
	for (cpos = 0; cpos < (&eng.ioram_end - &eng.ioram_start); cpos ++) {
	  cptr [cpos] = 0;
	}
	for (cpos = 0; cpos < MAX_GAME_STORE; cpos++) {
	  schGameIndex [cpos] = 0;
	}
	ext_init_game ();	// New Board..
	eng.play_level = 0x0402;	// Fixed depth 4ply
	ext_set_level ();
	eng.short_depth = 34;	// Default short-look depth
	eng.hash_mode = 5;		// Default cutoff for hash searches..
	eng.histanal = 40;	// scrolling analy lines
	eng.endgame_db = 80;	// Endgame database depth %..
	eng.autolearn = 1;      //#K entries in autolearn table (0=off)

	mySrand ((short) clock());
	initrnd ();
	#if ENDGAMEDB
	  if (edbDisabled == -1) {
	    if (FileExists (edbFile) == FALSE) {   // Default db not available..
	      strcpy (edbFile,"db6");	// Try 6 piece database file in cur dir
	      edbMaxPieces = 6;		// # pieces in that db
	      edbBuffSize = 8000;	// # K mem to alloc for buffers.
	    }
	    if (FileExists (edbFile) == FALSE) {   // Default db not available..
	      strcpy (edbFile,"db5");	// Try 5 piece database file in cur dir
	      edbType  = edbMaxPieces = 5;		// # pieces in that db
	      edbBuffSize = 2000;	// # K mem to alloc for buffers.
	    }
	    if (FileExists (edbFile) == FALSE) {   // Default db not available..
	      strcpy (edbFile,"db4");	// Try 4 piece database file in cur dir
	      edbType  = edbMaxPieces = 4;		// # pieces in that db
	      edbBuffSize = 1000;	// # K mem to alloc for buffers.
	    }
	    if (FileExists (edbFile)) {
	      edbDisabled = DBInit (edbFile,edbBuffSize, edbType % 10);	// Initialise/load endgame DB tables..
	    } else {
	      edbDisabled = TRUE;
	    }
	  }
	  if (edbDisabled) {		// Clear endgame db bit..
	    Clr_(EndgameDB);
	  } else {
	    edbMaxPieces = edbType % 10;
	    edbGameType = max (0,edbType / 10);	// 0=eng,1=ital..
	  }
	#endif
	#if EXT_ENG
	  dll_initialize ();
	#endif
	return(0);
}

short ext_finish (void)		// Called once on program exit..
{
	bokUnLoad ();		// Free up book memory resources..
	hashFinish ();		// Free up hash table memory..
	#if ENDGAMEDB		// Terminate end-game databases..
	  DBFinish ();
	#endif
	#if EXT_ENG
	  dll_finish ();
	#endif
	return 0;
}

short ext_reset (void)
{

	ext_initialize ();
	return(0);
}

	// Start a new game - init schBoard & internal variables..
short ext_init_game (void)
{
	hashClrDraws ();		// Wipe out any hash draw-entries..
	GameClr ();
	schNextBest = 0;	// Kill any next-best search move..
	eng.white_move_time = eng.black_move_time = 0L;
	eng.white_time = eng.black_time = 0L;	// Reset clocks..
	schInitParams ();	// Init vars, rebuild indexes..
	schNewBoard (schBoard, 1);
	sch2cgbrd (eng.checker_board,schBoard); // Move search-engine brd to eng.checker_board..
	InitMoves (1);	// Generate legal move list, initialise misc vars
	return(0);
}

short ext_next_best (void)
{
	if (schMode == schThinkComp || schMode == schThinkHint) return 0;
	schNextBest = schPossibleNextBest;
	eng.param_ax_pass = -1;
	return (ext_calcmove_start ());
}

  // Try to select a book move from current book-list
  // Return 0 if none available (or illegal book), or 1 if OK..
MYINLINE short schSelectBookMove ()
{
	short mbook = 0;		// No of moves in list
	short cbook;
	USHORT cmove;		
	long HUGE_ *Pbook;
	BYTE HUGE_ *cptr;
	USHORT bestbook = 0;		// Best book move so far..
	BYTE bestflag = 0;
	BYTE cflag;
	if (FlagMainBook == 0 || eng.book_moves [0] == 0) return 0;
	do {
	  cflag = (15 & bokFlags [mbook]) ^ 3;
	  	// Best so far? or if == rnd chance of picking..
	  if (cflag > bestflag || (cflag == bestflag && (myRand () & 1))) {
	    bestflag = cflag;
	    bestbook = mbook;
	  }
	  mbook ++;
	} while (eng.book_moves [mbook] && mbook < MAX_BOOK_MOVES);
	if (bestflag == 1) return 0;	// Only weak (?) move, dont use it..
		// (eng.gammisc1) == -10 to 10 weak..strong book
	if (eng.gammisc1 < 10) {		// Try some random moves..
	  for (cmove = 0; cmove < 10; cmove ++) {
	    BYTE chance;
	    cbook = myRand () % mbook;	// Select a book move..
	    cflag = (15 & bokFlags [cbook]) ^ 3;
	    	// Calc a chance of move flag 2..5 being selected
	    chance = (BYTE) ((short) (myRand () % max (1,(eng.gammisc1 + 11))) / 4 + 1);
	    if (eng.gammisc1 >= 0) chance ++;  // Also kill (<) moves..
	    if (cflag > chance) { 	// Not a weak (?) move, 
	      bestbook = cbook;
	    }
	  }
	}
	cflag = bokFlags [bestbook];	// Keep selected book move flag..
	//msrc = (BYTE) eng.book_moves [cbook];
	//mdest = (BYTE) ((short) eng.book_moves [cbook] >> 8);
	Pbook = bokPtr [bestbook];	// Ptr to full multijump move
	Manaly->mvfrom = Manaly->mvto = 0;
		// Extract full move sequence into main-anal best line..
	cbook = 0;
	cptr = Manaly->moves;
	do {
	  cmove = (USHORT) Pbook [cbook];		// Get from book
	  if (cflag & 0x80) cmove = bokRevColOf (cmove);  // REVERSED COLOR?
	  *((USHORT HUGE_ *) cptr) = cmove;	// and save to analysis
	  cbook ++;
	  cptr += 3;
	} while ((BYTE) Pbook [cbook] == (cmove >> 8) 
		&& ISMOV (Pbook [cbook]) && cbook < 12);
	*((USHORT HUGE_ *) cptr) = 0;		// null term
	Manaly->scorelo = (BYTE) 0xfe;		// book..
	Manaly->nodes = 0;
	schMode = 0;
	if (schIsLegal (cg2sch (Manaly->moves[0]),cg2sch (Manaly->moves[1]),0)) {
	  return 0;	// Bad move..
	}
	return 1;	// OK, do this move!
}

  // request checker engine to start calculating a move. Routine will return in a
  // fraction of a second. If it returns with ax=1 the checker program has found a
  // move. Move is in best so far. 3 bytes from,to,flags
  // To make the move transfer the move to move_test and call srvc_make_move.
  // Take care with promotion moves as flag byte of move_test must only contain
  // the promotion bits. Eg if any bits 3,4,5,6,7 are set make_move will fail.!!
  // if it returns with ax=-1 if there are no legal moves from the position.
  // If it returns with ax=-2 then the checker program is on a mate solve level
  // and it has not been able to find a move that gives mate.
  // If it returns with ax=1,-1 or -2 then srvc_calcmove_continue must not be called
  // If it returns with ax=0 then the client should perform whatever input/output
  // is required and then call either srvc_calcmove_continue or srvc_calcmove_stop.
  // Call with ax=ffh,1,2,0. calculate move, anticipate move, hint search, no search
short ext_calcmove_start (void)
{
	BOOL opPar = FALSE;
	ANALY oldan;
	short cret;
	memcpy (&oldan,Manaly,sizeof (ANALY));
	#if _DEBUG
	  schMixedFlags = schMixedFlagsVar;
	#endif
	#if EXT_ENG
	  cb_2play = FALSE;
	  if (eng_touse == 1 && *dll_szEng1) {	// ext engine exists..
	    cb_2play = TRUE;
          }
	  if (eng_touse == 2 && *dll_szEng2) {	// ext engine exists..
	    cb_2play = TRUE;
          }
	#endif
	oppKeepHash = 0;
	if (cb_2play == FALSE && schMode == schThinkOpp && eng.param_ax_pass == schThinkComp) {
	  if (oppGetOld ()) {
	    opPar = TRUE;	// Fast pickup opp think?
	    oppOverTime = 0;
	  } else {
	    if (schMixedFlags & 2048) {		// Force always keep hash..
	      oppKeepHash = 1;
	    }
	  }
	}
	if (eng.param_ax_pass == schThinkHint) {
	  mySrand (1); srand (1);
	}
	oppOverTime = 0;
	schMode = eng.param_ax_pass;   //-1=calc,0=none,1=think-opp,2=hint
	 	// Normal calc/hint search?
	if (schMode != schThinkNone) {
	  #if dbug_SPOOL		// Tree printing features.
	    dbugOpen ();
	  #endif
	  schBegTime = clock ();
	  SearchInit ();            // Initialise search params
	  if (eng.game_status) {		// Game over
	    schMode = 0;		// Kill search
	    Manaly->moves[0] = Manaly->moves[1] = Manaly->moves[2] = 0;
	    return 1;
	  }
	  #if EXT_ENG
	    if (cb_2play) {
	      if (eng.param_ax_pass == schThinkComp) {
	        return dll_calcmove_start ();
	      }
	      return 0;   // Dont support other think modes for cb engine..
	    }
	  #endif
	  if (eng.param_ax_pass == schThinkComp) {
		// Select a book move?
	    if (schSelectBookMove ()) return (1);	// Found a book move
	  }
		// Otherwise bad/no book, drop thro to do normal search..
    	  cret = SearchSect (2048);
	  if (opPar && cret == 0) {	// Pick up think opp time move..
	    _fmemcpy (Manaly,&oldan,sizeof (ANALY));
	    schMode = 0;
	    oppExtractHint (Manaly,1);		// Get (schHint..) moves  
	    return 1;		// Move over!
	  }
    	  return cret;
	}
	return(0);
}

  // Tell checker engine to contine calculating for another fraction of a second
  // Return in ax 0,1,-1,-2 as in _srvc_calcmove_start
  // call with ax=0 normally.
  // Call with ax=1 and the checker engine will return sooner.
short ext_calcmove_continue (void)
{
	short cret;
	if (schMode == schThinkNone) return 0;
	#if EXT_ENG
	  if (cb_2play) {
	    return dll_calcmove_continue ();
	  }
	#endif
	if (schMode == ThinkComp) eng.clock_flag |= 0x80;
	protMode = eng.param_ax_pass;		// For possible crash..
	return (SearchSect (2048));
}

short ext_calcmove_stop (void)
{
	#if EXT_ENG
	  dll_calcmove_stop ();
	#endif
	schMode = 0;
	#if dbug_SPOOL		// Tree printing features.
	  dbugClose ();		// Close any debug-spool
	#endif
	return(0);
}

  // Execute Checkers move - Multi jump line..
  // Flag = set bit 0 to build-book move list
  // Set bit 1 for fast-do, dont build tables/add to real moves.
short ext_checker_move (GAMESTORE far *mvlist, short mflag, BYTE *pRoute)
{
	short cflag;
	BYTE msrc,mdest;
	#if dbug_SPOOL		// Tree printing features.
	  dbugClose ();		// Close any debug-spool
	#endif
	schNextBest = 0;	// Kill any next-best search move..
	do {			// Scan and exec moves in list..
	  msrc = mvlist->src;
	  mdest = mvlist->dest;
	  cflag = qDoMove (msrc,mdest);
	  if (cflag == 0) {		// Illegal move.. Try expanding a multijump path..
	    if ((mflag & 0x80) == 0) {	// Ensure cannot recurse >once..
	      cflag = schExpandMulti (msrc,mdest,pRoute);
	      if (cflag) {
	        return (ext_checker_move (&schMV [1], mflag | 0x80,NULL));
	      }
	    }
	    return -1;
	  }
	  if ((mflag & 2) == 0) GameAdd (msrc,mdest, (BYTE) (cflag & 0xff));
	  mvlist ++;
	  		// Reloop if multi-jump..
	} while ((cflag & 0x40) && mdest == mvlist->src && mvlist->src != mvlist->dest);
	if (mflag & 2) return 0;	// Fast move do..
	hashAddDraw ();		// Add current pos as possible draw..
	InitMoves (mflag | 2); // Generate legal move list, initialise misc vars
	return 0;
}

  // pass move in _move_test. See _srvc_is_move_legal for details
  // Only call if move is legal.  else will return with ax=-1
  // If move is legal checker engine will execute the move and return ax=0
  // flg=1 normally (build book move list) 2=fast do
  // pRoute - list of sqrs if
short ext_make_move (BYTE flg, BYTE *pRoute)
{
	GAMESTORE pmov [2];
	pmov [0].src = Pmove_test->from;
	pmov [0].dest = Pmove_test->to;
	pmov [0].flag = Pmove_test->flags;
	pmov [1].src = 0xff;
	return ext_checker_move (pmov, flg,pRoute);
}

short ext_second (void)
{
	if (eng.clock_flag & 0x80) {
	  if (eng.move_number & 1) {
	    eng.black_time ++;
	    eng.black_move_time ++;
	    if (eng.black_cdown_movs != 0xffff) {
	      eng.black_cdown_time --;
	    }
	  } else {
	    eng.white_time ++;
	    eng.white_move_time ++;
	    if (eng.white_cdown_movs != 0xffff) {
	      eng.white_cdown_time --;
	    }    
	  }
	}
	schCurTime ++;			// Search timer..
	#if (DiskProt || ProtectOn)	// Proetection fail countdown..
	  protSec ++;	
	#endif
	return(0);
}


short ext_set_level (void)
{
	short clev = eng.play_level & 0xff;
	short cval = (eng.play_level >> 8) & 0xff;
	if (clev != 7) {	// Not user adjustable levels..
	  if (clev != 6) {
	    return 0;
	  }
	  eng.levb1 = eng.levb2 = eng.levw1 = eng.levw2 = 60 + 0x400;	// 4 secs/move..
	  //SetSecsMove;		// Secs/move flag..
	}
	SetSecsMove;		// Secs/move flag..
		// Set up countdown clock variables..
	ResetLevel (&eng.levb1, &eng.black_time, eng.move_number >> 1);
	ResetLevel (&eng.levw1, &eng.white_time, (eng.move_number + 1) >> 1);
	SetUpLevel ();
	return(0);
}

  // ax=-2,-1,0,1,2 replay,take back, restore, step forward, step to end
  // no need to test for legal as already tested
  // if ax=0, then rebuild game-ptr index
  // new function ax=3 if fast step forward. Just mmov and return
  // new function ax= 8xxx if go directly to move xxx. bit 14=0 and 15=1
  // _eng.param_pass. If this is zero then all analysis is invalidated
  // 			   If non zero it is not.
short ext_step_move (void)
{
	short cstep = eng.param_ax_pass;
	short destmv = eng.move_number;
	short cpos;
	short msrc,mdest;
	schNextBest = 0;	// Kill any next-best search move..
	eng.game_status = 0;
	schHintFrom = -1;
	Phint_move->from = Phint_move->to = 0;	// Clr engine hint..
	if ((cstep & 0xc000) == 0x8000) {	// GOTO move # direct
	  destmv = cstep & 0x7fff;
	} else {				// Step -2..+2..
	  switch (cstep) {
	    case -1:
	    case 1:
	      destmv += cstep; break;
	    case -2:
	      destmv = 0; break;
	    case 2:
	      destmv = 9999; break;
	    case 0:		// Just initialise parameters..
	      schInitParams (); break;
	  }
	}
	if (destmv <= eng.move_number) {	// Backwards, spool from start
	  hashClrDraws ();		// Wipe out any hash draw-entries..
	  if (eng.init_moven & 0x8000) {	// Orig was set-up
	    short cpos;
	    for (cpos = 0; cpos < MAX_CHECKER_BOARD; cpos ++) {
	      eng.checker_board [cpos] = eng.init_board [cpos];
	    }
	  } else {
	    schNewBoard (schBoard,1);
	    sch2cgbrd (eng.checker_board,schBoard);	// Move search-engine brd to eng.checker_board..
	  }
	  eng.move_number = eng.init_moven & 0x7ff;	// set to Start move#
	} 
	destmv = min (destmv,MAX_GAME_STORE - 10);
	cpos = eng.move_number - (eng.init_moven & 0x07ff);
	cpos = cpos + schGameIndex [cpos] - 1;
		// Spool up moves...
	while (eng.move_number < destmv) {
	  do {		// Do multijump fragment..
	    cpos ++;
	    msrc = eng.game_store [cpos].src;
	    mdest = eng.game_store [cpos].dest;
	    if (qDoMove ((short) (0x8000 | msrc),mdest) == 0) {	// Premature end..
	      goto stepend;
	    }
	  } while (eng.game_store[cpos].flag & 1);	// Loop if multijump
	  eng.move_number ++;
	  hashAddDraw ();		// Add current pos as possible draw..
	}
stepend:
	ext_set_level ();	// Reset clocks..
	// schColor = GetColorForMove(eng.move_number);
	InitMoves (3);	// Generate legal move list, initialise misc vars
	#if dbug_SPOOL		// Tree printing features.
	  dbugClose ();	// Close any debug-spool
	#endif
	return(0);
}

  // See if move is legal. Move is passed in move_test which is a 3 btye buffer
  // first byte is from square. 0 to 3fh
  // second byte is to square.  0 to 3fh
  // This routine can return with the following values in AX
  // ax=0  Move is legal. If promotion it is specified correctly
  // ax=-1 The from square is legal. The to square is not.
  // ax=-2 The from and to squares are legal but the move is a promotion and
  // 	the promotion type is not specified.
  // ax=-3 The from square is illegal. square empty
  // ax=-4 The from square is illegal. contains opponents piece
  // ax=-5 The from square is illegal. (piece has no legal moves)
  // IF flags == 255, special test for unique move - ret 0 if not, else ret dest
short ext_is_move_legal (void)
{
	if (eng.checker_board [Pmove_test->from] == 0) return (-3);
	return (schIsLegal (cg2sch (Pmove_test->from),
		cg2sch (Pmove_test->to),Pmove_test->flags));
}

  // ax specifies the information to be provided. (_eng.param_pass)
  // return with ax=0 if success. return with ax=-1 if failed or ax >2

  // ax=0	provide full information about the move whose number is passed in
  // 	param pass.
  // 	Note that if a game has been loaded from chessbase the first move
  // 	may not be move 1. Obtain the initial move number by anding _eng.init_moven
  // 	with 07ffh.
  // 	Returns ax=-1 if error. eg. move number is higher than current move or
  // 	less than _eng.init_moven & 7ffh. In this case information is not valid.
  // 	else:
  // 	checker engine puts from square,too square, and flag information into
  // 	_move_info.
  // 	the type of piece that moved is put in _move_info+3 (1 to 6)
  // 	If move was a capture of piece that was captured is put in _move_info+4
  // 	_move_info+5 not used yet. Reserved to help with notation . eg Re4
  // 	bits will specify if from square rank/file need specifying
  // 
  // ax=1	Replace the contents of _checker_board with the initial position.
  // 	(usefull if a position has been set up and the game needs to be printed)
  // 	After calling this function the client should call next function to
  // 	restore _checker_board to the current position.
  // 
  // ax=2	Replace the contents of _checker_board with the current position.
  // 	(checker program always keeps _checker_board updated with the current
  // 	position so  this function only required after previous)
  // 
  // ax=3       Test legality of move in short notation.
  //	_leng.param_pass contains long pointer to buffer containing short notation
  //	if Legal the move is put in move_test. (ready for srvc_makemove)
  //	(No need to call is_move_legal) and returns Ax=0
  //	If illegal then ax=-1


short ext_misc_service (void)	// ax=0: move in (eng.param_pass)->move_info
{
    short cpos;
    char *cstr;
    BYTE msrc,mdest;
    switch (eng.param_ax_pass) {
      case 0:			// Get move-info struct on given move
        if (eng.param_pass > eng.move_number) return -1;
        cpos = eng.param_pass - (eng.init_moven & 0x07ff);
        cpos += schGameIndex [cpos];	// Calc index into game-store..
        CheckerMoveInfo = eng.game_store + cpos;		// Ptr to full info
        CheckerNParts = 1;		// # jumps/move in sequence
        Pmove_info->from = eng.game_store [cpos].src;	// From
        Pmove_info->flags = eng.game_store [cpos].flag & 0x40; // Capture
	//Pmove_info->type = 1;		// Type moved
	//Pmove_info->capture = 0;	// Type captured
		// Scan for multijump, find last dest..
	while (schGAMEWORD (cpos + 1) && (eng.game_store [cpos].flag & 1)) {
	  cpos ++;
	  CheckerNParts ++;
	}
	Pmove_info->to = eng.game_store [cpos].dest; // Save final destination
        return (0);
      case 2:
      case 3:			// Decode ASC move at _leng.param_pass, ret mvinfo
        cstr = (char *) eng.lparam_pass;
        if (isdigit (*cstr) == 0) return -1;
        cpos = (short) str2val (cstr, 10, 5);
        if (cpos < 100) {
          msrc = (BYTE) cpos;
          while (isdigit (*cstr)) cstr ++;
          if (*cstr != '-' && *cstr != 'x') return -1;
          cstr ++;
          mdest = (BYTE) str2val (cstr, 10, 2);
          if (mdest < 1) return -1;
        } else {
          msrc = (BYTE) ((short) cpos / 100);
          mdest = (BYTE) ((short) cpos % 100);
        }
        Pmove_test->from = (BYTE) ext_num2pos (msrc);
        Pmove_test->to = (BYTE) ext_num2pos (mdest);
        Pmove_test->flags = 254;	// Allow multi-jump..
        if (eng.param_ax_pass == 2) return 0;	// Fast conv, no legal check..
        return ext_is_move_legal ();
    }
    return (0);
}


  // call with ax=0 white to move ax=1 black to move. 
  // 
  // This routine tests if the position in _checker_board is legal
  // if legal it returns with ax=0. (_game_status may indicate checkmate etc)
  // and routines such as _srvc_calcmove_start etc can be called
  // If illegal it returns with non zero

short ext_set_board_pos (void)
{
	short cpos;
	for (cpos = 0; cpos < MAX_CHECKER_BOARD; cpos ++) {
	  eng.init_board [cpos] = eng.checker_board [cpos];
	}
	hashClrDraws ();		// Wipe out any hash draw-entries..
	GameClr ();		// Clr game array, eng.move_number, etc..
	  // Black side to move? if eng.param_ax_pass == 1..
	if (GetColorForMove (eng.param_ax_pass) == CBLACK) {
	  eng.move_number = 1;
	}
	eng.init_moven = eng.move_number | 0x8000;	// bit 15=setup pos..
	InitMoves (3);	// Generate legal move list, initialise misc vars
	return(0);
}

  //ax specifies the which routine is reqired (eng.param_ax_pass)

  //ax=0	Prepare to edit book or add line to book or display edit book dialog box
  //	This routine must be called before editing or adding a line to book.
  //	It returns with the number of moves in the user book in the long word
  //	_leng.param_pass
  //	This routine sets the list of moves at _book_moves so that only user
  //	book moves are in the list.
  //
  //ax=1	Find the size of a book subvariation
  //	Pass the move in _eng.param_pass. Size returned in long word _leng.param_pass
  //	(to find the size of the subtree of any move in the list of moves at
  //	_book_moves copy the word from the _book_move list to _eng.param_pass and
  //	call this routine). This is required for the edit book dialog box.
  //
  //ax=2	Add line to userbook.
  //	The moves played so far are added to the userbook.
  //	If an error occurs. eg a disk error or some internal error then
  //	_eng.param_pass is set to 0ffffh
  //
  //ax=3	Edit user book.
  //	The edit user book dialog box can manipulate the list of book moves at
  //	_book_moves. It can delete moves, change the order, and change the
  //	probability. When it has finished and the user selects 'ok' this routine
  //	must be called. This routine examines the list at _book_moves and
  //	changes the userbook accordingly.
  //	If an error occurs. eg a disk error or some internal error then
  //	_eng.param_pass is set to 0ffffh
  //
  //ax=4	Test to see if Edit userbook and Add line to Userbook are possible.
  //	Return with ax=0 if neither possible.
  //	Bit 0 set if Edit userbook is possible
  //	Bit 1 set if Add line is possible.
  //
  //ax=5	Print userbook.
  //	Print the userbook to a file. Pass the maximum characters per line in
  //	_eng.param_pass. A carriage return and line feed are added in addition to
  //	the maximum characters. (Some lines are shorter)
  //	Pass the file name in _leng.param_pass. This routine creates the file (or
  //	deletes it if already present and prints the userbook to the file.
  //
  //The following parameters must be passed to the routine.
  //_eng.param_pass.	Number of characters per line. min 20 max 160.
  //_eng.lparam1_pass. Pointer to zero terminated string of path of file to create.
  //		Segment and offset. (as in srvc_database)
  //		Offset in first word and segment in next word
  //returns ax=-1 if error. (disk full, disk error or corrupt userbook file)
  //
short ext_userbook (void)
{
    short cret;
    switch (eng.param_ax_pass) {
      case 0:		// Prepare book for edit - ret # moves in book
        eng.param_pass = (short) bokMoveSize;
        return 0;
      case 1:		// Find size of sub-variation
        eng.param_pass = 0;
        return 0;
      case 2:		// Add line to book..
        cret = bokAddLine (NULL,0);
	bokSave ();			// Save current book..
        return (cret);
      case 3:		// Edit user book
        return 0;
      case 4:		// Test to see if addbook/edit book are possible
        return 3;
      case 5:		// Print user book to file
        return (bokPrint ((char *) eng.lparam1_pass));
      case 17:
	if (bokLoad (eng.gamtype,1)) {	// Force reload + realloc mem..
	  return -1;	// Error
	}
	schInitParams ();
	return 0;
    }
    return(0);
}

short ext_database (void)
{
	return(0);
}

short ext_hash (void)
{
	return(0);
}

short ext_decode_header (void)
{
	return(0);
}

  // Convert (eng.checker_board) position to draughts numbering
  // Ret 0 if illegal pos..
short ext_pos2num (BYTE cpos)
{
	BYTE xp,yp;
	BYTE bx = (BYTE) ENG_BOARDX;
	xp = cpos % bx; yp = cpos / bx;
	if (((xp + yp) & 1) == (BYTE) (FlagCornMode != 0) 
		|| yp >= (BYTE) ENG_BOARDY) return 0;
	if (FlagInvNum == 0) {	// Dont Invert sqr numbering
	  return (short) (((BYTE) schNsqrs) - (cpos >> 1));
	}
	return (short) ((cpos >> 1) + 1);
}

	// Convert number to (eng.checker_board) pos..(0-63 for 8x8)
short ext_num2pos (BYTE cnum)
{
	if (FlagInvNum == 0) {	// Dont Invert sqr numbering
	  cnum = ((BYTE) schNsqrs) + 1 - cnum;
	}
	cnum = (cnum << 1) - 1;
	if ((ENG_BOARDX & 1) == 0) {
	  return (cnum - (((cnum / ENG_BOARDX) ^ (FlagCornMode != 0)) & 1));
	}
	return (cnum - (FlagCornMode != 0));
}

short ext_new_board (short far *ibrd, short mode)
{
	short xpos,ypos;
	short cpos;
	schNewBoard (ibrd, mode);
	cpos = 0;
	for (ypos = 1; ypos <= ENG_BOARDY; ypos ++) {
	  for (xpos = 1; xpos <= ENG_BOARDX; xpos ++) {
	    ibrd [cpos] = ibrd [schPosOf (xpos, ypos)];
	    cpos ++;
	  }
	}
	return (0);
}



#define Col2sch(X) ((9-(X)/10)*10 + ((X)%10))

  // Load an old-format BLITZ/DYNAMO/DAMA ITALIANA file into engine..
  // Ret nz if error..
short ext_load_old_format (char *ifile, short ngame)
{
	short cgame,cflag;
	short *pgame = (short *) szTemp;
	BYTE fmt = 0;	// 0=SAGE,1=COL..
	GAMESTORE pmov [2];
	short fullgame = 1;
	memset (szTemp,0,SIZEszTemp);	// Clear mem..
	cflag = LoadHugeFile (ifile, (void HUGE_ *) pgame, 0, SIZEszTemp - 5);
	if (cflag == HFILE_ERROR) return -1;
	ngame -= 7000;
		// Is it SAGE/BLITZ/DYNAMO format..
	if ((UINT) ngame > 700 || pgame [ngame + 1] != ENG_BOARDX 
		|| pgame [ngame + 2] != ENG_BOARDY) {  // No, try col..
	  if (GetFileLen (ifile) != 1698 || (BYTE) pgame [0] - 0x1f > 6) {
	    return 0;	// Not colossus format either..
	  }
	  fmt = 1;	// Colossus..(old fmt)
	} else {	// It is SAGE/BL/DY format (not col..)
	  fullgame = pgame [ngame + 4];		// Setup pos..
	}
	ext_init_game ();		// Start new game..
	if (fullgame == 0) {		// Get set-up position..
	  short cpos = ENG_BOARDX * ENG_BOARDY;
	  do {
	    cpos --;
	    eng.init_board [cpos] = (BYTE) pgame [ngame + 8 + cg2sch(cpos)];
	  } while (cpos > 0);
	  eng.init_moven = (short) (0x8000L);		// Flag=Set up pos..
	}
	for (cgame = 1; cgame <= ngame; cgame ++) {
	  BYTE msrc,mdest;
	  switch (fmt) {	// Extract src/dest from data
	    case 0:
	      msrc = HIBYTE (pgame [cgame]);
	      mdest = LOBYTE (pgame [cgame]);
	      break;
	    case 1:
	      msrc = ((BYTE *) pgame) [cgame - 1];
	      msrc = Col2sch (msrc);
	      mdest = Col2sch (((char *) pgame) [cgame + 510]);
	      break;
	  }
	  	// Ok, now make move on board..
	  Pmove_test->from = pmov[0].src = (BYTE) sch2cg (msrc);
	  Pmove_test->to = pmov [0].dest = (BYTE) sch2cg (mdest);
	  Pmove_test->flags = pmov[0].flag = 0;
	  pmov [1].src = pmov [1].dest = 0;
	  cflag = ext_is_move_legal ();		// nz=illegal mv..
	  if (cflag) {		//
	    if (fmt == 1) {	// Colossus..
	      if (cgame == 1) return -1;	// Only say bad if 1st mv..
	      return 0;
	    } else {
	      return (-1);		// ret if illegal move..
	    }
	  }
	  	// Temp Store move-flag..
	  ext_checker_move (pmov,0,NULL);	// Exec move..
	}
	if (fmt == 0) {	// Read comment from SAGE/BLITZ game..
	  char *cstr = ((char *) pgame) + ((ngame + 10) << 1);
	  if (fullgame == 0) cstr += (ENG_BOARDX + 2) * (ENG_BOARDY + 2) * 2;
	  comInitialise ();
	  if (*cstr > 31) {
	    comAddBlock (gamiVENUE,cstr,comAUTOLEN);
	  }
	}
	return 0;
}

//-------------------------------------------------------
// External DLL engines, calling/managing..
//-------------------------------------------------------


#if EXT_ENG

typedef int (WINAPI *ENGCMD_PROC) (char *,char *); 
typedef int (WINAPI *GETMOVE_PROC) (int **,int, double,char *,int *,int,int,void *); 



HINSTANCE dll_hInst1 = NULL;
HINSTANCE dll_hInst2 = NULL;

char dll_szEng1[256] = "";
char dll_szEng2[256] = ""; // "\\Program Files\\CheckerBoard\\cakess.dll";
char dll_szEngName1[256] = "";
char dll_szEngName2[256] = "";
int eng_touse = 1;   // Normally 1, set to 2 in autoplay..
int dll_usesagebook1 = FALSE;
int dll_usesagebook2 = FALSE;

GETMOVE_PROC pfnGetMove = NULL;
HANDLE dll_hThread = NULL;
DWORD dll_IDThread; 


  // Strip out file name, leave path only
void dll_ExtractPath (char *szPath) 
{
    char *pName;
    pName = szPath + strlen (szPath);
    while (pName >= szPath) {
      pName --;
      if (*pName == '\\') break;
    }
    pName [1] = 0;  // Strip name out..
}

char dll_origdir[600] = "";

void dll_SetEngPath (char *szEng) 
{
    char szPath [600];
    strcpy (szPath,szEng);
    dll_ExtractPath (szPath);
    GetCurrentDirectory (sizeof(dll_origdir),dll_origdir);
    SetCurrentDirectory (szPath);
}

void dll_SetOrigPath () 
{
    SetCurrentDirectory (dll_origdir);
}

void dll_finish ()
{
    if (dll_hInst1) {
      FreeLibrary (dll_hInst1);
      dll_hInst1 = NULL;
    }
    if (dll_hInst2) {
      FreeLibrary (dll_hInst2);
      dll_hInst2 = NULL;
    }
}

BOOL dll_initialize ()
{
    char *szReply;
    // dll_Cake ();
    dll_finish ();

    if (*dll_szEng1 == 0) {   // No ext engine, use internal SAGE engine..
    } else {
      dll_SetEngPath (dll_szEng1);
      dll_hInst1 = LoadLibrary (dll_szEng1);
      dll_SetOrigPath ();
      if (dll_hInst1 == NULL) {
        *dll_szEng1 = 0;   // Engine bad, reset..
      }
   }

   if (*dll_szEng2 == 0) {   // No 2nd engine, use internal SAGE engine..
   } else {
     dll_SetEngPath (dll_szEng2);
     dll_hInst2 = LoadLibrary (dll_szEng2);
     dll_SetOrigPath ();
     if (dll_hInst2 == NULL) {
       *dll_szEng2 = 0;   // Engine bad, reset..
     }
   }
   strcpy (dll_szEngName1,STprogramname2);
   strcpy (dll_szEngName2,STprogramname2);
   szReply = dll_engcmd ("name", 1);
   if (szReply) strcpy (dll_szEngName1,szReply);
   szReply = dll_engcmd ("name", 2);
   if (szReply) strcpy (dll_szEngName2,szReply);
   return TRUE;
}

char dll_szReply [256];

  // Send a cmd to primary/secondary engine, return reply string (NULL=none)
char *dll_engcmd (char *szCmd, int eng)
{
    int cret;
    ENGCMD_PROC pfnEngCmd;
    HINSTANCE dll_hInst = (eng == 1) ? dll_hInst1 : dll_hInst2;
    if (dll_hInst == NULL) return NULL;
    pfnEngCmd = (ENGCMD_PROC) GetProcAddress(dll_hInst, "enginecommand"); 
    if (pfnEngCmd == NULL) return NULL;
    dll_SetEngPath ((eng == 1) ? dll_szEng1 : dll_szEng2);
    cret = (pfnEngCmd) (szCmd, dll_szReply);
    dll_SetOrigPath ();
    if (cret == 0) return NULL;
    return dll_szReply;
}

#define CB_OCCUPIED 0
#define CB_WHITE 1
#define CB_BLACK 2
#define CB_MAN 4
#define CB_KING 8
#define CB_FREE 16
/* return values */
#define CB_DRAW 0
#define CB_WIN 1
#define CB_LOSS 2
#define CB_UNKNOWN 3


struct cb_move2 
{
   short n;
   int m[8];
};

struct cb_coor             /* coordinate structure for board coordinates */
{
	int x;
	int y;
};

struct cb_move            	/* all the information you need about a move */
{
   int ismove;          /* kind of superfluous: is 0 if the move is not a valid move */
   int newpiece;        /* what type of piece appears on to */
   int oldpiece;        /* what disappears on from */
   struct cb_coor from,to; /* coordinates of the piece - in 8x8 notation!*/
   struct cb_coor path[12]; /* intermediate path coordinates of the moving piece */
   struct cb_coor del[12]; /* squares whose pieces are deleted after the move */
   int delpiece[12];    /* what is on these squares */
};

char cb_str [255];
int cb_playnow;
int cb_brd [8][8];
int cb_color;
int cb_maxtime;
int cb_info = 1;
int cb_unused = 1;
char cb_mv[2000];
int cb_ret;
int cb_thinking = 0;

int cb_frombrd (int cpc)
{
    if (cpc == Bman)  return CB_BLACK | CB_MAN;
    if (cpc == Bking) return CB_BLACK | CB_KING;
    if (cpc == Wman)  return CB_WHITE | CB_MAN;
    if (cpc == Wking) return CB_WHITE | CB_KING;
    return CB_FREE;
}

// Extract move from str.. (see also pdnDecodeMove..)
char *cb_Asc2Move (char *pStr, BYTE *pFrom, BYTE *pTo)
{
	BYTE pRoute [100];
	short cpos;
	int nroute = 0;
	const int maxroute = 100;

        memset (pRoute,0,maxroute);
        if (isdigit (*pStr) == 0) return 0;
        cpos = (short) str2val (pStr, 10, 5);
        pRoute [0] = (BYTE) ext_num2pos ((BYTE) cpos);
	nroute ++;
	while (1) {
          while (isdigit (*pStr)) pStr ++;
          if (*pStr != '-' && *pStr != 'x') break;
          pStr ++;
	  if (*pStr == ' ') pStr ++;
	  pRoute [nroute] = (BYTE) ext_num2pos ((BYTE) str2val (pStr, 10, 2));
          if (pRoute [nroute] < 0) return 0;
	  nroute ++;
	  if (nroute > maxroute-5) return 0;   // Too long!
	}
	if (nroute < 2) return 0;
	pRoute [nroute] = 0;	// Terminator..
	*pFrom = pRoute[0];
	*pTo = pRoute[1];
	if (*pFrom == *pTo) return NULL;
	return  pStr;
}

char * cb_FindToken (char *pSrc, char *pToken)
{
    char *pStr;
    pStr = strstr (pSrc, pToken);
    if (pStr == NULL) return NULL;
    pStr += strlen (pToken);
    if (*pStr == ':') pStr ++;
    while (*pStr == ' ') pStr ++;
    return pStr;
}


  // Extract analy info from cb engine info string..
  // Str format:
  //  simplech: "best: 11-15 time 12.85, depth 7, value -1 nodes 24850, etc"
  //  cake:     "best: 22-18 depth 15/33/17.6 nodes 1062909 value 0 time 1.21s  878 kn/s  pv:22-18 15x22 25x18.."
  //  titan     "5(10) Value:   4 Time: 0.00 PV: 10-14 23-18 14x23 26x19 11-15 19x10 6x15"
  //  cakeLV    " 9-14 depth 15/33/16.9 nodes 2068397 value 2 time 3.48s  595kN/s db 0 (-1.$) pv:  9-14 22-18  5- 9 25-22 11-16 29-25  8-11 18-15 11x18 22x15 10x19 24x15  1- 5 23-18 14x23 27x18 16-19 "
  //  cakeSS    "depth 13/28/14.6  time 0.27s  value=-6  nodes 163873  606kN/s  db 50%  pv 22-18 16-19 24x15 10x19 23x16 12x19 31-27 14x23 "


void cb_GetAnaly (ANALY *pAnaly, char *pAsc, int cside)
{
    char *pStr;
    memset (pAnaly, 0,sizeof(ANALY));
    pStr = cb_FindToken (pAsc, "best");   // CakeLV
    if (pStr == NULL) pStr = cb_FindToken (pAsc, "pv");  // CakeSS
    if (pStr == NULL) {
      pStr = cb_FindToken (pAsc, "PV:");   // Titan?
      if (pStr == NULL) {  // CakeLV?
        pStr = cb_Asc2Move (pAsc, &pAnaly->mvfrom, &pAnaly->mvto);
        if (pStr == NULL) return;   // Failed!
	goto bestdone;
      }
    }
    pStr = cb_Asc2Move (pStr, &pAnaly->mvfrom, &pAnaly->mvto);
    if (pStr == NULL) return;
bestdone:
    pAnaly->moves[0] = pAnaly->mvfrom ;
    pAnaly->moves[1] = pAnaly->mvto ;

    pStr = cb_FindToken (pAsc, "nodes");
    if (pStr) {

      pAnaly->nodes = str_2val(pStr,10,10,NULL);
    }

    pStr = cb_FindToken (pAsc, "depth");
    if (pStr) {
      pAnaly->depthmin = pAnaly->depthmax = (BYTE) str_2val(pStr,10,3,NULL);
    }

    pStr = cb_FindToken (pAsc, "time");
    if (pStr) {
      pAnaly->time = str_2val(pStr,10,10,NULL);
    }

    pStr = cb_FindToken (pAsc, "value=");
    if (pStr == NULL) pStr = cb_FindToken (pAsc, "value");   
    if (pStr == NULL) pStr = cb_FindToken (pAsc, "Value:");   // Titan?
    if (pStr) {
      long val;
      while (*pStr == ' ') pStr ++;
      val = atoi(pStr);
      if (cside == CB_BLACK) val = -val;
      pAnaly->scorelo = abs (val) / 100;
      if (val < 0) pAnaly->scorelo |= 0x80;
    	// Get the hundreths..
      pAnaly->scorehi = (BYTE) ((int) abs (val) % 100);
    }

    pStr = cb_FindToken (pAsc, "pv");
    if (pStr == NULL) pStr = cb_FindToken (pAsc, "PV:");   // Titan?
    if (pStr) {
      int cmv = 0;
      while (1) {
        pStr = cb_Asc2Move (pStr,pAnaly->moves+cmv*3,pAnaly->moves+cmv*3+1);
	if (pStr == NULL) break;
	if (*pStr == 32) pStr ++;
	if (*pStr == 32) pStr ++;
	if (cmv > 11) break;
	cmv ++;
      }
    }
}

  // Call DLL engine start & run..
DWORD dll_RunThread (void *pParam)
{
    static short xpos,ypos,cpos;
    static int src,dest,ch1,ch2;
      // Convert SAGE board info to CheckerBoard format..
    memset (cb_brd,0,sizeof (cb_brd));
    memset (Manaly,0,sizeof (ANALY));
    eng.anal_flag |= 0xa0;	// Main anal line/root changed..
    cpos = 0;
    for (ypos = 0; ypos < 8; ypos ++) {
      for (xpos = 0; xpos < 8; xpos ++) {
        int k = xpos;
	if (schType8x8inv) k = 7-xpos;
	cb_brd[k][7-ypos] = cb_frombrd (eng.checker_board [cpos]);
        cpos ++;
      }
    }
    //cb_color = (eng.move_number & 1) ? CB_WHITE : CB_BLACK;
    cb_color = CurColor ? CB_WHITE : CB_BLACK;
    cb_maxtime = schTargetTime ;
    cb_playnow = 0;
    cb_thinking = 2;
    dll_SetEngPath ((eng_touse == 1) ? dll_szEng1 : dll_szEng2);
    cb_ret = (pfnGetMove) (cb_brd, cb_color, cb_maxtime, cb_str, &cb_playnow, 
	cb_info, cb_unused, cb_mv);
    dll_SetOrigPath ();

    #if _DEBUG
      if (cb_playnow == 0) {
        con_printf ("**%s**\x0d\x0a",cb_str);
        con_printf ("**col=%d tim=%d \x0d\x0a",cb_color,cb_maxtime);
      }
    #endif
    cb_GetAnaly (Manaly, cb_str, cb_color);
    Manaly->type = AN_EXEC;
    
	// Ok, new position is in (cb_brd), deduce move by comparing with orig..
    src = dest = 0;
    cpos = 0;
    for (ypos = 0; ypos < 8; ypos ++) {
      for (xpos = 0; xpos < 8; xpos ++) {
    	ch2 = cb_brd[xpos][7-ypos];
	if (schItalFlag) ch2 = cb_brd[7-xpos][7-ypos];
	ch1 = cb_frombrd (eng.checker_board [cpos]);
	if (ch1 != ch2) {
	  if (cb_color & ch1) {		// From sq..
	    src = cpos;
	  }
	  if (cb_color & ch2) {		// dest sq..
	    dest = cpos;
	  }
	}
        cpos ++;
      }
    }
    Manaly->mvfrom = Manaly->moves[0] = (BYTE) src;
    Manaly->mvto = Manaly->moves[1] = (BYTE) dest;
    //Manaly->moves[2] = 0;   Manaly->moves[3] = 0;   Manaly->moves[4] = 0;
    

    eng.anal_flag = 0x80;
    cb_thinking = 1;    // New mv found, but not yet picked up by front end thread..
    return 0;	// Thread will terminate..
   //     Pmove_test->from = (BYTE) pRoute [0];
   //     Pmove_test->to = (BYTE) pRoute [nroute - 1];
   //     Pmove_test->flags = 254;	// Allow multi-jump..
   //     return ext_is_move_legal ();
}

clock_t cb_last;


short dll_calcmove_start ()
{
    HINSTANCE dll_hInst;
    char *szReply;
    dll_calcmove_stop ();
    dll_hInst = (eng_touse == 1) ? dll_hInst1 : dll_hInst2;
    if (dll_hInst == NULL) return 1;
    szReply = dll_engcmd ("get gametype", eng_touse);
    if (szReply == NULL) return 1;
    if (schItalFlag) { 
      if (atoi (szReply) != 22) return 1;  // Italian game?
    } else {
      if (atoi (szReply) != 21) return 1;   // English game?
    }
    pfnGetMove = (GETMOVE_PROC) GetProcAddress(dll_hInst, "getmove"); 
    if (pfnGetMove == NULL) return 1;
    
      //if (pfnEngCmd1 == NULL) goto dll_Error;
    cb_last = schBegTime = clock ();
    eng.anal_flag = 0;	// nz when new best line..
    memset (Manaly,0,sizeof(ANALY));
    if (eng.game_status) {		// Game over
      schMode = 0;		// Kill search
      //Manaly->moves[0] = Manaly->moves[1] = Manaly->moves[2] = 0;
      return 1;
    }
    //if (eng.disp_nmoves == 1) {
    //  int a,b;
    //  a = Manaly->moves[0] = eng.disp_mvlist[1].src;
    //  b = Manaly->moves[1] = eng.disp_mvlist[1].dest;
    //  return 1;
    //}

    if (eng.param_ax_pass == schThinkComp) {
 	// Select a sage book move?
      if ((eng_touse == 1) ? dll_usesagebook1 : dll_usesagebook2) {
        if (schSelectBookMove ()) return (1);	// Found a book move
      }
    }
    dll_hThread = CreateThread(NULL,  // no security attributes
	0,			// use default stack size 
	(LPTHREAD_START_ROUTINE) dll_RunThread,	// MAIN eng thread func..
	NULL,		// param to thread func 
	NULL,			// creation flag         
	&dll_IDThread);		// returns thread id   
    if (dll_hThread == NULL) return 1;
    SetThreadPriority (dll_hThread,THREAD_PRIORITY_NORMAL);
    return 0;
}


short dll_calcmove_continue ()
{
    clock_t cb_now = clock ();
    if (cb_thinking == 0) return 0;	// Not a cb move..
    if (cb_now - cb_last > CLOCKS_PER_SEC) {
      cb_GetAnaly (Manaly, cb_str, cb_color);
      Manaly->type = AN_MAIN;
      eng.anal_flag |= 0xa0;	// Main anal line/root changed..
      cb_last = cb_now;
    }
    if (cb_thinking == 2) return 0;	// Still computing..
    cb_thinking = 0;
    return 1;
}

short dll_calcmove_stop ()
{
    if (cb_thinking == 0) return 1;	// Not a cb move..
    cb_playnow = 1;
    while (cb_thinking == 2) {
      Sleep (100);
    }
    cb_thinking = 0;
    return 1;
}

#endif	// EXT_ENG


